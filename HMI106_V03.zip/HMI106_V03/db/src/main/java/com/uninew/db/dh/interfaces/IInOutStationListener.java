package com.uninew.db.dh.interfaces;

import java.util.List;

import com.uninew.db.dh.dao.InOutStation;
/**
 * 进出站信息的监听和回调接口
 * @author rong
 *
 */
public interface IInOutStationListener {
	/**
	 * 进出站信息查询回调接口
	 */
	public interface IQueryStationCallBack{
		/**
		 * 查询进出站的回调方法
		 * @param stations
		 */
		void queryStation(List<InOutStation> stations);
	}
	/**
	 * 进出站更新监听接口
	 */
	public interface IStationNotifyListener{
		/**
		 * 更新进出站的监听方法
		 * @param stations
		 */
		void stationNotify(List<InOutStation> stations);
	}
}
