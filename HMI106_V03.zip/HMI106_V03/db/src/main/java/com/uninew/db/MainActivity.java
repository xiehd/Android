package com.uninew.db;

import com.uninew.db.dh.Managers.DbSettingsManager;
import com.uninew.db.dh.interfaces.ISettingsListener.IUdpIpAndPortListener;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

public class MainActivity extends Activity {

	private DbSettingsManager mSettings;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		mSettings = new DbSettingsManager(getApplicationContext());
	}

	public void onViewClick(View v) {
		int id = v.getId();
		switch (id) {
		case R.id.button1:
			mSettings.queryUdpIpAndPort(new IUdpIpAndPortListener() {
				
				@Override
				public void UdpIpAndPort(String ip, int port) {
					Log.d("ss", "ip:"+ip+",port:"+port);
				}
			});
			break;
		case R.id.button2:
			mSettings.setUdpIpAndPort("192.168.1.1", 8080);
			break;
		default:
			break;
		}
	}
}
