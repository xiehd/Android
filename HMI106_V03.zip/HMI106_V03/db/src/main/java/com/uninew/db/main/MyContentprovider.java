package com.uninew.db.main;

import android.content.ContentProvider;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.UriMatcher;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.text.TextUtils;
import android.util.Log;

public class MyContentprovider extends ContentProvider {

	private static final String TAG = "MyContentprovider";

	private DBOpenHelper dbHelper;

	// 访问表的所有列
	public static final int INCOMING_USER_COLLECTION = 1;
	// 访问单独的列
	public static final int INCOMING_USER_SINGLE = 2;
	// 操作URI的类
	public static final UriMatcher uriMatcher;

	// 为UriMatcher添加自定义的URI
	static {
		uriMatcher = new UriMatcher(UriMatcher.NO_MATCH);
		uriMatcher.addURI(DbMetaData.AUTHORITIES, "/guideboard", INCOMING_USER_COLLECTION);
		uriMatcher.addURI(DbMetaData.AUTHORITIES, "/guideboard/#", INCOMING_USER_SINGLE);
	}

	@Override
	public boolean onCreate() {
		dbHelper = DBOpenHelper.getInstance(getContext());
		Log.d(TAG, "onCreate");
		return true;
	}

	@Override
	public Cursor query(Uri uri, String[] projection, String selection, String[] selectionArgs, String sortOrder) {
		Cursor c = null;
		SQLiteDatabase db = dbHelper.getWritableDatabase();
		String orderBy;
		if (TextUtils.isEmpty(sortOrder)) {
			orderBy = DbMetaData.GuideboardTable.DEFAULT_SORT_ORDER;
		} else {
			orderBy = sortOrder;
		}
		try {
			c = db.query(uri.getLastPathSegment(), projection, selection, selectionArgs, null, null, orderBy);
		} catch (Exception e) {
			c = null;
		}
		return c;
	}

	@Override
	public String getType(Uri uri) {
		// 根据用户请求，得到数据类型
		switch (uriMatcher.match(uri)) {
		case INCOMING_USER_COLLECTION:
			return DbMetaData.GuideboardTable.CONTENT_TYPE;
		case INCOMING_USER_SINGLE:
			return DbMetaData.GuideboardTable.CONTENT_TYPE_ITEM;
		default:
			throw new IllegalArgumentException("UnKnown URI" + uri);
		}
	}

	@Override
	public Uri insert(Uri uri, ContentValues values) {

//		Log.d(TAG, "insert");
		SQLiteDatabase db = dbHelper.getWritableDatabase();
		long rowId = db.insert(uri.getLastPathSegment(), null, values);
		if (rowId > 0) {
			Uri insertedUserUri = ContentUris.withAppendedId(uri, rowId);
			// 通知监听器，数据已经改变
			getContext().getContentResolver().notifyChange(insertedUserUri, null);			 
//			Log.d(TAG, insertedUserUri.toString());
			return insertedUserUri;
		}
		return uri;
	}

	@Override
	public int delete(Uri uri, String selection, String[] selectionArgs) {
		int count = 0;
		SQLiteDatabase db = dbHelper.getWritableDatabase();
		count = db.delete(uri.getLastPathSegment(), selection, selectionArgs);
		return count;
	}

	@Override
	public int update(Uri uri, ContentValues values, String selection, String[] selectionArgs) {
		int count = 0;
		SQLiteDatabase db = dbHelper.getWritableDatabase();
		count = db.update(uri.getLastPathSegment(), values, selection, selectionArgs);
		if (count > 0) {
			if(selectionArgs != null && selectionArgs.length > 0){
				StringBuffer buffer = new StringBuffer();
				for(String s : selectionArgs){
					buffer.append("/"+ s);
				}
				Uri insertedUserUri = Uri.parse(uri.toString() + buffer.toString());
				this.getContext().getContentResolver().notifyChange(insertedUserUri, null);
			}else{
				this.getContext().getContentResolver().notifyChange(uri, null);//如果改变数据，则通知所有人  
			}
		}
		return count;
	}

}
