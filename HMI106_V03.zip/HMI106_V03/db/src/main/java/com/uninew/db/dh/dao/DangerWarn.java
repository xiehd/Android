package com.uninew.db.dh.dao;

/**
 * 危险报警日志
 * 
 * @author rong
 *
 */
public class DangerWarn {

	/** ID **/
	private int id = -1;
	/** 报警类型 **/
	private int type = -1;
	/** 报警时间 **/
	private String time = null;
	/** 报警经度 **/
	private double longitude = -1;
	/** 报警纬度 **/
	private double latitude = -1;
	/** 报警内容 **/
	private String content = null;

	public DangerWarn() {
	}

	public DangerWarn(int type, String time, double longitude, double latitude, String content) {
		super();
		this.type = type;
		this.time = time;
		this.longitude = longitude;
		this.latitude = latitude;
		this.content = content;
	}

	public int getType() {
		return type;
	}

	public void setType(int type) {
		this.type = type;
	}

	public String getTime() {
		return time;
	}

	public void setTime(String time) {
		this.time = time;
	}

	public double getLongitude() {
		return longitude;
	}

	public void setLongitude(double longitude) {
		this.longitude = longitude;
	}

	public double getLatitude() {
		return latitude;
	}

	public void setLatitude(double latitude) {
		this.latitude = latitude;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "DangerWarin [id=" + id + ", type=" + type + ", " + (time != null ? "time=" + time + ", " : "")
				+ "longitude=" + longitude + ", latitude=" + latitude + ", "
				+ (content != null ? "content=" + content : "") + "]";
	}
	
}
