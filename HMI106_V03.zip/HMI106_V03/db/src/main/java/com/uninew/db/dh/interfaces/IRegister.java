package com.uninew.db.dh.interfaces;

import com.uninew.db.dh.dao.TerminalCertified;
import com.uninew.db.dh.interfaces.IRegisterListener.IQueryAuthCallBack;
import com.uninew.db.dh.interfaces.IRegisterListener.IQueryIpCallBack;
import com.uninew.db.dh.interfaces.IRegisterListener.IQueryRegisterMsgCallBack;
/***
 * 注册信息的操作接口
 * @author rong
 *
 */
public interface IRegister {
	/**
	 * 更新注册信息
	 * 
	 * @param serverId
	 *            服务器ID
	 * @param mTerminalCertified
	 */
	void updateRegisterMsg(int serverId, TerminalCertified mTerminalCertified);

	/**
	 * 查询注册信息
	 * 
	 * @param serverId
	 *            服务器ID
	 * @param resultCallBack
	 *            通用回调
	 */
	void queryRegisterMsg(int serverId,IQueryRegisterMsgCallBack queryRegisterMsgCallBack);

	/**
	 * 设置平台信息
	 * 
	 * @param serverId
	 *            服务器ID
	 * @param domainName
	 *            域名
	 * @param ip
	 *            IP地址
	 * @param prot
	 *            端口号
	 * @param commonCallBack
	 *            结果回调
	 */
	void setPlatformMsg(int serverId, String domainName, String ip, int port, IResultCallBack resultCallBack);

	/**
	 *  查询IP信息（包括域名、IP、端口号）
	 * @param serverId 服务器ID
	 * @param queryIpCallBack 结果回调
	 */
	void queryIP(int serverId, IQueryIpCallBack queryIpCallBack);

	/**
	 * 查询鉴权码
	 * 
	 * @param serverId 服务器ID
	 * @param queryAuthCallBack 结果回调
	 */
	void queryAuth(int serverId, IQueryAuthCallBack queryAuthCallBack);

	/**
	 * 删除鉴权码
	 * 
	 * @param serverId 服务器ID
	 * @param resultCallBack 通用回调
	 */
	void delAuth(int serverId, IResultCallBack resultCallBack);
}
