package com.uninew.db.dh.dao;

public class DefineNet {
	/**默认平台IP*/
	public static final String DEFAULT_IP = "120.77.169.159"; //大华
//	public static final String DEFAULT_IP = "172.5.2.2"; //大华
//	public static final String DEFAULT_IP = "114.215.206.70"; //一智
	/** 默认端口 */
	public static int DEFAULT_PORT = 9000; //大华
//	public static int DEFAULT_PORT = 2332; //一智
	/** 默认通讯模式0-串口 1-网络 */
	public static int DEFAULT_MODEL = 1; 
	/**默认电话*/
	public static final String PLAT_PHONE = "15353545452";//深圳	704
	
//	public static final String PLAT_PHONE = "018969029376";//大华	
//	public static final String PLAT_PHONE = "018503056153";//一智015120002480  018503056153
	public static String plat_phone=PLAT_PHONE;
	
	/** 省域ID */
	public static final int DEVICE_PROVINCE = 11;
	/** 市县域ID */
	public static final int DEVICE_CITY = 108;
	/** 厂商ID */
	public static final String DEVICE_MANUFACTURER = "00000";
	/** 终端型号 */
	public static final String DEVICE_MODEL = "HMI106";
	/** 终端id */
	public static final String DEVICE_ID = "15353545454";
	/** 车牌颜色 蓝色 */
	public static final int CAR_COLOR = 4;
	/** 车牌标示 */
//	public static final String CAR_FLAG = "浙A66937";
	public static final String CAR_FLAG = "粤B55666";
//	public static final String CAR_FLAG = "浙A29376";
}
