package com.uninew.db.dh.interfaces;
/**
 * 通用回调接口
 * @author Administrator
 *
 */
public interface IResultCallBack {
	/**
	 * 通用回调
	 * @param result
	 */
	void resultCallBack(boolean result);
}
