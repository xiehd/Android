package com.uninew.db.dh.Managers;

import java.util.ArrayList;
import java.util.List;

import com.uninew.db.dh.dao.InOutStation;
import com.uninew.db.dh.dao.InOutStationMsg;

import com.uninew.db.dh.interfaces.IReSendStation;
import com.uninew.db.dh.interfaces.IReSendStationListener;
import com.uninew.db.dh.interfaces.IReSendStationListener.IQueryStationCallBack;
import com.uninew.db.dh.interfaces.IReSendStationListener.IStationNotifyListener;
import com.uninew.db.dh.interfaces.IRegisterListener.IRegisterMsgListener;
import com.uninew.db.dh.interfaces.IResultCallBack;
import com.uninew.db.main.BaseContentResolver;
import com.uninew.db.main.DbMetaData.InOutStationMessage;
import com.uninew.db.main.DbMetaData.ReSendStationTable;
import com.uninew.db.main.IDBOpertionCallBack.IDeleteCallBack;
import com.uninew.db.main.IDBOpertionCallBack.IInsertCallBack;
import com.uninew.db.main.IDBOpertionCallBack.IQueryCallBack;
import com.uninew.db.main.IDBOpertionCallBack.IUpdateCallBack;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.ContentObserver;
import android.database.Cursor;
import android.net.Uri;
import android.os.Handler;
/**
 * 进出站数据库的操作管理器
 * @author rong
 * 
 * 添加进出站信息的更新监听器时，要先注册数据库变化监听器 （registerNotify() ）的方法，
 * 最好在生命周期开始时进行注册，
 * 而在生命周期结束时进行注销（unregisterNotify()）的方法，避免内存过量使用，
 * 然后添加监听器（addStationNotifyListener）；
 */
public class DbReSendStationManager implements IReSendStation {

	private static final String TAG = "GPSDataManager";
	private Context mContext;
	/** 进出站信息更新监听器*/
	private IStationNotifyListener stationNotifyListener;
	/** 数据库操作类 */
	private BaseContentResolver mResolver;
	
	/**
	 * 类的初始化
	 * @param mContext
	 */
	public DbReSendStationManager(Context mContext){
		this.mContext = mContext;
		mResolver = BaseContentResolver.getInstance(mContext);
	}
	
	/**
	 * 添加监听器
	 * @param stationNotifyListener
	 */
	public void addStationNotifyListener(IStationNotifyListener stationNotifyListener) {
		this.stationNotifyListener = stationNotifyListener;
	}
	
	/**
	 * 移除监听器
	 */
	public void removeStationNotifyListener(){
		if(stationNotifyListener != null){
			stationNotifyListener = null;
		}
	}
	
	/**
	 * 创建一个contentprovider的监听类
	 */
	private ContentObserver observer = new ContentObserver(new Handler()) {

		@SuppressLint("NewApi")
		@Override
		public void onChange(boolean selfChange, Uri uri) {
			// TODO Auto-generated method stubinter
			super.onChange(selfChange, uri);
		}

		@Override
		public void onChange(boolean selfChange) {
			// TODO Auto-generated method stub
			super.onChange(selfChange);
			queryInOutStation(null, new IQueryStationCallBack() {
				
				@Override
				public void queryStation(List<InOutStationMsg> stations) {
					if (stations != null && !stations.isEmpty()) {
						if(stationNotifyListener != null){
							stationNotifyListener.stationNotify(stations);
						}
					}
				}
			});
		}
	};

	@Override
	public void updateInOutStation(List<InOutStationMsg> stations) {
		if (stations != null && !stations.isEmpty()) {
			for (final InOutStationMsg station : stations) {
				queryInOutStation(null, new IQueryStationCallBack() {

					@Override
					public void queryStation(List<InOutStationMsg> stations) {
						if (stations != null && stations.size() > 20000) {
							delInOutStation(new int[] { stations.get(0).getId() }, new IResultCallBack() {

								@Override
								public void resultCallBack(boolean result) {
									final ContentValues values = new ContentValues();
									getValues(station, values);
									mResolver.insert(ReSendStationTable.CONTENT_URI, values, new IInsertCallBack() {

										@Override
										public void insertCallBack(Uri uri) {
											values.clear();
										}
									});
								}
							});
						} else {
							queryInOutStation(new long[] { station.getTime() }, new IQueryStationCallBack() {

								@Override
								public void queryStation(List<InOutStationMsg> stations) {
									if (stations != null && !stations.isEmpty()) {
										final ContentValues values = new ContentValues();
										getValues(station, values);
										mResolver.update(ReSendStationTable.CONTENT_URI, values,
												ReSendStationTable.TIME+ "=?", new String[] { station.getTime() + "" },
												new IUpdateCallBack() {

													@Override
													public void updateCallBack(int count) {
														values.clear();
													}
												});
									}else{
										final ContentValues values = new ContentValues();
										getValues(station, values);
										mResolver.insert(ReSendStationTable.CONTENT_URI, values, new IInsertCallBack() {
											
											@Override
											public void insertCallBack(Uri uri) {
												values.clear();
											}
										});
									}
								}
							});
						}
					}
				});
			}
		}
	}

	private void getValues(final InOutStationMsg station, final ContentValues values) {
		if(station.getMark() != -1 ){
			values.put(ReSendStationTable.MARK, station.getMark());
		}
		if(station.getMsgId() != -1 ){
			values.put(ReSendStationTable.MSG_ID, station.getMsgId());
		}
		if(station.getStationNum() != -1 ){
			values.put(ReSendStationTable.STATION_NUM, station.getStationNum());
		}
		if(station.getTime() != -1 ){
			values.put(ReSendStationTable.TIME, station.getTime());
		}
		if(station.getRouteId() != null ){
			values.put(ReSendStationTable.ROUTE_ID, station.getRouteId());
		}
		
		if(station.getMsgBody() != null ){
			values.put(ReSendStationTable.MSG_BODY, station.getMsgBody());
		}
		
	}

	@Override
	public void queryInOutStation(long[] times, final IQueryStationCallBack stationCallBack) {
		String selection = null;
		String[] selectionArgs = null;
		if (times != null && times.length > 0) {
			selection = ReSendStationTable.TIME+ "=?";
			int length = times.length;
			selectionArgs = new String[length];
			for (int i = 0; i < length; i++) {
				selectionArgs[i] = String.valueOf(times[i]);
			}
		}
		mResolver.query(ReSendStationTable.CONTENT_URI, null, selection, selectionArgs, "time asc",
				new IQueryCallBack() {

					@Override
					public void queryCallBack(Cursor c) {
						if (c != null && c.getCount() > 0) {
							List<InOutStationMsg> staions = new ArrayList<>();
							while (c.moveToNext()) {
								InOutStationMsg stationMsg = new InOutStationMsg();
								stationMsg.setId(c.getInt(c.getColumnIndex(ReSendStationTable._ID)));
								stationMsg.setMark(c.getInt(c.getColumnIndex(ReSendStationTable.STATION_NUM)));
								stationMsg.setMsgId(c.getInt(c.getColumnIndex(ReSendStationTable.MSG_ID)));
								stationMsg.setTime(c.getInt(c.getColumnIndex(ReSendStationTable.TIME)));
								stationMsg.setRouteId(c.getString(c.getColumnIndex(ReSendStationTable.ROUTE_ID)));
								stationMsg.setMsgBody(c.getBlob(c.getColumnIndex(ReSendStationTable.MSG_BODY)));
								staions.add(stationMsg);
							}
							c.close();
							if (stationCallBack != null) {
								stationCallBack.queryStation(staions);
							}
						} else {
							if(c != null){
								c.close();
							}
							if (stationCallBack != null) {
								stationCallBack.queryStation(null);
							}
						}
					}
				});
	}

	@Override
	public void delInOutStation(int[] ids, final IResultCallBack resultCallBack) {
		String selection = null;
		String[] selectionArgs = null;
		if (ids != null && ids.length > 0) {
			selection = ReSendStationTable._ID+ "=?";
			int length = ids.length;
			selectionArgs = new String[length];
			for (int i = 0; i < length; i++) {
				selectionArgs[i] = String.valueOf(ids[i]);
			}
		}
		mResolver.delete(ReSendStationTable.CONTENT_URI, selection, selectionArgs, new IDeleteCallBack() {

			@Override
			public void deleteCallBack(int count) {
				if (count > 0) {
					if (resultCallBack != null) {
						resultCallBack.resultCallBack(true);
					}
				} else {
					if (resultCallBack != null) {
						resultCallBack.resultCallBack(false);
					}
				}
			}
		});
	}

	/**
	 * 注册数据库表变化监听器
	 */
	public void registerNotify() {
		mResolver.registerContentObserver(ReSendStationTable.CONTENT_URI, true, observer);

	}

	/**
	 * 注销数据库表变化监听器
	 */
	public void unregisterNotify() {
		mResolver.unregisterContentObserver(observer);
		removeStationNotifyListener();
	}


}
