package com.uninew.db.dh.dao;

import java.util.Arrays;

public class TerminalCertified {
	private int _id;
	/** 设备电话号码 **/
	private String terninal_number = null;
	/** 省域ID **/
	private int provincial_id = -1;
	/** 市县ID **/
	private int county_id = -1;
	/** 制造商ID **/
	private String manufacturer_id = null;
	/** 终端型号 **/
	private String terminal_type = null;
	/** 终端ID **/
	private String terminal_id = null;
	/** 车牌颜色 **/
	private int terminal_color = -1;
	/** 车牌号 **/
	private String terminal_flag = null;
	/** 应答流水号 **/
	private int stream_num = -1;
	/** 应答时间 **/
	private String receive_time = null;
	/** 服务器IP **/
	private String service_ip = null;
	/** 服务器IP **/
	private int service_port = -1;
	/** 域名 */
	private String domainName;

	/** 结果 **/
	private int result = -1;
	/** 鉴权码 **/
	private byte[] authentication = null;

	public TerminalCertified() {
	}

	public TerminalCertified(int _id, String terninal_number, int provincial_id, int county_id, String manufacturer_id,
			String terminal_type, String terminal_id, int terminal_color, String terminal_flag, int stream_num,
			String receive_time, String service_ip, int service_port,String domainName, int result, byte[] authentication) {
		this._id = _id;
		this.terninal_number = terninal_number;
		this.provincial_id = provincial_id;
		this.county_id = county_id;
		this.manufacturer_id = manufacturer_id;
		this.terminal_type = terminal_type;
		this.terminal_id = terminal_id;
		this.terminal_color = terminal_color;
		this.terminal_flag = terminal_flag;
		this.stream_num = stream_num;
		this.receive_time = receive_time;
		this.service_ip = service_ip;
		this.service_port = service_port;
		this.result = result;
		this.authentication = authentication;
		this.domainName=domainName;
	}

	public int get_id() {
		return _id;
	}

	public void set_id(int _id) {
		this._id = _id;
	}

	/** 设备电话号码 **/
	public String getTerninal_number() {
		return terninal_number;
	}

	/** 设备电话号码 **/
	public void setTerninal_number(String terninal_number) {
		this.terninal_number = terninal_number;
	}

	/** 省域ID **/
	public int getProvincial_id() {
		return provincial_id;
	}

	/** 省域ID **/
	public void setProvincial_id(int provincial_id) {
		this.provincial_id = provincial_id;
	}

	/** 市县ID **/
	public int getCounty_id() {
		return county_id;
	}

	/** 市县ID **/
	public void setCounty_id(int county_id) {
		this.county_id = county_id;
	}

	/** 制造商ID **/
	public String getManufacturer_id() {
		return manufacturer_id;
	}

	/** 制造商ID **/
	public void setManufacturer_id(String manufacturer_id) {
		this.manufacturer_id = manufacturer_id;
	}

	/** 终端型号 **/
	public String getTerminal_type() {
		return terminal_type;
	}

	/** 终端型号 **/
	public void setTerminal_type(String terminal_type) {
		this.terminal_type = terminal_type;
	}

	/** 终端ID **/
	public String getTerminal_id() {
		return terminal_id;
	}

	/** 终端ID **/
	public void setTerminal_id(String terminal_id) {
		this.terminal_id = terminal_id;
	}

	/** 车牌颜色 **/
	public int getTerminal_color() {
		return terminal_color;
	}

	/** 车牌颜色 **/
	public void setTerminal_color(int terminal_color) {
		this.terminal_color = terminal_color;
	}

	/** 车牌号 **/
	public String getTerminal_flag() {
		return terminal_flag;
	}

	/** 车牌号 **/
	public void setTerminal_flag(String terminal_flag) {
		this.terminal_flag = terminal_flag;
	}

	/** 应答流水号 **/
	public int getStream_num() {
		return stream_num;
	}

	/** 应答流水号 **/
	public void setStream_num(int stream_num) {
		this.stream_num = stream_num;
	}

	/** 应答时间 **/
	public String getReceive_time() {
		return receive_time;
	}

	/** 应答时间 **/
	public void setReceive_time(String receive_time) {
		this.receive_time = receive_time;
	}

	/** 服务器IP **/
	public String getService_ip() {
		return service_ip;
	}

	/** 服务器IP **/
	public void setService_ip(String service_ip) {
		this.service_ip = service_ip;
	}

	/** 结果 **/
	public int getResult() {
		return result;
	}

	/** 结果 **/
	public void setResult(int result) {
		this.result = result;
	}

	/** 鉴权码 **/
	public byte[] getAuthentication() {
		return authentication;
	}

	/** 鉴权码 **/
	public void setAuthentication(byte[] authentication) {
		this.authentication = authentication;
	}

	public String getDomainName() {
		return domainName;
	}

	public void setDomainName(String domainName) {
		this.domainName = domainName;
	}

	public int getService_port() {
		return service_port;
	}

	public void setService_port(int service_port) {
		this.service_port = service_port;
	}

	@Override
	public String toString() {
		return "TerminalCertified [_id=" + _id + ", terninal_number=" + terninal_number + ", provincial_id="
				+ provincial_id + ", county_id=" + county_id + ", manufacturer_id=" + manufacturer_id
				+ ", terminal_type=" + terminal_type + ", terminal_id=" + terminal_id + ", terminal_color="
				+ terminal_color + ", terminal_flag=" + terminal_flag + ", stream_num=" + stream_num + ", receive_time="
				+ receive_time + ", service_ip=" + service_ip + ", service_port=" + service_port + ", domainName="
				+ domainName + ", result=" + result + ", authentication=" + Arrays.toString(authentication) + "]";
	}
}
