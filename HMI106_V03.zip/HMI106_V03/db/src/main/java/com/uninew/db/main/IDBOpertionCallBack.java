package com.uninew.db.main;

import android.database.Cursor;
import android.net.Uri;
/**
 * 数据库操作监听和回调接口
 * @author rong
 *
 */
public interface IDBOpertionCallBack {

	
	/**
	 * 数据库操作的插入返回结果
	 */
	public interface IInsertCallBack {
		/**
		 * 插入返回结果
		 * @param uri
		 */
		void insertCallBack(Uri uri);
	}

	/**
	 * 数据库操作的更新返回结果
	 */
	public interface IUpdateCallBack {
		/**
		 * 更新返回结果
		 * @param count
		 */
		void updateCallBack(int count);
	}

	/**
	 * 数据库操作的删除返回结果
	 */
	public interface IDeleteCallBack {
		/**
		 * 删除返回结果
		 * @param count
		 */
		void deleteCallBack(int count);
	}

	/**
	 * 数据库操作的查询返回结果
	 */
	public interface IQueryCallBack {
		/**
		 * 查询返回结果
		 * @param c
		 */
		void queryCallBack(Cursor c);
	}

}
