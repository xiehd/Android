package com.uninew.db.dh.dao;

public class PlanWork {
	/**
	 * 数据库的行id
	 */
	private int id = -1;
	/**
	 * 司机工号
	 */
	private String driverID = null;
	/**
	 * 司机姓名
	 */
	private String name = null;
	/**
	 * 线路标识
	 */
	private int lineID = -1;
	/**
	 * 线路方向(1:上行 2:下行 3:环形)
	 */
	private int lineDirection = -1;
	/**
	 * 发车时间(解析成:"YYYY-MM-DD hh:mm:ss")
	 */
	private String startTime = null;
	/**
	 * 计划趟次
	 */
	private int tripOrder = -1;
	/**
	 * 趟次属性 0:启用 1：停用
	 */
	private int type = -1;
	/**
	 * 提示方式(二进制 0b010101)
	 */
	private int noticeType = -1;
	/**
	 * 运营状态 0：未运营 1：正在运营 2：已运营
	 */
	private int runStatus = -1;
	
	/**
	 * 车牌号码
	 */
	private String plateID = null;
	
	public PlanWork() {
		super();
	}

	/**
	 * 
	 * @param driverID
	 *            司机工号
	 * @param name
	 *            司机姓名
	 * @param lineID
	 *            线路标识
	 * @param lineDirection
	 *            线路方向(1:上行 2:下行 3:环形)
	 * @param startTime
	 *            发车时间
	 * @param tripOrder
	 *            计划趟次 
	 * @param type
	 * 			趟次属性0:启用 1：停用
	 * @param noticeType
	 *            提示方式
	 * @param runStatus
	 *            运营状态 0：未运营 1：正在运营 2：已运营
	 * @param plateID 
	 * 				车牌号码
	 */
	public PlanWork(int id, String driverID, String name, int lineID, int lineDirection, String startTime,
			int tripOrder, int type, int noticeType, int runStatus, String plateID) {
		super();
		this.id = id;
		this.driverID = driverID;
		this.name = name;
		this.lineID = lineID;
		this.lineDirection = lineDirection;
		this.startTime = startTime;
		this.tripOrder = tripOrder;
		this.type = type;
		this.noticeType = noticeType;
		this.runStatus = runStatus;
		this.plateID = plateID;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getDriverID() {
		return driverID;
	}

	public void setDriverID(String driverID) {
		this.driverID = driverID;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getLineID() {
		return lineID;
	}

	public void setLineID(int lineID) {
		this.lineID = lineID;
	}

	public int getLineDirection() {
		return lineDirection;
	}

	public void setLineDirection(int lineDirection) {
		this.lineDirection = lineDirection;
	}

	public String getStartTime() {
		return startTime;
	}

	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}

	public int getTripOrder() {
		return tripOrder;
	}

	public void setTripOrder(int tripOrder) {
		this.tripOrder = tripOrder;
	}

	public int getType() {
		return type;
	}

	public void setType(int type) {
		this.type = type;
	}

	public int getNoticeType() {
		return noticeType;
	}

	public void setNoticeType(int noticeType) {
		this.noticeType = noticeType;
	}

	public int getRunStatus() {
		return runStatus;
	}

	public void setRunStatus(int runStatus) {
		this.runStatus = runStatus;
	}

	public String getPlateID() {
		return plateID;
	}

	public void setPlateID(String plateID) {
		this.plateID = plateID;
	}

	@Override
	public String toString() {
		return "PlanWrok [id=" + id + ", " + (driverID != null ? "driverID=" + driverID + ", " : "")
				+ (name != null ? "name=" + name + ", " : "") + "lineID=" + lineID + ", lineDirection=" + lineDirection
				+ ", " + (startTime != null ? "startTime=" + startTime + ", " : "") + "tripOrder=" + tripOrder
				+ ", type=" + type + ", noticeType=" + noticeType + ", runStatus=" + runStatus + ", "
				+ (plateID != null ? "plateID=" + plateID : "") + "]";
	}
	
	

}
