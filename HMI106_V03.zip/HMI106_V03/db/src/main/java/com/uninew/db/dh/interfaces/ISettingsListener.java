package com.uninew.db.dh.interfaces;
/**
 * Setting信息的监听和回调接口
 * @author rong
 *
 */
public interface ISettingsListener {

	/**
	 * 运营状态回调接口
	 * 
	 * @author Administrator
	 *
	 */
	public interface IRunStateCallBack {
		/**
		 * 运营状态回调结果
		 * @param state 1-运营，2-停运
		 */
		void runState(int state);
	}

	/**
	 * 运营状态监听接口
	 * 
	 * @author Administrator
	 *
	 */
	public interface IRunStateListener {
		/**
		 * 运营状态监听结果 
		 * @param State 1-运营，2-停运
		 */
		void runStateListener(int State);
	}

	/**
	 * 报站模式回调接口
	 */
	public interface IBroadcasterCallBack {
		/**
		 * 报站模式回调结果
		 * @param state 1-自动，2-手动
		 */
		void broadcasterState(int state);
	}

	/**
	 * 报站模式监听接口
	 */
	public interface IBroadcasterListener {
		/**
		 * 报站模式监听结果
		 * @param state 1-自动，2-手动
		 */
		void broadcasterStateListener(int state);
	}

	/**
	 * 语音格式回调接口
	 */
	public interface IVoiceFormatCallBack {
		/**
		 * 语音格式回调结果
		 * @param state 1-mp3,2-wav
		 */
		void voiceFormat(int state);
	}

	/**
	 * 语音格式监听接口
	 */
	public interface IVoiceFormatListener {
		/**
		 * 语音格式监听结果
		 * @param state 1-mp3,2-wav
		 */
		void voiceFormatListener(int state);
	}

	/**
	 * 视频模式回调接口
	 */
	public interface IVideoModerCallBack {
		/**
		 * 视频模式回调结果
		 * @param state 1-DVR，2-后门
		 */
		void VideoModer(int state);
	}

	/**
	 * 视频模式监听接口
	 */
	public interface IVideoModerListener {
		/**
		 * 视频模式监听结果
		 * @param state 1-DVR，2-后门
		 */
		void VideoModerListener(int state);
	}

	/**
	 * 通信模式回调接口
	 */
	public interface IComModelCallBack {
		/**
		 * 通信模式回调结果
		 * @param state 1-网络，2-串口
		 */
		void ComModel(int state);
	}
	
	/**
	 * 通信模式监听接口
	 */
	public interface IComModelListener {
		/**
		 * 通信模式监听结果
		 * @param state 1-网络，2-串口
		 */
		void ComModelListener(int state);
	}
	
	/**
	 * upd服务器IP和端口监听接口
	 */
	public interface IUdpIpAndPortListener{
		/**
		 *  upd服务器IP和端口监听结果
		 * @param ip
		 * @param port
		 */
		void UdpIpAndPort(String ip,int port);
	}
}
