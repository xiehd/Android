package com.uninew.db.main;

import com.uninew.db.main.DbMetaData.ArrangeMessage;
import com.uninew.db.main.DbMetaData.DangerWarnTable;
import com.uninew.db.main.DbMetaData.GPSMessage;
import com.uninew.db.main.DbMetaData.InOutStationMessage;
import com.uninew.db.main.DbMetaData.PlanWorkTable;
import com.uninew.db.main.DbMetaData.ReSendStationTable;
import com.uninew.db.main.DbMetaData.SelfInspectionTable;
import com.uninew.db.main.DbMetaData.SettingTable;
import com.uninew.db.main.DbMetaData.TableTerminalCertified;
import com.uninew.db.main.DbMetaData.TextMessage;
import com.uninew.db.main.DbMetaData.UsersTable;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
/**
 * 数据库创建类
 * @author rong
 *
 */
public class DBOpenHelper extends SQLiteOpenHelper {
	private static final String TAG = "DBOpenHelper";
	private DBOpenHelper(Context context) {
		super(context, DbMetaData.DATABASE_NAME, null, DbMetaData.DATABASE_VERSION);
	}
	private volatile static DBOpenHelper instance;

	public static DBOpenHelper getInstance(Context context) {
		if(instance != null){
			
		}else{
			synchronized (DBOpenHelper.class) {
				if (instance == null) {
					instance = new DBOpenHelper(context);
				}
			}
		}
		return instance;
	}
	
	@Override
	public void onCreate(SQLiteDatabase db) {
		db.execSQL(ArrangeMessage.SQL_CREATE_TABLE);
		db.execSQL(TableTerminalCertified.SQL_CREATE_TABLE);
		db.execSQL(GPSMessage.SQL_CREATE_TABLE);
		db.execSQL(InOutStationMessage.SQL_CREATE_TABLE);
		db.execSQL(TextMessage.SQL_CREATE_TABLE);
		db.execSQL(DangerWarnTable.SQL_CREATE_TABLE);
		db.execSQL(SelfInspectionTable.SQL_CREATE_TABLE);
		db.execSQL(SettingTable.SQL_CREATE_TABLE);
		db.execSQL(UsersTable.SQL_CREATE_TABLE);
		db.execSQL(ReSendStationTable.SQL_CREATE_TABLE);
		db.execSQL(PlanWorkTable.SQL_CREATE_TABLE);
	}
	@Override
	public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
		// DbMetaData.GuideboardTable.GUIDEBOARD_TABLE_NAME);
		db.execSQL("DROP TABLE " + TableTerminalCertified.TERMINAL_CERTIFIED_STRING);
		db.execSQL("DROP TABLE " + ArrangeMessage.ARRANGE_TABLE);
		db.execSQL("DROP TABLE " + GPSMessage.GPS_TABLE);
		db.execSQL("DROP TABLE " + InOutStationMessage.IN_OUT_STATION_TABLE);
		db.execSQL("DROP TABLE " + TextMessage.TEXT_TABLE);
		db.execSQL("DROP TABLE " + DangerWarnTable.DANGER_WARNIN_TABLE);
		db.execSQL("DROP TABLE " + SelfInspectionTable.SELF_INSPECTION_TABLE);
		db.execSQL("DROP TABLE " + SettingTable.SETTING_TABLE);
		db.execSQL("DROP TABLE " + UsersTable.USERS_TABLE);
		db.execSQL("DROP TABLE " + ReSendStationTable.RESENDSTATION_TABLE);
		db.execSQL("DROP TABLE " + PlanWorkTable.PLANWORK_TABLE);
		// db.execSQL(DbMetaData.GuideboardTable.SQL_CREATE_TABLE);
		db.execSQL(TableTerminalCertified.SQL_CREATE_TABLE);
		db.execSQL(ArrangeMessage.SQL_CREATE_TABLE);
		db.execSQL(GPSMessage.SQL_CREATE_TABLE);
		db.execSQL(InOutStationMessage.SQL_CREATE_TABLE);
		db.execSQL(TextMessage.SQL_CREATE_TABLE);
		db.execSQL(DangerWarnTable.SQL_CREATE_TABLE);
		db.execSQL(SelfInspectionTable.SQL_CREATE_TABLE);
		db.execSQL(SettingTable.SQL_CREATE_TABLE);
		db.execSQL(UsersTable.SQL_CREATE_TABLE);
		db.execSQL(ReSendStationTable.SQL_CREATE_TABLE);
		db.execSQL(PlanWorkTable.SQL_CREATE_TABLE);
	}
	
	public void closeDB() {
		if (instance != null) {
			try {
				SQLiteDatabase db = instance.getWritableDatabase();
				db.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
			instance = null;
		}
	}
	
}
