package com.uninew.db.dh.Managers;

import java.util.ArrayList;
import java.util.List;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.ContentObserver;
import android.database.Cursor;
import android.net.Uri;
import android.os.Handler;

import com.uninew.db.dh.dao.DangerWarn;
import com.uninew.db.dh.interfaces.IResultCallBack;
import com.uninew.db.dh.interfaces.IWarns;
import com.uninew.db.dh.interfaces.IWarnsListener.IQueryWarnsCallBack;
import com.uninew.db.dh.interfaces.IWarnsListener.IWarnsNotifyListener;
import com.uninew.db.main.BaseContentResolver;
import com.uninew.db.main.DbMetaData.DangerWarnTable;
import com.uninew.db.main.IDBOpertionCallBack.IDeleteCallBack;
import com.uninew.db.main.IDBOpertionCallBack.IInsertCallBack;
import com.uninew.db.main.IDBOpertionCallBack.IQueryCallBack;
import com.uninew.db.main.IDBOpertionCallBack.IUpdateCallBack;
/**
 * 危险信息数据库的操作管理器
 * @author rong
 * 
 * 添加危险信息的更新监听器时，要先注册数据库变化监听器 （registerNotify() ）的方法，
 * 最好在生命周期开始时进行注册，
 * 而在生命周期结束时进行注销（unregisterNotify()）的方法，避免内存过量使用，
 * 然后添加监听器（addIWarinsNotifyListener ）；
 */
public class DbWarnsManager implements IWarns {

	private static final String TAG = "WarinsManager";
	private Context mContext;
	/** 危险信息更新监听器*/
	private IWarnsNotifyListener warnsNotifyListener;
	/** 数据库操作类 */
	private BaseContentResolver mResolver;
	
	/**
	 * 类的初始化
	 * @param mContext 
	 */
	public DbWarnsManager(Context mContext) {
		this.mContext = mContext;
		mResolver = BaseContentResolver.getInstance(mContext);
	}
	/**
	 * 添加危险信息更新监听器
	 * @param warinsNotifyListener
	 */
	public void addIWarinsNotifyListener(IWarnsNotifyListener warnsNotifyListener) {
		this.warnsNotifyListener = warnsNotifyListener;
	}

	public void removeIWarnsNotifyListener(){
		if(warnsNotifyListener != null){
			warnsNotifyListener = null;
		}
	}
	
	/**
	 * 创建一个contentprovider的监听类
	 */
	private ContentObserver observer = new ContentObserver(new Handler()) {

		@SuppressLint("NewApi")
		@Override
		public void onChange(boolean selfChange, Uri uri) {
			// TODO Auto-generated method stub
			super.onChange(selfChange, uri);
//			Log.d(TAG, uri.toString());
		}

		@Override
		public void onChange(boolean selfChange) {
			// TODO Auto-generated method stub
			super.onChange(selfChange);
			queryWarns(null, new IQueryWarnsCallBack() {

				@Override
				public void queryWarns(List<DangerWarn> warns) {
					if (warns != null && !warns.isEmpty()) {
						if (warnsNotifyListener != null) {
							warnsNotifyListener.warnsNotify(warns);
						}
					}
				}
			});
		}

	};

	@Override
	public void updateWarns(List<DangerWarn> warns) {
		if (warns != null && !warns.isEmpty()) {
			for (final DangerWarn warin : warns) {
				queryWarns(null, new IQueryWarnsCallBack() {

					@Override
					public void queryWarns(List<DangerWarn> warns) {
						if (warns != null && warns.size() > 20000) {
							delWarns(new int[] { warns.get(0).getId() }, new IResultCallBack() {

								@Override
								public void resultCallBack(boolean result) {
									final ContentValues values = new ContentValues();
									getValues(warin, values);
									mResolver.insert(DangerWarnTable.CONTENT_URI, values, new IInsertCallBack() {

										@Override
										public void insertCallBack(Uri uri) {
											values.clear();
										}
									});
								}
							});
						} else {
							mResolver.query(DangerWarnTable.CONTENT_URI, null, DangerWarnTable.TIME+"=?", new String[]{warin.getTime()}, "time asc", new IQueryCallBack() {
								
								@Override
								public void queryCallBack(final Cursor c) {
									if(c != null && c.getCount() > 0){
										final ContentValues values = new ContentValues();
										getValues(warin, values);
										mResolver.update(DangerWarnTable.CONTENT_URI, values, DangerWarnTable.TIME+"=?",
												new String[] { warin.getTime() }, new IUpdateCallBack() {
													@Override
													public void updateCallBack(int count) {
														values.clear();
														c.close();
													}
												});
									}else{
										if(c != null){
											c.close();
										}
										final ContentValues values = new ContentValues();
										getValues(warin, values);
										mResolver.insert(DangerWarnTable.CONTENT_URI, values, new IInsertCallBack() {

											@Override
											public void insertCallBack(Uri uri) {
												values.clear();
											}
										});
									}
								}
							});
							
						}
					}
				});
			}

		}
	}

	private void getValues(final DangerWarn warin, final ContentValues values) {
		if (warin.getType() != -1) {
			values.put(DangerWarnTable.TYPE, warin.getType());
		}
		if (warin.getTime() != null) {
			values.put(DangerWarnTable.TIME, warin.getTime());
		}
		if (warin.getLongitude() != -1) {
			values.put(DangerWarnTable.LONGITUDE, warin.getLongitude());
		}
		if (warin.getLatitude() != -1) {
			values.put(DangerWarnTable.LATITUDE, warin.getLatitude());
		}
		if (warin.getContent() != null) {
			values.put(DangerWarnTable.CONTENT, warin.getContent());
		}
	}

	@Override
	public void queryWarns(int[] types, final IQueryWarnsCallBack queryWarnsCallBack) {
		String selection = null;
		String[] selectionArgs = null;
		if (types != null && types.length > 0) {
			selection = DangerWarnTable.TYPE+"=?";
			int length = types.length;
			selectionArgs = new String[length];
			for (int i = 0; i < length; i++) {
				if (types[i] == 0) {
					selection = null;
					selectionArgs = null;
					break;
				} else {
					selectionArgs[i] = String.valueOf(types[i]);
				}
			}
		}
		mResolver.query(DangerWarnTable.CONTENT_URI, null, selection, selectionArgs, "time asc", new IQueryCallBack() {

			@Override
			public void queryCallBack(Cursor c) {
				if (c != null && c.getCount() > 0) {
					List<DangerWarn> dangerWarins = new ArrayList<>();
					while (c.moveToNext()) {
						DangerWarn dw = new DangerWarn();
						dw.setId(c.getInt(c.getColumnIndex(DangerWarnTable._ID)));
						dw.setType(c.getInt(c.getColumnIndex(DangerWarnTable.TYPE)));
						dw.setTime(c.getString(c.getColumnIndex(DangerWarnTable.TIME)));
						dw.setLongitude(c.getDouble(c.getColumnIndex(DangerWarnTable.LONGITUDE)));
						dw.setLatitude(c.getDouble(c.getColumnIndex(DangerWarnTable.LATITUDE)));
						dw.setContent(c.getString(c.getColumnIndex(DangerWarnTable.CONTENT)));
						dangerWarins.add(dw);
					}
					if (queryWarnsCallBack != null) {
						queryWarnsCallBack.queryWarns(dangerWarins);
					}
					c.close();
				} else {
					if(c != null){
						c.close();
					}
					if (queryWarnsCallBack != null) {
						queryWarnsCallBack.queryWarns(null);
					}
				}
			}

		});
	}

	@Override
	public void delWarns(int[] ids, final IResultCallBack resultCallBack) {
		String selection = null;
		String[] selectionArgs = null;
		if (ids != null && ids.length > 0) {
			selection = DangerWarnTable._ID+"=?";
			int length = ids.length;
			selectionArgs = new String[length];
			for (int i = 0; i < length; i++) {
				selectionArgs[i] = String.valueOf(ids[i]);
			}
		}
		mResolver.delete(DangerWarnTable.CONTENT_URI, selection, selectionArgs, new IDeleteCallBack() {

			@Override
			public void deleteCallBack(int count) {
				if (count > 0) {
					if (resultCallBack != null) {
						resultCallBack.resultCallBack(true);
					}
				} else {
					if (resultCallBack != null) {
						resultCallBack.resultCallBack(false);
					}
				}
			}
		});
	}

	/**
	 * 注册数据库表变化监听器
	 */
	public void registerNotify() {
		mResolver.registerContentObserver(DangerWarnTable.CONTENT_URI, true, observer);

	}

	/**
	 * 注销数据库表变化监听器
	 */
	public void unregisterNotify() {
		mResolver.unregisterContentObserver(observer);
		removeIWarnsNotifyListener();
	}

}
