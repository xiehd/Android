package com.uninew.db.dh.Managers;

import com.uninew.db.dh.interfaces.ISettings;
import com.uninew.db.dh.interfaces.ISettingsListener.IBroadcasterCallBack;
import com.uninew.db.dh.interfaces.ISettingsListener.IBroadcasterListener;
import com.uninew.db.dh.interfaces.ISettingsListener.IComModelCallBack;
import com.uninew.db.dh.interfaces.ISettingsListener.IComModelListener;
import com.uninew.db.dh.interfaces.ISettingsListener.IRunStateCallBack;
import com.uninew.db.dh.interfaces.ISettingsListener.IRunStateListener;
import com.uninew.db.dh.interfaces.ISettingsListener.IUdpIpAndPortListener;
import com.uninew.db.dh.interfaces.ISettingsListener.IVideoModerCallBack;
import com.uninew.db.dh.interfaces.ISettingsListener.IVideoModerListener;
import com.uninew.db.dh.interfaces.ISettingsListener.IVoiceFormatCallBack;
import com.uninew.db.dh.interfaces.ISettingsListener.IVoiceFormatListener;
import com.uninew.db.main.BaseContentResolver;
import com.uninew.db.main.DbMetaData.SettingTable;
import com.uninew.db.main.IDBOpertionCallBack.IInsertCallBack;
import com.uninew.db.main.IDBOpertionCallBack.IQueryCallBack;
import com.uninew.db.main.IDBOpertionCallBack.IUpdateCallBack;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.ContentObserver;
import android.database.Cursor;
import android.net.Uri;
import android.os.Handler;

/**
 * Setting信息数据库的操作管理器
 * 
 * @author rong
 * 
 *         添加Setting信息的更新监听器时，要先注册数据库变化监听器 （registerNotify() ）的方法，
 *         最好在生命周期开始时进行注册， 而在生命周期结束时进行注销（unregisterNotify()）的方法，避免内存过量使用，
 *         然后添加监听器；
 */
public class DbSettingsManager implements ISettings {

	private static final String TAG = "SettingsManager";
	private Context mContext;
	/** 数据库操作类 */
	private BaseContentResolver resolver;
	/** 运营状态的字段名 */
	private static final String RUNNING = "running_state";
	/** 报站模式的字段名 */
	private static final String BROADCASTER = "broadcaster_station";
	/** 语音格式的字段名 */
	private static final String VOICE = "voice_format";
	/** 视频模式的字段名 */
	private static final String VIDEO = "video_model";
	/** 通信模式的字段名 */
	private static final String COM = "com_model";
	/** UDP的字段名 */
	private static final String UDP = "udp";
	/** 默认UDP的ip**/
	private static final String UDP_DEFAULT_IP = "121.15.7.100";
	/** 默认UDP的端口**/
	private static final int UDP_DEFAULT_PORT = 6688;
	/** 运营状态变化监听器 */
	private volatile IRunStateListener mRunStateListener;
	/** 视频模式变化监听器 */
	private volatile IVideoModerListener mVideoModerListener;
	/** 语音格式变化监听器 */
	private volatile IVoiceFormatListener mVoiceFormatListener;
	/** 通信模式变化监听器 */
	private volatile IComModelListener mComModelListener;
	/** 报站模式变化监听器 */
	private volatile IBroadcasterListener mBroadcasterListener;

	/**
	 * 类的初始化
	 * 
	 * @param mContext
	 */
	public DbSettingsManager(Context mContext) {
		this.mContext = mContext;
		resolver = BaseContentResolver.getInstance(mContext);
	}

	/**
	 * 设置运营状态变化监听器
	 * 
	 * @param mRunStateListener
	 *            the mRunStateListener to set
	 */
	public void setmRunStateListener(IRunStateListener mRunStateListener) {
		this.mRunStateListener = mRunStateListener;
	}

	/**
	 * 移除运营状态变化监听器
	 */
	public void removemRunStateListener() {
		if (mRunStateListener != null) {
			mRunStateListener = null;
		}
	}

	/**
	 * 设置视频模式变化监听器
	 * 
	 * @param mVideoModerListener
	 *            the mVideoModerListener to set
	 */
	public void setmVideoModerListener(IVideoModerListener mVideoModerListener) {
		this.mVideoModerListener = mVideoModerListener;
	}

	/**
	 * 移除视频模式变化监听器
	 */
	public void removemVideoModerListener() {
		if (mVideoModerListener != null) {
			mVideoModerListener = null;
		}
	}

	/**
	 * 设置语音格式变化监听器
	 * 
	 * @param mVoiceFormatListener
	 *            the mVoiceFormatListener to set
	 */
	public void setmVoiceFormatListener(IVoiceFormatListener mVoiceFormatListener) {
		this.mVoiceFormatListener = mVoiceFormatListener;
	}

	/**
	 * 移除语音格式变化监听器
	 */
	public void removemVoiceFormatListener() {
		if (mVoiceFormatListener != null) {
			mVoiceFormatListener = null;
		}
	}

	/**
	 * 设置通信模式变化监听器
	 * 
	 * @param mComModelListener
	 *            the mComModelListener to set
	 */
	public void setmComModelListener(IComModelListener mComModelListener) {
		this.mComModelListener = mComModelListener;
	}

	/**
	 * 移除通信模式变化监听器
	 */
	public void removemComModelListener() {
		if (mComModelListener != null) {
			mComModelListener = null;
		}
	}

	/**
	 * 设置报站模式变化监听器
	 * 
	 * @param mBroadcasterListener
	 *            the mBroadcasterListener to set
	 */
	public void setmBroadcasterListener(IBroadcasterListener mBroadcasterListener) {
		this.mBroadcasterListener = mBroadcasterListener;
	}

	/**
	 * 移除报站模式变化监听器
	 */
	public void removemBroadcasterListener() {
		if (mBroadcasterListener != null) {
			mBroadcasterListener = null;
		}
	}

	private volatile static String s = "";
	/**
	 * 创建一个contentprovider的监听类
	 */
	private ContentObserver observer = new ContentObserver(new Handler()) {

		@SuppressLint("NewApi")
		@Override
		public void onChange(boolean selfChange, Uri uri) {
			super.onChange(selfChange, uri);
			// Log.d(TAG, uri.getLastPathSegment());
			s = uri.getLastPathSegment();
			if (isInteger(s)) {
				resolver.query(SettingTable.CONTENT_URI, new String[] { SettingTable.NAME }, SettingTable._ID + "=?",
						new String[] { s }, "_id desc", new IQueryCallBack() {

							@Override
							public void queryCallBack(Cursor c) {
								if (c != null && c.getCount() > 0) {
									if (c.moveToNext()) {
										s = c.getString(c.getColumnIndex(SettingTable.NAME));
										// Log.d(TAG, s);
										getListener();
										c.close();
									}
								} else {
									if (c != null) {
										c.close();
									}
								}

							}
						});
			} else {
				getListener();
			}
		}

		@Override
		public void onChange(boolean selfChange) {
			super.onChange(selfChange);
		}
	};

	/** 监听返回结果 **/
	private void getListener() {
		switch (s) {
		case RUNNING:
			if (mRunStateListener != null) {
				resolver.query(SettingTable.CONTENT_URI, new String[] { SettingTable.KEY }, SettingTable.NAME + "=?",
						new String[] { RUNNING }, "_id desc", new IQueryCallBack() {

							@Override
							public void queryCallBack(Cursor c) {
								if (c != null && c.getCount() > 0) {
									if (c.moveToNext()) {
										int key = c.getInt(c.getColumnIndex(SettingTable.KEY));
										if (mRunStateListener != null) {
											mRunStateListener.runStateListener(key);
										}
										c.close();
										s = "";
									}
								} else {
									if (c != null) {
										c.close();
									}
								}
							}
						});
			}
			break;
		case BROADCASTER:
			if (mBroadcasterListener != null) {
				resolver.query(SettingTable.CONTENT_URI, new String[] { SettingTable.KEY }, SettingTable.NAME + "=?",
						new String[] { BROADCASTER }, "name desc", new IQueryCallBack() {

							@Override
							public void queryCallBack(Cursor c) {
								if (c != null) {
									if (c.moveToNext()) {
										int key = c.getInt(c.getColumnIndex(SettingTable.KEY));
										if (mBroadcasterListener != null) {
											mBroadcasterListener.broadcasterStateListener(key);
										}
										c.close();
										s = "";
									}
								}
							}
						});
			}
			break;
		case VOICE:
			if (mVoiceFormatListener != null) {
				resolver.query(SettingTable.CONTENT_URI, new String[] { SettingTable.KEY }, SettingTable.NAME + "=?",
						new String[] { VOICE }, "name desc", new IQueryCallBack() {

							@Override
							public void queryCallBack(Cursor c) {
								if (c != null) {
									if (c.moveToNext()) {
										int key = c.getInt(c.getColumnIndex(SettingTable.KEY));
										if (mVoiceFormatListener != null) {
											mVoiceFormatListener.voiceFormatListener(key);
										}
										c.close();
										s = "";
									}
								}
							}
						});
			}
			break;
		case VIDEO:
			if (mVideoModerListener != null) {
				resolver.query(SettingTable.CONTENT_URI, new String[] { SettingTable.KEY }, SettingTable.NAME + "=?",
						new String[] { VIDEO }, "name desc", new IQueryCallBack() {

							@Override
							public void queryCallBack(Cursor c) {
								if (c != null) {
									if (c.moveToNext()) {
										int key = c.getInt(c.getColumnIndex(SettingTable.KEY));
										if (mVideoModerListener != null) {
											mVideoModerListener.VideoModerListener(key);
										}
										c.close();
										s = "";
									}
								}
							}
						});
			}
			break;
		case COM:
			if (mComModelListener != null) {
				resolver.query(SettingTable.CONTENT_URI, new String[] { SettingTable.KEY }, SettingTable.NAME + "=?",
						new String[] { COM }, "name desc", new IQueryCallBack() {

							@Override
							public void queryCallBack(Cursor c) {
								if (c != null) {
									if (c.moveToNext()) {
										int key = c.getInt(c.getColumnIndex(SettingTable.KEY));
										if (mComModelListener != null) {
											mComModelListener.ComModelListener(key);
										}
										c.close();
										s = "";
									}
								}
							}
						});
			}
			break;
		}
	}

	@Override
	public void setRunning(final int key) {
		resolver.query(SettingTable.CONTENT_URI, new String[] { SettingTable.KEY }, SettingTable.NAME + "=?",
				new String[] { RUNNING }, "name desc", new IQueryCallBack() {

					@Override
					public void queryCallBack(final Cursor c) {
						if (c != null && c.getCount() > 0) {
							final ContentValues values = new ContentValues();
							values.put(SettingTable.KEY, key);
							resolver.update(SettingTable.CONTENT_URI, values, SettingTable.NAME + "=?",
									new String[] { RUNNING }, new IUpdateCallBack() {

										@Override
										public void updateCallBack(int count) {
											values.clear();
											c.close();
										}
									});
						} else {
							final ContentValues values = new ContentValues();
							values.put(SettingTable.KEY, key);
							values.put(SettingTable.NAME, RUNNING);
							resolver.insert(SettingTable.CONTENT_URI, values, new IInsertCallBack() {

								@Override
								public void insertCallBack(Uri uri) {
									values.clear();
								}
							});
						}

					}
				});
	}

	@Override
	public void queryRunning(final IRunStateCallBack runStateCallBack) {
		resolver.query(SettingTable.CONTENT_URI, new String[] { SettingTable.KEY }, SettingTable.NAME + "=?",
				new String[] { RUNNING }, "_id desc", new IQueryCallBack() {

					@Override
					public void queryCallBack(final Cursor c) {
						if (c != null && c.getCount() > 0) {
							if (c.moveToNext()) {
								int key = c.getInt(c.getColumnIndex(SettingTable.KEY));
								if (runStateCallBack != null) {
									runStateCallBack.runState(key);
								}
								c.close();
							}
						} else {
							if (c != null) {
								c.close();
							}
							final ContentValues values = new ContentValues();
							values.put(SettingTable.KEY, 1);
							values.put(SettingTable.NAME, RUNNING);
							resolver.insert(SettingTable.CONTENT_URI, values, new IInsertCallBack() {

								@Override
								public void insertCallBack(Uri uri) {
									values.clear();
									if (runStateCallBack != null) {
										runStateCallBack.runState(1);
									}
								}
							});
						}
					}
				});

	}

	@Override
	public void setBroadcaster(final int key) {
		resolver.query(SettingTable.CONTENT_URI, new String[] { SettingTable.KEY }, SettingTable.NAME + "=?",
				new String[] { BROADCASTER }, "_id desc", new IQueryCallBack() {

					@Override
					public void queryCallBack(final Cursor c) {
						if (c != null && c.getCount() > 0) {
							final ContentValues values = new ContentValues();
							values.put(SettingTable.KEY, key);
							resolver.update(SettingTable.CONTENT_URI, values, SettingTable.NAME + "=?",
									new String[] { BROADCASTER }, new IUpdateCallBack() {

										@Override
										public void updateCallBack(int count) {
											values.clear();
											c.close();
										}
									});
						} else {
							if (c != null) {
								c.close();
							}
							final ContentValues values = new ContentValues();
							values.put(SettingTable.KEY, key);
							values.put(SettingTable.NAME, BROADCASTER);
							resolver.insert(SettingTable.CONTENT_URI, values, new IInsertCallBack() {

								@Override
								public void insertCallBack(Uri uri) {
									values.clear();
								}
							});
						}

					}
				});
	}

	@Override
	public void queryBroadcaster(final IBroadcasterCallBack broadcasterCallBack) {
		resolver.query(SettingTable.CONTENT_URI, new String[] { SettingTable.KEY }, SettingTable.NAME + "=?",
				new String[] { BROADCASTER }, "_id desc", new IQueryCallBack() {

					@Override
					public void queryCallBack(final Cursor c) {
						if (c != null && c.getCount() > 0) {
							if (c.moveToNext()) {
								int key = c.getInt(c.getColumnIndex(SettingTable.KEY));
								if (broadcasterCallBack != null) {
									broadcasterCallBack.broadcasterState(key);
								}
								c.close();
							}
						} else {
							if (c != null) {
								c.close();
							}
							final ContentValues values = new ContentValues();
							values.put(SettingTable.KEY, 2);
							values.put(SettingTable.NAME, BROADCASTER);
							resolver.insert(SettingTable.CONTENT_URI, values, new IInsertCallBack() {

								@Override
								public void insertCallBack(Uri uri) {
									values.clear();
									if (broadcasterCallBack != null) {
										broadcasterCallBack.broadcasterState(2);
									}
								}
							});
						}
					}
				});
	}

	@Override
	public void setVoiceFormat(final int key) {
		resolver.query(SettingTable.CONTENT_URI, new String[] { SettingTable.KEY }, SettingTable.NAME + "=?",
				new String[] { VOICE }, "name desc", new IQueryCallBack() {

					@Override
					public void queryCallBack(final Cursor c) {
						if (c != null && c.getCount() > 0) {
							final ContentValues values = new ContentValues();
							values.put(SettingTable.KEY, key);
							resolver.update(SettingTable.CONTENT_URI, values, SettingTable.NAME + "=?",
									new String[] { VOICE }, new IUpdateCallBack() {

										@Override
										public void updateCallBack(int count) {
											values.clear();
											c.close();
										}
									});
						} else {
							if (c != null) {
								c.close();
							}
							final ContentValues values = new ContentValues();
							values.put(SettingTable.KEY, key);
							values.put(SettingTable.NAME, VOICE);
							resolver.insert(SettingTable.CONTENT_URI, values, new IInsertCallBack() {

								@Override
								public void insertCallBack(Uri uri) {
									values.clear();
								}
							});
						}

					}
				});
	}

	@Override
	public void queryVoiceFormat(final IVoiceFormatCallBack voiceFormatCallBack) {
		resolver.query(SettingTable.CONTENT_URI, new String[] { SettingTable.KEY }, SettingTable.NAME + "=?",
				new String[] { VOICE }, "name desc", new IQueryCallBack() {

					@Override
					public void queryCallBack(final Cursor c) {
						if (c != null && c.getCount() > 0) {
							if (c.moveToNext()) {
								int key = c.getInt(c.getColumnIndex(SettingTable.KEY));
								if (voiceFormatCallBack != null) {
									voiceFormatCallBack.voiceFormat(key);
								}
								c.close();
							}
						} else {
							if (c != null) {
								c.close();
							}
							final ContentValues values = new ContentValues();
							values.put(SettingTable.KEY, 1);
							values.put(SettingTable.NAME, VOICE);
							resolver.insert(SettingTable.CONTENT_URI, values, new IInsertCallBack() {

								@Override
								public void insertCallBack(Uri uri) {
									values.clear();
									if (voiceFormatCallBack != null) {
										voiceFormatCallBack.voiceFormat(1);
									}
								}
							});
						}
					}
				});
	}

	@Override
	public void setVideoModel(final int key) {
		resolver.query(SettingTable.CONTENT_URI, new String[] { SettingTable.KEY }, SettingTable.NAME + "=?",
				new String[] { VIDEO }, "name desc", new IQueryCallBack() {

					@Override
					public void queryCallBack(final Cursor c) {
						if (c != null && c.getCount() > 0) {
							final ContentValues values = new ContentValues();
							values.put(SettingTable.KEY, key);
							resolver.update(SettingTable.CONTENT_URI, values, SettingTable.NAME + "=?",
									new String[] { VIDEO }, new IUpdateCallBack() {

										@Override
										public void updateCallBack(int count) {
											values.clear();
											c.close();

										}
									});
						} else {
							if (c != null) {
								c.close();
							}
							final ContentValues values = new ContentValues();
							values.put(SettingTable.KEY, key);
							values.put(SettingTable.NAME, VIDEO);
							resolver.insert(SettingTable.CONTENT_URI, values, new IInsertCallBack() {

								@Override
								public void insertCallBack(Uri uri) {
									values.clear();
								}
							});
						}

					}
				});
	}

	@Override
	public void queryVideoModel(final IVideoModerCallBack videoModerCallBack) {
		resolver.query(SettingTable.CONTENT_URI, new String[] { SettingTable.KEY }, SettingTable.NAME + "=?",
				new String[] { VIDEO }, "name desc", new IQueryCallBack() {

					@Override
					public void queryCallBack(final Cursor c) {
						if (c != null && c.getCount() > 0) {
							if (c.moveToNext()) {
								int key = c.getInt(c.getColumnIndex(SettingTable.KEY));
								if (videoModerCallBack != null) {
									videoModerCallBack.VideoModer(key);
								}
								c.close();
							}
						} else {
							if (c != null) {
								c.close();
							}
							final ContentValues values = new ContentValues();
							values.put(SettingTable.KEY, 1);
							values.put(SettingTable.NAME, VIDEO);
							resolver.insert(SettingTable.CONTENT_URI, values, new IInsertCallBack() {

								@Override
								public void insertCallBack(Uri uri) {
									values.clear();
									if (videoModerCallBack != null) {
										videoModerCallBack.VideoModer(1);
									}
								}
							});
						}
					}
				});
	}

	@Override
	public void setComModel(final int key) {
		resolver.query(SettingTable.CONTENT_URI, new String[] { SettingTable.KEY }, SettingTable.NAME + "=?",
				new String[] { COM }, "name desc", new IQueryCallBack() {

					@Override
					public void queryCallBack(final Cursor c) {
						if (c != null && c.getCount() > 0) {
							final ContentValues values = new ContentValues();
							values.put(SettingTable.KEY, key);
							resolver.update(SettingTable.CONTENT_URI, values, SettingTable.NAME + "=?",
									new String[] { COM }, new IUpdateCallBack() {

										@Override
										public void updateCallBack(int count) {
											values.clear();
											c.close();
										}
									});
						} else {
							if (c != null) {
								c.close();
							}
							final ContentValues values = new ContentValues();
							values.put(SettingTable.KEY, key);
							values.put(SettingTable.NAME, COM);
							resolver.insert(SettingTable.CONTENT_URI, values, new IInsertCallBack() {

								@Override
								public void insertCallBack(Uri uri) {
									values.clear();
								}
							});
						}

					}
				});
	}

	@Override
	public void queryComModel(final IComModelCallBack comModelCallBack) {
		resolver.query(SettingTable.CONTENT_URI, new String[] { SettingTable.KEY }, SettingTable.NAME + "=?",
				new String[] { COM }, "name desc", new IQueryCallBack() {

					@Override
					public void queryCallBack(final Cursor c) {
						if (c != null && c.getCount() > 0) {
							if (c.moveToNext()) {
								int key = c.getInt(c.getColumnIndex(SettingTable.KEY));
								if (comModelCallBack != null) {
									comModelCallBack.ComModel(key);
								}
								c.close();
							}
						} else {
							if (c != null) {
								c.close();
							}
							final ContentValues values = new ContentValues();
							values.put(SettingTable.KEY, 1);
							values.put(SettingTable.NAME, COM);
							resolver.insert(SettingTable.CONTENT_URI, values, new IInsertCallBack() {

								@Override
								public void insertCallBack(Uri uri) {
									values.clear();
									if (comModelCallBack != null) {
										comModelCallBack.ComModel(1);
									}
								}
							});
						}
					}
				});
	}

	/**
	 * 注册数据库表变化监听器
	 */
	public void registerNotify() {
		resolver.registerContentObserver(SettingTable.CONTENT_URI, true, observer);

	}

	/**
	 * 注销数据库表变化监听器
	 */
	public void unregisterNotify() {
		resolver.unregisterContentObserver(observer);
		removemBroadcasterListener();
		removemComModelListener();
		removemRunStateListener();
		removemVideoModerListener();
		removemVoiceFormatListener();
	}

	/**
	 * 判断字符串是否是整数
	 */
	public static boolean isInteger(String value) {
		try {
			Integer.parseInt(value);
			return true;
		} catch (NumberFormatException e) {
			return false;
		}
	}

	@Override
	public void setUdpIpAndPort(final String ip, final int port) {
		resolver.query(SettingTable.CONTENT_URI, null, SettingTable.NAME + "=?",
				new String[] { UDP }, "name desc", new IQueryCallBack() {

					@Override
					public void queryCallBack(final Cursor c) {
						if (c != null && c.getCount() > 0) {
							final ContentValues values = new ContentValues();
							values.put(SettingTable.KEY, port);
							values.put(SettingTable.VALUE, ip);
							resolver.update(SettingTable.CONTENT_URI, values, SettingTable.NAME + "=?",
									new String[] { UDP }, new IUpdateCallBack() {

										@Override
										public void updateCallBack(int count) {
											values.clear();
											c.close();
										}
									});
						} else {
							if (c != null) {
								c.close();
							}
							final ContentValues values = new ContentValues();
							values.put(SettingTable.KEY, port);
							values.put(SettingTable.VALUE, ip);
							values.put(SettingTable.NAME, UDP);
							resolver.insert(SettingTable.CONTENT_URI, values, new IInsertCallBack() {

								@Override
								public void insertCallBack(Uri uri) {
									values.clear();
								}
							});
						}

					}
				});
	}

	@Override
	public void queryUdpIpAndPort(final IUdpIpAndPortListener udpIpAndPortListener) {
		resolver.query(SettingTable.CONTENT_URI, null, SettingTable.NAME + "=?",
				new String[] { UDP }, "name desc", new IQueryCallBack() {

					@Override
					public void queryCallBack(final Cursor c) {
						if (c != null && c.getCount() > 0) {
							if (c.moveToNext()) {
								int key = c.getInt(c.getColumnIndex(SettingTable.KEY));
								String value = c.getString(c.getColumnIndex(SettingTable.VALUE));
								if (udpIpAndPortListener != null) {
									udpIpAndPortListener.UdpIpAndPort(value, key);
								}
								c.close();
							}
						} else {
							if (c != null) {
								c.close();
							}
							final ContentValues values = new ContentValues();
							values.put(SettingTable.KEY, UDP_DEFAULT_PORT);
							values.put(SettingTable.VALUE, UDP_DEFAULT_IP);
							values.put(SettingTable.NAME, UDP);
							resolver.insert(SettingTable.CONTENT_URI, values, new IInsertCallBack() {

								@Override
								public void insertCallBack(Uri uri) {
									values.clear();
									if (udpIpAndPortListener != null) {
										udpIpAndPortListener.UdpIpAndPort(UDP_DEFAULT_IP, UDP_DEFAULT_PORT);
									}
								}
							});
						}
					}
				});
	}
}
