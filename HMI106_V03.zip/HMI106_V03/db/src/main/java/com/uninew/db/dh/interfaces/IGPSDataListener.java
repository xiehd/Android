package com.uninew.db.dh.interfaces;

import java.util.List;

import com.uninew.db.dh.dao.GPSData;
/**
 * 此接口是对gps信息的监听和回调接口
 * @author rong
 *
 */
public interface IGPSDataListener {
	
	/**
	 * gps信息查询回调接口
	 */
	public interface IQueryGPSCallBack{
		/**
		 * 查询GPS信息的回调方法
		 * @param gpsDatas
		 */
		void queryGPSCallBack(List<GPSData> gpsDatas);
	}
	
	/**
	 * gps信息更新监听接口
	 */
	public interface IGPSNotifyListener{
		/**
		 * 更新GPS信息的监听方法
		 * @param gpsDatas
		 */
		void gpsNotify(List<GPSData> gpsDatas);
	}
}
