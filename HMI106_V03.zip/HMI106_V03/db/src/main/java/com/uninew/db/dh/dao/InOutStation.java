package com.uninew.db.dh.dao;

public class InOutStation {

	/**
	 * id
	 */
	private int id = -1;
	/**
	 * 车辆状态(二进制 0b0101)
	 */
	private int carState = -1;
	/**
	 * 站点标识
	 */
	private int siteID= -1;
	/**
	 * 计划趟次
	 */
	private int tripOrder= -1;
	/**
	 * 站序
	 */
	private int siteNum= -1;
	/**
	 * 线路方向(1:上行 2:下行 3:环形)
	 */
	private int lineDirection= -1;
	/**
	 * 线路标识
	 */
	private int lineID= -1;
	/**
	 * 报站类型(0:GPS 1:手动)
	 */
	private int method= -1;
	/**
	 * 类型(0:进站 1:出站 2:进站补传 3:出站补传)
	 */
	private int type= -1;
	/**
	 * 进出站时间(解析成:"YYYY-MM-DD hh:mm:ss")
	 */
	private long time= -1;
	public InOutStation() {
		super();
	}
	public InOutStation(int id, int carState, int siteID, int tripOrder, int siteNum, int lineDirection, int lineID,
			int method, int type, long time) {
		super();
		this.id = id;
		this.carState = carState;
		this.siteID = siteID;
		this.tripOrder = tripOrder;
		this.siteNum = siteNum;
		this.lineDirection = lineDirection;
		this.lineID = lineID;
		this.method = method;
		this.type = type;
		this.time = time;
	}
	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}
	/**
	 * @return the carState
	 */
	public int getCarState() {
		return carState;
	}
	/**
	 * @param carState the carState to set
	 */
	public void setCarState(int carState) {
		this.carState = carState;
	}
	/**
	 * @return the siteID
	 */
	public int getSiteID() {
		return siteID;
	}
	/**
	 * @param siteID the siteID to set
	 */
	public void setSiteID(int siteID) {
		this.siteID = siteID;
	}
	/**
	 * @return the tripOrder
	 */
	public int getTripOrder() {
		return tripOrder;
	}
	/**
	 * @param tripOrder the tripOrder to set
	 */
	public void setTripOrder(int tripOrder) {
		this.tripOrder = tripOrder;
	}
	/**
	 * @return the siteNum
	 */
	public int getSiteNum() {
		return siteNum;
	}
	/**
	 * @param siteNum the siteNum to set
	 */
	public void setSiteNum(int siteNum) {
		this.siteNum = siteNum;
	}
	/**
	 * @return the lineDirection
	 */
	public int getLineDirection() {
		return lineDirection;
	}
	/**
	 * @param lineDirection the lineDirection to set
	 */
	public void setLineDirection(int lineDirection) {
		this.lineDirection = lineDirection;
	}
	/**
	 * @return the lineID
	 */
	public int getLineID() {
		return lineID;
	}
	/**
	 * @param lineID the lineID to set
	 */
	public void setLineID(int lineID) {
		this.lineID = lineID;
	}
	/**
	 * @return the method
	 */
	public int getMethod() {
		return method;
	}
	/**
	 * @param method the method to set
	 */
	public void setMethod(int method) {
		this.method = method;
	}
	/**
	 * @return the type
	 */
	public int getType() {
		return type;
	}
	/**
	 * @param type the type to set
	 */
	public void setType(int type) {
		this.type = type;
	}
	/**
	 * @return the time
	 */
	public long getTime() {
		return time;
	}
	/**
	 * @param time the time to set
	 */
	public void setTime(long time) {
		this.time = time;
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "InOutStation [id=" + id + ", carState=" + carState + ", siteID=" + siteID + ", tripOrder=" + tripOrder
				+ ", siteNum=" + siteNum + ", lineDirection=" + lineDirection + ", lineID=" + lineID + ", method="
				+ method + ", type=" + type + ", time=" + time + "]";
	}
	
	
}
