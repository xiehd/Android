package com.uninew.db.dh.interfaces;

import java.util.List;

import com.uninew.db.dh.dao.DangerWarn;
/**
 * 危险信息的监听和回调接口
 * @author rong
 *
 */
public interface IWarnsListener {
	/**
	 * 查询危险信息回调接口
	 */
	public interface IQueryWarnsCallBack{
		/**
		 * 查询危险信息回调结果
		 * @param warins
		 */
		void queryWarns(List<DangerWarn> warns);
	}
	/**
	 * 危险信息更新监听接口
	 */
	public interface IWarnsNotifyListener{
		/**
		 * 更新危险信息监听结果
		 * @param warins
		 */
		void warnsNotify(List<DangerWarn> warns);
	}
}
