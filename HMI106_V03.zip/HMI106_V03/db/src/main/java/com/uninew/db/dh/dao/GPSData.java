package com.uninew.db.dh.dao;

public class GPSData {
	/** id **/
	private int id = -1;
	/** 状态 **/
	private int state = -1;
	/** 纬度 **/
	private double latitude = -1;
	/** 经度 **/
	private double longitude = -1;
	/** 高程 m **/
	private double elevation = -1;
	/** 速度 s **/
	private float speed = -1;
	/** 方向 0-360 **/
	private float direction = -1;
	/** 时间 毫秒 **/
	private long time = -1;
	/** 里程**/
	private double mileage = -1;
	
	public GPSData() {
		super();
	}

	public GPSData(int id,int state, double latitude, double longitude, double elevation, float speed, float direction,
			long time, double mileage) {
		super();
		this.id = id;
		this.state = state;
		this.latitude = latitude;
		this.longitude = longitude;
		this.elevation = elevation;
		this.speed = speed;
		this.direction = direction;
		this.time = time;
		this.mileage = mileage;
	}

	/**
	 * @return the state
	 */
	public int getState() {
		return state;
	}

	/**
	 * @param state the state to set
	 */
	public void setState(int state) {
		this.state = state;
	}

	/**
	 * @return the latitude
	 */
	public double getLatitude() {
		return latitude;
	}

	/**
	 * @param latitude the latitude to set
	 */
	public void setLatitude(double latitude) {
		this.latitude = latitude;
	}

	/**
	 * @return the longitude
	 */
	public double getLongitude() {
		return longitude;
	}

	/**
	 * @param longitude the longitude to set
	 */
	public void setLongitude(double longitude) {
		this.longitude = longitude;
	}

	/**
	 * @return the elevation
	 */
	public double getElevation() {
		return elevation;
	}

	/**
	 * @param elevation the elevation to set
	 */
	public void setElevation(double elevation) {
		this.elevation = elevation;
	}

	/**
	 * @return the speed
	 */
	public float getSpeed() {
		return speed;
	}

	/**
	 * @param speed the speed to set
	 */
	public void setSpeed(float speed) {
		this.speed = speed;
	}

	/**
	 * @return the direction
	 */
	public float getDirection() {
		return direction;
	}

	/**
	 * @param direction the direction to set
	 */
	public void setDirection(float direction) {
		this.direction = direction;
	}

	/**
	 * @return the time
	 */
	public long getTime() {
		return time;
	}

	/**
	 * @param time the time to set
	 */
	public void setTime(long time) {
		this.time = time;
	}

	/**
	 * @return the mileage
	 */
	public double getMileage() {
		return mileage;
	}

	/**
	 * @param mileage the mileage to set
	 */
	public void setMileage(double mileage) {
		this.mileage = mileage;
	}

	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "GPSData [id=" + id + ", state=" + state + ", latitude=" + latitude + ", longitude=" + longitude
				+ ", elevation=" + elevation + ", speed=" + speed + ", direction=" + direction + ", time=" + time
				+ ", mileage=" + mileage + "]";
	}

	
}
