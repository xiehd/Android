package com.uninew.db.dh.interfaces;

public class IUsersListener {
	public interface IQuerUserPwd{
		void querUserPwd(String pwd);
	}
	public interface IQuerUser{
		void querUser(String user);
	}
}
