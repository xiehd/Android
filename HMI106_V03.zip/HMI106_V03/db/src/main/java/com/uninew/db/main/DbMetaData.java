package com.uninew.db.main;

import android.net.Uri;
import android.provider.BaseColumns;

/**
 * 数据表元数据
 * 
 * @author Administrator
 *
 */
public class DbMetaData {

	/** 数据库名 */
	public static final String DATABASE_NAME = "uninew_bus.db";
	/** 数据库版本号 */
	public static final int DATABASE_VERSION = 2;
	/** 表名：路线 **/
	public static final String TABLE_NAME_ROUTE = "route";
	/** 表名：轨迹点 **/
	public static final String TABLE_NAME_POINT = "point";

	/** contentprovider的authorities,并保证于配置文件中一致 **/
	public static final String AUTHORITIES = "com.uninew.bus.MyContentProvider";

	/**
	 * 路线表
	 * 
	 * @author Administrator INTEGER,REAL,TEXT,BLOB,
	 */
	public static final class TableRode implements BaseColumns {
		/** 路线ID **/
		public static final String RID = "rid";
		/** 路线名称 **/
		public static final String ROUTE_NAME = "route_name";
		/** 开始时间 **/
		public static final String START_TIME = "start_time";
		/** 结束时间 **/
		public static final String END_TIME = "end_time";
		/** 起点名称 **/
		public static final String START_NAME = "start_name";
		/** 终点名称 **/
		public static final String END_NAME = "end_name";
		/** 是否收藏 **/
		public static final String ISCOLLECTION = "isCollection";
		/** 默认排序 **/
		public static final String DEFAULT_SORT_ORDER = "rid asc";
		/**
		 * 创建表的SQL语句
		 */
		public static final String SQL_CREATE_TABLE = "CREATE TABLE " + TABLE_NAME_ROUTE + "(" + RID
				+ " INTEGER PRIMARY KEY AUTOINCREMENT," + ROUTE_NAME + " TEXT," + START_TIME + " TIMESTAMP," + END_TIME
				+ " TIMESTAMP," + START_NAME + " TEXT," + END_NAME + " TEXT," + ISCOLLECTION + " INTEGER" + ");";
		/**
		 * 创建表的索引SQL语句
		 */
	}

	public static final class GuideboardTable implements BaseColumns {

		public static final String GUIDEBOARD_TABLE_NAME = "guideboard_table";
		public static final String GID = "g_id";
		public static final String DATE = "date";
		public static final String GUIDEBOARD_NUMBER = "guideboard_number";
		public static final String ROUTE_NUMBER = "route_number";
		public static final String BUS_NUMBER = "bus_number";
		public static final String BEGIN_STATION = "begin_station";
		public static final String END_STATION = "end_station";
		public static final String START_BUS_TIME = "start_bus_time";
		public static final String DRIVER_NAME = "driver_name";
		public static final Uri CONTENT_URI = Uri.parse("content://" + AUTHORITIES + "/" + GUIDEBOARD_TABLE_NAME + "/");
		public static final String CONTENT_TYPE = "vnd.android.cursor.dir/vnd.myprovider.guideboard";
		public static final String CONTENT_TYPE_ITEM = "vnd.android.cursor.item/vnd.myprovider.guideboard";
		// 默认的排序方法
		public static final String DEFAULT_SORT_ORDER = "g_id desc";

		/**
		 * 创建表的SQL语句
		 */
		public static final String SQL_CREATE_TABLE = "CREATE TABLE " + GUIDEBOARD_TABLE_NAME + "(" + GID
				+ " INTEGER PRIMARY KEY AUTOINCREMENT," + DATE + " TEXT," + GUIDEBOARD_NUMBER + " INTEGER,"
				+ ROUTE_NUMBER + " TEXT," + BUS_NUMBER + " TEXT," + BEGIN_STATION + " TEXT," + END_STATION + " TEXT,"
				+ START_BUS_TIME + " TEXT," + DRIVER_NAME + " TEXT" + ");";
	}

	/**
	 * 轨迹点表
	 * 
	 * @author Administrator
	 * 
	 */
	public static final class TablePoint implements BaseColumns {
		/** 轨迹点序号 **/
		public static final String PID = "pid";
		/** 所属路线ID **/
		public static final String RID = "rid";
		/** 经度 **/
		public static final String LONGITUDE = "longitude";
		/** 纬度 **/
		public static final String LATITUDE = "latitude";
		/** 高度 **/
		public static final String ALTITUDE = "altitude";
		/** 方向 **/
		public static final String DIRECTION = "direction";
		/** 时间 **/
		public static final String PTIME = "ptime";

		/** 默认排序 **/
		public static final String DEFAULT_SORT_ORDER = "driver_name desc";
		/**
		 * 创建表的SQL语句
		 */
		public static final String SQL_CREATE_TABLE = "CREATE TABLE " + TABLE_NAME_POINT + "(" + PID
				+ " INTEGER PRIMARY KEY AUTOINCREMENT," + RID + " INTEGER," + LONGITUDE + " REAL," + LATITUDE + " REAL,"
				+ ALTITUDE + " REAL," + DIRECTION + " REAL," + PTIME + " TIMESTAMP" + ");";
		/**
		 * 创建表的索引SQL语句
		 */
	}

	/**
	 * 排班信息
	 * 
	 * @author uninew
	 */
	public static class ArrangeMessage implements BaseColumns {
		/** 表名 **/
		public static final String ARRANGE_TABLE = "Arrange_table";
		/** 表的Uri **/
		public static final String CONTENT_URI_TERMINALCERTIFIED = AUTHORITIES + "/" + ARRANGE_TABLE;
		/** contentprovider 在该表的URL **/
		public static final Uri CONTENT_URI = Uri.parse("content://" + CONTENT_URI_TERMINALCERTIFIED + "/");
		/** 线路id **/
		public static final String LINE_ID = "LineID";
		/** 线路方向 **/
		public static final String LINE_DIRECTION = "LineDirection";
		/** 司机工号 **/
		public static final String DRIVER_ID = "DriverID";
		/** 司机姓名 **/
		public static final String DRIVER_NAME = "DriverName";
		/** 发车时间 **/
		public static final String START_TIME = "StartTime";
		/** 计划趟次 **/
		public static final String TRIP_ORDER = "TripOrder";
		/** 趟次属性 **/
		public static final String TYPE = "Type";
		/** 提示方式 **/
		public static final String NOTICE_TYPE = "NoticeType";
		/** 车牌号码 **/
		public static final String PLATE_ID = "PlateID";
		/** 运营状态 **/
		public static final String RUN_STATUS = "runStatus";

		/**
		 * 创建表的SQL语句
		 */
		public static final String SQL_CREATE_TABLE = "CREATE TABLE " + ARRANGE_TABLE + "(" + _ID
				+ " INTEGER PRIMARY KEY AUTOINCREMENT," + PLATE_ID + " TEXT," + DRIVER_ID + " TEXT," + LINE_ID
				+ " INTEGER," + LINE_DIRECTION + " INTEGER," + DRIVER_NAME + " TEXT," + START_TIME + " TEXT,"
				+ TRIP_ORDER + " INTEGER," + TYPE + " INTEGER," + RUN_STATUS + " INTEGER," + NOTICE_TYPE + " INTEGER"
				+ ");";
	}

	/** 注册应答 **/
	public static class TableTerminalCertified implements BaseColumns {
		/** 表名 **/
		public static final String TERMINAL_CERTIFIED_STRING = "tb_terminal_certified";
		/** 表的Uri **/
		public static final String CONTENT_URI_TERMINALCERTIFIED = AUTHORITIES + "/" + TERMINAL_CERTIFIED_STRING;
		/** contentprovider 在该表的URL **/
		public static final Uri CONTENT_URI = Uri.parse("content://" + CONTENT_URI_TERMINALCERTIFIED + "/");
		/** 设备电话号码 **/
		public static final String TERMINAL_NUMBER = "terninal_number";
		/** 省域ID **/
		public static final String PROVINCIAL_ID = "provincial_id";
		/** 市县ID **/
		public static final String COUNTY_ID = "county_id";
		/** 制造商ID **/
		public static final String MANUFACTURER_ID = "manufacturer_id";
		/** 终端型号 **/
		public static final String TERMINAL_TYPE = "terminal_type";
		/** 终端ID **/
		public static final String TERMINAL_ID = "terminal_id";
		/** 车牌颜色 **/
		public static final String TERMINAL_COLOR = "terminal_color";
		/** 车牌号 **/
		public static final String TERMINAL_FLAG = "terminal_flag";
		/** 应答流水号 **/
		public static final String STREAM_NUM = "stream_num";
		/** 应答时间 **/
		public static final String RECEIVE_TIME = "receive_time";
		/** 服务器IP **/
		public static final String SERVICE_IP = "service_ip";
		/** 服务器Port **/
		public static final String SERVICE_PORT = "service_port";
		/** 网络域名 **/
		public static final String SERVICE_DOMAINNAME = "service_domainName";
		/** 结果 **/
		public static final String RESULT = "result";
		/** 鉴权码 **/
		public static final String AUTHENTICATION = "authentication";

		/**
		 * 创建表的SQL语句
		 */
		public static final String SQL_CREATE_TABLE = "CREATE TABLE " + TERMINAL_CERTIFIED_STRING + "(" + _ID
				+ " INTEGER PRIMARY KEY AUTOINCREMENT," + TERMINAL_NUMBER + " TEXT," + PROVINCIAL_ID + " INTEGER,"
				+ COUNTY_ID + " INTEGER," + MANUFACTURER_ID + " TEXT," + TERMINAL_TYPE + " TEXT," + TERMINAL_ID
				+ " TEXT," + TERMINAL_COLOR + " INTEGER," + TERMINAL_FLAG + " TEXT," + STREAM_NUM + " INTEGER,"
				+ RECEIVE_TIME + " TEXT," + SERVICE_IP + " TEXT," + SERVICE_PORT + " INTEGER,"+ SERVICE_DOMAINNAME + " TEXT," + RESULT + " INTEGER,"
				+ AUTHENTICATION + " BLOB" + ");";
	}

	/**
	 * GPS信息
	 * 
	 * @author rong
	 *
	 */
	public static class GPSMessage implements BaseColumns {
		/** 表名 **/
		public static final String GPS_TABLE = "GPS_table";
		/** url **/
		public static final String CONTENT_URI_GPS = AUTHORITIES + "/" + GPS_TABLE;
		/** contentprovider 在该表的URL **/
		public static final Uri CONTENT_URI = Uri.parse("content://" + CONTENT_URI_GPS + "/");
		/** 经度 **/
		public static final String LATITUDE = "latitude";
		/** 纬度 **/
		public static final String LONGITUDE = "longitude";
		/** 时间 **/
		public static final String TIME = "time";
		/** 速度 **/
		public static final String SPEED = "speed";
		/** 方向 **/
		public static final String DIRECTION = "direction";
		/** 高程 **/
		public static final String ELEVATION = "elevation";
		
		/**
		 * 创建表的SQL语句
		 */
		public static final String SQL_CREATE_TABLE = "CREATE TABLE " + GPS_TABLE + "(" + _ID
				+ " INTEGER PRIMARY KEY AUTOINCREMENT," + LATITUDE + " INTEGER," + LONGITUDE + " INTEGER," + TIME
				+ " INTEGER," + SPEED + " REAL," + ELEVATION + " REAL," + DIRECTION + " REAL" + ");";
	}

	/**
	 * 进出站信息
	 * 
	 * @author rong
	 *
	 */
	public static class InOutStationMessage implements BaseColumns {
		/** 表名 **/
		public static final String IN_OUT_STATION_TABLE = "in_out_station_table";
		/** url **/
		public static final String CONTENT_URI_INOUTSTATION = AUTHORITIES + "/" + IN_OUT_STATION_TABLE;
		/** contentprovider 在该表的URL **/
		public static final Uri CONTENT_URI = Uri.parse("content://" + CONTENT_URI_INOUTSTATION + "/");
		/** 车辆状态 **/
		public static final String CAR_STATE = "car_state";
		/** 站点标识 **/
		public static final String SITE_ID = "site_id";
		/** 计划趟次 **/
		public static final String TRIP_ORDER = "trip_order";
		/** 站序 **/
		public static final String SITE_NUM = "site_num";
		/** 线路方向 **/
		public static final String LINE_DIRECTION = "line_direction";
		/** 线路标识 **/
		public static final String LINE_ID = "line_id";
		/** 报站类型 **/
		public static final String METHOD = "method";
		/** 进站时间 **/
		public static final String TIME = "time";
		/** 类型 **/
		public static final String TYPE = "type";
		/**
		 * 创建表的SQL语句
		 */
		public static final String SQL_CREATE_TABLE = "CREATE TABLE " + IN_OUT_STATION_TABLE + "(" + _ID
				+ " INTEGER PRIMARY KEY AUTOINCREMENT," + CAR_STATE + " INTEGER," + SITE_ID + " INTEGER," + TIME
				+ " INTEGER," + TRIP_ORDER + " INTEGER," + SITE_NUM + " INTEGER," + LINE_DIRECTION + " INTEGER,"
				+ LINE_ID + " INTEGER," + METHOD + " INTEGER," + TYPE + " INTEGER" + ");";
	}

	/**
	 * 文本信息
	 * 
	 * @author rong
	 *
	 */
	public static final class TextMessage implements BaseColumns {
		/** 表名 **/
		public static final String TEXT_TABLE = "text_data_table";
		/** 内容类型 **/
		public static final String CAR_STATE = "car_state";
		/** 场站标识 **/
		public static final String PLACE_ID = "place_id";
		/** 提示内容长度 **/
		public static final String TEXT_LEN = "text_len";
		/** 数据发送时间 **/
		public static final String TIME = "time";
		/** 内容 **/
		public static final String TEXT_DATA = "text_data";
		/** 提示方式 **/
		public static final String NOTICE_TYPE = "notice_type";
		/** contentprovider连接文本信息的uri **/
		public static final Uri CONTENT_URI = Uri.parse("content://" + AUTHORITIES + "/" + TEXT_TABLE + "/");

		/**
		 * 创建表的SQL语句
		 */
		public static final String SQL_CREATE_TABLE = "CREATE TABLE " + TEXT_TABLE + "(" + _ID
				+ " INTEGER PRIMARY KEY AUTOINCREMENT," + CAR_STATE + " INTEGER," + NOTICE_TYPE + " INTEGER," + PLACE_ID
				+ " INTEGER," + TEXT_LEN + " INTEGER," + TEXT_DATA + " TEXT," + TIME + " TEXT" + ");";
	}

	/**
	 * 报警日志
	 * 
	 * @author rong
	 *
	 */
	public static final class DangerWarnTable implements BaseColumns {
		/** 表名 **/
		public static final String DANGER_WARNIN_TABLE = "danger_warnin_table";
		/** 类型 **/
		public static final String TYPE = "type";
		/** 经度 **/
		public static final String LONGITUDE = "longitude";
		/** 纬度 **/
		public static final String LATITUDE = "latitude";
		/** 时间 **/
		public static final String TIME = "time";
		/** 内容 **/
		public static final String CONTENT = "content";
		/** contentprovider连接文本信息的uri **/
		public static final Uri CONTENT_URI = Uri.parse("content://" + AUTHORITIES + "/" + DANGER_WARNIN_TABLE + "/");
		/**
		 * 创建表的SQL语句
		 */
		public static final String SQL_CREATE_TABLE = "CREATE TABLE " + DANGER_WARNIN_TABLE + "(" + _ID
				+ " INTEGER PRIMARY KEY AUTOINCREMENT," + TYPE + " INTEGER," + LONGITUDE + " REAL," + LATITUDE
				+ " REAL,"+ CONTENT + " TEXT," + TIME + " TEXT" + ");";
	}

	/**
	 * 设备自检上报
	 * 
	 * @author rong
	 *
	 */
	public static final class SelfInspectionTable implements BaseColumns {
		/** 表名 **/
		public static final String SELF_INSPECTION_TABLE = "self_inspection_table";
		/** 车辆状态 **/
		public static final String CAR_STATE = "car_state";
		/** 外设状态 **/
		public static final String PLUGIN_STATE = "plugin_state";
		/** 经度 **/
		public static final String LONGITUDE = "longitude";
		/** 纬度 **/
		public static final String LATITUDE = "latitude";
		/** 时间 **/
		public static final String TIME = "time";
		/** contentprovider连接文本信息的uri **/
		public static final Uri CONTENT_URI = Uri.parse("content://" + AUTHORITIES + "/" + SELF_INSPECTION_TABLE + "/");
		/**
		 * 创建表的SQL语句
		 */
		public static final String SQL_CREATE_TABLE = "CREATE TABLE " + SELF_INSPECTION_TABLE + "(" + _ID
				+ " INTEGER PRIMARY KEY AUTOINCREMENT," + CAR_STATE + " INTEGER," + PLUGIN_STATE + " INTEGER,"
				+ LONGITUDE + " INTEGER," + LATITUDE + " INTEGER," + TIME + " INTEGER" + ");";
	}
	
	public static final class SettingTable implements BaseColumns {
		/** 表名 **/
		public static final String SETTING_TABLE = "setting_table";
		/** contentprovider连接文本信息的uri **/
		public static final Uri CONTENT_URI = Uri.parse("content://" + AUTHORITIES + "/" + SETTING_TABLE + "/");
		/** setting 名**/
		public static final String NAME = "name";
		/** setting 键 **/
		public static final String KEY = "key";
		/** setting 值**/
		public static final String VALUE = "value";
		/**
		 * 创建表的SQL语句
		 */
		public static final String SQL_CREATE_TABLE = "CREATE TABLE " + SETTING_TABLE + "(" +_ID
				+ " INTEGER PRIMARY KEY AUTOINCREMENT," +NAME+" TEXT UNIQUE,"+VALUE+" TEXT ,"+ KEY + " INTEGER"
				+");";
	}
	
	public static final class UsersTable implements BaseColumns{
		/** 表名 **/
		public static final String USERS_TABLE = "users_table";
		/** contentprovider连接文本信息的uri **/
		public static final Uri CONTENT_URI = Uri.parse("content://" + AUTHORITIES + "/" + USERS_TABLE + "/");
		/** setting 名**/
		public static final String NAME = "name";
		/** setting 键 **/
		public static final String KEY = "key";
		/**
		 * 创建表的SQL语句
		 */
		public static final String SQL_CREATE_TABLE = "CREATE TABLE " + USERS_TABLE + "(" +_ID
				+ " INTEGER PRIMARY KEY AUTOINCREMENT," +NAME+" TEXT UNIQUE,"+ KEY + " TEXT"
				+");";
	}
	
	public static final class ReSendStationTable implements BaseColumns{
		/** 表名 **/
		public static final String RESENDSTATION_TABLE = "resendstation_table";
		/** contentprovider连接文本信息的uri **/
		public static final Uri CONTENT_URI = Uri.parse("content://" + AUTHORITIES + "/" + RESENDSTATION_TABLE + "/");
		/** 线路Id**/
		public static final String ROUTE_ID = "route_id";
		/** 消息Id */
		public static final String MSG_ID = "msg_id";
		/** 站序*/
		public static final String STATION_NUM = "station_num";
		/** 进出站标志*/
		public static final String MARK = "mark";
		/** 消息体 **/
		public static final String MSG_BODY = "msg_body";
		/** 时间**/
		public static final String TIME = "time";
		/**
		 * 创建表的SQL语句
		 */
		public static final String SQL_CREATE_TABLE = "CREATE TABLE " + RESENDSTATION_TABLE + "(" +_ID
				+ " INTEGER PRIMARY KEY AUTOINCREMENT," +MSG_ID+" INTEGER,"+ ROUTE_ID + " TEXT,"+STATION_NUM+" INTEGER,"
				+MARK+" INTEGER,"+TIME+" INTEGER,"+ MSG_BODY + " BLOB"+");";
	}
	
	public static final class PlanWorkTable implements BaseColumns{
		/** 表名 **/
		public static final String PLANWORK_TABLE = "planwork_table";
		/** contentprovider连接文本信息的uri **/
		public static final Uri CONTENT_URI = Uri.parse("content://" + AUTHORITIES + "/" + PLANWORK_TABLE + "/");
		/** 消息Id */
		public static final String MSG_ID = "msg_id";
		/** 消息体 **/
		public static final String MSG_BODY = "msg_body";
		/** 时间**/
		public static final String TIME = "time";
		/**
		 * 创建表的SQL语句
		 */
		public static final String SQL_CREATE_TABLE = "CREATE TABLE " + PLANWORK_TABLE + "(" +_ID
				+ " INTEGER PRIMARY KEY AUTOINCREMENT," +MSG_ID+" INTEGER,"+TIME+" INTEGER,"+ MSG_BODY + " BLOB"+");";
	}
}
