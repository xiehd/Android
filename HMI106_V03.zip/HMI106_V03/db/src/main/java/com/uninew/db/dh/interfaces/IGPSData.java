package com.uninew.db.dh.interfaces;

import java.util.List;

import com.uninew.db.dh.dao.GPSData;
import com.uninew.db.dh.interfaces.IGPSDataListener.IQueryGPSCallBack;
/**
 * 此接口是gps信息的操作接口
 * @author rong
 *
 */
public interface IGPSData {
	/**
	 * 更新gps信息
	 * @param gpsDatas gps信息数据集合
	 */
	void updateGPS(List<GPSData> gpsDatas);
	
	/**
	 * 查询GPS信息
	 * @param times 为空时查询所有
	 * @param queryGPSCallBack 查询回调接口
	 */
	void queryGPS(long[] times,IQueryGPSCallBack queryGPSCallBack);
	
	/**
	 * 删除GPS信息
	 * @param ids 为空时删除所有
	 * @param resultCallBack 通用回调接口
	 */
	void delGPS(int[] ids,IResultCallBack resultCallBack);
}
