package com.uninew.db.dh.interfaces;

import java.util.List;

import com.uninew.db.dh.dao.DangerWarn;
import com.uninew.db.dh.interfaces.IWarnsListener.IQueryWarnsCallBack;
/**
 * 危险信息的操作接口
 * @author rong
 *
 */
public interface IWarns {
	/**
	 * 更新危险信息
	 * @param warins
	 */
	void updateWarns(List<DangerWarn> warins);
	/**
	 * 查询危险信息 根据报警类型
	 * @param types 
	 * 0：全部 1：超速报警 2：开门报警 3：紧急报警 4：危险报警 5：区域报警 6：路线报警 7：行驶时间报警
	 *            8：非法点火报警 9：非法位移报警
	 *            当types为空时也是查找全部
	 */
	void queryWarns(int[] types,IQueryWarnsCallBack queryWarinsCallBack);
	/**
	 * 删除危险信息
	 * @param ids 当为空时是查找所有，数据库表每列的id
	 */
	void delWarns(int[] ids,IResultCallBack resultCallBack);
}
