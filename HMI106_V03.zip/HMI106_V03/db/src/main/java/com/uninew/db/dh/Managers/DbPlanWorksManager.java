package com.uninew.db.dh.Managers;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.uninew.db.dh.dao.PlanWork;
import com.uninew.db.dh.interfaces.IResultCallBack;
import com.uninew.db.dh.interfaces.IWorks;
import com.uninew.db.dh.interfaces.IWorksListener.IQueryWorksCallBack;
import com.uninew.db.dh.interfaces.IWorksListener.IWorksNotifyListener;
import com.uninew.db.main.BaseContentResolver;
import com.uninew.db.main.DbMetaData.ArrangeMessage;
import com.uninew.db.main.IDBOpertionCallBack.IDeleteCallBack;
import com.uninew.db.main.IDBOpertionCallBack.IInsertCallBack;
import com.uninew.db.main.IDBOpertionCallBack.IQueryCallBack;
import com.uninew.db.main.IDBOpertionCallBack.IUpdateCallBack;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.ContentObserver;
import android.database.Cursor;
import android.net.Uri;
import android.os.Handler;
/**
 * 排班信息数据库的操作管理器
 * @author rong
 * 
 * 添加排班信息的更新监听器时，要先注册数据库变化监听器 （registerNotify() ）的方法，
 * 最好在生命周期开始时进行注册，
 * 而在生命周期结束时进行注销（unregisterNotify()）的方法，避免内存过量使用，
 * 然后添加监听器（addWorksNotifyListener）；
 */
public class DbPlanWorksManager implements IWorks {

	private static final String TAG = "PlanWorksManager";
	private Context mContext;
	/** 排班信息更新监听器*/
	private IWorksNotifyListener worksNotifyListener;
	/** 数据库操作类 */
	private BaseContentResolver mResolver;
	
	/**
	 * 类的初始化
	 * @param mContext 
	 */
	public DbPlanWorksManager(Context mContext){
		this.mContext = mContext;
		mResolver = BaseContentResolver.getInstance(mContext);
	}
	/**
	 * 添加监听器
	 * @param worksNotifyListener
	 */
	public void addWorksNotifyListener(IWorksNotifyListener worksNotifyListener) {
		this.worksNotifyListener = worksNotifyListener;
	}
	
	/**
	 * 移除监听器
	 */
	public void removeWorksNotifyListener(){
		if(worksNotifyListener != null){
			worksNotifyListener = null;
		}
	}
	/**
	 * 创建一个contentprovider的监听类
	 */
	private ContentObserver observer = new ContentObserver(new Handler()) {

		@SuppressLint("NewApi")
		@Override
		public void onChange(boolean selfChange, Uri uri) {
			// TODO Auto-generated method stub
			super.onChange(selfChange, uri);
//			Log.d(TAG, uri.toString());
		}

		@Override
		public void onChange(boolean selfChange) {
			// TODO Auto-generated method stub
			super.onChange(selfChange);
			queryWorks(null, new IQueryWorksCallBack() {

				@Override
				public void queryWroksCallBack(List<PlanWork> works) {
					if (works != null && !works.isEmpty()) {
						if (worksNotifyListener != null) {
							worksNotifyListener.worksNotify(works);
						}
					}
				}
			});
		}
	};

	@Override
	public void updateWorks(final List<PlanWork> works) {
		if (works != null && !works.isEmpty()) {
//			Log.e(TAG, "更新排班信息表");
			for (final PlanWork work : works) {
//				Log.d(TAG, work.toString());
				queryWorks(null, new IQueryWorksCallBack() {

					@Override
					public void queryWroksCallBack(List<PlanWork> pworks) {
//						Log.e(TAG, "更新排班信息表");
						if (pworks != null) {
							long minDay = getDay(pworks.get(0).getStartTime());
							long maxDay = getDay(work.getStartTime());
							if ((maxDay - minDay) >= 8 * 24 * 60 * 60 * 1000) {
								delWorks(new int[] { pworks.get(0).getId() }, null);
								final ContentValues values = new ContentValues();
								getValues(work, values);
								mResolver.insert(ArrangeMessage.CONTENT_URI, values, new IInsertCallBack() {

									@Override
									public void insertCallBack(Uri uri) {
										values.clear();
									}
								});
							} else {
								queryWorks(new String[]{work.getStartTime() }, new IQueryWorksCallBack() {
									
									@Override
									public void queryWroksCallBack(List<PlanWork> works) {
										if(works != null && !works.isEmpty()){
											final ContentValues values = new ContentValues();
											getValues(work, values);
											mResolver.update(ArrangeMessage.CONTENT_URI, values, ArrangeMessage.START_TIME + "=?",
													new String[] { work.getStartTime() }, new IUpdateCallBack() {

														@Override
														public void updateCallBack(int count) {
															values.clear();
														}
													});
										}else{
											final ContentValues values = new ContentValues();
											getValues(work, values);
											mResolver.insert(ArrangeMessage.CONTENT_URI, values, new IInsertCallBack() {

												@Override
												public void insertCallBack(Uri uri) {
													values.clear();
												}
											});
										}
									}
								});
							}
						} else {
//							Log.d(TAG, "表为空");
							final ContentValues values = new ContentValues();
							getValues(work, values);
							mResolver.insert(ArrangeMessage.CONTENT_URI, values, new IInsertCallBack() {

								@Override
								public void insertCallBack(Uri uri) {
									values.clear();
								}
							});

						}
					}
				});
			}
		}
	}

	@Override
	public void queryWorks(String[] startTimes, final IQueryWorksCallBack worksCallBack) {
		String selection = null;
		if (startTimes != null && startTimes.length > 0) {
			selection = ArrangeMessage.START_TIME+ "=?";
		} else {
			selection = null;
		}
		mResolver.query(ArrangeMessage.CONTENT_URI, null, selection , startTimes, "StartTime asc",
				new IQueryCallBack() {

					@Override
					public void queryCallBack(Cursor c) {
						List<PlanWork> wroks = null;
						if (c != null && c.getCount() > 0) {
							wroks = new ArrayList<PlanWork>();
							while (c.moveToNext()) {
								PlanWork work = new PlanWork();
								work.setId(c.getInt(c.getColumnIndex(ArrangeMessage._ID)));
								work.setDriverID(c.getString(c.getColumnIndex(ArrangeMessage.DRIVER_ID)));
								work.setName(c.getString(c.getColumnIndex(ArrangeMessage.DRIVER_NAME)));
								work.setStartTime(c.getString(c.getColumnIndex(ArrangeMessage.START_TIME)));
								work.setLineDirection(c.getInt(c.getColumnIndex(ArrangeMessage.LINE_DIRECTION)));
								work.setLineID(c.getInt(c.getColumnIndex(ArrangeMessage.LINE_ID)));
								work.setNoticeType(c.getInt(c.getColumnIndex(ArrangeMessage.NOTICE_TYPE)));
								work.setTripOrder(c.getInt(c.getColumnIndex(ArrangeMessage.TRIP_ORDER)));
								work.setType(c.getInt(c.getColumnIndex(ArrangeMessage.TYPE)));
								work.setRunStatus(c.getInt(c.getColumnIndex(ArrangeMessage.RUN_STATUS)));
								work.setPlateID(c.getString(c.getColumnIndex(ArrangeMessage.PLATE_ID)));
								wroks.add(work);
							}
							if (worksCallBack != null) {
								worksCallBack.queryWroksCallBack(wroks);
							}
							c.close();
						} else {
							if(c != null){
								c.close();
							}
							if (worksCallBack != null) {
								worksCallBack.queryWroksCallBack(wroks);
							}
						}
					}
				});
	}

	private void getValues(final PlanWork work, final ContentValues values) {
		if (work.getDriverID() != null) {
			values.put(ArrangeMessage.DRIVER_ID, work.getDriverID());
		}
		if (work.getName() != null) {
			values.put(ArrangeMessage.DRIVER_NAME, work.getName());
		}
		if (work.getLineID() != -1) {
			values.put(ArrangeMessage.LINE_ID, work.getLineID());
		}
		if (work.getLineDirection() != -1) {
			values.put(ArrangeMessage.LINE_DIRECTION, work.getLineDirection());
		}
		if (work.getNoticeType() != -1) {
			values.put(ArrangeMessage.NOTICE_TYPE, work.getNoticeType());
		}
		if (work.getStartTime() != null) {
			values.put(ArrangeMessage.START_TIME, work.getStartTime());
		}
		if (work.getTripOrder() != -1) {
			values.put(ArrangeMessage.TRIP_ORDER, work.getTripOrder());
		}
		if (work.getType() != -1) {
			values.put(ArrangeMessage.TYPE, work.getType());
		}
		if (work.getDriverID() != null) {
			values.put(ArrangeMessage.PLATE_ID, work.getPlateID());
		}
		if (work.getRunStatus() != -1) {
			values.put(ArrangeMessage.RUN_STATUS, work.getRunStatus());
		}
	}

	@Override
	public void delWorks(int[] ids, final IResultCallBack resultCallBack) {
		String[] strIds = null;
		String selection = null;
		if (ids != null) {
			selection = ArrangeMessage._ID + "=?";
			strIds = new String[ids.length];
			for (int i = 0; i < ids.length; i++) {
				strIds[i] = String.valueOf(ids[i]);
			}
		}
		mResolver.delete(ArrangeMessage.CONTENT_URI, selection , strIds, new IDeleteCallBack() {

			@Override
			public void deleteCallBack(int count) {
				if (count > 0) {
					if (resultCallBack != null) {
						resultCallBack.resultCallBack(true);
					}
				} else {
					if (resultCallBack != null) {
						resultCallBack.resultCallBack(false);
					}
				}
			}
		});
	}

	/**
	 * 注册数据库表变化监听器
	 */
	public void registerNotify() {
		mResolver.registerContentObserver(ArrangeMessage.CONTENT_URI, true, observer);

	}

	/**
	 * 注销数据库表变化监听器
	 */
	public void unregisterNotify() {
		mResolver.unregisterContentObserver(observer);
		removeWorksNotifyListener();
	}

	/**
	 * 得到时间
	 * 
	 * @param date
	 */
	private long getDay(String date) {
		long time = 0;
		try {
			SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			Date data = dateFormat.parse(date);
			time = data.getTime();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return time;
	}
}
