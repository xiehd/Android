package com.uninew.db.dh.dao;

public class MsgBaseDatas {
	private int id;//表Id
	private int msgId = -1;//消息Id
	private long time;//时间
	private byte[] msgBody;//消息体
	
	
	/**
	 *  
	 * @param msgId 消息Id
	 * @param time 时间
	 * @param msgBody 消息体
	 */
	public MsgBaseDatas(int msgId, long time, byte[] msgBody) {
		super();
		this.msgId = msgId;
		this.time = time;
		this.msgBody = msgBody;
	}
	
	
	public MsgBaseDatas() {
		super();
	}


	/**
	 * @return 消息Id
	 */
	public int getMsgId() {
		return msgId;
	}
	/**
	 * @param 消息Id
	 */
	public void setMsgId(int msgId) {
		this.msgId = msgId;
	}
	/**
	 * @return 时间
	 */
	public long getTime() {
		return time;
	}
	/**
	 * @param 时间
	 */
	public void setTime(long time) {
		this.time = time;
	}
	/**
	 * @return 消息体
	 */
	public byte[] getMsgBody() {
		return msgBody;
	}
	/**
	 * @param 消息体
	 */
	public void setMsgBody(byte[] msgBody) {
		this.msgBody = msgBody;
	}

	

	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}


	/**
	 * @param id the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}


	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "MsgBaseDatas [msgId=" + msgId + ", time=" + time + ", " + (msgBody != null ? "msgBody=" + msgBody : "")
				+ "]";
	}
	
	
}
