package com.uninew.db.dh.interfaces;

import java.util.List;

import com.uninew.db.dh.dao.MsgBaseDatas;

public interface ITaskWorksListener {
	/**
	 * 表信息查询回调
	 * @author rong
	 *
	 */
	public interface IQueryTaskListener{
		void queryCallBack(List<MsgBaseDatas> baseDatas);
	}
	/**
	 * 表信息更新监听
	 * @author rong
	 *
	 */
	public interface ITaskNotifyListener{
		void msgDatasNotify(List<MsgBaseDatas> baseDatas);
	}
}
