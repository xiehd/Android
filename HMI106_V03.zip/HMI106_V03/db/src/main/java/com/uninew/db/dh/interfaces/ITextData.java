package com.uninew.db.dh.interfaces;

import java.util.List;

import com.uninew.db.dh.dao.TextData;
import com.uninew.db.dh.interfaces.ITextDataListener.IQueryTextDataCallBack;
/**
 * 文本信息的操作接口
 * @author rong
 *
 */
public interface ITextData {
	/**
	 * 更新文本信息
	 * @param textDatas 文本信息
	 */
	void updateTextData(List<TextData> textDatas);
	/**
	 * 查询文本信息
	 * @param times 为空是查询所有
	 * @param textDataCallBack 结果回调
	 */
	void queryTextData(String[] times,IQueryTextDataCallBack textDataCallBack);
	/**
	 * 删除文本信息
	 * @param ids 为空删除所有
	 * @param resultCallBack 通用回调
	 */
	void delTextData(int[] ids,IResultCallBack resultCallBack);
}
