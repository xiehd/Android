package com.uninew.db.dh.interfaces;

import java.util.List;

import com.uninew.db.dh.dao.PlanWork;
import com.uninew.db.dh.interfaces.IWorksListener.IQueryWorksCallBack;
/**
 * 排班信息的操作接口
 * @author rong
 *
 */
public interface IWorks {
	/**
	 * 更新排班信息
	 * @param wroks
	 */
	void updateWorks(List<PlanWork> works);
	/**
	 * 查询排班信息，根据发车时间查询
	 * @param startTimes 当为空时查询所有，发车时间
	 * @param wroksCallBack 结果回调
	 */
	void queryWorks(String[] startTimes,IQueryWorksCallBack worksCallBack);
	/**
	 * 根据对应的id，删除排班信息
	 * @param ids 当为空时查询所有
	 * @param resultCallBack 通用回调
	 */
	void delWorks(int[] ids,IResultCallBack resultCallBack);
}
