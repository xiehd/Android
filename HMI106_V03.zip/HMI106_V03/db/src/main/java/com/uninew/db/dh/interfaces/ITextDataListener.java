package com.uninew.db.dh.interfaces;

import java.util.List;

import com.uninew.db.dh.dao.TextData;
/***
 * 文本信息监听和回调接口
 * @author rong
 *
 */
public interface ITextDataListener {
	/**
	 * 查询文本信息回调接口
	 */
	public interface IQueryTextDataCallBack{
		/**
		 * 查询文本信息回调结果
		 * @param textDatas
		 */
		void queryTextData(List<TextData> textDatas);
	}
	
	/**
	 * 更新文本信息监听接口
	 */
	public interface ITextDataNotifyListener{
		/**
		 * 更新文本信息监听结果
		 * @param textDatas
		 */
		void textDataNotify(List<TextData> textDatas);
	}
}
