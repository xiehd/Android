package com.uninew.db.dh.dao;

public class TextData {
	/**
	 * id
	 */
	private int id = -1;
	/**
	 * 车辆状态
	 */
	private int carState = -1;
	/**
	 * 场站标识
	 */
	private int placeID = -1;
	/**
	 * 提示内容文字长度
	 */
	private int textLen = -1;
	/**
	 * 提示内容
	 */
	private String text = null;
	/**
	 * 提示方式
	 */
	private int noticeType = -1;

	/**
	 * 时间
	 */
	private String time = null;

	public TextData() {
		super();
	}

	protected TextData(int id, int carState, int placeID, int textLen, String text, int noticeType, String time) {
		super();
		this.id = id;
		this.carState = carState;
		this.placeID = placeID;
		this.textLen = textLen;
		this.text = text;
		this.noticeType = noticeType;
		this.time = time;
	}

	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}

	/**
	 * @param id
	 *            the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}

	/**
	 * @return the carState
	 */
	public int getCarState() {
		return carState;
	}

	/**
	 * @param carState
	 *            the carState to set
	 */
	public void setCarState(int carState) {
		this.carState = carState;
	}

	/**
	 * @return the placeID
	 */
	public int getPlaceID() {
		return placeID;
	}

	/**
	 * @param placeID
	 *            the placeID to set
	 */
	public void setPlaceID(int placeID) {
		this.placeID = placeID;
	}

	/**
	 * @return the textLen
	 */
	public int getTextLen() {
		return textLen;
	}

	/**
	 * @param textLen
	 *            the textLen to set
	 */
	public void setTextLen(int textLen) {
		this.textLen = textLen;
	}

	/**
	 * @return the text
	 */
	public String getText() {
		return text;
	}

	/**
	 * @param text
	 *            the text to set
	 */
	public void setText(String text) {
		this.text = text;
	}

	/**
	 * @return the noticeType
	 */
	public int getNoticeType() {
		return noticeType;
	}

	/**
	 * @param noticeType
	 *            the noticeType to set
	 */
	public void setNoticeType(int noticeType) {
		this.noticeType = noticeType;
	}

	/**
	 * @return the time
	 */
	public String getTime() {
		return time;
	}

	/**
	 * @param time
	 *            the time to set
	 */
	public void setTime(String time) {
		this.time = time;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "TextData [id=" + id + ", carState=" + carState + ", placeID=" + placeID + ", textLen=" + textLen + ", "
				+ (text != null ? "text=" + text + ", " : "") + "noticeType=" + noticeType + ", "
				+ (time != null ? "time=" + time : "") + "]";
	}

}
