package com.uninew.db.dh.interfaces;

import com.uninew.db.dh.dao.TerminalCertified;
/**
 * 注册信息的监听和回调接口
 * @author rong
 *
 */
public interface IRegisterListener {

	/**
	 * 查询注册信息回调接口
	 */
	public interface IQueryRegisterMsgCallBack {
		/**
		 * 查询注册信息的返回结果
		 * @param mTerminalCertified 注册信息
		 */
		void queryRegisterCallBack(TerminalCertified mTerminalCertified);
	}

	/**
	 * 注册信息更新监听接口
	 */
	public interface IRegisterMsgListener {
		/**
		 * 更新注册信息的监听结果
		 * @param mTerminalCertified 注册信息
		 */
		void registerMsg(TerminalCertified mTerminalCertified);
	}

	/**
	 *	查询ip信息回调接口 
	 */
	public interface IQueryIpCallBack {
		/**
		 * 查询IP信息的回调结果
		 * @param domainName 域名
		 * @param ip IP地址
		 * @param port 端口号
		 */
		void queryIpCallBack(String domainName, String ip, int port);
	}

	/**
	 *	查询ip信息回调接口 
	 */
	public interface IQueryAuthCallBack {
		/**
		 * 查询鉴权码的回调结果
		 * @param auth 鉴权码
		 */
		void queryAuthCallBack(byte[] auth);
	}
	
}
