package com.uninew.db.dh.Managers;

import java.util.ArrayList;
import java.util.List;

import com.uninew.db.dh.dao.InOutStationMsg;
import com.uninew.db.dh.dao.MsgBaseDatas;
import com.uninew.db.dh.dao.TextData;
import com.uninew.db.dh.interfaces.IResultCallBack;
import com.uninew.db.dh.interfaces.ITaskWorks;
import com.uninew.db.dh.interfaces.IReSendStationListener.IQueryStationCallBack;
import com.uninew.db.dh.interfaces.ITaskWorksListener.IQueryTaskListener;
import com.uninew.db.dh.interfaces.ITaskWorksListener.ITaskNotifyListener;
import com.uninew.db.main.BaseContentResolver;
import com.uninew.db.main.DbMetaData.PlanWorkTable;
import com.uninew.db.main.DbMetaData.ReSendStationTable;
import com.uninew.db.main.DbMetaData.TextMessage;
import com.uninew.db.main.IDBOpertionCallBack.IDeleteCallBack;
import com.uninew.db.main.IDBOpertionCallBack.IInsertCallBack;
import com.uninew.db.main.IDBOpertionCallBack.IQueryCallBack;
import com.uninew.db.main.IDBOpertionCallBack.IUpdateCallBack;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.ContentObserver;
import android.database.Cursor;
import android.net.Uri;
import android.os.Handler;

public class DbTaskDatasManager implements ITaskWorks{

	/** 数据库操作类 */
	private BaseContentResolver mResolver;
	private static final String TAG = "PlanWorksManager";
	private Context mContext;
	private ITaskNotifyListener mNotifyListener;
	
	public DbTaskDatasManager(Context context) {
		mResolver = BaseContentResolver.getInstance(context);
		this.mContext = context;
	}
	
	/**
	 * 创建一个contentprovider的监听类
	 */
	private ContentObserver observer = new ContentObserver(new Handler()) {

		@SuppressLint("NewApi")
		@Override
		public void onChange(boolean selfChange, Uri uri) {
			// TODO Auto-generated method stub
			super.onChange(selfChange, uri);
//			Log.d(TAG, uri.toString());
		}

		@Override
		public void onChange(boolean selfChange) {
			// TODO Auto-generated method stub
			super.onChange(selfChange);
		
		}
	};
	
	@Override
	public void registerNotify() {
		mResolver.registerContentObserver(PlanWorkTable.CONTENT_URI, true, observer);
	}

	@Override
	public void unRegisterNotify() {
		mResolver.unregisterContentObserver(observer);
		removeMsgNotify();
	}

	

	@Override
	public void removeMsgNotify() {
		if(mNotifyListener != null){
			mNotifyListener = null;
		}
	}

	@Override
	public void updateMsgDatas(List<MsgBaseDatas> baseDatas) {
		if (baseDatas != null && !baseDatas.isEmpty()) {
			for (final MsgBaseDatas data : baseDatas) {
				queryMsgDatas(null, new IQueryTaskListener() {

					@Override
					public void queryCallBack(List<MsgBaseDatas> baseDatas) {
						if (baseDatas != null && baseDatas.size() > 20000) {
							delMsgDatas(new long[] { baseDatas.get(0).getTime() }, new IResultCallBack() {

								@Override
								public void resultCallBack(boolean result) {
									final ContentValues values = new ContentValues();
									 getValues(data, values);
									mResolver.insert(PlanWorkTable.CONTENT_URI, values, new IInsertCallBack() {

										@Override
										public void insertCallBack(Uri uri) {
											values.clear();
										}
									});
								}
							});
						} else {
							queryMsgDatas(new long[] { data.getTime() }, new IQueryTaskListener() {

								@Override
								public void queryCallBack(List<MsgBaseDatas> baseDatas) {
									if (baseDatas != null && !baseDatas.isEmpty()) {
										final ContentValues values = new ContentValues();
										getValues(data, values);
										mResolver.update(PlanWorkTable.CONTENT_URI, values,
												ReSendStationTable.TIME + "=?",
												new String[] { data.getTime() + "" }, new IUpdateCallBack() {

													@Override
													public void updateCallBack(int count) {
														values.clear();
													}
												});
									} else {
										final ContentValues values = new ContentValues();
										getValues(data, values);
										mResolver.insert(PlanWorkTable.CONTENT_URI, values, new IInsertCallBack() {

											@Override
											public void insertCallBack(Uri uri) {
												values.clear();
											}
										});
									}
								}
							});
						}
					}
				});
			}
		}
	}
	
	

	private void getValues(final MsgBaseDatas data, final ContentValues values) {
		if(data.getMsgId() != -1 ){
			values.put(PlanWorkTable.MSG_ID, data.getMsgId());
		}
		if(data.getTime() != -1 ){
			values.put(PlanWorkTable.TIME, data.getTime());
		}
		if(data.getMsgBody() != null ){
			values.put(PlanWorkTable.MSG_BODY, data.getMsgBody());
		}
		
	}

	@Override
	public void delMsgDatas(long[] time, final IResultCallBack resultCallBack) {
		String selection = null;
		String[] selectionArgs = null;
		if (time != null && time.length > 0) {
			//selection = TextMessage._ID+ "=?";
			int length = time.length;
			selectionArgs = new String[length];
			for (int i = 0; i < length; i++) {
				if(i == 0){
					selection = PlanWorkTable.TIME+ "=?";
				}else{
					selection += " or "+PlanWorkTable.TIME+ "=?";
				}
				selectionArgs[i] = String.valueOf(time[i]);
			}
		}
		mResolver.delete(PlanWorkTable.CONTENT_URI, selection, selectionArgs, new IDeleteCallBack() {

			@Override
			public void deleteCallBack(int count) {
				if (count > 0) {
					if (resultCallBack != null) {
						resultCallBack.resultCallBack(true);
					}
				} else {
					if (resultCallBack != null) {
						resultCallBack.resultCallBack(false);
					}
				}
			}
		});
	}

	@Override
	public void addMsgNotify(ITaskNotifyListener notifyListener) {
		this.mNotifyListener = notifyListener;
	}

	@Override
	public void queryMsgDatas(long[] time, final IQueryTaskListener queryTaskListener) {
		String selection = null;
		String[] selectionArgs = null;
		if (time != null && time.length > 0) {
			//selection = TextMessage._ID+ "=?";
			int length = time.length;
			selectionArgs = new String[length];
			for (int i = 0; i < length; i++) {
				if(i == 0){
					selection = PlanWorkTable.TIME+ "=?";
				}else{
					selection += " or "+PlanWorkTable.TIME+ "=?";
				}
				selectionArgs[i] = String.valueOf(time[i]);
			}
		}
		mResolver.query(PlanWorkTable.CONTENT_URI, null, selection, selectionArgs, "time asc", new IQueryCallBack() {

			@Override
			public void queryCallBack(Cursor c) {
				if (c != null && c.getCount() > 0) {
					List<MsgBaseDatas> datas = new ArrayList<>();
					while (c.moveToNext()) {
						MsgBaseDatas baseData = new MsgBaseDatas();
						baseData.setId(c.getInt(c.getColumnIndex(PlanWorkTable._ID)));
						baseData.setMsgBody(c.getBlob(c.getColumnIndex(PlanWorkTable.MSG_BODY)));
						baseData.setMsgId(c.getInt(c.getColumnIndex(PlanWorkTable.MSG_ID)));
						baseData.setTime(c.getLong(c.getColumnIndex(PlanWorkTable.TIME)));
						datas.add(baseData);
					}
					c.close();
					if (queryTaskListener != null) {
						queryTaskListener.queryCallBack(datas);
					}
				} else {
					if (c != null) {
						c.close();
					}
					if (queryTaskListener != null) {
						queryTaskListener.queryCallBack(null);
					}
				}
			}
		});
	}

}
