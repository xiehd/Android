package com.uninew.db.main;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import com.uninew.db.main.IDBOpertionCallBack.IDeleteCallBack;
import com.uninew.db.main.IDBOpertionCallBack.IInsertCallBack;
import com.uninew.db.main.IDBOpertionCallBack.IQueryCallBack;
import com.uninew.db.main.IDBOpertionCallBack.IUpdateCallBack;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.database.ContentObserver;
import android.database.Cursor;
import android.net.Uri;
/**
 * 数据库操作类
 * @author rong
 *
 */
public class BaseContentResolver {

	private static volatile BaseContentResolver instance;
	/**线程池 */
	private static ExecutorService cachedThreadPool;
	private static ContentResolver resolver;
	
	/**
	 * 使用单例模式进行类的初始化
	 * @param context
	 * @return
	 */
	public static BaseContentResolver getInstance(Context context) {
		if (instance != null) {

		} else {
			synchronized (BaseContentResolver.class) {
				if (instance == null) {
					instance = new BaseContentResolver();
				}
			}
		}
		resolver = context.getContentResolver();
		return instance;
	}

	private BaseContentResolver() {
		if (cachedThreadPool == null) {
			cachedThreadPool = Executors.newCachedThreadPool();
		}
	}
	
	/**
	 * 表中插入数据
	 * @param url 对应表的url
	 * @param values 添加的值
	 * @param insertCallBack 结果回调
	 */
	public synchronized void insert(final Uri url, final ContentValues values, final IInsertCallBack insertCallBack) {
		cachedThreadPool.execute(new Runnable() {

			@Override
			public void run() {
				try {
					insertCallBack.insertCallBack(resolver.insert(url, values));
				} catch (IllegalArgumentException e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	/**
	 * 更新表中的数据
	 * @param uri 对应表的uri
	 * @param values 更新的值
	 * @param where 更新的判断字段
	 * @param selectionArgs 更新的条件
	 * @param updateCallBack 结果回调
	 */
	public synchronized void update(final Uri uri, final ContentValues values, final String where,
			final String[] selectionArgs, final IUpdateCallBack updateCallBack) {
		cachedThreadPool.execute(new Runnable() {

			@Override
			public void run() {
				try {
					updateCallBack.updateCallBack(resolver.update(uri, values, where, selectionArgs));
				} catch (IllegalArgumentException e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * 删除表中的数据
	 * @param url 对应表的uri
	 * @param where 删除的判断字段
	 * @param selectionArgs 删除的条件
	 * @param deleteCallBack 结果返回
	 */
	public synchronized void delete(final Uri url, final String where, final String[] selectionArgs,
			final IDeleteCallBack deleteCallBack) {
		cachedThreadPool.execute(new Runnable() {

			@Override
			public void run() {
				try {
					deleteCallBack.deleteCallBack(resolver.delete(url, where, selectionArgs));
				} catch (IllegalArgumentException e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * 查询表中的数据
	 * @param uri 对应表的uri
	 * @param projection 查看的列名
	 * @param selection 查看的判断字段
	 * @param selectionArgs 查看条件
	 * @param sortOrder 排列方式
	 * @param queryCallBack 结果回调
	 */
	public synchronized void query(final Uri uri, final String[] projection, final String selection,
			final String[] selectionArgs, final String sortOrder, final IQueryCallBack queryCallBack) {
			cachedThreadPool.execute(new Runnable() {
			@Override
			public void run() {
				try {
					queryCallBack.queryCallBack(resolver.query(uri, projection, selection, selectionArgs, sortOrder));
				} catch (IllegalArgumentException e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * 注册数据库表变化监听器
	 */
	public void registerContentObserver(Uri uri, boolean notifyForDescendents, ContentObserver observer) {
		resolver.registerContentObserver(uri, notifyForDescendents, observer);
	}

	/**
	 * 注册数据库表变化监听器
	 */
	public void unregisterContentObserver(ContentObserver observer) {
		resolver.unregisterContentObserver(observer);
	}
}
