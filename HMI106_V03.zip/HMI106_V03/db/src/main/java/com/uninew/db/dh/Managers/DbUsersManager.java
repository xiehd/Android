package com.uninew.db.dh.Managers;

import com.uninew.db.dh.interfaces.IResultCallBack;
import com.uninew.db.dh.interfaces.IUsersData;
import com.uninew.db.dh.interfaces.IUsersListener.IQuerUser;
import com.uninew.db.dh.interfaces.IUsersListener.IQuerUserPwd;
import com.uninew.db.main.BaseContentResolver;
import com.uninew.db.main.DbMetaData.UsersTable;
import com.uninew.db.main.IDBOpertionCallBack.IInsertCallBack;
import com.uninew.db.main.IDBOpertionCallBack.IQueryCallBack;
import com.uninew.db.main.IDBOpertionCallBack.IUpdateCallBack;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;

public class DbUsersManager implements IUsersData {

	private BaseContentResolver baseContentResolver;
	private static final int ROOT_ID = 1;
	private static final int ADMIN_ID = 2;
	private static final String ROOT = "root";
	private static final String ROOT_PWD = "root";
	private static final String ADMIN = "admin";
	private static final String ADMIN_PWD = "admin";

	public DbUsersManager(Context context) {
		baseContentResolver = BaseContentResolver.getInstance(context);
		baseContentResolver.query(UsersTable.CONTENT_URI, null, UsersTable._ID + "=?", new String[] { ROOT_ID + "" },
				"_id asc", new IQueryCallBack() {

					@Override
					public void queryCallBack(Cursor c) {
						if (c == null || c.getCount() < 1) {
							if(c != null ){
								c.close();
							}
							final ContentValues values = new ContentValues();
							values.put(UsersTable.NAME, ROOT);
							values.put(UsersTable.KEY, ROOT_PWD);
							baseContentResolver.insert(UsersTable.CONTENT_URI, values, new IInsertCallBack() {

								@Override
								public void insertCallBack(Uri uri) {
									values.clear();
								}
							});
						}else{
							c.close();
						}
					}

				});
		baseContentResolver.query(UsersTable.CONTENT_URI, null, UsersTable._ID + "=?", new String[] { ADMIN_ID + "" },
				"_id asc", new IQueryCallBack() {

					@Override
					public void queryCallBack(Cursor c) {
						if (c == null || c.getCount() < 1) {
							if(c != null ){
								c.close();
							}
							final ContentValues values = new ContentValues();
							values.put(UsersTable.NAME, ADMIN);
							values.put(UsersTable.KEY, ADMIN_PWD);
							baseContentResolver.insert(UsersTable.CONTENT_URI, values, new IInsertCallBack() {

								@Override
								public void insertCallBack(Uri uri) {
									values.clear();
								}
							});
						}else{
							c.close();
						}
					}
				});
	}

	@Override
	public void setUserPwd(String user, String pwd, final IResultCallBack resultCallBack) {
		if (user.equals(ROOT)) {
			final ContentValues values = new ContentValues();
			values.put(UsersTable.NAME, user);
			values.put(UsersTable.KEY, pwd);
			baseContentResolver.update(UsersTable.CONTENT_URI, values, UsersTable._ID + "=?",
					new String[] { ROOT_ID + "" }, new IUpdateCallBack() {

						@Override
						public void updateCallBack(int count) {
							values.clear();
							if (count > 0) {
								if (resultCallBack != null) {
									resultCallBack.resultCallBack(true);
								}
							} else {
								if (resultCallBack != null) {
									resultCallBack.resultCallBack(false);
								}
							}
						}
					});
		} else {
			final ContentValues values = new ContentValues();
			values.put(UsersTable.NAME, user);
			values.put(UsersTable.KEY, pwd);
			baseContentResolver.update(UsersTable.CONTENT_URI, values, UsersTable._ID + "=?",
					new String[] { ADMIN_ID + "" }, new IUpdateCallBack() {

						@Override
						public void updateCallBack(int count) {
							values.clear();
							if (count > 0) {
								if (resultCallBack != null) {
									resultCallBack.resultCallBack(true);
								}
							} else {
								if (resultCallBack != null) {
									resultCallBack.resultCallBack(false);
								}
							}
						}
					});
		}

	}

	@Override
	public void querUserPwd(String user, final IQuerUserPwd querUserPwd) {
		baseContentResolver.query(UsersTable.CONTENT_URI, null, UsersTable.NAME + "=?", new String[] { user },
				"_id asc", new IQueryCallBack() {

					@Override
					public void queryCallBack(Cursor c) {
						if (c == null || c.getCount() < 1) {
							if(c != null ){
								c.close();
							}
							if (querUserPwd != null) {
								querUserPwd.querUserPwd(null);
							}
						} else {
							if (c.moveToNext()) {
								String pwd = c.getString(c.getColumnIndex(UsersTable.KEY));
								if (querUserPwd != null) {
									querUserPwd.querUserPwd(pwd);
								}
							}
							c.close();
						}
					}
				});
	}

	@Override
	public void querUser(final IQuerUser querUser) {
		baseContentResolver.query(UsersTable.CONTENT_URI, null, UsersTable._ID + "=?", new String[] { ADMIN_ID + "" },
				"_id asc", new IQueryCallBack() {

					@Override
					public void queryCallBack(Cursor c) {
						if (c == null || c.getCount() < 1) {
							if(c != null ){
								c.close();
							}
							if (querUser != null) {
								querUser.querUser(null);
							}
						} else {
							if (c.moveToNext()) {
								String pwd = c.getString(c.getColumnIndex(UsersTable.NAME));
								if (querUser != null) {
									querUser.querUser(pwd);
								}
							}
							c.close();
						}
					}
				});
	}

	@Override
	public void querRootUser(final IQuerUser querUser) {
		baseContentResolver.query(UsersTable.CONTENT_URI, null, UsersTable._ID + "=?", new String[] { ROOT_ID + "" },
				"_id asc", new IQueryCallBack() {

					@Override
					public void queryCallBack(Cursor c) {
						if (c == null || c.getCount() < 1) {
							if(c != null ){
								c.close();
							}
							if (querUser != null) {
								querUser.querUser(null);
							}
						} else {
							if (c.moveToNext()) {
								String pwd = c.getString(c.getColumnIndex(UsersTable.NAME));
								if (querUser != null) {
									querUser.querUser(pwd);
								}
							}
							c.close();
						}
					}
				});
	}

}
