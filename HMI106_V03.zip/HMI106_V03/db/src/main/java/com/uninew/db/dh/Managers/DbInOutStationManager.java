package com.uninew.db.dh.Managers;

import java.util.ArrayList;
import java.util.List;

import com.uninew.db.dh.dao.InOutStation;
import com.uninew.db.dh.interfaces.IInOutStation;
import com.uninew.db.dh.interfaces.IInOutStationListener.IQueryStationCallBack;
import com.uninew.db.dh.interfaces.IInOutStationListener.IStationNotifyListener;
import com.uninew.db.dh.interfaces.IResultCallBack;
import com.uninew.db.main.BaseContentResolver;
import com.uninew.db.main.DbMetaData.InOutStationMessage;
import com.uninew.db.main.IDBOpertionCallBack.IDeleteCallBack;
import com.uninew.db.main.IDBOpertionCallBack.IInsertCallBack;
import com.uninew.db.main.IDBOpertionCallBack.IQueryCallBack;
import com.uninew.db.main.IDBOpertionCallBack.IUpdateCallBack;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.ContentObserver;
import android.database.Cursor;
import android.net.Uri;
import android.os.Handler;
/**
 * 进出站数据库的操作管理器
 * @author rong
 * 
 * 添加进出站信息的更新监听器时，要先注册数据库变化监听器 （registerNotify() ）的方法，
 * 最好在生命周期开始时进行注册，
 * 而在生命周期结束时进行注销（unregisterNotify()）的方法，避免内存过量使用，
 * 然后添加监听器（addStationNotifyListener）；
 */
public class DbInOutStationManager implements IInOutStation {

	private static final String TAG = "GPSDataManager";
	private Context mContext;
	/** 进出站信息更新监听器*/
	private IStationNotifyListener stationNotifyListener;
	/** 数据库操作类 */
	private BaseContentResolver mResolver;
	
	/**
	 * 类的初始化
	 * @param mContext
	 */
	public DbInOutStationManager(Context mContext){
		this.mContext = mContext;
		mResolver = BaseContentResolver.getInstance(mContext);
	}
	
	/**
	 * 添加监听器
	 * @param stationNotifyListener
	 */
	public void addStationNotifyListener(IStationNotifyListener stationNotifyListener) {
		this.stationNotifyListener = stationNotifyListener;
	}
	
	/**
	 * 移除监听器
	 */
	public void removeStationNotifyListener(){
		if(stationNotifyListener != null){
			stationNotifyListener = null;
		}
	}
	
	/**
	 * 创建一个contentprovider的监听类
	 */
	private ContentObserver observer = new ContentObserver(new Handler()) {

		@SuppressLint("NewApi")
		@Override
		public void onChange(boolean selfChange, Uri uri) {
			// TODO Auto-generated method stubinter
			super.onChange(selfChange, uri);
		}

		@Override
		public void onChange(boolean selfChange) {
			// TODO Auto-generated method stub
			super.onChange(selfChange);
			queryInOutStation(null, new IQueryStationCallBack() {
				
				@Override
				public void queryStation(List<InOutStation> stations) {
					if (stations != null && !stations.isEmpty()) {
						if(stationNotifyListener != null){
							stationNotifyListener.stationNotify(stations);
						}
					}
				}
			});
		}
	};

	@Override
	public void updateInOutStation(List<InOutStation> stations) {
		if (stations != null && !stations.isEmpty()) {
			for (final InOutStation station : stations) {
				queryInOutStation(null, new IQueryStationCallBack() {

					@Override
					public void queryStation(List<InOutStation> stations) {
						if (stations != null && stations.size() > 20000) {
							delInOutStation(new int[] { stations.get(0).getId() }, new IResultCallBack() {

								@Override
								public void resultCallBack(boolean result) {
									final ContentValues values = new ContentValues();
									getValues(station, values);
									mResolver.insert(InOutStationMessage.CONTENT_URI, values, new IInsertCallBack() {

										@Override
										public void insertCallBack(Uri uri) {
											values.clear();
										}
									});
								}
							});
						} else {
							queryInOutStation(new long[] { station.getTime() }, new IQueryStationCallBack() {

								@Override
								public void queryStation(List<InOutStation> stations) {
									if (stations != null && !stations.isEmpty()) {
										final ContentValues values = new ContentValues();
										getValues(station, values);
										mResolver.update(InOutStationMessage.CONTENT_URI, values,
												InOutStationMessage.TIME+ "=?", new String[] { station.getTime() + "" },
												new IUpdateCallBack() {

													@Override
													public void updateCallBack(int count) {
														values.clear();
													}
												});
									}else{
										final ContentValues values = new ContentValues();
										getValues(station, values);
										mResolver.insert(InOutStationMessage.CONTENT_URI, values, new IInsertCallBack() {
											
											@Override
											public void insertCallBack(Uri uri) {
												values.clear();
											}
										});
									}
								}
							});
						}
					}
				});
			}
		}
	}

	private void getValues(final InOutStation station, final ContentValues values) {
		if (station.getCarState() != -1)
			values.put(InOutStationMessage.CAR_STATE, station.getCarState());
		if (station.getSiteID() != -1)
			values.put(InOutStationMessage.SITE_ID, station.getSiteID());
		if (station.getTripOrder() != -1)
			values.put(InOutStationMessage.TRIP_ORDER, station.getTripOrder());
		if (station.getSiteNum() != -1)
			values.put(InOutStationMessage.SITE_NUM, station.getSiteNum());
		if (station.getLineDirection() != -1)
			values.put(InOutStationMessage.LINE_DIRECTION, station.getLineDirection());
		if (station.getLineID() != -1)
			values.put(InOutStationMessage.LINE_ID, station.getLineID());
		if (station.getMethod() != -1)
			values.put(InOutStationMessage.METHOD, station.getMethod());
		if (station.getType() != -1)
			values.put(InOutStationMessage.TYPE, station.getType());
		if (station.getTime() != -1)
			values.put(InOutStationMessage.TIME, station.getTime());
	}

	@Override
	public void queryInOutStation(long[] times, final IQueryStationCallBack stationCallBack) {
		String selection = null;
		String[] selectionArgs = null;
		if (times != null && times.length > 0) {
			selection = InOutStationMessage.TIME+ "=?";
			int length = times.length;
			selectionArgs = new String[length];
			for (int i = 0; i < length; i++) {
				selectionArgs[i] = String.valueOf(times[i]);
			}
		}
		mResolver.query(InOutStationMessage.CONTENT_URI, null, selection, selectionArgs, "time asc",
				new IQueryCallBack() {

					@Override
					public void queryCallBack(Cursor c) {
						if (c != null && c.getCount() > 0) {
							List<InOutStation> staions = new ArrayList<>();
							while (c.moveToNext()) {
								InOutStation staion = new InOutStation();
								staion.setId(c.getInt(c.getColumnIndex(InOutStationMessage._ID)));
								staion.setCarState(c.getInt(c.getColumnIndex(InOutStationMessage.CAR_STATE)));
								staion.setSiteID(c.getInt(c.getColumnIndex(InOutStationMessage.SITE_ID)));
								staion.setSiteNum(c.getInt(c.getColumnIndex(InOutStationMessage.SITE_NUM)));
								staion.setTripOrder(c.getInt(c.getColumnIndex(InOutStationMessage.TRIP_ORDER)));
								staion.setLineDirection(c.getInt(c.getColumnIndex(InOutStationMessage.LINE_DIRECTION)));
								staion.setLineID(c.getInt(c.getColumnIndex(InOutStationMessage.LINE_ID)));
								staion.setMethod(c.getInt(c.getColumnIndex(InOutStationMessage.METHOD)));
								staion.setType(c.getInt(c.getColumnIndex(InOutStationMessage.TYPE)));
								staion.setCarState(c.getInt(c.getColumnIndex(InOutStationMessage.CAR_STATE)));
								staion.setTime(c.getLong(c.getColumnIndex(InOutStationMessage.TIME)));
								staions.add(staion);
							}
							c.close();
							if (stationCallBack != null) {
								stationCallBack.queryStation(staions);
							}
						} else {
							if(c != null){
								c.close();
							}
							if (stationCallBack != null) {
								stationCallBack.queryStation(null);
							}
						}
					}
				});
	}

	@Override
	public void delInOutStation(int[] ids, final IResultCallBack resultCallBack) {
		String selection = null;
		String[] selectionArgs = null;
		if (ids != null && ids.length > 0) {
			selection = InOutStationMessage._ID+ "=?";
			int length = ids.length;
			selectionArgs = new String[length];
			for (int i = 0; i < length; i++) {
				selectionArgs[i] = String.valueOf(ids[i]);
			}
		}
		mResolver.delete(InOutStationMessage.CONTENT_URI, selection, selectionArgs, new IDeleteCallBack() {

			@Override
			public void deleteCallBack(int count) {
				if (count > 0) {
					if (resultCallBack != null) {
						resultCallBack.resultCallBack(true);
					}
				} else {
					if (resultCallBack != null) {
						resultCallBack.resultCallBack(false);
					}
				}
			}
		});
	}

	/**
	 * 注册数据库表变化监听器
	 */
	public void registerNotify() {
		mResolver.registerContentObserver(InOutStationMessage.CONTENT_URI, true, observer);

	}

	/**
	 * 注销数据库表变化监听器
	 */
	public void unregisterNotify() {
		mResolver.unregisterContentObserver(observer);
		removeStationNotifyListener();
	}

}
