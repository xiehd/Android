package com.uninew.db.dh.interfaces;

import com.uninew.db.dh.interfaces.ISettingsListener.IBroadcasterCallBack;
import com.uninew.db.dh.interfaces.ISettingsListener.IBroadcasterListener;
import com.uninew.db.dh.interfaces.ISettingsListener.IComModelCallBack;
import com.uninew.db.dh.interfaces.ISettingsListener.IComModelListener;
import com.uninew.db.dh.interfaces.ISettingsListener.IRunStateCallBack;
import com.uninew.db.dh.interfaces.ISettingsListener.IRunStateListener;
import com.uninew.db.dh.interfaces.ISettingsListener.IUdpIpAndPortListener;
import com.uninew.db.dh.interfaces.ISettingsListener.IVideoModerCallBack;
import com.uninew.db.dh.interfaces.ISettingsListener.IVideoModerListener;
import com.uninew.db.dh.interfaces.ISettingsListener.IVoiceFormatCallBack;
import com.uninew.db.dh.interfaces.ISettingsListener.IVoiceFormatListener;
/**
 * Setting信息的操作接口
 * @author rong
 *
 */
public interface ISettings {

	/**
	 * 设置运营模式
	 * @param key 1-运营，2-停运
	 */
	void setRunning(int key);
	/**
	 * 查询运营模式
	 * @param runStateCallBack 结果回调
	 */
	void queryRunning(IRunStateCallBack runStateCallBack);
	/**
	 * 设置报站模式
	 * @param key 1-自动，2-手动
	 */
	void setBroadcaster(int key);
	/**
	 * 查询报站模式
	 * @param broadcasterCallBack 结果回调
	 */
	void queryBroadcaster(IBroadcasterCallBack broadcasterCallBack);
	/**
	 * 设置语音格式
	 * @param key 1-mp3,2-wav
	 */
	void setVoiceFormat(int key);
	/**
	 * 查询语音格式
	 * @param voiceFormatCallBack 结果回调
	 */
	void queryVoiceFormat(IVoiceFormatCallBack voiceFormatCallBack);
	/**
	 * 设置视频模式
	 * @param key 1-DVR，2-后门
	 */
	void setVideoModel(int key);
	/**
	 * 查询视频模式
	 * @param videoModerCallBack 结果回调
	 */
	void queryVideoModel(IVideoModerCallBack videoModerCallBack);
	/**
	 * 设置网络模式
	 * @param key 1-网络，2-串口
	 */
	void setComModel(int key);
	/**
	 * 查询网络模式
	 * @param comModelCallBack 结果回调
	 */
	void queryComModel(IComModelCallBack comModelCallBack);
	
	/**
	 * 设置UDP服务器的ip和端口
	 * @param ip
	 * @param port
	 */
	void setUdpIpAndPort(String ip,int port);
	/**
	 * 查看udp信息
	 * @param udpIpAndPortListener 结果回调
	 */
	void queryUdpIpAndPort(IUdpIpAndPortListener udpIpAndPortListener);
}
