package com.uninew.db.dh.Managers;

import java.util.ArrayList;
import java.util.List;

import com.uninew.db.dh.dao.GPSData;
import com.uninew.db.dh.interfaces.IGPSData;
import com.uninew.db.dh.interfaces.IGPSDataListener.IGPSNotifyListener;
import com.uninew.db.dh.interfaces.IGPSDataListener.IQueryGPSCallBack;
import com.uninew.db.dh.interfaces.IResultCallBack;
import com.uninew.db.main.BaseContentResolver;
import com.uninew.db.main.DbMetaData.GPSMessage;
import com.uninew.db.main.IDBOpertionCallBack.IDeleteCallBack;
import com.uninew.db.main.IDBOpertionCallBack.IInsertCallBack;
import com.uninew.db.main.IDBOpertionCallBack.IQueryCallBack;
import com.uninew.db.main.IDBOpertionCallBack.IUpdateCallBack;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.ContentObserver;
import android.database.Cursor;
import android.net.Uri;
import android.os.Handler;
/**
 * GPS信息数据库的操作管理器
 * @author rong
 * 
 * 添加gps信息的更新监听器时，要先注册数据库变化监听器 （registerNotify() ）的方法，
 * 最好在生命周期开始时进行注册，
 * 而在生命周期结束时进行注销（unregisterNotify()）的方法，避免内存过量使用，
 * 然后添加监听器（addGPSNotifyListener）；
 */
public class DbGPSDataManager implements IGPSData {

	private static final String TAG = "GPSDataManager";
	private Context mContext;
	/** gps信息更新的监听器 */
	private IGPSNotifyListener gpsNotifyListener;
	/** 数据库操作类 */
	private BaseContentResolver mResolver;
	
	/**
	 * 类的初始化
	 * @param mContext 
	 */
	public DbGPSDataManager(Context mContext){
		this.mContext = mContext;
		mResolver = BaseContentResolver.getInstance(mContext);
	}
	
	/**
	 * 添加gps信息的监听器
	 * @param gpsNotifyListener
	 */
	public void addGPSNotifyListener(IGPSNotifyListener gpsNotifyListener) {
		this.gpsNotifyListener = gpsNotifyListener;
	}
	
	/**
	 * 创建一个contentprovider的监听类
	 */
	private ContentObserver observer = new ContentObserver(new Handler()) {

		@SuppressLint("NewApi")
		@Override
		public void onChange(boolean selfChange, Uri uri) {
			// TODO Auto-generated method stub
			super.onChange(selfChange, uri);
//			Log.d(TAG, uri.toString());
		}

		@Override
		public void onChange(boolean selfChange) {
			// TODO Auto-generated method stub
			super.onChange(selfChange);
			queryGPS(null, new IQueryGPSCallBack() {

				@Override
				public void queryGPSCallBack(List<GPSData> gpsDatas) {
					if (gpsDatas != null && !gpsDatas.isEmpty()) {
						if (gpsNotifyListener != null) {
							gpsNotifyListener.gpsNotify(gpsDatas);
						}
					}
				}
			});
		}
	};
	
	@Override
	public void updateGPS(List<GPSData> gpsDatas) {
		if (gpsDatas != null && !gpsDatas.isEmpty()) {
			for (final GPSData gpsData : gpsDatas) {
				queryGPS(null, new IQueryGPSCallBack() {

					@Override
					public void queryGPSCallBack(List<GPSData> gpsDatas) {
						if (gpsDatas != null && gpsDatas.size() > 20000) {
							delGPS(new int[] { gpsDatas.get(0).getId() }, new IResultCallBack() {

								@Override
								public void resultCallBack(boolean result) {
									final ContentValues values = new ContentValues();
									getValues(gpsData, values);
									mResolver.insert(GPSMessage.CONTENT_URI, values, new IInsertCallBack() {

										@Override
										public void insertCallBack(Uri uri) {
											values.clear();
										}
									});
								}
							});
						} else {
							queryGPS(new long[]{gpsData.getTime()}, new IQueryGPSCallBack() {
								
								@Override
								public void queryGPSCallBack(List<GPSData> gpsDatas) {
									if(gpsDatas != null && !gpsDatas.isEmpty()){
										final ContentValues values = new ContentValues();
										getValues(gpsData, values);
										mResolver.update(GPSMessage.CONTENT_URI, values, GPSMessage.TIME+"=?",
												new String[] { gpsData.getTime() + "" }, new IUpdateCallBack() {

													@Override
													public void updateCallBack(int count) {
														values.clear();
													}
												});
									}else{
										final ContentValues values = new ContentValues();
										getValues(gpsData, values);
										mResolver.insert(GPSMessage.CONTENT_URI, values, new IInsertCallBack() {
											
											@Override
											public void insertCallBack(Uri uri) {
												values.clear();
											}
										});
									}
								}
							});
						}
					}
				});
			}
		}
	}

	private void getValues(final GPSData gpsData, final ContentValues values) {
		if (gpsData.getLatitude() != -1) {
			values.put(GPSMessage.LATITUDE, gpsData.getLatitude());
		}
		if (gpsData.getLongitude() != -1) {
			values.put(GPSMessage.LONGITUDE, gpsData.getLongitude());
		}
		if (gpsData.getSpeed() != -1) {
			values.put(GPSMessage.SPEED, gpsData.getSpeed());
		}
		if (gpsData.getDirection() != -1) {
			values.put(GPSMessage.DIRECTION, gpsData.getDirection());
		}
		if (gpsData.getTime() != -1) {
			values.put(GPSMessage.TIME, gpsData.getTime());
		}
		if(gpsData.getElevation() != -1){
			values.put(GPSMessage.ELEVATION, gpsData.getElevation());
		}
	}

	@Override
	public void queryGPS(long[] times, final IQueryGPSCallBack queryGPSCallBack) {
		String selection = null;
		String[] selectionArgs = null;
		if (times != null && times.length > 0) {
			selection = GPSMessage.TIME +"=?";
			int length = times.length;
			selectionArgs = new String[length];
			for (int i = 0; i < length; i++) {
				selectionArgs[i] = String.valueOf(times[i]);
			}
		}
		mResolver.query(GPSMessage.CONTENT_URI, null, selection, selectionArgs, "time asc", new IQueryCallBack() {

			@Override
			public void queryCallBack(Cursor c) {
				if (c != null && c.getCount() > 0) {
					List<GPSData> gpsDatas = new ArrayList<>();
					while (c.moveToNext()) {
						GPSData gpsData = new GPSData();
						gpsData.setId(c.getInt(c.getColumnIndex(GPSMessage._ID)));
						gpsData.setLatitude(c.getDouble(c.getColumnIndex(GPSMessage.LATITUDE)));
						gpsData.setLongitude(c.getDouble(c.getColumnIndex(GPSMessage.LONGITUDE)));
						gpsData.setSpeed(c.getFloat(c.getColumnIndex(GPSMessage.SPEED)));
						gpsData.setDirection(c.getFloat(c.getColumnIndex(GPSMessage.DIRECTION)));
						gpsData.setElevation(c.getFloat(c.getColumnIndex(GPSMessage.ELEVATION)));
						gpsData.setTime(c.getLong(c.getColumnIndex(GPSMessage.TIME)));
						gpsDatas.add(gpsData);
					}
					if (queryGPSCallBack != null) {
						queryGPSCallBack.queryGPSCallBack(gpsDatas);
					}
					c.close();
				} else {
					if(c != null){
						c.close();
					}
					if (queryGPSCallBack != null) {
						queryGPSCallBack.queryGPSCallBack(null);
					}
				}
			}
		});
	}

	@Override
	public void delGPS(int[] ids, final IResultCallBack resultCallBack) {
		String selection = null;
		String[] selectionArgs = null;
		if (ids != null && ids.length > 0) {
			selection = GPSMessage._ID +"=?";
			int length = ids.length;
			selectionArgs = new String[length];
			for (int i = 0; i < length; i++) {
				selectionArgs[i] = String.valueOf(ids[i]);
			}
		}
		mResolver.delete(GPSMessage.CONTENT_URI, selection, selectionArgs, new IDeleteCallBack() {

			@Override
			public void deleteCallBack(int count) {
				if (count > 0) {
					if (resultCallBack != null) {
						resultCallBack.resultCallBack(true);
					}
				} else {
					if (resultCallBack != null) {
						resultCallBack.resultCallBack(false);
					}
				}
			}
		});
	}

	/**
	 * 注册数据库表变化监听器
	 */
	public void registerNotify() {
		mResolver.registerContentObserver(GPSMessage.CONTENT_URI, true, observer);

	}

	/**
	 * 注销数据库表变化监听器
	 */
	public void unregisterNotify() {
		mResolver.unregisterContentObserver(observer);
		removeGPSNotifyListener();
	}
	
	/**
	 * 移除监听器
	 */
	public void removeGPSNotifyListener(){
		if(gpsNotifyListener != null){
			gpsNotifyListener = null;
		}
	}
	
}
