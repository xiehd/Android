package com.uninew.db.dh.interfaces;

import com.uninew.db.dh.interfaces.IUsersListener.IQuerUser;
import com.uninew.db.dh.interfaces.IUsersListener.IQuerUserPwd;

public interface IUsersData {

	void setUserPwd(String user,String pwd,IResultCallBack resultCallBack);
	void querUserPwd(String user,IQuerUserPwd querUserPwd);
	void querUser(IQuerUser querUser);
	void querRootUser(IQuerUser querUser);
}
