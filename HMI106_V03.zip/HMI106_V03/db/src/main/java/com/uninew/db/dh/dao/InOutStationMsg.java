package com.uninew.db.dh.dao;

import java.util.Arrays;

public class InOutStationMsg {
	private int id;
	private int msgId;//消息ID
	private String routeId;//线路ID
	private long time;//时间
	private int stationNum;//站序
	private int mark;//进出站标志
	private byte[] msgBody;//消息体
	
	
	
	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}
	
	/**
	 * @return 消息ID
	 */
	public int getMsgId() {
		return msgId;
	}
	/**
	 * @param 消息ID
	 */
	public void setMsgId(int msgId) {
		this.msgId = msgId;
	}
	/**
	 * @return 线路ID
	 */
	public String getRouteId() {
		return routeId;
	}
	/**
	 * @param 线路ID
	 */
	public void setRouteId(String routeId) {
		this.routeId = routeId;
	}
	/**
	 * @return 时间
	 */
	public long getTime() {
		return time;
	}
	/**
	 * @param 时间
	 */
	public void setTime(long time) {
		this.time = time;
	}
	/**
	 * @return 站序
	 */
	public int getStationNum() {
		return stationNum;
	}
	/**
	 * @param 站序
	 */
	public void setStationNum(int stationNum) {
		this.stationNum = stationNum;
	}
	/**
	 * @return 进出站标志
	 */
	public int getMark() {
		return mark;
	}
	/**
	 * @param 进出站标志
	 */
	public void setMark(int mark) {
		this.mark = mark;
	}
	/**
	 * @return 消息体
	 */
	public byte[] getMsgBody() {
		return msgBody;
	}
	/**
	 * @param 消息体
	 */
	public void setMsgBody(byte[] msgBody) {
		this.msgBody = msgBody;
	}
	
	
	public InOutStationMsg() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public InOutStationMsg(int msgId, String routeId, long time, int stationNum, int mark, byte[] msgBody) {
		super();
		this.msgId = msgId;
		this.routeId = routeId;
		this.time = time;
		this.stationNum = stationNum;
		this.mark = mark;
		this.msgBody = msgBody;
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "InOutStationMsg [msgId=" + msgId + ", " + (routeId != null ? "routeId=" + routeId + ", " : "") + "time="
				+ time + ", stationNum=" + stationNum + ", mark=" + mark + ", "
				+ (msgBody != null ? "msgBody=" + Arrays.toString(msgBody) : "") + "]";
	}
	
}
