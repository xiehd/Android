package com.uninew.db.dh.Managers;

import java.util.ArrayList;
import java.util.List;

import com.uninew.db.dh.dao.TextData;
import com.uninew.db.dh.interfaces.IResultCallBack;
import com.uninew.db.dh.interfaces.ITextData;
import com.uninew.db.dh.interfaces.ITextDataListener.IQueryTextDataCallBack;
import com.uninew.db.dh.interfaces.ITextDataListener.ITextDataNotifyListener;
import com.uninew.db.main.BaseContentResolver;
import com.uninew.db.main.DbMetaData.TextMessage;
import com.uninew.db.main.IDBOpertionCallBack.IDeleteCallBack;
import com.uninew.db.main.IDBOpertionCallBack.IInsertCallBack;
import com.uninew.db.main.IDBOpertionCallBack.IQueryCallBack;
import com.uninew.db.main.IDBOpertionCallBack.IUpdateCallBack;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.ContentObserver;
import android.database.Cursor;
import android.net.Uri;
import android.os.Handler;
/**
 * 文本信息数据库的操作管理器
 * @author rong
 * 
 * 添加文本信息的更新监听器时，要先注册数据库变化监听器 （registerNotify() ）的方法，
 * 最好在生命周期开始时进行注册，
 * 而在生命周期结束时进行注销（unregisterNotify()）的方法，避免内存过量使用，
 * 然后添加监听器（ addTextDataNotifyListener）；
 */
public class DbTextDataManager implements ITextData {

	private static final String TAG = "TextDataManager";
	private Context mContext;
	/**　更新文本信息监听器*/
	private ITextDataNotifyListener textDataNotifyListener;
	/** 数据库操作类 */
	private BaseContentResolver mResolver;
	
	/**
	 * 类的初始化
	 * @param mContext 
	 */
	public DbTextDataManager(Context mContext) {
		this.mContext = mContext;
		mResolver = BaseContentResolver.getInstance(mContext);
	}

	/**
	 * 添加文本信息更新监听器
	 * @param textDataNotifyListener
	 */
	public void addTextDataNotifyListener(ITextDataNotifyListener textDataNotifyListener) {
		this.textDataNotifyListener = textDataNotifyListener;
	}
	
	/**
	 * 移除监听器
	 */
	public void removeTextDataNotifyListener(){
		if(textDataNotifyListener != null){
			textDataNotifyListener = null;
		}
	}
	/**
	 * 创建一个contentprovider的监听类
	 */
	private ContentObserver observer = new ContentObserver(new Handler()) {

		@SuppressLint("NewApi")
		@Override
		public void onChange(boolean selfChange, Uri uri) {
			// TODO Auto-generated method stub
			super.onChange(selfChange, uri);
//			Log.d(TAG, uri.toString());
		}

		@Override
		public void onChange(boolean selfChange) {
			// TODO Auto-generated method stub
			super.onChange(selfChange);
			queryTextData(null, new IQueryTextDataCallBack() {
				
				@Override
				public void queryTextData(List<TextData> textDatas) {
					if(textDatas != null && !textDatas.isEmpty()){
						if(textDataNotifyListener != null){
							textDataNotifyListener.textDataNotify(textDatas);
						}
					}
				}
			});
		}
	};

	@Override
	public void updateTextData(List<TextData> textDatas) {
		if (textDatas != null && !textDatas.isEmpty()) {
			for (final TextData data : textDatas) {
				queryTextData(null, new IQueryTextDataCallBack() {

					@Override
					public void queryTextData(List<TextData> textDatas) {
						if (textDatas != null && textDatas.size() > 20000) {
							delTextData(new int[] { data.getId() }, new IResultCallBack() {

								@Override
								public void resultCallBack(boolean result) {
									final ContentValues values = new ContentValues();
									getValues(data, values);
									mResolver.insert(TextMessage.CONTENT_URI, values, new IInsertCallBack() {
										
										@Override
										public void insertCallBack(Uri uri) {
											values.clear();
										}
									});
								}
							});
						}else{
							DbTextDataManager.this.queryTextData(new String[]{data.getTime()}, new IQueryTextDataCallBack() {
								
								@Override
								public void queryTextData(List<TextData> textDatas) {
									if (textDatas != null && !textDatas.isEmpty()) {
										final ContentValues values = new ContentValues();
										getValues(data, values);
										mResolver.update(TextMessage.CONTENT_URI, values, TextMessage.TIME+ "=?", new String[]{data.getTime()}, new IUpdateCallBack() {
											
											@Override
											public void updateCallBack(int count) {
												values.clear();
											}
										});
									}else{
										final ContentValues values = new ContentValues();
										getValues(data, values);
										mResolver.insert(TextMessage.CONTENT_URI, values, new IInsertCallBack() {
											
											@Override
											public void insertCallBack(Uri uri) {
												values.clear();
											}
										});
									}
								}
							});
						}
					}
				});
			}
		}
	}

	private void getValues(final TextData data, final ContentValues values) {
		if (data.getCarState() != -1)
			values.put(TextMessage.CAR_STATE, data.getCarState());
		if (data.getPlaceID() != -1)
			values.put(TextMessage.PLACE_ID, data.getPlaceID());
		if (data.getTextLen() != -1)
			values.put(TextMessage.TEXT_LEN, data.getTextLen());
		if (data.getTime() != null)
			values.put(TextMessage.TIME, data.getTime());
		if (data.getText() != null)
			values.put(TextMessage.TEXT_DATA, data.getText());
		if (data.getNoticeType() != -1)
			values.put(TextMessage.NOTICE_TYPE, data.getNoticeType());
	}

	@Override
	public void queryTextData(String[] times, final IQueryTextDataCallBack textDataCallBack) {
		String selection = null;
		if (times != null && times.length > 0) {
			selection = TextMessage.TIME+ "=?";
		}
		mResolver.query(TextMessage.CONTENT_URI, null, selection, times, "time asc", new IQueryCallBack() {

			@Override
			public void queryCallBack(Cursor c) {
				if (c != null && c.getCount() > 0) {
					List<TextData> textDatas = new ArrayList<>();
					while (c.moveToNext()) {
						TextData textData = new TextData();
						textData.setId(c.getInt(c.getColumnIndex(TextMessage._ID)));
						textData.setCarState(c.getInt(c.getColumnIndex(TextMessage.CAR_STATE)));
						textData.setPlaceID(c.getInt(c.getColumnIndex(TextMessage.PLACE_ID)));
						textData.setTextLen(c.getInt(c.getColumnIndex(TextMessage.TEXT_LEN)));
						textData.setText(c.getString(c.getColumnIndex(TextMessage.TEXT_DATA)));
						textData.setNoticeType(c.getInt(c.getColumnIndex(TextMessage.NOTICE_TYPE)));
						textData.setTime(c.getString(c.getColumnIndex(TextMessage.TIME)));
						textDatas.add(textData);
					}
					c.close();
					if (textDataCallBack != null) {
						textDataCallBack.queryTextData(textDatas);
					}
				} else {
					if(c != null){
						c.close();
					}
					if (textDataCallBack != null) {
						textDataCallBack.queryTextData(null);
					}
				}
			}
		});
	}

	@Override
	public void delTextData(int[] ids, final IResultCallBack resultCallBack) {
		String selection = null;
		String[] selectionArgs = null;
		if (ids != null && ids.length > 0) {
			//selection = TextMessage._ID+ "=?";
			int length = ids.length;
			selectionArgs = new String[length];
			for (int i = 0; i < length; i++) {
				if(i == 0){
					selection = TextMessage._ID+ "=?";
				}else{
					selection += " or "+TextMessage._ID+ "=?";
				}
				selectionArgs[i] = String.valueOf(ids[i]);
			}
		}
		mResolver.delete(TextMessage.CONTENT_URI, selection, selectionArgs, new IDeleteCallBack() {

			@Override
			public void deleteCallBack(int count) {
				if (count > 0) {
					if (resultCallBack != null) {
						resultCallBack.resultCallBack(true);
					}
				} else {
					if (resultCallBack != null) {
						resultCallBack.resultCallBack(false);
					}
				}
			}
		});
	}

	/**
	 * 注册数据库表变化监听器
	 */
	public void registerNotify() {
		mResolver.registerContentObserver(TextMessage.CONTENT_URI, true, observer);

	}

	/**
	 * 注销数据库表变化监听器
	 */
	public void unregisterNotify() {
		mResolver.unregisterContentObserver(observer);
		removeTextDataNotifyListener();
	}

}
