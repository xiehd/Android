package com.uninew.db.dh.interfaces;

import java.util.List;

import com.uninew.db.dh.dao.InOutStationMsg;
import com.uninew.db.dh.interfaces.IReSendStationListener.IQueryStationCallBack;
/**
 * 进出站信息的操作接口
 * @author rong
 *
 */
public interface IReSendStation {
	/**
	 * 更新进出站信息
	 * @param stations
	 */
	void updateInOutStation(List<InOutStationMsg> stations);
	/**
	 * 查询进出站信息
	 * @param time
	 */
	void queryInOutStation(long[] times,IQueryStationCallBack stationCallBack);
	/**
	 * 删除进出站信息
	 * @param ids
	 */
	void delInOutStation(int[] ids,IResultCallBack resultCallBack);
}
