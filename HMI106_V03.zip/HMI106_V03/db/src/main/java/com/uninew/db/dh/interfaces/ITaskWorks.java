package com.uninew.db.dh.interfaces;

import java.util.List;

import com.uninew.db.dh.dao.MsgBaseDatas;
import com.uninew.db.dh.interfaces.ITaskWorksListener.IQueryTaskListener;
import com.uninew.db.dh.interfaces.ITaskWorksListener.ITaskNotifyListener;

public interface ITaskWorks {
	/**
	 * 注册服务器监听器
	 */
	void registerNotify();
	/**
	 * 注销
	 */
	void unRegisterNotify();
	/**
	 * 添加监听器
	 * @param notifyListener
	 */
	void addMsgNotify(ITaskNotifyListener notifyListener);
	/**
	 * 移除监听器
	 */
	void removeMsgNotify();
	/**
	 * 更新表信息
	 * @param baseDatas
	 */
	void updateMsgDatas(List<MsgBaseDatas> baseDatas);
	/**
	 * 查询表信息
	 * @param time
	 * @param queryMsgListener
	 */
	void queryMsgDatas(long[] time,IQueryTaskListener queryTaskListener);
	/**
	 * 删除表信息
	 * @param time
	 * @param resultCallBack
	 */
	void delMsgDatas(long[] time,IResultCallBack resultCallBack);
}
