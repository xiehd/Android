package com.uninew.db.dh.Managers;

import com.uninew.db.dh.dao.DefineNet;
import com.uninew.db.dh.dao.TerminalCertified;
import com.uninew.db.dh.interfaces.IRegister;
import com.uninew.db.dh.interfaces.IRegisterListener.IQueryAuthCallBack;
import com.uninew.db.dh.interfaces.IRegisterListener.IQueryIpCallBack;
import com.uninew.db.dh.interfaces.IRegisterListener.IQueryRegisterMsgCallBack;
import com.uninew.db.dh.interfaces.IRegisterListener.IRegisterMsgListener;
import com.uninew.db.dh.interfaces.IResultCallBack;
import com.uninew.db.main.BaseContentResolver;
import com.uninew.db.main.DbMetaData.TableTerminalCertified;
import com.uninew.db.main.IDBOpertionCallBack.IInsertCallBack;
import com.uninew.db.main.IDBOpertionCallBack.IQueryCallBack;
import com.uninew.db.main.IDBOpertionCallBack.IUpdateCallBack;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.ContentObserver;
import android.database.Cursor;
import android.net.Uri;
import android.os.Handler;
import android.text.TextUtils;
/**
 * 注册信息数据库的操作管理器
 * @author rong
 * 
 * 添加注册信息的更新监听器时，要先注册数据库变化监听器 （registerNotify() ）的方法，
 * 最好在生命周期开始时进行注册，
 * 而在生命周期结束时进行注销（unregisterNotify()）的方法，避免内存过量使用，
 * 然后添加监听器（addRegisterMsgListener）；
 */
public class DbRegisterManager implements IRegister {

	private static final String TAG = "RegisterManager";
	private Context mContext;
	/** 注册信息更新监听器*/
	private IRegisterMsgListener mRegisterMsgListener;
	/** 数据库操作类*/
	private BaseContentResolver mResolver;
	
	/**
	 * 类的初始化
	 * @param mContext 
	 */
	public DbRegisterManager(Context mContext){
		this.mContext = mContext;
		mResolver = BaseContentResolver.getInstance(mContext);
	}
	
	/**
	 * 添加监听器
	 * @param mRegisterMsgListener
	 */
	public void addRegisterMsgListener(IRegisterMsgListener mRegisterMsgListener) {
		this.mRegisterMsgListener = mRegisterMsgListener;
	}
	/**
	 * 移除监听器
	 */
	public void removeRegisterMsgListener(){
		if(mRegisterMsgListener != null){
			mRegisterMsgListener = null;
		}
	}
	/**
	 * 创建一个contentprovider的监听类
	 */
	private ContentObserver observer = new ContentObserver(new Handler()) {

		@SuppressLint("NewApi")
		@Override
		public void onChange(boolean selfChange, Uri uri) {
			// TODO Auto-generated method stub
			super.onChange(selfChange, uri);
//			Log.d(TAG, uri.getLastPathSegment());
			String s = uri.getLastPathSegment();
			mResolver.query(TableTerminalCertified.CONTENT_URI, null, TableTerminalCertified._ID + "=?",
					new String[] { s }, "_id asc", new IQueryCallBack() {

						@Override
						public void queryCallBack(Cursor c) {
							if (c != null) {
								if (c.moveToNext()) {
									TerminalCertified terminalCertified = new TerminalCertified();
									terminalCertified.set_id(c.getInt(c.getColumnIndex(TableTerminalCertified._ID)));
									terminalCertified.setTerninal_number(
											c.getString(c.getColumnIndex(TableTerminalCertified.TERMINAL_NUMBER)));
									terminalCertified.setProvincial_id(
											c.getInt(c.getColumnIndex(TableTerminalCertified.PROVINCIAL_ID)));
									terminalCertified
											.setCounty_id(c.getInt(c.getColumnIndex(TableTerminalCertified.COUNTY_ID)));
									terminalCertified.setManufacturer_id(
											c.getString(c.getColumnIndex(TableTerminalCertified.MANUFACTURER_ID)));
									terminalCertified.setTerminal_type(
											c.getString(c.getColumnIndex(TableTerminalCertified.TERMINAL_TYPE)));
									terminalCertified.setTerminal_id(
											c.getString(c.getColumnIndex(TableTerminalCertified.TERMINAL_ID)));
									terminalCertified.setTerminal_color(
											c.getInt(c.getColumnIndex(TableTerminalCertified.TERMINAL_COLOR)));

									terminalCertified.setTerminal_flag(
											c.getString(c.getColumnIndex(TableTerminalCertified.TERMINAL_FLAG)));
									terminalCertified.setStream_num(
											c.getInt(c.getColumnIndex(TableTerminalCertified.STREAM_NUM)));
									terminalCertified.setReceive_time(
											c.getString(c.getColumnIndex(TableTerminalCertified.RECEIVE_TIME)));
									terminalCertified.setService_ip(
											c.getString(c.getColumnIndex(TableTerminalCertified.SERVICE_IP)));
									terminalCertified.setService_port(
											c.getInt(c.getColumnIndex(TableTerminalCertified.SERVICE_PORT)));
									terminalCertified
											.setResult(c.getInt(c.getColumnIndex(TableTerminalCertified.RESULT)));
									terminalCertified.setAuthentication(
											c.getBlob(c.getColumnIndex(TableTerminalCertified.AUTHENTICATION)));
									terminalCertified.setDomainName(
											c.getString(c.getColumnIndex(TableTerminalCertified.SERVICE_DOMAINNAME)));
									if(mRegisterMsgListener != null){
										mRegisterMsgListener.registerMsg(terminalCertified);
									}
								}
								c.close();
							}
						}
					});
		}

		@Override
		public void onChange(boolean selfChange) {
			// TODO Auto-generated method stub
			super.onChange(selfChange);
			

		}

	};

	@Override
	public void updateRegisterMsg(final int serverId, final TerminalCertified mTerminalCertified) {
		mResolver.query(TableTerminalCertified.CONTENT_URI, null, TableTerminalCertified._ID + "=?",
				new String[] { serverId + "" }, "_id asc", new IQueryCallBack() {

					@Override
					public void queryCallBack(final Cursor c) {
						if (c == null || c.getCount() <= 0) {
							final ContentValues values = getValues(mTerminalCertified, false);
							mResolver.insert(TableTerminalCertified.CONTENT_URI, values, new IInsertCallBack() {

								@Override
								public void insertCallBack(Uri uri) {
									values.clear();
									c.close();
								}
							});
						} else {
							if(c != null){
								c.close();
							}
							final ContentValues values = getValues(mTerminalCertified, true);
							if (isValuesEmpty(values)) {
								mResolver.update(TableTerminalCertified.CONTENT_URI, values,
										TableTerminalCertified._ID + "=?", new String[] { serverId + "" },
										new IUpdateCallBack() {

											@Override
											public void updateCallBack(int count) {
												values.clear();											}
										});
							} else {
								values.clear();
							}							
						}
					}
				});
	}

	private boolean isValuesEmpty(ContentValues values) {
		if (values.containsKey(TableTerminalCertified.TERMINAL_NUMBER)
				|| values.containsKey(TableTerminalCertified.AUTHENTICATION)
				|| values.containsKey(TableTerminalCertified.MANUFACTURER_ID)
				|| values.containsKey(TableTerminalCertified.PROVINCIAL_ID)
				|| values.containsKey(TableTerminalCertified.RECEIVE_TIME)
				|| values.containsKey(TableTerminalCertified.RESULT)
				|| values.containsKey(TableTerminalCertified.SERVICE_IP)
				|| values.containsKey(TableTerminalCertified.SERVICE_PORT)
				|| values.containsKey(TableTerminalCertified.SERVICE_DOMAINNAME)
				|| values.containsKey(TableTerminalCertified.STREAM_NUM)
				|| values.containsKey(TableTerminalCertified.TERMINAL_COLOR)
				|| values.containsKey(TableTerminalCertified.TERMINAL_FLAG)
				|| values.containsKey(TableTerminalCertified.TERMINAL_ID)
				|| values.containsKey(TableTerminalCertified.TERMINAL_TYPE)
				|| values.containsKey(TableTerminalCertified.COUNTY_ID)) {
			return true;
		} else {
			return false;
		}
	}

	private ContentValues getValues(final TerminalCertified mTerminalCertified, final boolean isExist) {
		ContentValues values = new ContentValues();
		if (mTerminalCertified.getTerninal_number() != null) {
			values.put(TableTerminalCertified.TERMINAL_NUMBER, mTerminalCertified.getTerninal_number());
		} else {
			if (!isExist) {
				mTerminalCertified.setTerninal_number(DefineNet.PLAT_PHONE);
				values.put(TableTerminalCertified.TERMINAL_NUMBER, DefineNet.PLAT_PHONE);
			}
		}
		if (mTerminalCertified.getAuthentication() != null) {
			values.put(TableTerminalCertified.AUTHENTICATION, mTerminalCertified.getAuthentication());
		} else {
			if (!isExist) {
				byte[] key = null;
				mTerminalCertified.setAuthentication(null);
				values.put(TableTerminalCertified.AUTHENTICATION, key);
			}
		}
		if (mTerminalCertified.getManufacturer_id() != null) {
			values.put(TableTerminalCertified.MANUFACTURER_ID, mTerminalCertified.getManufacturer_id());
		} else {
			if (!isExist) {
				mTerminalCertified.setManufacturer_id(DefineNet.DEVICE_MANUFACTURER);
				values.put(TableTerminalCertified.MANUFACTURER_ID, DefineNet.DEVICE_MANUFACTURER);
			}
		}
		if (mTerminalCertified.getProvincial_id() != -1) {
			values.put(TableTerminalCertified.PROVINCIAL_ID, mTerminalCertified.getProvincial_id());
		} else {
			if (!isExist) {
				mTerminalCertified.setProvincial_id(DefineNet.DEVICE_PROVINCE);
				values.put(TableTerminalCertified.PROVINCIAL_ID, DefineNet.DEVICE_PROVINCE);
			}
		}
		if (mTerminalCertified.getReceive_time() != null) {
			values.put(TableTerminalCertified.RECEIVE_TIME, mTerminalCertified.getReceive_time());
		} else {
			if (!isExist) {
				mTerminalCertified.setReceive_time("");
				values.put(TableTerminalCertified.RECEIVE_TIME, "");
			}
		}
		if (mTerminalCertified.getResult() != -1) {
			values.put(TableTerminalCertified.RESULT, mTerminalCertified.getResult());
		} else {
			if (!isExist) {
				mTerminalCertified.setResult(0);
				values.put(TableTerminalCertified.RESULT, 0);
			}
		}
		if (mTerminalCertified.getService_ip() != null) {
			values.put(TableTerminalCertified.SERVICE_IP, mTerminalCertified.getService_ip());
		} else {
			if (!isExist) {
				mTerminalCertified.setService_ip(DefineNet.DEFAULT_IP);
				values.put(TableTerminalCertified.SERVICE_IP, DefineNet.DEFAULT_IP);
			}
		}
		if (mTerminalCertified.getService_port() != -1) {
			values.put(TableTerminalCertified.SERVICE_PORT, mTerminalCertified.getService_port());
		} else {
			if (!isExist) {
				mTerminalCertified.setService_port(DefineNet.DEFAULT_PORT);
				values.put(TableTerminalCertified.SERVICE_PORT, DefineNet.DEFAULT_PORT);
			}
		}
		if (mTerminalCertified.getDomainName() != null) {
			values.put(TableTerminalCertified.SERVICE_DOMAINNAME, mTerminalCertified.getDomainName());
		} else {
			if (!isExist) {
				mTerminalCertified.setDomainName("");
				values.put(TableTerminalCertified.SERVICE_DOMAINNAME, "");
			}
		}
		if (mTerminalCertified.getStream_num() != -1) {
			values.put(TableTerminalCertified.STREAM_NUM, mTerminalCertified.getStream_num());
		} else {
			if (!isExist) {
				mTerminalCertified.setStream_num(0);
				values.put(TableTerminalCertified.STREAM_NUM, 0);
			}
		}
		if (mTerminalCertified.getTerminal_color() != -1) {
			values.put(TableTerminalCertified.TERMINAL_COLOR, mTerminalCertified.getTerminal_color());
		} else {
			if (!isExist) {
				mTerminalCertified.setTerminal_color(DefineNet.CAR_COLOR);
				values.put(TableTerminalCertified.TERMINAL_COLOR, DefineNet.CAR_COLOR);
			}
		}
		if (mTerminalCertified.getTerminal_flag() != null) {
			values.put(TableTerminalCertified.TERMINAL_FLAG, mTerminalCertified.getTerminal_flag());
		} else {
			if (!isExist) {
				mTerminalCertified.setTerminal_flag(DefineNet.CAR_FLAG);
				values.put(TableTerminalCertified.TERMINAL_FLAG, DefineNet.CAR_FLAG);
			}
		}
		if (mTerminalCertified.getTerminal_id() != null) {
			values.put(TableTerminalCertified.TERMINAL_ID, mTerminalCertified.getTerminal_id());
		} else {
			if (!isExist) {
				mTerminalCertified.setTerminal_id(DefineNet.DEVICE_ID);
				values.put(TableTerminalCertified.TERMINAL_ID, DefineNet.DEVICE_ID);
			}
		}
		if (mTerminalCertified.getTerminal_type() != null) {
			values.put(TableTerminalCertified.TERMINAL_TYPE, mTerminalCertified.getTerminal_type());
		} else {
			if (!isExist) {
				mTerminalCertified.setTerminal_type(DefineNet.DEVICE_MODEL);
				values.put(TableTerminalCertified.TERMINAL_TYPE, DefineNet.DEVICE_MODEL);
			}
		}
		if (mTerminalCertified.getCounty_id() != -1) {
			values.put(TableTerminalCertified.COUNTY_ID, mTerminalCertified.getCounty_id());
		} else {
			if (!isExist) {
				mTerminalCertified.setCounty_id(DefineNet.DEVICE_CITY);
				values.put(TableTerminalCertified.COUNTY_ID, DefineNet.DEVICE_CITY);
			}
		}
		return values;
	}

	@Override
	public void queryRegisterMsg(int serverId, final IQueryRegisterMsgCallBack queryRegisterMsgCallBack) {
		mResolver.query(TableTerminalCertified.CONTENT_URI, null, TableTerminalCertified._ID + "=?",
				new String[] { serverId + "" }, "_id asc", new IQueryCallBack() {

					@Override
					public void queryCallBack(Cursor c) {
						if (c != null && c.getCount() > 0) {
							if (c.moveToNext()) {
								TerminalCertified terminalCertified = new TerminalCertified();
								terminalCertified.set_id(c.getInt(c.getColumnIndex(TableTerminalCertified._ID)));
								terminalCertified.setTerninal_number(
										c.getString(c.getColumnIndex(TableTerminalCertified.TERMINAL_NUMBER)));
								terminalCertified.setProvincial_id(
										c.getInt(c.getColumnIndex(TableTerminalCertified.PROVINCIAL_ID)));
								terminalCertified
										.setCounty_id(c.getInt(c.getColumnIndex(TableTerminalCertified.COUNTY_ID)));
								terminalCertified.setManufacturer_id(
										c.getString(c.getColumnIndex(TableTerminalCertified.MANUFACTURER_ID)));
								terminalCertified.setTerminal_type(
										c.getString(c.getColumnIndex(TableTerminalCertified.TERMINAL_TYPE)));
								terminalCertified.setTerminal_id(
										c.getString(c.getColumnIndex(TableTerminalCertified.TERMINAL_ID)));
								terminalCertified.setTerminal_color(
										c.getInt(c.getColumnIndex(TableTerminalCertified.TERMINAL_COLOR)));

								terminalCertified.setTerminal_flag(
										c.getString(c.getColumnIndex(TableTerminalCertified.TERMINAL_FLAG)));
								terminalCertified
										.setStream_num(c.getInt(c.getColumnIndex(TableTerminalCertified.STREAM_NUM)));
								terminalCertified.setReceive_time(
										c.getString(c.getColumnIndex(TableTerminalCertified.RECEIVE_TIME)));
								terminalCertified.setService_ip(
										c.getString(c.getColumnIndex(TableTerminalCertified.SERVICE_IP)));
								terminalCertified.setService_port(
										c.getInt(c.getColumnIndex(TableTerminalCertified.SERVICE_PORT)));
								terminalCertified.setResult(c.getInt(c.getColumnIndex(TableTerminalCertified.RESULT)));
								terminalCertified.setAuthentication(
										c.getBlob(c.getColumnIndex(TableTerminalCertified.AUTHENTICATION)));
								terminalCertified.setDomainName(
										c.getString(c.getColumnIndex(TableTerminalCertified.SERVICE_DOMAINNAME)));
								queryRegisterMsgCallBack.queryRegisterCallBack(terminalCertified);
							}
							c.close();
						}else{
							if(c != null){
								c.close();
							}
							TerminalCertified terminalCertified = new TerminalCertified();
							final ContentValues values = getValues(terminalCertified, false);
							mResolver.insert(TableTerminalCertified.CONTENT_URI, values, new IInsertCallBack() {

								@Override
								public void insertCallBack(Uri uri) {
									values.clear();
								}
							});
							queryRegisterMsgCallBack.queryRegisterCallBack(terminalCertified);
						}
					}
				});

	}

	@Override
	public void setPlatformMsg(int serverId, String domainName, String ip, int port,
			final IResultCallBack resultCallBack) {
		final ContentValues values = new ContentValues();
		values.put(TableTerminalCertified.SERVICE_IP, ip);
		values.put(TableTerminalCertified.SERVICE_PORT, port);
		if (!TextUtils.isEmpty(domainName)) {
			values.put(TableTerminalCertified.SERVICE_DOMAINNAME, domainName);
		}
		mResolver.update(TableTerminalCertified.CONTENT_URI, values, TableTerminalCertified._ID + "=?",
				new String[] { serverId + "" }, new IUpdateCallBack() {

					@Override
					public void updateCallBack(int count) {
						values.clear();
						if (count > 0) {
							if (resultCallBack != null) {
								resultCallBack.resultCallBack(true);
							}
						} else {
							if (resultCallBack != null) {
								resultCallBack.resultCallBack(false);
							}
						}
					}
				});
	}

	@Override
	public void queryIP(final int serverId, final IQueryIpCallBack queryIpCallBack) {
		mResolver.query(TableTerminalCertified.CONTENT_URI,
				new String[] { TableTerminalCertified.SERVICE_IP, TableTerminalCertified.SERVICE_PORT ,TableTerminalCertified.SERVICE_DOMAINNAME},
				TableTerminalCertified._ID + "=?", new String[] { serverId + "" }, "_id asc", new IQueryCallBack() {

					@Override
					public void queryCallBack(Cursor c) {
						if (c != null && c.getCount() > 0) {
							if (c.moveToNext()) {
								String ip = c.getString(c.getColumnIndex(TableTerminalCertified.SERVICE_IP));
								int port = c.getInt(c.getColumnIndex(TableTerminalCertified.SERVICE_PORT));
								String domainName = c
										.getString(c.getColumnIndex(TableTerminalCertified.SERVICE_DOMAINNAME));
								queryIpCallBack.queryIpCallBack(domainName, ip, port);
							}
							c.close();
						}else{
							if(c != null){
								c.close();
							}
							TerminalCertified terminalCertified = new TerminalCertified();
							updateRegisterMsg(serverId, terminalCertified);
							queryIpCallBack.queryIpCallBack(null, DefineNet.DEFAULT_IP, DefineNet.DEFAULT_PORT);
						}
					}
				});
	}

	@Override
	public void queryAuth(final int serverId, final IQueryAuthCallBack queryAuthCallBack) {
		mResolver.query(TableTerminalCertified.CONTENT_URI,
				new String[] {TableTerminalCertified.AUTHENTICATION },
				TableTerminalCertified._ID + "=?", new String[] { serverId + "" }, "_id asc", new IQueryCallBack() {

					@Override
					public void queryCallBack(Cursor c) {
						if (c != null && c.getCount() > 0) {
							if (c.moveToNext()) {
								byte[] auth = null;
								auth = c.getBlob(c.getColumnIndex(TableTerminalCertified.AUTHENTICATION));
								queryAuthCallBack.queryAuthCallBack(auth);
							}
							c.close();
						}else{
							if(c != null){
								c.close();
							}
							TerminalCertified terminalCertified = new TerminalCertified();
							updateRegisterMsg(serverId, terminalCertified);
						}
					}
				});
	}

	@Override
	public void delAuth(int serverId, final IResultCallBack resultCallBack) {
		final ContentValues values = new ContentValues();
		byte[] key = null;
		values.put(TableTerminalCertified.AUTHENTICATION, key);
		mResolver.update(TableTerminalCertified.CONTENT_URI, values, TableTerminalCertified._ID + "=?",
				new String[] { serverId + "" }, new IUpdateCallBack() {

					@Override
					public void updateCallBack(int count) {
						values.clear();
						if (count > 0) {
							if (resultCallBack != null) {
								resultCallBack.resultCallBack(true);
							}
						} else {
							if (resultCallBack != null) {
								resultCallBack.resultCallBack(false);
							}
						}
					}
				});
	}

	/**
	 * 注册数据库表变化监听器
	 */
	public void registerNotify() {
		mResolver.registerContentObserver(TableTerminalCertified.CONTENT_URI, true, observer);

	}

	/**
	 * 注销数据库表变化监听器
	 */
	public void unregisterNotify() {
		mResolver.unregisterContentObserver(observer);
		removeRegisterMsgListener();
	}

}
