package com.uninew.file.check;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.uninew.file.dao.MarkerDao;
import com.uninew.file.dao.RoutesDao;
import com.uninew.file.dao.StationDao;
import com.uninew.file.json.JsonParse;

import android.text.TextUtils;
import android.util.Log;

/**
 * 线路完整性测试
 * 
 * @author rong
 *
 */
public class RouteIntegrity {

	private static final String TAG = "RouteIntegrity";
	private FileExistUnite fileExistUnite;
	private File route_list_file;
	private File route_file;
	private JsonParse jp;
	private boolean isRouteCompletion = true;
	private List<StationDao> stations;
	private List<String> routes = null;

	public RouteIntegrity(String path) {
		fileExistUnite = new FileExistUnite(path);
		jp = new JsonParse();
		routes = new ArrayList<>();
		if (fileExistUnite.isRoute() && fileExistUnite.isRouteList()) {
			List<FileIntegrity> fileIntegrities = fileExistUnite.getFileList();
			if (fileIntegrities.size() != 0) {
				for (FileIntegrity fileIntegrity : fileIntegrities) {
					switch (fileIntegrity.name) {
					case "线路":
						route_file = new File(fileIntegrity.path);
						break;
					case "线路列表.txt":
						route_list_file = new File(fileIntegrity.path);
						break;
					default:
						break;
					}
				}
			}
		}
		getRoute();
		if (isRouteCompletion) {
			Log.d(TAG, "线路比较完整，可以进行下一步操作了");
		} else {
			Log.e(TAG,  "线路不完整，请仔细检查");
		}
	}

	/**
	 * 获取所以线路
	 */
	private void getRoute() {
		if (route_file != null && !route_file.exists()) {
			Log.e(TAG,  "线路文件不存在，请仔细检查！");
			return;
		}
		if (route_list_file != null && route_list_file.exists()) {
			try {
				List<RoutesDao> routes = jp.getRoutes(route_list_file.getAbsolutePath());
				if (routes != null && !routes.isEmpty()) {
					for (RoutesDao route : routes) {
						RouteExist routeExist = new RouteExist(route_file);
						Map<String, String> paths = routeExist.getPaths();
						getRouteFile(paths, route.getRouteName());
					}
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		} else {
			Log.e(TAG, "线路列表文件不存在，请仔细检查！");
			isRouteCompletion = false;
		}

	}

	/**
	 * 获取线路列表中对应线路的3个文件
	 * 
	 * @param paths
	 * @param route_name
	 */
	private void getRouteFile(Map<String, String> paths, String route_name) {

		if (paths.size() != 0) {
			String path_2 = paths.get(route_name + ".txt");
			if (TextUtils.isEmpty(path_2)) {
				Log.e(TAG,  "该线路的" + route_name + "文件不存在，请仔细检查！");
				isRouteCompletion = false;
			}else{
				getStation(route_name);
				routes.add(route_name);
			}
			String path_3 = paths.get(route_name + "拐弯提醒.txt");
			if (TextUtils.isEmpty(path_3)) {
				Log.e(TAG,  "该线路的" + route_name + "拐弯提醒文件不存在，请仔细检查！");
				isRouteCompletion = false;
			} else {
				File file = new File(path_3);
				getCorner(file,route_name);
			}
		}

	}

	/**
	 * 获取路口
	 * 
	 * @param file
	 */
	private boolean getCorner(File file, String routeName) {
		boolean isCorner = false;
		if (file.exists()) {
			try {
				List<MarkerDao> corners = jp.getCorners(file.getAbsolutePath(),routeName);
				if (corners != null && !corners.isEmpty()) {
					isCorner = true;
				}else{
					isCorner = false;
				}
			} catch (Exception e) {
				isCorner = false;
				e.printStackTrace();
			}
		} else {
			Log.e(TAG,  file.getName() + "轨迹文件不存在，请仔细检查！");
			isCorner = false;
		}
		return isCorner;
	}

	/**
	 * 通过站点编号来查询站点是否存在
	 * 
	 * @param route_name
	 *            线路名称
	 * @return true 存在;false 不存在
	 */
	private boolean getStation(String route_name) {
		boolean isEixst = false;
		RouteExist routeExist = new RouteExist(route_file);
		Map<String, String> paths = routeExist.getPaths();
		String path = paths.get(route_name + ".txt");
		File file = new File(path);
		if (file.exists()) {

			try {
				stations = jp.getStations(file.getAbsolutePath(),route_name);
				if(stations != null && !stations.isEmpty()){
					isEixst = true;
				}else{
					isEixst = false;
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		} else {
			Log.e(TAG,  route_name + "文件不存在，请仔细检查！");
			isRouteCompletion = false;
		}
		return isEixst;
	}

	/**
	 * 确认线路是否完整
	 * 
	 * @return true 完整;false 不完整
	 */
	public boolean isRouteCompletion() {
		return isRouteCompletion;
	}

	public List<StationDao> getStations() {
		if (stations != null)
			return stations;
		return null;
	}

	public List<String> getRoutes() {
		return routes;
	}

	public void setRoutes(List<String> routes) {
		this.routes = routes;
	}
	
	

}
