package com.uninew.file.json;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;

public class FilePushPoll {
	private final static String FROMPATH_SD = "/mnt/media_rw/extsd/公交资源文件/";
	private final static String TOPATH_PH = "/mnt/sdcard/公交资源文件/";
	private static volatile FilePushPoll mFilePushPoll;
   Runnable runnab=new Runnable() {
	
	@Override
	public void run() {
		// TODO Auto-generated method stub
		copy(FROMPATH_SD,TOPATH_PH );
	}
};
	private FilePushPoll(){
//		new Thread(runnab).start();
		
	}
	
	public static FilePushPoll getInstance(){
		if(mFilePushPoll != null){
			
		}else {
			synchronized (FilePushPoll.class) {
				if(mFilePushPoll == null){
					mFilePushPoll = new FilePushPoll();
				}
			}
		}
		return mFilePushPoll;
	}
	/**
	 * 目录拷贝
	 * 
	 * @param fromFile
	 * @param toFile
	 * @return
	 */
	public int copy(String fromFile, String toFile) {
		// 要复制的文件目录
		File[] currentFiles;
		File root = new File(fromFile);
		 
		// 如同判断SD卡是否存在或者文件是否存在
		// 如果不存在则 return出去
		if (!root.exists()) {
			return -1;
		}
		// 如果存在则获取当前目录下的全部文件 填充数组
		currentFiles = root.listFiles();
		File targetDir = new File(toFile);
		if (!targetDir.exists()) {
			targetDir.mkdirs();
		}
		
		// 遍历要复制该目录下的全部文件
		for (int i = 0; i < currentFiles.length; i++) {
			if (currentFiles[i].isDirectory())// 如果当前项为子目录 进行递归
			{
				copy(currentFiles[i].getPath() + "/",
						toFile + currentFiles[i].getName() + "/");
			} else {
			
				CopySdcardFile(currentFiles[i].getPath(), toFile
						+ currentFiles[i].getName());
			}
		}
		return 0;
	}

	/**
	 * 单个文件拷贝
	 * 
	 * @param fromFile
	 * @param toFile
	 * @return
	 */
	public int CopySdcardFile(String fromFile, String toFile) {
		  File targetFile=new File(toFile);
		  int result=-1;
		  if(!targetFile.exists()||targetFile.length()<=0){
				try {
					InputStream fosfrom = new FileInputStream(fromFile);
					OutputStream fosto = new FileOutputStream(toFile);
					byte bt[] = new byte[1024];
					int c;
					while ((c = fosfrom.read(bt)) > 0) {
						fosto.write(bt, 0, c);
					}
					fosfrom.close();
					fosto.close();
					result=0;

				} catch (Exception ex) {
					result=-1;
				}
		  }
     return result;
	}
	/**
	 * 删除指定文件下的所有文件和文件目录
	 * @param file 指定文件或文件目录
	 */
	public void deleteFiles(File file){
		if(file.isFile()&&file.exists()){
			file.delete();
		}else{
			File[] fileList=file.listFiles();
			for(int i=0;i<fileList.length;i++){
				deleteFiles(fileList[i]);
			}
			if(file.isDirectory()&&file.exists()){
				file.delete();
			}
		}
		
	}

}
