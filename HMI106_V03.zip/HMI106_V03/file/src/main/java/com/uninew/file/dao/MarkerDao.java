package com.uninew.file.dao;


import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.IOException;
import java.io.Serializable;
import java.io.UnsupportedEncodingException;

import android.test.IsolatedContext;
import android.util.Log;

/**
 * 拐弯提醒类
 * @author Administrator
 *
 */
public class MarkerDao implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = -6263358845134642994L;
	/** 标识 */
	private int cornerId;
	/** 序号 */
	private int cornerOrder;
	/** 语音 */
	private String cornerVoice;
	/**
	 * 类型
	 * 路口: 0:转弯 1:路口 2:直行 3:停车场 4:首站 5:场站一体 6:虚站
	 * 场站: 0:停车场
	 */
	private int type;
	/** 状态*/
	private String state;
	/** 经度 */
	private double longitude;
	/** 纬度 */
	private double latitude;
	/** 角度 */
	private int angle;
	/** 限速 */
	private double limitSpeed;
	/** 站前里程 */
	private double frontMileage;
	/** 是否播报 */
	private String isBroadcast;
	/** 是否上报 */
	private String isReport;
	/** 名称*/
	private String name;
	/**与参考点的距离--排序使用*/
	private int distance;
	
	private byte[]data;
	private byte[]nameData = new byte[40];
	public MarkerDao() {
		super();
	}
	/**
	 * 
	 * @param cornerId	标识
	 * @param mark		编号
	 * @param type		类型	
	 * @param longitude	经度
	 * @param latitude	纬度
	 * @param frontMileage	站前里程
	 * @param name		名称
	 */
	public MarkerDao(int cornerId, int cornerOrder,String name ,  double longitude,
			double latitude ,double frontMileage,int type ,double limitSpeed,String state) {
		super();
		this.cornerId = cornerId;
		this.cornerOrder = cornerOrder;
		this.name = name;
		this.longitude = longitude;
		this.latitude = latitude;
		this.frontMileage = frontMileage;
		this.type = type;
		this.limitSpeed = limitSpeed;
		this.state = state ;
		cornerVoice = "拐弯提醒";
		isBroadcast = "是";
		isReport="是";
		angle = 1;
	}

	public MarkerDao(byte[] data) {
		super();
		this.data = data;
		try {
			init();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	/**
	 * 数据解析
	 * @throws IOException 
	 */
	private void init() throws IOException {
		ByteArrayInputStream bs = new ByteArrayInputStream(data);
		DataInputStream in = new DataInputStream(bs);
		cornerId = in.readByte();//拐弯提醒编号
		in.read(nameData);
		cornerVoice = getName(nameData);//站点语音
		longitude = (float)in.readInt()/1000000;//经度
		latitude = (float)in.readInt()/1000000;//纬度
		angle = in.readShort();//角度
		limitSpeed = ((float)in.readShort()/10);//限速
		frontMileage = 	((float)in.readInt()/10);//站前里程
		byte d = in.readByte();
		isBroadcast = getresult(d);//是否播报
		in.close();
		bs.close();
	}
	/**
	 * 获得名字
	 * @param nameData2
	 * @return
	 */
	private String getName(byte[] nameData2) {
		int flag = 0;
		for (int i = 0; i < nameData2.length; i++) {
			if (nameData2[i]!=0) {
				flag++;
			}
		}
		byte[]name = new byte[flag];
		for (int i = 0; i < name.length; i++) {
			name[i] = nameData2[i];
		}
		String string = "";
		try {
			string = new String(name, "GBK");
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return string;
	}
	/**
	 * 是否播报
	 * @param d
	 * @return
	 */
	private String getresult(byte d) {
		String s = "";
		if (d==0x00) {
			s = "否";
		}else if (d==0x01) {
			s = "是";
		}
		return s;
	}
	
	public MarkerDao(int cornerId, String cornerVoice, double longitude,
			double latitude, int angle, double limitSpeed,
			double frontMileage, String isBroadcast,String isReport) {
		super();
		this.cornerId = cornerId;
		this.cornerVoice = cornerVoice;
		this.longitude = longitude;
		this.latitude = latitude;
		this.angle = angle;
		this.limitSpeed = limitSpeed;
		this.frontMileage = frontMileage;
		this.isBroadcast = isBroadcast;
		this.isReport=isReport;
	}
	public int getCornerId() {
		return cornerId;
	}
	public void setCornerId(int cornerId) {
		this.cornerId = cornerId;
	}
	public String getCornerVoice() {
		return cornerVoice;
	}
	public void setCornerVoice(String cornerVoice) {
		this.cornerVoice = cornerVoice;
	}
	public double getLongitude() {
		return longitude;
	}
	public void setLongitude(double longitude) {
		this.longitude = longitude;
	}
	public double getLatitude() {
		return latitude;
	}
	public void setLatitude(double latitude) {
		this.latitude = latitude;
	}
	public int getAngle() {
		return angle;
	}
	public void setAngle(int angle) {
		this.angle = angle;
	}
	public double getLimitSpeed() {
		return limitSpeed;
	}
	public void setLimitSpeed(double limitSpeed) {
		this.limitSpeed = limitSpeed;
	}
	
	public double getFrontMileage() {
		return frontMileage;
	}
	
	public void setFrontMileage(double frontMileage) {
		this.frontMileage = frontMileage;
	}
	
	public String getIsBroadcast() {
		return isBroadcast;
	}
	
	public void setIsBroadcast(String isBroadcast) {
		this.isBroadcast = isBroadcast;
	}
	
	public boolean getIsBroadcast2() {
		if ("是".equals(isBroadcast)) {
			return true;
		}
		return false;
	}
	public void setIsBroadcast2(boolean isBroadcast) {
		if (isBroadcast) {
			this.isBroadcast="是";
		}else{
			this.isBroadcast="否";
		}
	}
	public String getIsReport() {
		return isReport;
	}
	
	public void setIsReport(String isBroadcast) {
		this.isReport = isBroadcast;
	}
	
	public boolean getIsReport2() {
		if ("是".equals(isReport)) {
			return true;
		}
		return false;
	}
	
	public void setIsReport2(boolean isBroadcast) {
		if (isBroadcast) {
			this.isReport="是";
		}else{
			this.isReport="否";
		}
	}
	
	public int getType() {
		return type;
	}

	public void setType(int type) {
		this.type = type;
	}


	public int getCornerOrder() {
		return cornerOrder;
	}
	public void setCornerOrder(int cornerOrder) {
		this.cornerOrder = cornerOrder;
	}
	public int getDistance() {
		return distance;
	}
	public void setDistance(int distance) {
		this.distance = distance;
	}
	@Override
	public String toString() {
		return "CornerDao [cornerId=" + cornerId + ", cornerVoice="
				+ cornerVoice + ", longitude=" + longitude + ", latitude="
				+ latitude + ", angle=" + angle + ", limitSpeed=" + limitSpeed
				+ ", frontMileage=" + frontMileage + ", isBroadcast="
				+ isBroadcast + "]";
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	
}
