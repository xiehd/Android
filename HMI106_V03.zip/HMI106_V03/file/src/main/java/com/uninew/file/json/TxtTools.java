package com.uninew.file.json;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.nio.channels.FileChannel;

import android.util.Log;

/**
 * txt文件操作类
 * 
 * @author Administrator
 * 
 */
public class TxtTools {
	private static final String TAG = "TxtTools";
	private static boolean D=true;

	public String readTxtFile(String filePath) {
		try {
			String encoding = "GBK";
			File file = new File(filePath);
			if (file.isFile() && file.exists()) { // 判断文件是否存在
				InputStreamReader read = new InputStreamReader(
						new FileInputStream(file), encoding);// 考虑到编码格式
				BufferedReader bufferedReader = new BufferedReader(read);
				String lineTxt = null;
				StringBuilder buffer = new StringBuilder();
				while ((lineTxt = bufferedReader.readLine()) != null) {
					buffer.append(lineTxt);
				}
				read.close();
				// LogTool.logD(TAG, buffer.toString());
				return buffer.toString();
			} else {
				Log.e(TAG, filePath+" 文件找不到!!!");
			}
		} catch (Exception e) {
			Log.e(TAG, "读取文件内容出错!!!");
		}
		return null;

	}

	public boolean writerTxtFile(String filePath, String content) {
		try {
			String encoding = "GBK";
			File file = new File(filePath);
			if (file.isFile() && file.exists()) { // 判断文件是否存在
				OutputStreamWriter writer = new OutputStreamWriter(
						new FileOutputStream(file), encoding);// 考虑到编码格式
				BufferedWriter bufferedWriter = new BufferedWriter(writer);
				bufferedWriter.write(content);
				bufferedWriter.flush();
				writer.close();
				return true;
			} else {
				Log.e(TAG, filePath+"，找不到指定的文件!!!");
				if(!file.getParentFile().exists()){
					file.getParentFile().mkdirs();
				}
				file.createNewFile();
				OutputStreamWriter writer = new OutputStreamWriter(
						new FileOutputStream(file), encoding);
				BufferedWriter bufferedWriter = new BufferedWriter(writer);
				bufferedWriter.write(content);
				bufferedWriter.flush();
				writer.close();
			}
		} catch (Exception e) {
			Log.e(TAG, "写入文件内容出错!!!");
		}
		return false;
	}

	public boolean writeFile(String filePath, String content) {
		try {
			// 打开一个写文件器，构造函数中的第二个参数true表示以追加形式写文件
			FileWriter writer = new FileWriter(filePath, true);
			writer.write(content);
			writer.close();
			return true;
		} catch (IOException e) {
			e.printStackTrace();
		}
		return false;
	}
	
    /** 
     * 复制单个文件 
     *  
     * @param srcFileName 
     *            待复制的文件名 
     * @param descFileName 
     *            目标文件名 
     * @param overlay 
     *            如果目标文件存在，是否覆盖 
     * @return 如果复制成功返回true，否则返回false 
     */  
    public synchronized static boolean copyFile(String srcFileName, String destFileName,  
            boolean overlay) {  
        File srcFile = new File(srcFileName);  
  
        // 判断源文件是否存在  
        if (!srcFile.exists()) {  
        	Log.e(TAG, "源文件：" + srcFileName + "不存在！");
            return false;  
        } else if (!srcFile.isFile()) {  
        	Log.e(TAG, "复制文件失败，源文件：" + srcFileName + "不是一个文件！");
            return false;  
        }  
  
        // 判断目标文件是否存在  
        File destFile = new File(destFileName);  
        if (destFile.exists()) {  
            // 如果目标文件存在并允许覆盖  
            if (overlay) {  
                // 删除已经存在的目标文件，无论目标文件是目录还是单个文件  
                new File(destFileName).delete();  
            }  
        } else {  
            // 如果目标文件所在目录不存在，则创建目录  
            if (!destFile.getParentFile().exists()) {  
                // 目标文件所在目录不存在  
                if (!destFile.getParentFile().mkdirs()) {  
                    // 复制文件失败：创建目标文件所在目录失败  
                    return false;  
                }  
            }  
        }  
        // 复制文件  
        int length=1024; // 读取的字节数  
        FileInputStream in = null;
        FileOutputStream out = null;
		try {
			in = new FileInputStream(srcFile);  
			out=new FileOutputStream(destFile);
	        FileChannel inC=in.getChannel();
	        FileChannel outC=out.getChannel();
	        int i=0;
	        while(true){
	            if(inC.position()==inC.size()){
	                inC.close();
	                outC.close();
	                return true;
	            }
	            if((inC.size()-inC.position())<1024)
	                length=(int)(inC.size()-inC.position());
	            else
	                length=1024;
	            inC.transferTo(inC.position(),length,outC);
	            inC.position(inC.position()+length);
	            i++;
	        }
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			return false;
		} catch (IOException e) {
			e.printStackTrace();
			return false;
		}finally {  
			try {
				if (out != null)
					out.close();
				if (in != null)
					in.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		} 
    }
    
    /** 
     * 复制整个目录的内容 
     *  
     * @param srcDirName 
     *            待复制目录的目录名 
     * @param destDirName 
     *            目标目录名 
     * @param overlay 
     *            如果目标目录存在，是否覆盖 
     * @return 如果复制成功返回true，否则返回false 
     */  
    public static boolean copyDirectory(String srcDirName, String destDirName,  
            boolean overlay) {  
        // 判断源目录是否存在  
        File srcDir = new File(srcDirName);  
        if (!srcDir.exists()) {  
        	Log.e(TAG, "源文件：" + srcDirName + "不存在！");
            return false;  
        } else if (!srcDir.isDirectory()) {  
        	Log.e(TAG, "复制文件失败，源文件：" + srcDirName + "不是一个文件夹！");
            return false;  
        }  
  
        // 如果目标目录名不是以文件分隔符结尾，则加上文件分隔符  
        if (!destDirName.endsWith(File.separator)) {  
            destDirName = destDirName + File.separator;  
        }  
        File destDir = new File(destDirName);  
        // 如果目标文件夹存在  
        if (destDir.exists()) {  
            // 如果允许覆盖则删除已存在的目标目录  
            if (overlay) {  
                new File(destDirName).delete();  
            } else {  
            	Log.e(TAG,  "复制目录失败：目的目录" + destDirName + "已存在！");
                return false;  
            }  
        } else {  
            // 创建目的目录  
            System.out.println("目的目录不存在，准备创建。。。");  
            if (!destDir.mkdirs()) {  
                System.out.println("复制目录失败：创建目的目录失败！");  
                return false;  
            }  
        }  
  
        boolean flag = true;  
        File[] files = srcDir.listFiles();  
        for (int i = 0; i < files.length; i++) {  
            // 复制文件  
            if (files[i].isFile()) {  
                flag = copyFile(files[i].getAbsolutePath(),  
                        destDirName + files[i].getName(), overlay);  
                if (!flag)  
                    break;  
            } else if (files[i].isDirectory()) {  
                flag = copyDirectory(files[i].getAbsolutePath(),  
                        destDirName + files[i].getName(), overlay);  
                if (!flag)  
                    break;  
            }  
        }  
        if (!flag) {  
        	Log.e(TAG,   "复制目录" + srcDirName + "至" + destDirName + "失败！");
            return false;  
        } else {  
            return true;  
        }  
    }  
    /**
	 * 删除文件的方法
	 * @param file
	 */
	public static boolean deleteFile(File file) {
		if (file.exists()) { // 判断文件是否存在
			if (file.isFile()) { // 判断是否是文件
				return file.delete(); // delete()方法 你应该知道 是删除的意思;
			}else{
				Log.e(TAG, "不是文件！");
			}
		} else {
			Log.e(TAG, "文件不存在！");
		}
		return false;
	}
	/**
	 * 根据名称删除对应的文件
	 * @param name
	 * @param file
	 */
	public static boolean deleteFiles(String name,File file){
		boolean result = false;
		if (file.exists()) { // 判断文件是否存在
			if (file.isDirectory()) { // 判断是否是文件
				File[] files = file.listFiles();
				if(files != null && files.length > 0){
					for(File file2:files){
						if(file2.isFile()){
							if((file2.getName().startsWith(name))){
								result=deleteFile(file2);
							}
						}else {
							Log.e(TAG, "不是文件！");
						}
					}
				}else{
					Log.e(TAG, "不存在子文件！");
				}
			}else{
				Log.e(TAG, "不是文件夹！");
			}
		} else {
			Log.e(TAG, "文件不存在！");
		}
		return result;
	}
}


