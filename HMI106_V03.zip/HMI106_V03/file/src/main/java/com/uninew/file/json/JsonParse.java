package com.uninew.file.json;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.uninew.file.dao.MarkerDao;
import com.uninew.file.dao.PointsDao;
import com.uninew.file.dao.RoutesDao;
import com.uninew.file.dao.RunRoutesDao;
import com.uninew.file.dao.SettingsDao;
import com.uninew.file.dao.StationDao;
import com.uninew.file.dao.VoiceRuleDao;


/**
 * 
 * Json文件解析类
 * 
 * @author Administrator
 * 
 */
public class JsonParse {
	private String json = null;
	private JSONObject object = null;
	private static final String TAG = "JsonParse";
	private TxtTools txtTools;

	public JsonParse() {
		super();
		txtTools = new TxtTools();
	}

	/**
	 * 获取系统运行参数
	 * 
	 * @return
	 */
	public RunRoutesDao getRuningMsg() {
		// {
		// "本班次":"9路上行",
		// "开车时间":"",
		// "收车时间":""
		// }
		json = txtTools.readTxtFile(JsonFileContants.PATH_SYS_RUN_FILE);
		if (json == null || json.equals("")) {
			return null;
		}
		RunRoutesDao crd = new RunRoutesDao();
		try {
			object = new JSONObject(json);
			crd.setRouteName(object.getString(JsonFileContants.RUN_ROUTE_NAME));
			crd.setStartTime(object.getString(JsonFileContants.RUN_START_TIME));
			crd.setEndTime(object.getString(JsonFileContants.RUN_END_TIME));
			crd.setLineMark(object.getInt(JsonFileContants.RUN_LINEMARK));
			crd.setStartStation(object.getString(JsonFileContants.RUN_START_STATION));
			crd.setEndStation(object.getString(JsonFileContants.RUN_END_STATION));
			// LogTool.logD(TAG, "getRuningMsg:"+crd.toString());
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return crd;
	}

	/**
	 * 获取系统设置信息
	 * 
	 * @return
	 */
	public SettingsDao getSysSettings() {
		// {
		// "车牌号":"粤B12340",
		// "驾驶员":"张三四",
		// "车辆编号":"075513",
		// "乘务员":"",
		// "限乘人数":""
		// }
		json = txtTools.readTxtFile(JsonFileContants.PATH_SETTINGS_FILE);
		if (json == null || json.equals("")) {
			return null;
		}
		SettingsDao sd = new SettingsDao();
		try {
			object = new JSONObject(json);
			sd.setLicensePlate(object.getString(JsonFileContants.SETTING_LICENSEPLATE));
			sd.setDriver(object.getString(JsonFileContants.SETTING_DRIVER));
			sd.setJobNumber(object.getString(JsonFileContants.SETTING_VEHICLENUMBER));
			sd.setTicketSeller(object.getString(JsonFileContants.SETTING_TICKETSELLER));
			sd.setLimitedNumber(object.getInt(JsonFileContants.SETTING_LIMITEDNUMBER));
			// LogTool.logD(TAG, "getSysSettings:"+sd.toString());
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return sd;
	}

	/**
	 * 获取线路列表信息
	 * 
	 * @return
	 */
	public ArrayList<RoutesDao> getRoutes() {
		// {
		// "线路列表":
		// [
		// {"线路名称":"9路上行","首班时间":"","末班时间":"","线路版本":"","音频路径":""},
		// {"线路名称":"9路下行","首班时间":"","末班时间":"","线路版本":"","音频路径":""},
		// {"线路名称":"10路上行","首班时间":"","末班时间":"","线路版本":"","音频路径":""},
		// {"线路名称":"10路上行","首班时间":"","末班时间":"","线路版本":"","音频路径":""}
		// ]
		// }
		json = txtTools.readTxtFile(JsonFileContants.PATH_ROUTES_FILE);
		if (json == null || json.equals("")) {
			return null;
		}
		ArrayList<RoutesDao> routes = new ArrayList<RoutesDao>();
		RoutesDao rd = null;
		try {
			object = new JSONObject(json);
			JSONArray ja = object.getJSONArray(JsonFileContants.ROUTE_LIST);
			for (int i = 0; i < ja.length(); i++) {
				rd = new RoutesDao();
				JSONObject jo = ja.getJSONObject(i);
				rd.setRouteName(jo.getString(JsonFileContants.ROUTE_NAME));
				rd.setStartTime(jo.getString(JsonFileContants.ROUTE_START_NAME));
				rd.setEndTime(jo.getString(JsonFileContants.ROUTE_END_TIME));
				rd.setLineMark(jo.getInt(JsonFileContants.ROUTE_LINEMARK));// 线路标识
				rd.setVersion(jo.getInt(JsonFileContants.ROUTE_VERSION));// 线路版本
				rd.setTtsPath(jo.getString(JsonFileContants.ROUTE_TTSPATH));// 音频路径
				rd.setTtsName(jo.getString(JsonFileContants.ROUTE_TTSNAME));//线路音频名
				rd.setStartStation(jo.getString(JsonFileContants.ROUTE_START_STATION));
				rd.setEndStation(jo.getString(JsonFileContants.ROUTE_END_STATION));
				routes.add(rd);
				// LogTool.logD(TAG, "routes ,route=" + rd.toString());
			}
			// System.out.println(crd.toString());
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return routes;
	}
	/**
	 * 获取线路列表信息
	 * @param path 线路列表文件路径
	 * @return
	 */
	public ArrayList<RoutesDao> getRoutes(String path) {
		// {
		// "线路列表":
		// [
		// {"线路名称":"9路上行","首班时间":"","末班时间":"","线路版本":"","音频路径":""},
		// {"线路名称":"9路下行","首班时间":"","末班时间":"","线路版本":"","音频路径":""},
		// {"线路名称":"10路上行","首班时间":"","末班时间":"","线路版本":"","音频路径":""},
		// {"线路名称":"10路上行","首班时间":"","末班时间":"","线路版本":"","音频路径":""}
		// ]
		// }
		json = txtTools.readTxtFile(path);
		if (json == null || json.equals("")) {
			return null;
		}
		ArrayList<RoutesDao> routes = new ArrayList<RoutesDao>();
		RoutesDao rd = null;
		try {
			object = new JSONObject(json);
			JSONArray ja = object.getJSONArray(JsonFileContants.ROUTE_LIST);
			for (int i = 0; i < ja.length(); i++) {
				rd = new RoutesDao();
				JSONObject jo = ja.getJSONObject(i);
				rd.setRouteName(jo.getString(JsonFileContants.ROUTE_NAME));
				rd.setStartTime(jo.getString(JsonFileContants.ROUTE_START_NAME));
				rd.setEndTime(jo.getString(JsonFileContants.ROUTE_END_TIME));
				rd.setLineMark(jo.getInt(JsonFileContants.ROUTE_LINEMARK));// 线路标识
				rd.setVersion(jo.getInt(JsonFileContants.ROUTE_VERSION));// 线路版本
				rd.setTtsPath(jo.getString(JsonFileContants.ROUTE_TTSPATH));// 音频路径
				rd.setTtsName(jo.getString(JsonFileContants.ROUTE_TTSNAME));//线路音频名
				rd.setStartStation(jo.getString(JsonFileContants.ROUTE_START_STATION));
				rd.setEndStation(jo.getString(JsonFileContants.ROUTE_END_STATION));
				routes.add(rd);
				// LogTool.logD(TAG, "routes ,route=" + rd.toString());
			}
			// System.out.println(crd.toString());
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return routes;
	}
	
	/**
	 * 获取站点信息
	 * 
	 * @param routeName
	 *            路径名称，如 9路上行 或9路下行
	 * @return
	 */
	public ArrayList<StationDao> getStations(String routeName) {
		// {
		// "上行站点":
		// [
		// {"站点编号":0,"站点名称":"人民医院南院北门","站点语音":"医院北门","经度":"","纬度":"","角度":"","限速":"50","站前里程":"25","站点类型":"起点站","出站语音顺序":"默认","进站语音顺序":"默认","是否播报":"是"},
		// {"站点编号":1,"站点名称":"人民医院临停站","站点语音":"人民临停","经度":"","纬度":"","角度":"","限速":"50","站前里程":"20","站点类型":"小站","出站语音顺序":"默认","进站语音顺序":"进站音1.mp3+人民临停.mp3+
		// 进站音2.mp3+进站音3.mp3","是否播报":"是"},
		// {"站点编号":2,"站点名称":"武警支队","站点语音":"武警支队","经度":"","纬度":"","角度":"","限速":"50","站前里程":"20","站点类型":"小站","出站语音顺序":"默认","进站语音顺序":"默认","是否播报":"是"},
		// {"站点编号":3,"站点名称":"军分区行政中心","站点语音":"军分区行","经度":"","纬度":"","角度":"","限速":"50","站前里程":"20","站点类型":"小站","出站语音顺序":"默认","进站语音顺序":"默认","是否播报":"是"},
		// {"站点编号":4,"站点名称":"市政府东门","站点语音":"市政府东","经度":"","纬度":"","角度":"","限速":"50","站前里程":"20","站点类型":"小站","出站语音顺序":"默认","进站语音顺序":"默认","是否播报":"是"},
		// {"站点编号":5,"站点名称":"市政府","站点语音":"市政府","经度":"","纬度":"","角度":"","限速":"50","站前里程":"20","站点类型":"大站","出站语音顺序":"默认","进站语音顺序":"默认","是否播报":"是"},
		// {"站点编号":6,"站点名称":"盛世家和园","站点语音":"盛世家和","经度":"","纬度":"","角度":"","限速":"50","站前里程":"20","站点类型":"终点站","出站语音顺序":"默认","进站语音顺序":"默认","是否播报":"是"}
		// ]
		// }
		json = txtTools.readTxtFile(JsonFileContants.PATH_ROUTES_ROOT + routeName + ".txt");
		if (json == null || json.equals("")) {
			return null;
		}
		ArrayList<StationDao> stations = new ArrayList<StationDao>();
		StationDao sd = null;
		try {
			object = new JSONObject(json);
			JSONArray ja = object.getJSONArray(JsonFileContants.STATION_LIST);
			for (int i = 0; i < ja.length(); i++) {
				sd = new StationDao();
				JSONObject jo = ja.getJSONObject(i);
				sd.setStationMark(jo.getInt(JsonFileContants.STATION_MARK)); // 站点标识
				sd.setStationId(jo.getInt(JsonFileContants.STATION_ID)); // 站点编号
				sd.setStationName(jo.getString(JsonFileContants.STATION_NAME)); // 站点名称
				sd.setStationVoice(jo.getString(JsonFileContants.STATION_VOICE)); // 站点语音
				sd.setLongitude(jo.getDouble(JsonFileContants.STATION_LONGITUDE)); // 经度
				sd.setLatitude(jo.getDouble(JsonFileContants.STATION_LATITUDE)); // 纬度
				sd.setAngle(jo.getInt(JsonFileContants.STATION_ANGLE)); // 角度
				sd.setLimitSpeed(jo.getInt(JsonFileContants.STATION_LIMITSPEED)); // 限速
				sd.setFrontMileage(jo.getInt(JsonFileContants.STATION_FRONTMILEAGE)); // 站前里程
				sd.setStationStyle(jo.getString(JsonFileContants.STATION_STYLE)); // 站点类型
				sd.setOutStationVoice(jo.getString(JsonFileContants.STATION_OUTSTATIONVOICE)); // 出站语音顺序
				sd.setInStationVoice(jo.getString(JsonFileContants.STATION_INSTATIONVOICE)); // 进站语音顺序
				sd.setIsBroadcast(jo.getString(JsonFileContants.STATION_ISBROADCAST)); // 是否播报
				sd.setTicket(jo.getDouble(JsonFileContants.STATION_TICKET));// 票价
				sd.setTTSName(jo.getString(JsonFileContants.STATION_TTSNAME));// 音频名
				sd.setSpacing(jo.getInt(JsonFileContants.STATION_SPACING));// 站点间距
				stations.add(sd);
				// LogTool.logD(TAG, "stations ,station=" + sd.toString());
			}
			// System.out.println(crd.toString());
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return stations;
	}


	/**
	 * 获取站点信息
	 * 
	 * @param routeName
	 *            路径名称，如 9路上行 或9路下行
	 * @return
	 */
	public ArrayList<StationDao> getStations(String path,String routeName) {
		// {
		// "上行站点":
		// [
		// {"站点编号":0,"站点名称":"人民医院南院北门","站点语音":"医院北门","经度":"","纬度":"","角度":"","限速":"50","站前里程":"25","站点类型":"起点站","出站语音顺序":"默认","进站语音顺序":"默认","是否播报":"是"},
		// {"站点编号":1,"站点名称":"人民医院临停站","站点语音":"人民临停","经度":"","纬度":"","角度":"","限速":"50","站前里程":"20","站点类型":"小站","出站语音顺序":"默认","进站语音顺序":"进站音1.mp3+人民临停.mp3+
		// 进站音2.mp3+进站音3.mp3","是否播报":"是"},
		// {"站点编号":2,"站点名称":"武警支队","站点语音":"武警支队","经度":"","纬度":"","角度":"","限速":"50","站前里程":"20","站点类型":"小站","出站语音顺序":"默认","进站语音顺序":"默认","是否播报":"是"},
		// {"站点编号":3,"站点名称":"军分区行政中心","站点语音":"军分区行","经度":"","纬度":"","角度":"","限速":"50","站前里程":"20","站点类型":"小站","出站语音顺序":"默认","进站语音顺序":"默认","是否播报":"是"},
		// {"站点编号":4,"站点名称":"市政府东门","站点语音":"市政府东","经度":"","纬度":"","角度":"","限速":"50","站前里程":"20","站点类型":"小站","出站语音顺序":"默认","进站语音顺序":"默认","是否播报":"是"},
		// {"站点编号":5,"站点名称":"市政府","站点语音":"市政府","经度":"","纬度":"","角度":"","限速":"50","站前里程":"20","站点类型":"大站","出站语音顺序":"默认","进站语音顺序":"默认","是否播报":"是"},
		// {"站点编号":6,"站点名称":"盛世家和园","站点语音":"盛世家和","经度":"","纬度":"","角度":"","限速":"50","站前里程":"20","站点类型":"终点站","出站语音顺序":"默认","进站语音顺序":"默认","是否播报":"是"}
		// ]
		// }
		json = txtTools.readTxtFile(path +File.separator);
		if (json == null || json.equals("")) {
			return null;
		}
		ArrayList<StationDao> stations = new ArrayList<StationDao>();
		StationDao sd = null;
		try {
			object = new JSONObject(json);
			JSONArray ja = object.getJSONArray(JsonFileContants.STATION_LIST);
			for (int i = 0; i < ja.length(); i++) {
				sd = new StationDao();
				JSONObject jo = ja.getJSONObject(i);
				sd.setStationMark(jo.getInt(JsonFileContants.STATION_MARK)); // 站点标识
				sd.setStationId(jo.getInt(JsonFileContants.STATION_ID)); // 站点编号
				sd.setStationName(jo.getString(JsonFileContants.STATION_NAME)); // 站点名称
				sd.setStationVoice(jo.getString(JsonFileContants.STATION_VOICE)); // 站点语音
				sd.setLongitude(jo.getDouble(JsonFileContants.STATION_LONGITUDE)); // 经度
				sd.setLatitude(jo.getDouble(JsonFileContants.STATION_LATITUDE)); // 纬度
				sd.setAngle(jo.getInt(JsonFileContants.STATION_ANGLE)); // 角度
				sd.setLimitSpeed(jo.getInt(JsonFileContants.STATION_LIMITSPEED)); // 限速
				sd.setFrontMileage(jo.getInt(JsonFileContants.STATION_FRONTMILEAGE)); // 站前里程
				sd.setStationStyle(jo.getString(JsonFileContants.STATION_STYLE)); // 站点类型
				sd.setOutStationVoice(jo.getString(JsonFileContants.STATION_OUTSTATIONVOICE)); // 出站语音顺序
				sd.setInStationVoice(jo.getString(JsonFileContants.STATION_INSTATIONVOICE)); // 进站语音顺序
				sd.setIsBroadcast(jo.getString(JsonFileContants.STATION_ISBROADCAST)); // 是否播报
				sd.setTicket(jo.getDouble(JsonFileContants.STATION_TICKET));// 票价
				sd.setTTSName(jo.getString(JsonFileContants.STATION_TTSNAME));// 音频名
				sd.setSpacing(jo.getInt(JsonFileContants.STATION_SPACING));// 站点间距
				stations.add(sd);
				// LogTool.logD(TAG, "stations ,station=" + sd.toString());
			}
			// System.out.println(crd.toString());
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return stations;
	}

	
	/**
	 * 获取轨迹点信息
	 * 
	 * @param routeName
	 *            路径名称，如 9路上行 或9路下行
	 * @return
	 */
	public ArrayList<PointsDao> getPoints(String routeName) {
		// {
		// "轨迹点列表":
		// [
		// {"编号":0,"上站点编号"：0，"下站点编号"：0，"经度":113.88333,"纬度":22.61222},
		// {"编号":1,"上站点编号"：0，"下站点编号"：1，"经度":113.88333,"纬度":22.61222},
		// {"编号":2,"上站点编号"：0，"下站点编号"：1，"经度":113.88333,"纬度":22.61222},
		// {"编号":3,"上站点编号"：0，"下站点编号"：1，"经度":113.88333,"纬度":22.61222},
		// {"编号":4,"上站点编号"：1，"下站点编号"：1，"经度":113.88333,"纬度":22.61222},
		// {"编号":5,"上站点编号"：1，"下站点编号"：2，"经度":113.88333,"纬度":22.61222}
		// ]
		// }
		json = txtTools.readTxtFile(JsonFileContants.PATH_ROUTES_ROOT + routeName + "轨迹.txt");
		if (json == null || json.equals("")) {
			return null;
		}
		ArrayList<PointsDao> points = new ArrayList<PointsDao>();
		PointsDao pd = null;
		try {
			object = new JSONObject(json);
			JSONArray ja = object.getJSONArray(JsonFileContants.POINTS_LIST);
			for (int i = 0; i < ja.length(); i++) {
				pd = new PointsDao();
				JSONObject jo = ja.getJSONObject(i);
				pd.setCrossID(jo.getInt(JsonFileContants.POINTS_CROSS_ID));
				pd.setPid(jo.getInt(JsonFileContants.POINTS_ID));
				pd.setLastStationId(jo.getInt(JsonFileContants.POINTS_LAST_STATIONID));
				pd.setNextStationId(jo.getInt(JsonFileContants.POINTS_NEXT_STATIONID));
				pd.setCrossType(jo.getInt(JsonFileContants.POINTS_CROSSTYPE));
				pd.setLongitude(jo.getDouble(JsonFileContants.POINTS_LONGITUDE));
				pd.setLatitude(jo.getDouble(JsonFileContants.POINTS_LATITUDE));
				points.add(pd);
				// LogTool.logD(TAG, "Points ,Point=" + pd.toString());
			}
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return points;
	}

	/**
	 * 获取拐点信息
	 * 
	 * @return
	 */
	public ArrayList<MarkerDao> getCorners(String routeName) {
		// {
		// "拐弯提醒":
		// [
		// {"编号":0,"语音":"拐弯提醒","经度":"","纬度":"","角度":"","限速":"50","站前里程":"25","是否播报":"是"},
		// {"编号":1,"语音":"拐弯提醒","经度":"","纬度":"","角度":"","限速":"50","站前里程":"25","是否播报":"是"},
		// {"编号":2,"语音":"拐弯提醒","经度":"","纬度":"","角度":"","限速":"50","站前里程":"25","是否播报":"是"},
		// {"编号":3,"语音":"拐弯提醒","经度":"","纬度":"","角度":"","限速":"50","站前里程":"25","是否播报":"是"},
		// {"编号":4,"语音":"拐弯提醒","经度":"","纬度":"","角度":"","限速":"50","站前里程":"25","是否播报":"是"},
		// {"编号":5,"语音":"拐弯提醒","经度":"","纬度":"","角度":"","限速":"50","站前里程":"25","是否播报":"是"},
		// {"编号":6,"语音":"拐弯提醒","经度":"","纬度":"","角度":"","限速":"50","站前里程":"25","是否播报":"是"}
		// ]
		// }
		json = txtTools.readTxtFile(JsonFileContants.PATH_ROUTES_ROOT + routeName + "拐弯提醒.txt");

		if (json == null || json.equals("")) {
			return null;
		}
		ArrayList<MarkerDao> corners = new ArrayList<MarkerDao>();
		MarkerDao cd = null;
		try {
			object = new JSONObject(json);
			JSONArray ja = object.getJSONArray(JsonFileContants.CORNER_NOTIFY);
			for (int i = 0; i < ja.length(); i++) {
				cd = new MarkerDao();
				JSONObject jo = ja.getJSONObject(i);
				cd.setCornerId(jo.getInt(JsonFileContants.CORNER_CORNERID));
				cd.setCornerOrder(jo.getInt(JsonFileContants.CORNER_MARK));
				cd.setCornerVoice(jo.getString(JsonFileContants.CORNER_CORNERVOICE));
				cd.setName(jo.getString(JsonFileContants.CORNER_NAME));
				cd.setType(jo.getInt(JsonFileContants.CORNER_TYPE));
				cd.setLongitude(jo.getDouble(JsonFileContants.CORNER_LONGITUDE));// jo.getDouble("经度");
				cd.setLatitude(jo.getDouble(JsonFileContants.CORNER_LATITUDE));// jo.getDouble("经度");
				cd.setAngle(jo.getInt(JsonFileContants.CORNER_ANGLE));// jo.getDouble("角度");
				cd.setLimitSpeed(jo.getInt(JsonFileContants.CORNER_LIMITSPEED));// jo.getDouble("限速");
				cd.setFrontMileage(jo.getInt(JsonFileContants.CORNER_FRONTMILEAGE));// jo.getDouble("站前里程");
				cd.setIsBroadcast(jo.getString(JsonFileContants.CORNER_ISBROADCAST));
				cd.setIsReport(jo.getString(JsonFileContants.CORNER_ISREPORT));
				cd.setState(jo.getString(JsonFileContants.CORNER_STATE));
				corners.add(cd);
				// LogTool.logD(TAG, "corners ,corner=" + cd.toString());
			}
			// System.out.println(crd.toString());
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return corners;
	}
	
	/**
	 * 获取拐点信息
	 * 
	 * @return
	 */
	public ArrayList<MarkerDao> getCorners(String path,String routeName) {
		// {
		// "拐弯提醒":
		// [
		// {"编号":0,"语音":"拐弯提醒","经度":"","纬度":"","角度":"","限速":"50","站前里程":"25","是否播报":"是"},
		// {"编号":1,"语音":"拐弯提醒","经度":"","纬度":"","角度":"","限速":"50","站前里程":"25","是否播报":"是"},
		// {"编号":2,"语音":"拐弯提醒","经度":"","纬度":"","角度":"","限速":"50","站前里程":"25","是否播报":"是"},
		// {"编号":3,"语音":"拐弯提醒","经度":"","纬度":"","角度":"","限速":"50","站前里程":"25","是否播报":"是"},
		// {"编号":4,"语音":"拐弯提醒","经度":"","纬度":"","角度":"","限速":"50","站前里程":"25","是否播报":"是"},
		// {"编号":5,"语音":"拐弯提醒","经度":"","纬度":"","角度":"","限速":"50","站前里程":"25","是否播报":"是"},
		// {"编号":6,"语音":"拐弯提醒","经度":"","纬度":"","角度":"","限速":"50","站前里程":"25","是否播报":"是"}
		// ]
		// }
		json = txtTools.readTxtFile(path+File.separator+ routeName + "拐弯提醒.txt");

		if (json == null || json.equals("")) {
			return null;
		}
		ArrayList<MarkerDao> corners = new ArrayList<MarkerDao>();
		MarkerDao cd = null;
		try {
			object = new JSONObject(json);
			JSONArray ja = object.getJSONArray(JsonFileContants.CORNER_NOTIFY);
			for (int i = 0; i < ja.length(); i++) {
				cd = new MarkerDao();
				JSONObject jo = ja.getJSONObject(i);
				cd.setCornerId(jo.getInt(JsonFileContants.CORNER_CORNERID));
				cd.setCornerOrder(jo.getInt(JsonFileContants.CORNER_MARK));
				cd.setCornerVoice(jo.getString(JsonFileContants.CORNER_CORNERVOICE));
				cd.setName(jo.getString(JsonFileContants.CORNER_NAME));
				cd.setType(jo.getInt(JsonFileContants.CORNER_TYPE));
				cd.setLongitude(jo.getDouble(JsonFileContants.CORNER_LONGITUDE));// jo.getDouble("经度");
				cd.setLatitude(jo.getDouble(JsonFileContants.CORNER_LATITUDE));// jo.getDouble("经度");
				cd.setAngle(jo.getInt(JsonFileContants.CORNER_ANGLE));// jo.getDouble("角度");
				cd.setLimitSpeed(jo.getInt(JsonFileContants.CORNER_LIMITSPEED));// jo.getDouble("限速");
				cd.setFrontMileage(jo.getInt(JsonFileContants.CORNER_FRONTMILEAGE));// jo.getDouble("站前里程");
				cd.setIsBroadcast(jo.getString(JsonFileContants.CORNER_ISBROADCAST));
				cd.setIsReport(jo.getString(JsonFileContants.CORNER_ISREPORT));
				cd.setState(jo.getString(JsonFileContants.CORNER_STATE));
				corners.add(cd);
				// LogTool.logD(TAG, "corners ,corner=" + cd.toString());
			}
			// System.out.println(crd.toString());
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return corners;
	}
	/**
	 * 获取默认语音组织方式
	 * 
	 * @return
	 */
	public VoiceRuleDao getVoiceRules() {
		// {
		// "起点出站":["起点音1.mp3","线路名称","起点音2.mp3","起点站","起点音3.mp3","起点音3.mp3","起点音4.mp3","起点音5.mp3","起点音6.mp3","本站","出站扩展"],
		// "进站播报":["进站音1.mp3","进站广告","本站","进站音2.mp3","进站提示","进站音3.mp3"],
		// "出站播报":["进站广告","出站音1.mp3","下站","出站提示","出站音2.mp3","出站扩展"],
		// "终点前站出站播报":["终点音1.mp3","终点音2.mp3","下站","终点站","终点音3.mp3"],
		// "终点进站播报":["终点音2.mp3","终点站","终点音4.mp3"],
		// "起点外音":["外音1.mp3","线路名称","外音2.mp3","外音3.mp3","终点站","外音4.mp3"],
		// "进站外音":["外音1.mp3","线路名称","外音2.mp3","外音3.mp3","终点站","外音4.mp3"],
		// "出站外音":["外音1.mp3","线路名称","外音2.mp3","外音3.mp3","终点站","外音4.mp3"]
		// }
		json = txtTools.readTxtFile(JsonFileContants.PATH_VOICE_RULE_FILE);
		if (json == null || json.equals("")) {
			return null;
		}
		VoiceRuleDao voice = new VoiceRuleDao();
		try {
			object = new JSONObject(json);

			JSONArray start = object.getJSONArray(JsonFileContants.VOICE_STARTOUT);
			ArrayList<String> startArray = new ArrayList<String>();
			for (int j = 0; j < start.length(); j++) {
				startArray.add(JsonFileContants.PATH_VOICE_ROOT + start.get(j));
			}
			voice.setStartOut(startArray);

			JSONArray in = object.getJSONArray(JsonFileContants.VOICE_ARRIVESTATION);
			ArrayList<String> inArray = new ArrayList<String>();
			for (int j = 0; j < in.length(); j++) {
				inArray.add(JsonFileContants.PATH_VOICE_ROOT + in.get(j));
			}
			voice.setArriveStation(inArray);

			JSONArray out = object.getJSONArray(JsonFileContants.VOICE_OUTSTATION);
			ArrayList<String> outArray = new ArrayList<String>();
			for (int j = 0; j < out.length(); j++) {
				outArray.add(JsonFileContants.PATH_VOICE_ROOT + out.get(j));
			}
			voice.setOutStation(outArray);

			JSONArray last = object.getJSONArray(JsonFileContants.VOICE_LASTSENCONDOUT);
			ArrayList<String> lastArray = new ArrayList<String>();
			for (int j = 0; j < last.length(); j++) {
				lastArray.add(JsonFileContants.PATH_VOICE_ROOT + last.get(j));
			}
			voice.setLastSencondOut(lastArray);

			JSONArray end = object.getJSONArray(JsonFileContants.VOICE_ARRIVETHEEND);
			ArrayList<String> endArray = new ArrayList<String>();
			for (int j = 0; j < end.length(); j++) {
				endArray.add(JsonFileContants.PATH_VOICE_ROOT + end.get(j));
			}
			voice.setArriveTheEnd(endArray);

			JSONArray startOut = object.getJSONArray(JsonFileContants.VOICE_STARTOUTVOICE);
			ArrayList<String> startOutArray = new ArrayList<String>();
			for (int j = 0; j < startOut.length(); j++) {
				startOutArray.add(JsonFileContants.PATH_VOICE_ROOT + startOut.get(j));
			}
			voice.setStartOutVoice(startOutArray);

			JSONArray inOut = object.getJSONArray(JsonFileContants.VOICE_ARRIVEOUTVOICE);
			ArrayList<String> inOutArray = new ArrayList<String>();
			for (int j = 0; j < inOut.length(); j++) {
				inOutArray.add(JsonFileContants.PATH_VOICE_ROOT + inOut.get(j));
			}
			voice.setArriveOutVoice(inOutArray);

			JSONArray oOut = object.getJSONArray(JsonFileContants.VOICE_OUTSTATIONVOICE);
			ArrayList<String> oOutArray = new ArrayList<String>();
			for (int j = 0; j < oOut.length(); j++) {
				oOutArray.add(JsonFileContants.PATH_VOICE_ROOT + oOut.get(j));
			}
			voice.setOutStationVoice(oOutArray);
			// LogTool.logD(TAG, "voice=" + voice.toString());
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return voice;
	}
	

	/**
	 * 获取默认语音组织方式
	 * 
	 * @return
	 */
	public VoiceRuleDao getVoiceRules(String path) {
		// {
		// "起点出站":["起点音1.mp3","线路名称","起点音2.mp3","起点站","起点音3.mp3","起点音3.mp3","起点音4.mp3","起点音5.mp3","起点音6.mp3","本站","出站扩展"],
		// "进站播报":["进站音1.mp3","进站广告","本站","进站音2.mp3","进站提示","进站音3.mp3"],
		// "出站播报":["进站广告","出站音1.mp3","下站","出站提示","出站音2.mp3","出站扩展"],
		// "终点前站出站播报":["终点音1.mp3","终点音2.mp3","下站","终点站","终点音3.mp3"],
		// "终点进站播报":["终点音2.mp3","终点站","终点音4.mp3"],
		// "起点外音":["外音1.mp3","线路名称","外音2.mp3","外音3.mp3","终点站","外音4.mp3"],
		// "进站外音":["外音1.mp3","线路名称","外音2.mp3","外音3.mp3","终点站","外音4.mp3"],
		// "出站外音":["外音1.mp3","线路名称","外音2.mp3","外音3.mp3","终点站","外音4.mp3"]
		// }
		json = txtTools.readTxtFile(path);
		if (json == null || json.equals("")) {
			return null;
		}
		VoiceRuleDao voice = new VoiceRuleDao();
		try {
			object = new JSONObject(json);

			JSONArray start = object.getJSONArray(JsonFileContants.VOICE_STARTOUT);
			ArrayList<String> startArray = new ArrayList<String>();
			for (int j = 0; j < start.length(); j++) {
				startArray.add(JsonFileContants.PATH_VOICE_ROOT + start.get(j));
			}
			voice.setStartOut(startArray);

			JSONArray in = object.getJSONArray(JsonFileContants.VOICE_ARRIVESTATION);
			ArrayList<String> inArray = new ArrayList<String>();
			for (int j = 0; j < in.length(); j++) {
				inArray.add(JsonFileContants.PATH_VOICE_ROOT + in.get(j));
			}
			voice.setArriveStation(inArray);

			JSONArray out = object.getJSONArray(JsonFileContants.VOICE_OUTSTATION);
			ArrayList<String> outArray = new ArrayList<String>();
			for (int j = 0; j < out.length(); j++) {
				outArray.add(JsonFileContants.PATH_VOICE_ROOT + out.get(j));
			}
			voice.setOutStation(outArray);

			JSONArray last = object.getJSONArray(JsonFileContants.VOICE_LASTSENCONDOUT);
			ArrayList<String> lastArray = new ArrayList<String>();
			for (int j = 0; j < last.length(); j++) {
				lastArray.add(JsonFileContants.PATH_VOICE_ROOT + last.get(j));
			}
			voice.setLastSencondOut(lastArray);

			JSONArray end = object.getJSONArray(JsonFileContants.VOICE_ARRIVETHEEND);
			ArrayList<String> endArray = new ArrayList<String>();
			for (int j = 0; j < end.length(); j++) {
				endArray.add(JsonFileContants.PATH_VOICE_ROOT + end.get(j));
			}
			voice.setArriveTheEnd(endArray);

			JSONArray startOut = object.getJSONArray(JsonFileContants.VOICE_STARTOUTVOICE);
			ArrayList<String> startOutArray = new ArrayList<String>();
			for (int j = 0; j < startOut.length(); j++) {
				startOutArray.add(JsonFileContants.PATH_VOICE_ROOT + startOut.get(j));
			}
			voice.setStartOutVoice(startOutArray);

			JSONArray inOut = object.getJSONArray(JsonFileContants.VOICE_ARRIVEOUTVOICE);
			ArrayList<String> inOutArray = new ArrayList<String>();
			for (int j = 0; j < inOut.length(); j++) {
				inOutArray.add(JsonFileContants.PATH_VOICE_ROOT + inOut.get(j));
			}
			voice.setArriveOutVoice(inOutArray);

			JSONArray oOut = object.getJSONArray(JsonFileContants.VOICE_OUTSTATIONVOICE);
			ArrayList<String> oOutArray = new ArrayList<String>();
			for (int j = 0; j < oOut.length(); j++) {
				oOutArray.add(JsonFileContants.PATH_VOICE_ROOT + oOut.get(j));
			}
			voice.setOutStationVoice(oOutArray);
			// LogTool.logD(TAG, "voice=" + voice.toString());
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return voice;
	}
}
