package com.uninew.file.check;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import android.text.TextUtils;
import android.util.Log;

import com.uninew.file.dao.StationDao;
import com.uninew.file.dao.VoiceRuleDao;
import com.uninew.file.json.JsonFileContants;
import com.uninew.file.json.JsonParse;

/**
 * 语音完整性测试
 * @author rong
 *
 */
public class VoiceIntegrity {
	
	private final static String TAG = "VoiceIntegrity";

	private FileExistUnite existUnite;
	private RouteIntegrity routeIntegrity;
	private File voiceFile;
	private List<StationDao> stations;
	private VoiceExist voiceExist;
	private File voiceOrderFile;
	private JsonParse jp;
	private List<String> deficiencyVoices;
	private boolean isVoiceCompletion = true;

	public VoiceIntegrity(String vpath) {
		existUnite = new FileExistUnite(vpath);
		deficiencyVoices = new ArrayList<>();
		jp = new JsonParse();
		routeIntegrity = new RouteIntegrity(vpath);
		if (existUnite.isVoice() && existUnite.isVoiceOrder()) {
			List<FileIntegrity> fIntegrities = existUnite.getFileList();
			if (fIntegrities.size() != 0) {
				for (FileIntegrity fileIntegrity : fIntegrities) {
					switch (fileIntegrity.name) {
					case "语音":
						voiceFile = new File(fileIntegrity.path);
						break;
					case "语音播报顺序设置文件.txt":
						voiceOrderFile = new File(fileIntegrity.path);
						break;
					default:
						break;
					}
				}
			}
		}
		voiceExist = new VoiceExist(voiceFile);
		getStationVoice();
		getVoiceOrderFile();
		getRouteVoice();
		//拐弯提醒的语音文件完整性测试
		String path = (voiceExist.getPaths()).get("转弯提醒"+".MP3");
		if (!TextUtils.isEmpty(path)) {
			File file = new File(path);
			if (!file.exists()) {
				Log.e(TAG, "拐弯提醒的音频文件不存在，请仔细检查！");
				isVoiceCompletion = false;
				deficiencyVoices.add("转弯提醒"+".mp3");
			}
		}else
		{
			Log.e(TAG, "拐弯提醒的音频文件不存在，请仔细检查！");
			isVoiceCompletion = false;
			deficiencyVoices.add("转弯提醒.mp3");
		}
	}

	private void getRouteVoice(){
		if(routeIntegrity.isRouteCompletion()){
			List<String> routes = routeIntegrity.getRoutes();
			if(routes != null && !routes.isEmpty()){
				for(String route : routes){
					String str = null;
					if(route.indexOf("路上行") != -1){
						str = route.replace("路上行", "");
					}else if(route.indexOf("路下行") != -1){
					    str = route.replace("路下行", "");
					}
					if(!TextUtils.isEmpty(str)){
						String path = (voiceExist.getPaths()).get(str+".mp3");
						if (!TextUtils.isEmpty(path)) {
							File file = new File(path);
							if (!file.exists()) {
								Log.e(TAG, str+"的音频文件不存在，请仔细检查！");
								isVoiceCompletion = false;
								deficiencyVoices.add(str);
							}
						}else
						{
							Log.e(TAG, str+"的音频文件不存在，请仔细检查！");
							isVoiceCompletion = false;
							deficiencyVoices.add(str);
						}
					}
				}
			}
		}
	}
	
	/**
	 * 站点语音完整性测试
	 */
	private void getStationVoice() {
		if (routeIntegrity.isRouteCompletion()) {
			stations = routeIntegrity.getStations();
			if (stations != null) {
				for (StationDao station : stations) {
					String path = (voiceExist.getPaths()).get(station.getStationName() + ".mp3");
					if(!TextUtils.isEmpty(path)){
						File file = new File(path);
						if (!file.exists() || file == null) {
							Log.e(TAG, station.getStationName() + "的音频文件不存在，请仔细检查！");
							isVoiceCompletion = false;
						}
					}else{
						Log.e(TAG, station.getStationName() + "的音频文件不存在，请仔细检查！");
						isVoiceCompletion = false;
						deficiencyVoices.add(station.getStationName());
					}
				}
			}
		}
	}

	/**
	 * 测试语音顺序设置文件中的语音文件的完整性
	 */
	@SuppressWarnings("deprecation")
	private void getVoiceOrderFile() {
		if (voiceOrderFile != null && voiceOrderFile.exists()) {
			try {
				VoiceRuleDao voiceOrder = jp.getVoiceRules(voiceOrderFile.getAbsolutePath());
				if (voiceOrder != null) {
					ArrayList<String> ArriveOutVoice =voiceOrder.getArriveOutVoice();
					getVoiceNames(ArriveOutVoice);
					ArrayList<String> ArriveStation =voiceOrder.getArriveStation();
					getVoiceNames(ArriveStation);
					ArrayList<String> ArriveTheEnd =voiceOrder.getArriveTheEnd();
					getVoiceNames(ArriveTheEnd);
					ArrayList<String> LastSencondOut =voiceOrder.getLastSencondOut();
					getVoiceNames(LastSencondOut);
					ArrayList<String> OutStation =voiceOrder.getOutStation();
					getVoiceNames(OutStation);
					ArrayList<String> OutStationVoice =voiceOrder.getOutStationVoice();
					getVoiceNames(OutStationVoice);
					ArrayList<String> StartOut =voiceOrder.getStartOut();
					getVoiceNames(StartOut);
					ArrayList<String> StartOutVoice =voiceOrder.getStartOutVoice();
					getVoiceNames(StartOutVoice);
				} else
					isVoiceCompletion = false;
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}

	}

	/**
	 * 遍历测试语音顺序设置文件中语音文件的名称
	 * @param strs
	 */
	private void getVoiceNames(ArrayList<String> strs) {
		if (strs != null && !strs.isEmpty()) {
			for (String s : strs) {
				if (s.endsWith(".MP3")) {
					String str = s.replace(JsonFileContants.PATH_VOICE_ROOT, "");
					Log.d(TAG, "voice_name:"+str);
					if(!TextUtils.isEmpty((voiceExist.getPaths()).get(str))){
						Log.d(TAG, "voice_path:"+(voiceExist.getPaths()).get(str));
						File file = new File((voiceExist.getPaths()).get(str));
						if (file != null && !file.exists()) {
							Log.e(TAG, s + "的音频文件不存在，请仔细检查！");
							isVoiceCompletion = false;
							deficiencyVoices.add(s);
						}
					}else{
						Log.e(TAG, s + "的音频文件不存在，请仔细检查！");
						isVoiceCompletion = false;
						deficiencyVoices.add(str);
					}
				}
			}
		} else
			isVoiceCompletion = false;
	}
	
	/**
	 * 语音文件的完整性
	 * @return true 完整;false 不完整
	 */
	public boolean isVoiceCompletion() {
		return isVoiceCompletion;
	}

	/**
	 * 获取缺失的音频文件
	 * @return
	 */
	public List<String> getDeficiencyVoices() {
		return deficiencyVoices;
	}
}
