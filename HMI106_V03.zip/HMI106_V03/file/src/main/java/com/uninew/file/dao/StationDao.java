package com.uninew.file.dao;

import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.Serializable;
import java.io.UnsupportedEncodingException;
import java.util.Arrays;

import android.util.Log;

/**
 * 站点信息类
 * 
 * @author Administrator
 * 
 */
public class StationDao implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 991400544013218508L;
	/** 站点标识*/
	private int	 stationMark;
	/** 站点编号 */
	private int stationId;
	/** 站点名称 */
	private String stationName;
	/** 站点语音 */
	private String stationVoice;
	/** 经度 */
	private double longitude;
	/** 纬度 */
	private double latitude;
	/** 角度 */
	private int angle;
	/** 限速 */
	private int limitSpeed;
	/** 站前里程 */
	private int frontMileage;
	/** 站点类型 */
	private String stationStyle;
	/** 进站语音顺序 */
	private String inStationVoice;
	/** 出站语音顺序 */
	private String outStationVoice;
	/** 是否播报 */
	private String isBroadcast;
	/** 票价*/
	private double ticket;
	/** 音频名*/
	private String TTSName;
	/** 站点间距*/
	private int spacing;
	/**与参考点的距离--排序使用*/
	private int distance;
	public StationDao() {
		super();
	}
	
	
	/**
	 * 
	 * @param stationMark		站点标识
	 * @param stationId			站点编号
	 * @param stationName		站点名称
	 * @param longitude			经度
	 * @param latitude			纬度
	 * @param limitSpeed		限速
	 * @param frontMileage		站前里程
	 * @param stationStyle		站点类型
	 * @param ticket			票价
	 * @param tTSName			TTS语音名
	 * @param spacing			站点间距
	 */
	public StationDao(int stationMark, int stationId, String stationName,
			 double longitude, double latitude, 
			int limitSpeed, int frontMileage, String stationStyle,
			
			double ticket, String tTSName, int spacing) {
		super();
		this.stationMark = stationMark;
		this.stationId = stationId;
		this.stationName = stationName;
		this.longitude = longitude;
		this.latitude = latitude;
		this.limitSpeed = limitSpeed;
		this.frontMileage = frontMileage;
		this.stationStyle = stationStyle;
		this.ticket = ticket;
		TTSName = tTSName;
		this.spacing = spacing;
		parseData();
	}
	/**
	 * 数据解析
	 */
	private void parseData() {
		stationVoice = stationName;//语音 = 站点名
		angle = 0;
		inStationVoice = "默认";
		outStationVoice = "默认";
		isBroadcast = "是";
	}


	public int getStationId() {
		return stationId;
	}

	public void setStationId(int stationId) {
		this.stationId = stationId;
	}

	public String getStationName() {
		return stationName;
	}

	public void setStationName(String stationName) {
		this.stationName = stationName;
	}

	public String getStationVoice() {
		return stationVoice;
	}

	public void setStationVoice(String stationVoice) {
		this.stationVoice = stationVoice;
	}

	public double getLongitude() {
		return longitude;
	}

	public void setLongitude(double longitude) {
		this.longitude = longitude;
	}

	public double getLatitude() {
		return latitude;
	}

	public void setLatitude(double latitude) {
		this.latitude = latitude;
	}

	public int getAngle() {
		return angle;
	}

	public void setAngle(int angle) {
		this.angle = angle;
	}

	public int getLimitSpeed() {
		return limitSpeed;
	}

	public void setLimitSpeed(int limitSpeed) {
		this.limitSpeed = limitSpeed;
	}

	public int getFrontMileage() {
		return frontMileage;
	}

	public void setFrontMileage(int frontMileage) {
		this.frontMileage = frontMileage;
	}

	public String getStationStyle() {
		return stationStyle;
	}

	public void setStationStyle(String stationStyle) {
		this.stationStyle = stationStyle;
	}

	public String getInStationVoice() {
		return inStationVoice;
	}

	public void setInStationVoice(String inStationVoice) {
		this.inStationVoice = inStationVoice;
	}

	public String getOutStationVoice() {
		return outStationVoice;
	}

	public void setOutStationVoice(String outStationVoice) {
		this.outStationVoice = outStationVoice;
	}

	public String getIsBroadcast() {
		return isBroadcast;
	}

	public void setIsBroadcast(String isBroadcast) {
		this.isBroadcast = isBroadcast;
	}

	public void setStationMark(int stationMark) {
		this.stationMark = stationMark;
	}
	

	public double getTicket() {
		return ticket;
	}


	public void setTicket(double ticket) {
		this.ticket = ticket;
	}


	public String getTTSName() {
		return TTSName;
	}


	public void setTTSName(String tTSName) {
		TTSName = tTSName;
	}


	public int getSpacing() {
		return spacing;
	}


	public void setSpacing(int spacing) {
		this.spacing = spacing;
	}


	public int getStationMark() {
		return stationMark;
	}

	public int getDistance() {
		return distance;
	}


	public void setDistance(int distance) {
		this.distance = distance;
	}


	@Override
	public String toString() {
		return "StationDao [stationId=" + stationId + ", stationName="
				+ stationName + ", stationVoice=" + stationVoice
				+ ", longitude=" + longitude + ", latitude=" + latitude
				+ ", angle=" + angle + ", limitSpeed=" + limitSpeed
				+ ", frontMileage=" + frontMileage + ", stationStyle="
				+ stationStyle + ", inStationVoice=" + inStationVoice
				+ ", outStationVoice=" + outStationVoice + ", isBroadcast="
				+ isBroadcast + "]";
	}

}
