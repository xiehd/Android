package com.uninew.file;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.Looper;
import android.os.Message;
import android.util.Log;

import com.uninew.file.common.DefineFileAction;
import com.uninew.file.common.FileBroadCastTools;
import com.uninew.file.dao.MarkerDao;
import com.uninew.file.dao.RoutesDao;
import com.uninew.file.dao.RunRoutesDao;
import com.uninew.file.dao.SettingsDao;
import com.uninew.file.dao.StationDao;
import com.uninew.file.dao.VoiceRuleDao;
import com.uninew.file.json.JsonFileContants;
import com.uninew.file.json.JsonParse;
import com.uninew.file.json.JsonUpdate;
import com.uninew.file.json.TxtTools;
import com.uninew.file.json.VoiceTools;

/**
 * 管理公交资源文件
 * 
 * @author Administrator
 * 
 */
public class FileService extends Service {
	private static final String TAG = "FileService";
	private static boolean D = true;

	private ExecutorService cachedThreadPool;
	private FileBroadCastTools mBroadCastTools;
	
	private JsonParse jsonParse;
	private JsonUpdate jsonUpdate;
	
	// 运行路线
	private RunRoutesDao runRoutesDao;
	// 路线信息
	private ArrayList<RoutesDao> routes;
	// 站点信息
	private ArrayList<StationDao> stations;
	// 设置信息
	private SettingsDao settings;
	// 路口信息（拐点等）
	private ArrayList<MarkerDao> corners;
	// 语音播放规则
	private VoiceRuleDao voiceRuleDao;
	// 服务语音
	private ArrayList<String> serviceVoices;
	// 站点信息
	private ArrayList<StationDao> reverseStations;
	// 路口信息（拐点等）
	private ArrayList<MarkerDao> reverseCorners;

	private HandlerThread mHandlerThread;
	private Handler mHandler;

	@Override
	public IBinder onBind(Intent arg0) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void onCreate() {
		// TODO Auto-generated method stub
		if(D)Log.d(TAG, "-----onCreate-----");
		super.onCreate();
		cachedThreadPool = Executors.newCachedThreadPool();
		jsonParse = new JsonParse();
		jsonUpdate=new JsonUpdate();
		mBroadCastTools = new FileBroadCastTools(this);
		initFileMsgs();
		registerBroadCast();

		mHandlerThread = new HandlerThread("McuService");
		mHandlerThread.start();
		mHandler = new FileHandler(mHandlerThread.getLooper());
	}
	

	@Override
	public void onDestroy() {
		// TODO Auto-generated method stub
		super.onDestroy();
		if(D)Log.d(TAG, "-----onDestroy-----");
		unregisterReceiver(mBroadcastReceiver);
	}

	// /////////////////////////////////文件初始化管理///////////////////////////////////////
	/**
	 * 文件初始化
	 */
	private void initFileMsgs() {
		cachedThreadPool.execute(new Runnable() {
			@Override
			public void run() {
				// TODO Auto-generated method stub
				if (D)Log.e(TAG,"---FileInit-----start-------"+ System.currentTimeMillis());
				dealFileMiss();
				getRunRoute();
				getRoutes();
				getStations();
				getSettings();
				getCorners();
				getVoiceRule();
				getServiceVoices();
				getReverseCorners();
				getReverseStations();
				if (D)Log.e(TAG,"---FileInit-----end-------"+ System.currentTimeMillis());
				// 初始化完成，广播
				mBroadCastTools.sendFileInitFinish(runRoutesDao, routes,
						stations, settings, serviceVoices, corners,
						voiceRuleDao,reverseStations,reverseCorners);
			}
		});
	}

	/**
	 * 文件丢失处理
	 */
	private void dealFileMiss(){
		File file = new File(JsonFileContants.FILE_ROOT);
		File commonality = new File(JsonFileContants.PATH_PUBLIC_VOICE_ROOT);
		if(!file.exists()){
			if(D)Log.e(TAG, "FileDir is Null !!");
			TxtTools.copyDirectory(JsonFileContants.FILE_ROOT_0, JsonFileContants.FILE_ROOT, true);
		}
		if(commonality == null || 
				commonality.listFiles() == null || commonality.listFiles().length <= 0){
			if(D)Log.e(TAG, "Public Voice is Null !!");
			TxtTools.copyDirectory(JsonFileContants.PATH_PUBLIC_VOICE_ROOT_0, JsonFileContants.PATH_PUBLIC_VOICE_ROOT, true);
		}
	}
	
	/**
	 * 运行线路信息
	 */
	private void getRunRoute() {
		runRoutesDao = jsonParse.getRuningMsg();
		if(runRoutesDao==null){
			//将备份的运行线路拷贝
			if(D)Log.e(TAG, "RunRoute is Null !!");
			boolean isCope=TxtTools.copyFile(JsonFileContants.PATH_SYS_RUN_FILE_0, JsonFileContants.PATH_SYS_RUN_FILE, true);
			if(isCope){
				runRoutesDao = jsonParse.getRuningMsg();
			}
		}
	}

	/**
	 * 参数设置信息
	 */
	private void getSettings() {
		settings = jsonParse.getSysSettings();
		if(settings==null){
			//将备份的拷贝
			if(D)Log.e(TAG, "SysSettings is Null !!");
			boolean isCope =TxtTools.copyFile(JsonFileContants.PATH_SETTINGS_FILE_0, JsonFileContants.PATH_SETTINGS_FILE, true);
			if(isCope){
				settings = jsonParse.getSysSettings();
			}
		}
	}

	/**
	 * 线路列表信息
	 */
	private void getRoutes() {
		routes = jsonParse.getRoutes();
		if(routes==null){
			//将备份的拷贝
			if(D)Log.e(TAG, "RouteMsgs is Null !!");
			boolean isCope =TxtTools.copyFile(JsonFileContants.PATH_ROUTES_FILE_0, JsonFileContants.PATH_ROUTES_FILE, true);
			if(isCope){
				routes = jsonParse.getRoutes();
			}
		}
	}

	/**
	 * 语音播报规则信息
	 */
	private void getVoiceRule() {
		voiceRuleDao = jsonParse.getVoiceRules();
		// 为空时，从备份获取
		if (voiceRuleDao == null) {
			if(D)Log.e(TAG, "VoiceRule is Null !!");
			boolean isCope = TxtTools.copyFile(
					JsonFileContants.PATH_VOICE_RULE_FILE_0,
					JsonFileContants.PATH_VOICE_RULE_FILE, true);
			if (isCope) {
				voiceRuleDao = jsonParse.getVoiceRules();
			}
		}
	}

	/**
	 * 路口信息
	 */
	private void getCorners() {
		if (runRoutesDao != null) {
			corners = jsonParse.getCorners(runRoutesDao.getRouteName());
			if(corners==null){
				if(D)Log.e(TAG, "Markers is Null !!");
				boolean isCope = TxtTools.copyFile(JsonFileContants.PATH_ROUTES_ROOT_0+runRoutesDao.getRouteName()+
						JsonFileContants.PATH_CORNERS_FILE_0,
						JsonFileContants.PATH_ROUTES_ROOT+runRoutesDao.getRouteName()+
						JsonFileContants.PATH_CORNERS_FILE, true);
				if (isCope) {
					corners = jsonParse.getCorners(runRoutesDao.getRouteName());
				}
			}
		}
	}
	
	/**
	 * 反向路口信息
	 */
	private void getReverseCorners() {
		if (runRoutesDao != null) {
			reverseCorners = jsonParse.getCorners(RouteTools.getReverseRouteName(runRoutesDao.getRouteName()));
			if(reverseCorners==null){
				boolean isCope =TxtTools.copyFile(
						JsonFileContants.PATH_ROUTES_ROOT_0+RouteTools.getReverseRouteName(runRoutesDao.getRouteName())+
						JsonFileContants.PATH_CORNERS_FILE_0,
						JsonFileContants.PATH_ROUTES_ROOT+RouteTools.getReverseRouteName(runRoutesDao.getRouteName())+
						JsonFileContants.PATH_CORNERS_FILE, true);
				if (isCope) {
					reverseCorners = jsonParse.getCorners(RouteTools.getReverseRouteName(runRoutesDao.getRouteName()));
				}
			}
		}
	}

	/**
	 * 运行线路对应的站点信息
	 */
	private void getStations() {
		// 站点信息，从运行信息确定站点信息
		if (runRoutesDao != null) {
			String routeName = runRoutesDao.getRouteName();
			stations = jsonParse.getStations(routeName);
			if (stations==null) {
				if(D)Log.e(TAG, "Stations is Null !!");
				boolean isCope =TxtTools.copyFile(
						JsonFileContants.PATH_ROUTES_ROOT_0+runRoutesDao.getRouteName()+JsonFileContants.FILE_EXTEND_TXT,
						JsonFileContants.PATH_ROUTES_ROOT+runRoutesDao.getRouteName()+JsonFileContants.FILE_EXTEND_TXT, true);
				if(isCope){
					stations = jsonParse.getStations(routeName);
				}
			}
		}
	}
	
	/**
	 * 站点信息(反向)
	 */
	private void getReverseStations() {
		// 站点信息，从运行信息确定站点信息
		if (runRoutesDao != null) {
			reverseStations = jsonParse.getStations(RouteTools.getReverseRouteName(runRoutesDao.getRouteName()));
			if (stations==null) {
				if(D)Log.e(TAG, "ReverseStations is Null !!");
				boolean isCope =TxtTools.copyFile(
						JsonFileContants.PATH_ROUTES_ROOT_0+RouteTools.getReverseRouteName(runRoutesDao.getRouteName())+JsonFileContants.FILE_EXTEND_TXT,
						JsonFileContants.PATH_ROUTES_ROOT+RouteTools.getReverseRouteName(runRoutesDao.getRouteName())+JsonFileContants.FILE_EXTEND_TXT, true);
				if(isCope){
					reverseStations = jsonParse.getStations(RouteTools.getReverseRouteName(runRoutesDao.getRouteName()));
				}
			}
		}
	}

	/**
	 * 获取服务语音列表
	 */
	private void getServiceVoices() {
		File voiceService = new File(JsonFileContants.PATH_SERVICE_VOICE_ROOT);
		if (voiceService == null
				|| voiceService.listFiles() == null
				|| voiceService.listFiles().length <= 0 ) {
			
			TxtTools.copyDirectory(JsonFileContants.PATH_SERVICE_VOICE_ROOT_0,
					JsonFileContants.PATH_SERVICE_VOICE_ROOT, true);
		}
		serviceVoices = VoiceTools
				.getServerMusicFileNameList(JsonFileContants.PATH_SERVICE_VOICE_ROOT);
	}

	// //////////////////////////////接收外部请求////////////////////////////////////////////////
	private BroadcastReceiver mBroadcastReceiver;
	/**
	 * 广播注册
	 */
	private void registerBroadCast() {
		IntentFilter iFilter = new IntentFilter();
		iFilter.addAction(DefineFileAction.FileServerInitRequest);
		iFilter.addAction(DefineFileAction.FileServerRouteSwitchRequest);
		iFilter.addAction(DefineFileAction.FileServerSearch);
		iFilter.addAction(DefineFileAction.FileServerUpdate);
		iFilter.addAction(DefineFileAction.FileServerDelete);
		mBroadcastReceiver = new FileBroadCastReceiver();
		this.registerReceiver(mBroadcastReceiver, iFilter);
	}

	public class FileBroadCastReceiver extends BroadcastReceiver {
		@Override
		public void onReceive(Context context, Intent intent) {
			String action = intent.getAction();
			Log.v(TAG, "FileBroadCastReceiver,action=" + action);
			switch (action) {
			case DefineFileAction.FileServerInitRequest:
				initFileMsgs();
				break;
			case DefineFileAction.FileServerRouteSwitchRequest:
				RunRoutesDao rd = (RunRoutesDao) intent
						.getSerializableExtra(DefineFileAction.RouteSwitch_Key.RouteSwitch);
				mHandler.obtainMessage(What_SwitchRoute, rd).sendToTarget();
				break;
			case DefineFileAction.FileServerSearch:
				String routeName=intent.getStringExtra(DefineFileAction.Search_Key.RouteName);
				int sourceId3 = intent.getIntExtra(
						DefineFileAction.Search_Key.SourceId, 1);
				mHandler.obtainMessage(What_FileSearch, sourceId3,0,routeName)
						.sendToTarget();
				break;
			case DefineFileAction.FileServerUpdate:
				String routeName2=intent.getStringExtra(DefineFileAction.Search_Key.RouteName);
				int sourceId4 = intent.getIntExtra(
						DefineFileAction.Update_Key.SourceId, 1);
				@SuppressWarnings("unchecked")
				ArrayList<Object> list2 = (ArrayList<Object>) intent
						.getSerializableExtra(DefineFileAction.Search_Key.Value);
				Map<String, Object> maps=new HashMap<>();
				maps.put("routeName", routeName2);
				maps.put("list", list2);
				mHandler.obtainMessage(What_FileUpdate, sourceId4, 0, maps)
						.sendToTarget();
				break;
			case DefineFileAction.FileServerDelete:
				RoutesDao route = (RoutesDao) intent
				.getSerializableExtra(DefineFileAction.Delete_Key.DeleteRoute);
				mHandler.obtainMessage(What_Filedelete, route).sendToTarget();
				break;
			default:
				break;
			}
		}
	}

	// //////////////////////////具体实现如下/////////////////////////////////

	private static final int What_SwitchRoute = 0x00;
	private static final int What_FileSearch = 0x01;
	private static final int What_FileUpdate = 0x02;
	private static final int What_Filedelete = 0x03;

	class FileHandler extends Handler {
		public FileHandler(Looper lp) {
			super(lp);
		}

		@SuppressWarnings("unchecked")
		@Override
		public void handleMessage(Message msg) {
			switch (msg.what) {
			case What_SwitchRoute:
				RunRoutesDao rd = (RunRoutesDao) msg.obj;
				switchRoute(rd);
				break;
			case What_Filedelete:
				RoutesDao route = (RoutesDao) msg.obj;
				deleteRoute(route);
				break;
			case What_FileSearch:
				int srcId3 = (int) msg.arg1;
				String routeName=(String) msg.obj;
				searchMsgById(routeName,srcId3);
				break;
			case What_FileUpdate:
				int srcId4 = msg.arg1;
				Map<String, Object> map=(Map<String, Object>) msg.obj;
				String routeName2=(String) map.get("routeName");
				ArrayList<Object> list2 = (ArrayList<Object>) map.get("list");
				updateFileMsg(routeName2,srcId4, list2);
				break;
			default:
				break;
			}
		}

	}

	/**
	 * 线路切换操作
	 * 
	 * @param rd
	 */
	private void switchRoute(RunRoutesDao route) {
		// 1.修改运行文件
		if (route == null) {
			return;
		}
		boolean result = new JsonUpdate().updateRunFile(route);
		int switchType=0;
		if(RouteTools.getSimpleRouteName(runRoutesDao.getRouteName()).
				equals(RouteTools.getSimpleRouteName(route.getRouteName()))){
			//切换后的线路一致，为上下行切换
			switchType=0;
		}else{
			switchType=1;
		}
		// 切换完成
		if (result) {
			getRunRoute();
			getRoutes();
			getStations();
			getCorners();
			mBroadCastTools.sendRouteSwitchResponse(DefineFileAction.Result.Result_Success,switchType,runRoutesDao, routes,
					stations, corners);
		}else{
			mBroadCastTools.sendRouteSwitchResponse(DefineFileAction.Result.Result_Failure,switchType,runRoutesDao, routes,
					stations, corners);
		}
	}

	/**
	 * 根据资源ID查询资源信息
	 * 
	 * @param srcId
	 */
	private void searchMsgById(String routeName,int srcId) {
		// TODO Auto-generated method stub
		if(D)Log.d(TAG, "searchMsgById---srcId="+srcId);
		switch (srcId) {
		case DefineFileAction.SourceId.CornersMsg:
			ArrayList<MarkerDao> marks=jsonParse.getCorners(routeName);
			if (marks!=null && marks.size() > 0) {
				mBroadCastTools.sendFileSearchResponse(DefineFileAction.Result.Result_Success,routeName,DefineFileAction.SourceId.CornersMsg, marks);
			}else{
				mBroadCastTools.sendFileSearchResponse(DefineFileAction.Result.Result_Failure,routeName,DefineFileAction.SourceId.CornersMsg, marks);
			}
			break;
		case DefineFileAction.SourceId.RoutesMsg:
			if (routes !=null && routes.size() > 0) {
				mBroadCastTools.sendFileSearchResponse(DefineFileAction.Result.Result_Success,routeName,DefineFileAction.SourceId.RoutesMsg, routes);
			}else{
				mBroadCastTools.sendFileSearchResponse(DefineFileAction.Result.Result_Failure,routeName,DefineFileAction.SourceId.RoutesMsg, routes);
			}
			break;
		case DefineFileAction.SourceId.RunningMsg:
			ArrayList<RunRoutesDao> runMsg=new ArrayList<RunRoutesDao>();
			runMsg.add(runRoutesDao);
			if (runRoutesDao!=null) {
				mBroadCastTools.sendFileSearchResponse(DefineFileAction.Result.Result_Success,routeName,DefineFileAction.SourceId.RunningMsg,runMsg);
			}else{
				mBroadCastTools.sendFileSearchResponse(DefineFileAction.Result.Result_Failure,routeName,DefineFileAction.SourceId.RunningMsg,runMsg);
			}
			break;
		case DefineFileAction.SourceId.ServiceVoices:
			if (serviceVoices !=null && serviceVoices.size() >0) {
				mBroadCastTools.sendFileSearchResponse(DefineFileAction.Result.Result_Success,routeName,DefineFileAction.SourceId.ServiceVoices, serviceVoices);
			}else{
				mBroadCastTools.sendFileSearchResponse(DefineFileAction.Result.Result_Failure,routeName,DefineFileAction.SourceId.ServiceVoices, serviceVoices);
			}
			break;
		case DefineFileAction.SourceId.SettingsMsg:
			ArrayList<SettingsDao> st=new ArrayList<SettingsDao>();
			st.add(settings);
			if (settings!=null) {
				mBroadCastTools.sendFileSearchResponse(DefineFileAction.Result.Result_Success,routeName,DefineFileAction.SourceId.SettingsMsg,st);
			}else{
				mBroadCastTools.sendFileSearchResponse(DefineFileAction.Result.Result_Failure,routeName,DefineFileAction.SourceId.SettingsMsg,st);
			}
			break;
		case DefineFileAction.SourceId.StationsMsg:
			ArrayList<StationDao> stations2=jsonParse.getStations(routeName);
			if (stations2 !=null && stations2.size() >0) {
				mBroadCastTools.sendFileSearchResponse(DefineFileAction.Result.Result_Success,routeName,DefineFileAction.SourceId.StationsMsg, stations2);
			}else{
				mBroadCastTools.sendFileSearchResponse(DefineFileAction.Result.Result_Failure,routeName,DefineFileAction.SourceId.StationsMsg, stations2);
			}
			break;
		case DefineFileAction.SourceId.VoiceRuleMsg:
			ArrayList<VoiceRuleDao> vr=new ArrayList<VoiceRuleDao>();
			vr.add(voiceRuleDao);
			if (voiceRuleDao!=null) {
				mBroadCastTools.sendFileSearchResponse(DefineFileAction.Result.Result_Success,routeName,DefineFileAction.SourceId.VoiceRuleMsg,vr);
			}else{
				mBroadCastTools.sendFileSearchResponse(DefineFileAction.Result.Result_Failure,routeName,DefineFileAction.SourceId.VoiceRuleMsg,vr);
			}
			break;
		default:
			break;
		}
	}

	/**
	 * 根据资源ID更新资源信息
	 * 
	 * @param srcId2
	 * @param list
	 */
	@SuppressWarnings("unchecked")
	public void updateFileMsg(String routeName,int srcId2, ArrayList<?> list) {
		// TODO Auto-generated method stub
		if(D)Log.d(TAG, "---updateFileMsg---srcId="+srcId2);
		if (list==null || list.size() < 1) {
			Log.e(TAG, "updateFileMsg,Value is NULL !!!!");
			return;
		}
		switch (srcId2) {
		case DefineFileAction.SourceId.CornersMsg:
			boolean cornerResult=jsonUpdate.updateCornersFile((ArrayList<MarkerDao>)list, routeName);
			if (cornerResult) {
				getCorners();
				mBroadCastTools.sendFileUpdateResponse(DefineFileAction.Result.Result_Success,routeName,DefineFileAction.SourceId.CornersMsg, corners);
			}else{
				mBroadCastTools.sendFileUpdateResponse(DefineFileAction.Result.Result_Failure,routeName,DefineFileAction.SourceId.CornersMsg, corners);
			}
			break;
		case DefineFileAction.SourceId.RoutesMsg:
			//更新当前运行线路的
			boolean rResult=jsonUpdate.updateRoute((ArrayList<RoutesDao>)list);
			if (rResult) {
				getRoutes();
				mBroadCastTools.sendFileUpdateResponse(DefineFileAction.Result.Result_Success,routeName,DefineFileAction.SourceId.RoutesMsg, routes);
			}else{
				mBroadCastTools.sendFileUpdateResponse(DefineFileAction.Result.Result_Failure,routeName,DefineFileAction.SourceId.RoutesMsg, routes);
			}
			break;
		case DefineFileAction.SourceId.RunningMsg:
			boolean runResult=jsonUpdate.updateRunFile((RunRoutesDao)list.get(0));
			int result=0;
			if (runResult) {
				getRunRoute();
				result=DefineFileAction.Result.Result_Success;
			}else{
				result=DefineFileAction.Result.Result_Failure;
			}
			ArrayList<RunRoutesDao> runMsg=new ArrayList<RunRoutesDao>();
			runMsg.add(runRoutesDao);
			mBroadCastTools.sendFileUpdateResponse(result,routeName,DefineFileAction.SourceId.RunningMsg,runMsg);
			break;
		case DefineFileAction.SourceId.ServiceVoices:
			//无法进行更新
			break;
		case DefineFileAction.SourceId.SettingsMsg:
			boolean sResult=jsonUpdate.updateSettingsFile((SettingsDao)list.get(0));
			int result2=0;
			if (sResult) {
				getSettings();
				result2=DefineFileAction.Result.Result_Success;
			}else{
				result2=DefineFileAction.Result.Result_Failure;
			}
			ArrayList<SettingsDao> setMsg=new ArrayList<SettingsDao>();
			setMsg.add(settings);
			mBroadCastTools.sendFileUpdateResponse(result2,routeName,DefineFileAction.SourceId.SettingsMsg,setMsg);
			break;
		case DefineFileAction.SourceId.StationsMsg:
			boolean stationResult=jsonUpdate.updateStationFile((ArrayList<StationDao>)list,runRoutesDao.getRouteName());
			if (stationResult) {
				getStations();
				mBroadCastTools.sendFileUpdateResponse(DefineFileAction.Result.Result_Success,routeName,DefineFileAction.SourceId.StationsMsg, stations);
			}else{
				mBroadCastTools.sendFileUpdateResponse(DefineFileAction.Result.Result_Failure,routeName,DefineFileAction.SourceId.StationsMsg, stations);
			}		
			break;
		case DefineFileAction.SourceId.VoiceRuleMsg:
			//暂时不支持修改
			break;
		default:
			break;
		}
	}
	
	/**
	 * 线路删除
	 * @param route
	 */
	private void deleteRoute(RoutesDao route) {
		// 删除线路文件
		TxtTools.deleteFiles(route.getRouteName(), new File(JsonFileContants.PATH_ROUTES_ROOT));
		//更新线路信息
		for (int i = 0; i < routes.size(); i++) {
			if (route.getRouteName().equals(routes.get(i).getRouteName())) {
				routes.remove(routes.get(i));
			}
		}
		boolean r3=jsonUpdate.updateRoute(routes);
		if (r3) {
			mBroadCastTools.sendFileDeleteResponse(DefineFileAction.Result.Result_Success);
		}else{
			mBroadCastTools.sendFileDeleteResponse(DefineFileAction.Result.Result_Failure);
		}
		//初始化，全局更新
		initFileMsgs();
	}
	
}
