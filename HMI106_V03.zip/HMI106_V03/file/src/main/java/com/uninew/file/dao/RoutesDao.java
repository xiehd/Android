package com.uninew.file.dao;

import java.io.Serializable;

/**
 * 路线信息类
 * 
 * @author Administrator
 *
 */
public class RoutesDao implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1753920099084276446L;
	/** 本班次 */
	private String routeName;
	/** 开车时间 */
	private String startTime;
	/** 收车时间 */
	private String endTime;
	/** 线路标识 */
	private int lineMark;
	/** 线路版本 **/
	private int version;
	/** 音频路径 **/
	private String ttsPath;
	/** 线路音频路径**/
	private String ttsName;
	/** 起始站 */
	private String startStation;
	/** 终点站*/
	private String endStation;

	public RoutesDao() {
	}

	public RoutesDao(String routeName, String startTime, String endTime, int lineMark, int version, String ttsPath,String ttsName) {
		this.routeName = routeName;
		this.startTime = startTime;
		this.endTime = endTime;
		this.lineMark = lineMark;
		this.version = version;
		this.ttsPath = ttsPath;
		this.ttsName = ttsName;
	}

	public int getLineMark() {
		return lineMark;
	}

	public void setLineMark(int lineMark) {
		this.lineMark = lineMark;
	}

	public String getRouteName() {
		return routeName;
	}

	public void setRouteName(String routeName) {
		this.routeName = routeName;
	}

	public String getStartTime() {
		return startTime;
	}

	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}

	public String getEndTime() {
		return endTime;
	}

	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}

	public int getVersion() {
		return version;
	}

	public void setVersion(int version) {
		this.version = version;
	}

	public String getTtsPath() {
		return ttsPath;
	}

	public void setTtsPath(String ttsPath) {
		this.ttsPath = ttsPath;
	}

	public String getTtsName() {
		return ttsName;
	}

	public void setTtsName(String ttsName) {
		this.ttsName = ttsName;
	}

	public String getStartStation() {
		return startStation;
	}

	public void setStartStation(String startStation) {
		this.startStation = startStation;
	}

	public String getEndStation() {
		return endStation;
	}

	public void setEndStation(String endStation) {
		this.endStation = endStation;
	}

	@Override
	public String toString() {
		return "RoutesDao [routeName=" + routeName + ", startTime=" + startTime
				+ ", endTime=" + endTime + ", lineMark=" + lineMark
				+ ", version=" + version + ", ttsPath=" + ttsPath
				+ ", ttsName=" + ttsName + ", startStation=" + startStation
				+ ", endStation=" + endStation + "]";
	}

	
}
