package com.uninew.file.check;

public class FileIntegrity {
	public boolean isExist = false;
	public String name = "文件不存在";
	public String path = "D://";

	public FileIntegrity() {
	}

	public FileIntegrity(boolean isExist, String name, String path) {
		this.isExist = isExist;
		this.name = name;
		this.path = path;
	}

	@Override
	public String toString() {
		return "FileIntegrity [isExist=" + isExist + ", name=" + name + ", path=" + path + "]";
	}

}
