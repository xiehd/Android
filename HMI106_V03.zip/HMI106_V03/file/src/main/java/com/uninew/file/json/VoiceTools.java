package com.uninew.file.json;

import java.io.File;
import java.util.ArrayList;

import com.uninew.file.dao.StationDao;

/**
 * 获取语音组合帮助类
 * @author Administrator
 *
 */
public class VoiceTools {
	
	public static final String Format_MP3=".mp3";
	public static final String Format_WAV=".wav";
	public static String Audio_Format=Format_MP3;

	/**
	 * 进站语音播放文件
	 */
	public static ArrayList<String> getInVoicePaths(StationDao sd) {
		ArrayList<String> list = new ArrayList<String>();
		if (JsonFileContants.STATION_DEFAULT_VOICE.equals(sd
				.getInStationVoice())) {
//			list = MainApplication.voiceRuleDao.getArriveStation();
			copyAudioFile(sd.getStationVoice());
			list=VoiceCombineRule.getIntoStationSound(JsonFileContants.ADNAME_INTOSTATION, sd.getStationVoice(), null);
		} else {
			list = getPaths(sd.getInStationVoice());
		}
		return list;
	}
	/**
	 * 终点站进站语音播放文件
	 */
	public static ArrayList<String> getEndInStationSound(StationDao sd) {
		ArrayList<String> list = new ArrayList<String>();
		if (JsonFileContants.STATION_DEFAULT_VOICE.equals(sd
				.getInStationVoice())) {
//			list = MainApplication.voiceRuleDao.getArriveStation();
			copyAudioFile(sd.getStationVoice());
			list=VoiceCombineRule.getEndInStationSound(sd.getStationVoice());
		} else {
			list = getPaths(sd.getInStationVoice());
		}
		return list;
	}
	/**
	 * 起点出站语音播放文件
	 */
	public static ArrayList<String> getStartOutVoicePaths(StationDao start,String nextStation,String routeName,
			 String endStation, String bigStation,
			 String outExtend) {
		ArrayList<String> list = new ArrayList<String>();
		if (JsonFileContants.STATION_DEFAULT_VOICE.equals(start
				.getInStationVoice())) {
//			list = MainApplication.voiceRuleDao.getArriveStation();
			copyAudioFile(start.getStationVoice());
			list=VoiceCombineRule.getStartingOutSound(routeName, start.getStationName(), endStation, bigStation, nextStation, outExtend);
		} else {
			list = getPaths(start.getOutStationVoice());
		}
		return list;
	}
	
	/**
	 * 出站语音播放文件
	 */
	public static ArrayList<String> getOutVoicePaths(StationDao next) {
		ArrayList<String> list = new ArrayList<String>();
		if (JsonFileContants.STATION_DEFAULT_VOICE.equals(next
				.getOutStationVoice())) {
			copyAudioFile(next.getStationVoice());
			list=VoiceCombineRule.getOutStationSound(JsonFileContants.ADNAME_OUTSTATION, next.getStationVoice(), null, null);
		} else {
			list = getPaths(next.getOutStationVoice());
		}
		return list;
	}
	/**
	 * 终点前站出站语音播放文件
	 */
	public static ArrayList<String> getLastSecondOutVoicePaths(StationDao next) {
		ArrayList<String> list = new ArrayList<String>();
		if (JsonFileContants.STATION_DEFAULT_VOICE.equals(next
				.getOutStationVoice())) {
			list=VoiceCombineRule.getLastSecondOutSound(next.getStationVoice());
		} else {
			list = getPaths(next.getOutStationVoice());
		}
		return list;
	}
	/**
	 * 服务语音
	 * @return
	 */
	public static ArrayList<String> getServicePaths(String serviceName){
		ArrayList<String> list = new ArrayList<String>();
		list.add(FileConstant.SERVICE_AUDIO_PATH  + serviceName+Audio_Format);
		return list;
	}
	/**
	 * 关门提醒
	 * @return
	 */
	public static ArrayList<String> getCloseDoorPaths(){
		ArrayList<String> list = new ArrayList<String>();
		list.add(FileConstant.PUBLIC_AUDIO_PATH  + "服务音1"+Audio_Format);
		return list;
	}
	
	/**
	 * 转弯提醒
	 * @return
	 */
	public static ArrayList<String> getSwervePaths(){
		ArrayList<String> list = new ArrayList<String>();
		list.add(FileConstant.PUBLIC_AUDIO_PATH + "服务音7"+Audio_Format);
		list.add(FileConstant.PUBLIC_AUDIO_PATH + "服务音7"+Audio_Format);
		return list;
	}
	
	/**
	 * 让座提醒
	 * @return
	 */
	public static ArrayList<String> getOfferSeatPaths(){
		ArrayList<String> list = new ArrayList<String>();
		list.add(FileConstant.PUBLIC_AUDIO_PATH + "服务音8"+Audio_Format);
		return list;
	}
	/**
	 * 投币提醒
	 * @return
	 */
	public static ArrayList<String> getCoinsPaths(){
		ArrayList<String> list = new ArrayList<String>();
		list.add(FileConstant.PUBLIC_AUDIO_PATH + "投币提醒"+Audio_Format);
		return list;
	}
	
	/**
	 * 注意卫生提醒
	 * @return
	 */
	public static ArrayList<String> getHealthPaths(){
		ArrayList<String> list = new ArrayList<String>();
		list.add(FileConstant.PUBLIC_AUDIO_PATH + "服务音9"+Audio_Format);
		return list;
	}
	
	/**
	 * 将语音文件名重组成list
	 * 
	 * @param str
	 *            a.mp3+b.mp3 格式
	 * @return
	 */
	private static ArrayList<String> getPaths(String str) {
		ArrayList<String> list = new ArrayList<String>();
		String[] strs = str.split("\\+");
		for (int i = 0; i < strs.length; i++) {
			list.add(JsonFileContants.PATH_VOICE_ROOT+strs[i].trim());
		}
		return list;
	}
	
	/**
	 * 获取服务语音文件夹下的文件名
	 * 
	 * @param path
	 * @return
	 */

	public static ArrayList<String> getServerMusicFileNameList(String path) {
		ArrayList<String> musicList = new ArrayList<String>();
		File file = new File(path);
		String[] fileNameArry = file.list();
		if (fileNameArry != null && fileNameArry.length > 0) {
			for (int i = 0; i < fileNameArry.length; i++) {
				int index = fileNameArry[i].toString().lastIndexOf('.');
				String fileName = fileNameArry[i].substring(0, index);
				musicList.add(fileName);
			}
		}
		return musicList;
	}
	
	private static void copyAudioFile(String audioName){
		if(!new File(JsonFileContants.PATH_VOICE_ROOT+audioName+JsonFileContants.MP3_FILE).exists()){
			//站点语音不存在
			TxtTools.copyFile(JsonFileContants.PATH_VOICE_ROOT_0+audioName+JsonFileContants.MP3_FILE, 
					JsonFileContants.PATH_VOICE_ROOT+audioName+JsonFileContants.MP3_FILE, true);
		}
	}
	
}
