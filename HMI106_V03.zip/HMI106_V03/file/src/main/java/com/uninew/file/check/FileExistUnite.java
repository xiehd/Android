package com.uninew.file.check;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import android.util.Log;

public class FileExistUnite {
	private static final boolean D=true;
	private final static String TAG = "FileExistUnite";
	private List<FileIntegrity> fileList;
	private FileIntegrity resourceFile;
	private File path;
	private boolean isResource = false;
	private boolean isRoute = false;
	private boolean isVoice = false;
	private boolean isSet = false;
	private boolean isRun = false;
	private boolean isRouteList = false;
	private boolean isVoiceOrder = false;

	public FileExistUnite(String voicpath) {
		path = new File(voicpath);
		isResource = path.exists();
		System.out.println(path.getName());
		if (isResource && path.isDirectory()) {
			fileList = new ArrayList<>();
			File[] files = path.listFiles();
			for (File file : files) {
				getFile(file);
			}
		}
		getResourceFile();
		if(!isRoute){
			Log.e(TAG, "线路文件不存在，请仔细检查文件目录！");
		}
		if(!isVoice){
			Log.e(TAG,  "语音文件不存在，请仔细检查文件目录！");
		}
		if(!isSet){
			Log.e(TAG, "系统设置文件不存在，请仔细检查文件目录！");
		}
		if(!isRun){
			Log.e(TAG,  "系统运行文件不存在，请仔细检查文件目录！");
		}
		if(!isVoiceOrder){
			Log.e(TAG,  "语音播报顺序设置文件不存在，请仔细检查文件目录！");
		}
		if(D)Log.d(TAG, "第一层文件检测完毕");
	}

	/**
	 * 获取公交资源文件
	 * 
	 * @return
	 */
	private  FileIntegrity getResourceFile() {
		resourceFile = new FileIntegrity();
		if (isResource) {
			resourceFile.isExist = isResource;
			resourceFile.name = path.getName();
			resourceFile.path = path.getAbsolutePath();
		}
		return resourceFile;
	}

	/**
	 * 将公交资源文件的子文件存在list
	 * 
	 * @return
	 */
	public List<FileIntegrity> getFileList() {
		return fileList;
	}

	private void getFile(File file) {
		FileIntegrity routeFile = new FileIntegrity();
		routeFile.isExist = file.exists();
		routeFile.name = file.getName();
		routeFile.path = file.getAbsolutePath();
		fileList.add(routeFile);
		if(D)Log.d(TAG, "fileName:"+file.getName());
		if(D)Log.d(TAG, "filePath:"+file.getAbsolutePath());
		switch (file.getName()) {
		case "线路":
			isRoute = true;
			break;
		case "语音":
			isVoice = true;
			break;
		case "系统设置.txt":
			isSet = true;
			break;
		case "系统运行.txt":
			isRun = true;
			break;
		case "线路列表.txt":
			isRouteList = true;
			break;
		case "语音播报顺序设置文件.txt":
			isVoiceOrder = true;
			break;
		default:
			break;
		}
	}

	/**
	 * 判断资源文件是否存在
	 * 
	 * @return
	 */
	public boolean isResourceExist() {
		if (isResource)
			return true;
		return false;
	}

	/**
	 * 路线文件是否存在
	 * 
	 * @return
	 */
	public boolean isRoute() {
		return isRoute;
	}

	/**
	 * 语音文件是否存在
	 * 
	 * @return
	 */
	public boolean isVoice() {
		return isVoice;
	}

	/**
	 * 系统设置是否存在
	 * 
	 * @return
	 */
	public boolean isSet() {
		return isSet;
	}

	/**
	 * 系统运行是否存在
	 * 
	 * @return
	 */
	public boolean isRun() {
		return isRun;
	}

	/**
	 * 路线列表是否存在
	 * 
	 * @return
	 */
	public boolean isRouteList() {
		return isRouteList;
	}

	/**
	 * 语音播报顺序设置文件是否存在
	 * 
	 * @return
	 */
	public boolean isVoiceOrder() {
		return isVoiceOrder;
	}
}
