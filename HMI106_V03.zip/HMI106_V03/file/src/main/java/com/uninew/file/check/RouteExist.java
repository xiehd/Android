package com.uninew.file.check;

import java.io.File;
import java.util.HashMap;
import java.util.Map;


/**
 * 遍历路线文件下的所有子文件，并并获取其绝对路径
 * 
 * @author rong
 *
 */
public class RouteExist {
	private File routeFile;
	private File[] files;
	private Map<String, String> paths;

	public RouteExist(File routeFile) {
		this.routeFile = routeFile;
		if (this.routeFile.isDirectory()) {
			files = this.routeFile.listFiles();
		}
		paths = new HashMap<>();
		// 初始化文件判断数据
		judge();
	}

	private void judge() {
		for (File file : files) {
			paths.put(file.getName(), file.getAbsolutePath());
		}
	}

	/**
	 * 并获取绝对路径
	 * 是用map来存储的，key值为文件名，value值为绝对路径
	 * @return
	 */
	public Map<String, String> getPaths() {
		return paths;
	}

}
