package com.uninew.file;

import java.util.ArrayList;
import java.util.List;

import android.util.Log;

import com.uninew.file.dao.StationDao;

public class RouteTools {
	private static final String TAG="RouteTools";
	
	
	/**
	 * 根据路线名称确定方向线路名称
	 * @return 704路上行-》704路下行
	 */
	public static String getReverseRouteName(String routeName){
		if (routeName==null || "".equals(routeName)) {
			Log.e(TAG, "routeName is Null !!!");
			return null;
		}
		if (routeName.endsWith("上行")) {
			return getSimpleRouteName(routeName)+"下行";
		}else if (routeName.endsWith("下行")) {
			return getSimpleRouteName(routeName)+"上行";
		}
		return null;
	}
	
	/**
	 * 根据路线名称确定上下行
	 * @return 0-上行 ，1-下行
	 */
	public static String getUpDownSide(String routeName){
		if (routeName==null || "".equals(routeName)) {
			Log.e(TAG, "routeName is Null !!!");
			return null;
		}
		if (routeName.endsWith("上行")) {
			return "上行";
		}else if (routeName.endsWith("下行")) {
			return "下行";
		}
		return null;
	}
	
	/**
	 * 根据路线名称确定上下行
	 * @return 1-上行 ，2-下行
	 */
	public static int getUpDownSideNum(String routeName){
		if (routeName==null || "".equals(routeName)) {
			Log.e(TAG, "routeName is Null !!!");
			return 0;
		}
		if (routeName.endsWith("上行")) {
			return 1;
		}else if (routeName.endsWith("下行")) {
			return 2;
		}
		return 0;
	}
	
	/**
	 * 获取路线缩略名称
	 * @param routeName 完整路线名称  如9路上行-》9路
	 * @return
	 */
	public static String getSimpleRouteName(String routeName){
		return routeName.substring(0, routeName.length()-2);
	}
	
	/**
	 * 获取路线缩略名称
	 * @param routeName 完整路线名称  如9路上行-》9
	 * @return
	 */
	public static String getNumberRouteName(String routeName){
		String name;
		if (routeName.contains("路")) {
			name = routeName.substring(0, routeName.length()-3);
		}else{
			name = routeName.substring(0, routeName.length()-2);
		}
		return name;
	}
	
	/**
	 * 获取当前站点的后续站点集合
	 * @param currentStation 当前站点
	 * @param stations 路线站点
	 */
	public static List<StationDao> getRestStations(StationDao currentStation,List<StationDao> stations){
		boolean start = false;
		List<StationDao> list=new ArrayList<StationDao>();
		for (int i = 0; i < stations.size(); i++) {
			if (currentStation.getStationId()==stations.get(i).getStationId()) {
				start=true;
			}
			if (start) {
				list.add(stations.get(i));
			}
		}
		return list;
	}	
	
}
