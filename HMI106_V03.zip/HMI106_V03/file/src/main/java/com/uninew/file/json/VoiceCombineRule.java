package com.uninew.file.json;

import java.util.ArrayList;



/**
 * 播报语音组合规则(默认的)
 * 
 * @author Administrator
 * 
 */
public class VoiceCombineRule {

	/**
	 * 起点出站播报
	 * 
	 * @param routeName
	 *            线路名称
	 * @param startStation
	 *            起点站
	 * @param endStation
	 *            终点站
	 * @param bigStation
	 *            大站
	 * @param currentStation
	 *            当前站
	 * @param outExtend
	 *            出站扩展 ,可省略
	 *            
	 * @param isDoubleLanguage 是否有双语         
	 * @param return 组合语音
	 * 
	 */
	public static ArrayList<String> getStartingOutSound(String routeName,
			String startStation, String endStation, String bigStation,
			String nextStation, String outExtend) {
		// 起点出站：起点音1.mp3 +（线路名称）+ 起点音2.mp3 + （起点站）+ 起点音3.mp3 +
		// （终点站）+ 起点音4.mp3 + (大站) + 起点音5.mp3 + 起点音6.mp3 + （本站）+ （出站扩展）
		ArrayList<String> list = new ArrayList<String>();
		list.add(FileConstant.PUBLIC_AUDIO_PATH + "起点音1"+VoiceTools.Audio_Format);
		list.add(FileConstant.AUDIO_PATH + routeName + VoiceTools.Audio_Format);
		list.add(FileConstant.PUBLIC_AUDIO_PATH + "起点音2"+VoiceTools.Audio_Format);
		list.add(FileConstant.AUDIO_PATH + startStation + VoiceTools.Audio_Format);
		list.add(FileConstant.PUBLIC_AUDIO_PATH + "起点音3"+VoiceTools.Audio_Format);
		list.add(FileConstant.AUDIO_PATH + endStation + VoiceTools.Audio_Format);
		list.add(FileConstant.PUBLIC_AUDIO_PATH + "起点音4"+VoiceTools.Audio_Format);
		list.add(FileConstant.AUDIO_PATH + bigStation + VoiceTools.Audio_Format);
		list.add(FileConstant.PUBLIC_AUDIO_PATH + "起点音5"+VoiceTools.Audio_Format);
		list.add(FileConstant.PUBLIC_AUDIO_PATH + "起点音6"+VoiceTools.Audio_Format);
		list.add(FileConstant.AUDIO_PATH + nextStation + VoiceTools.Audio_Format);
		if (outExtend != null && !"".equals(outExtend)) {
			list.add(FileConstant.AUDIO_PATH + outExtend + VoiceTools.Audio_Format);
		}
		if (FileConstant.BROADCAST_DOUBLE_LANGUAGE) {
			list.add(FileConstant.PUBLIC_AUDIO_PATH + "下一站"+VoiceTools.Audio_Format);
			list.add(FileConstant.AUDIO_PATH + nextStation + "2" + VoiceTools.Audio_Format);
		}
		return list;
	}

	/**
	 * 进站播报
	 * 
	 * @param intoStationAd
	 *            进站广告，可选项
	 * @param currentStation
	 *            当前站
	 * @param intoStationPrompt
	 *            进站提示，可选项
	 * @return
	 */
	public static ArrayList<String> getIntoStationSound(String intoStationAd,
			String currentStation, String intoStationPrompt) {
		//  进站播报：进站音1.mp3 + （进站广告） +（本站）+ 进站音2.mp3 + (进站提示) + 进站音3.mp3
		ArrayList<String> list = new ArrayList<String>();
		list.add(FileConstant.PUBLIC_AUDIO_PATH + "进站音1"+VoiceTools.Audio_Format);
		if (intoStationAd != null && !"".equals(intoStationAd)) {
			list.add(FileConstant.AUDIO_PATH + intoStationAd + VoiceTools.Audio_Format);
		}
		list.add(FileConstant.AUDIO_PATH + currentStation + VoiceTools.Audio_Format);
		list.add(FileConstant.PUBLIC_AUDIO_PATH + "进站音2"+VoiceTools.Audio_Format);
		if (intoStationPrompt != null && !"".equals(intoStationPrompt)) {
			list.add(FileConstant.AUDIO_PATH + intoStationPrompt + VoiceTools.Audio_Format);
		}
		list.add(FileConstant.PUBLIC_AUDIO_PATH + "进站音3"+VoiceTools.Audio_Format);
		if (FileConstant.BROADCAST_DOUBLE_LANGUAGE) {
			list.add(FileConstant.AUDIO_PATH + currentStation+ "_2" + VoiceTools.Audio_Format);
			list.add(FileConstant.PUBLIC_AUDIO_PATH + "到了"+VoiceTools.Audio_Format);
		}
		return list;
	}

	/**
	 * 出站播报
	 * @param outStationAd 出站广告
	 * @param nextStation	下一站
	 * @param outStationPrompt	出站提示
	 * @param outExtend	出站扩展
	 */
	public static ArrayList<String> getOutStationSound(String outStationAd, String nextStation,
			String outStationPrompt, String outExtend) {
//		出站播报：（出站广告） + 出站音1.mp3 + （下站）+  (出站提示) + 出站音2.mp3 + （出站扩展）
		ArrayList<String> list = new ArrayList<String>();
		if (outStationAd != null && !"".equals(outStationAd)) {
			list.add(FileConstant.AUDIO_PATH + outStationAd + VoiceTools.Audio_Format);
		}
		list.add(FileConstant.PUBLIC_AUDIO_PATH + "出站音1"+VoiceTools.Audio_Format);
		list.add(FileConstant.AUDIO_PATH + nextStation + VoiceTools.Audio_Format);
		if (outStationPrompt != null && !"".equals(outStationPrompt)) {
			list.add(FileConstant.AUDIO_PATH + outStationPrompt + VoiceTools.Audio_Format);
		}
		list.add(FileConstant.PUBLIC_AUDIO_PATH + "出站音2"+VoiceTools.Audio_Format);
		if (outExtend != null && !"".equals(outExtend)) {
			list.add(FileConstant.AUDIO_PATH + outExtend + VoiceTools.Audio_Format);
		}
		if (FileConstant.BROADCAST_DOUBLE_LANGUAGE) {
			list.add(FileConstant.PUBLIC_AUDIO_PATH + "下一站"+VoiceTools.Audio_Format);
			list.add(FileConstant.AUDIO_PATH + nextStation+ "2" + VoiceTools.Audio_Format);
		}
		return list;
	}

	/**
	 * 终点前站出站播报
	 */
	public static ArrayList<String> getLastSecondOutSound(String endStation) {
		ArrayList<String> list = new ArrayList<String>();
		list.add(FileConstant.PUBLIC_AUDIO_PATH + "终点音1"+VoiceTools.Audio_Format);
		list.add(FileConstant.PUBLIC_AUDIO_PATH + "终点音2"+VoiceTools.Audio_Format);
		list.add(FileConstant.AUDIO_PATH + endStation + VoiceTools.Audio_Format);
		list.add(FileConstant.PUBLIC_AUDIO_PATH + "终点音3"+VoiceTools.Audio_Format);
		if (FileConstant.BROADCAST_DOUBLE_LANGUAGE) {
			list.add(FileConstant.PUBLIC_AUDIO_PATH + "前方到站"+VoiceTools.Audio_Format);
			list.add(FileConstant.PUBLIC_AUDIO_PATH + "终点站"+VoiceTools.Audio_Format);
			list.add(FileConstant.AUDIO_PATH + endStation+ "2" + VoiceTools.Audio_Format);
		}
		return list;
	}

	/**
	 * 终点进站播报
	 * @param endStation 终点站
	 */
	public static  ArrayList<String> getEndInStationSound(String endStation) {
		ArrayList<String> list = new ArrayList<String>();
		list.add(FileConstant.PUBLIC_AUDIO_PATH + "终点音2"+VoiceTools.Audio_Format);
		list.add(FileConstant.AUDIO_PATH + endStation + VoiceTools.Audio_Format);
		list.add(FileConstant.PUBLIC_AUDIO_PATH + "终点音4"+VoiceTools.Audio_Format);
		if (FileConstant.BROADCAST_DOUBLE_LANGUAGE) {
			list.add(FileConstant.PUBLIC_AUDIO_PATH + "终点站"+VoiceTools.Audio_Format);
			list.add(FileConstant.AUDIO_PATH + endStation + "2" + VoiceTools.Audio_Format);
			list.add(FileConstant.PUBLIC_AUDIO_PATH + "到了"+VoiceTools.Audio_Format);
		}
		return list;
	}

	/**
	 * 起点外音
	 * @param routeName 线路名称
	 * @param endStation 终点站
	 */
	public static ArrayList<String> getStartingOutsideSound(String routeName,String endStation) {
		ArrayList<String> list = new ArrayList<String>();
		list.add(FileConstant.PUBLIC_AUDIO_PATH + "外音1"+VoiceTools.Audio_Format);
		list.add(FileConstant.AUDIO_PATH + routeName + VoiceTools.Audio_Format);
		list.add(FileConstant.PUBLIC_AUDIO_PATH + "外音2"+VoiceTools.Audio_Format);
		list.add(FileConstant.PUBLIC_AUDIO_PATH + "外音3"+VoiceTools.Audio_Format);
		list.add(FileConstant.AUDIO_PATH + endStation + VoiceTools.Audio_Format);
		list.add(FileConstant.PUBLIC_AUDIO_PATH + "外音4"+VoiceTools.Audio_Format);
		return list;
	}

	/**
	 * 进站外音
	 * @param routeName 线路名称
	 * @param endStation 终点站
	 */
	public static ArrayList<String> getInOutsideSound(String routeName,String endStation) {
		ArrayList<String> list = new ArrayList<String>();
		list.add(FileConstant.PUBLIC_AUDIO_PATH + "外音1"+VoiceTools.Audio_Format);
		list.add(FileConstant.AUDIO_PATH + routeName + VoiceTools.Audio_Format);
		list.add(FileConstant.PUBLIC_AUDIO_PATH + "外音2"+VoiceTools.Audio_Format);
		list.add(FileConstant.PUBLIC_AUDIO_PATH + "外音3"+VoiceTools.Audio_Format);
		list.add(FileConstant.AUDIO_PATH + endStation + VoiceTools.Audio_Format);
		list.add(FileConstant.PUBLIC_AUDIO_PATH + "外音4"+VoiceTools.Audio_Format);
		return list;
	}

	/**
	 * 出站外音
	 * @param routeName 线路名称
	 * @param endStation 终点站
	 */
	public static ArrayList<String> getOutOutsideSound(String routeName,String endStation) {
		ArrayList<String> list = new ArrayList<String>();
		list.add(FileConstant.PUBLIC_AUDIO_PATH + "外音1"+VoiceTools.Audio_Format);
		list.add(FileConstant.AUDIO_PATH + routeName + VoiceTools.Audio_Format);
		list.add(FileConstant.PUBLIC_AUDIO_PATH + "外音2"+VoiceTools.Audio_Format);
		list.add(FileConstant.PUBLIC_AUDIO_PATH + "外音3"+VoiceTools.Audio_Format);
		list.add(FileConstant.AUDIO_PATH + endStation + VoiceTools.Audio_Format);
		list.add(FileConstant.PUBLIC_AUDIO_PATH + "外音4"+VoiceTools.Audio_Format);
		return list;
	}
}
