package com.uninew.file.dao;

import java.io.Serializable;

/**
 * 运行路线信息类
 * 
 * @author Administrator
 *
 */
public class RunRoutesDao implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 3266514236506988082L;
	/** 本班次 */
	private String routeName;
	/** 开车时间 */
	private String startTime;
	/** 收车时间 */
	private String endTime;
	/** 线路标识 */
	private int lineMark;
	/** 起始站 */
	private String startStation;
	/** 终点站*/
	private String endStation;

	public String getRouteName() {
		return routeName;
	}

	public void setRouteName(String routeName) {
		this.routeName = routeName;
	}

	public String getStartTime() {
		return startTime;
	}

	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}

	public String getEndTime() {
		return endTime;
	}

	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}

	public int getLineMark() {
		return lineMark;
	}

	public void setLineMark(int lineMark) {
		this.lineMark = lineMark;
	}
	
	public String getStartStation() {
		return startStation;
	}

	public void setStartStation(String startStation) {
		this.startStation = startStation;
	}

	public String getEndStation() {
		return endStation;
	}

	public void setEndStation(String endStation) {
		this.endStation = endStation;
	}

	@Override
	public String toString() {
		return "RunRoutesDao [routeName=" + routeName + ", startTime="
				+ startTime + ", endTime=" + endTime + ", lineMark=" + lineMark
				+ ", startStation=" + startStation + ", endStation="
				+ endStation + "]";
	}
	
}
