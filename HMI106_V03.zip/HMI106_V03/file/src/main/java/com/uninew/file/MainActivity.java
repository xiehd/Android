package com.uninew.file;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

import com.uninew.file.common.DefineFileAction;
import com.uninew.file.common.FileBroadCastTools;
import com.uninew.file.dao.RoutesDao;
import com.uninew.file.dao.RunRoutesDao;
import com.uninew.file.dao.StationDao;

import java.util.ArrayList;

public class MainActivity extends Activity implements OnClickListener{

	private Button btn_query,btn_update;
	private static final String TAG="MainActivity";
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		findViews();
		Intent service=new Intent("com.uninew.bus.file.FileService");
		startService(service);
		registerBroadCast();
	}

	private void findViews() {
		// TODO Auto-generated method stub
		btn_query=(Button) findViewById(R.id.button1);
		btn_update=(Button) findViewById(R.id.button2);
		btn_query.setOnClickListener(this);
		btn_update.setOnClickListener(this);
		
	}



	@Override
	public void onClick(View arg0) {
		// TODO Auto-generated method stub
		switch (arg0.getId()) {
		case R.id.button1://查询
			new FileBroadCastTools(this).sendFileSearch("704路下行", DefineFileAction.SourceId.StationsMsg);
			break;
		case R.id.button2:
			new FileBroadCastTools(this).sendFileInitRequest();
			break;	
		default:
			break;
		}
	}
	
	
	private BroadcastReceiver mBroadcastReceiver;
	/**
	 * 广播注册
	 */
	private void registerBroadCast() {
		IntentFilter iFilter = new IntentFilter();
		iFilter.addAction(DefineFileAction.FileServerInitFinish);
		iFilter.addAction(DefineFileAction.FileServerRouteSwitchResponse);
		iFilter.addAction(DefineFileAction.FileServerSearchResponse);
		iFilter.addAction(DefineFileAction.FileServerUpdateResponse);
		iFilter.addAction(DefineFileAction.FileServerDeleteResponse);
		mBroadcastReceiver = new FileBroadCastReceiver();
		this.registerReceiver(mBroadcastReceiver, iFilter);
	}

	public class FileBroadCastReceiver extends BroadcastReceiver {
		@Override
		public void onReceive(Context context, Intent intent) {
			String action = intent.getAction();
			Log.v(TAG, "FileBroadCastReceiver,action=" + action);
			switch (action) {
			case DefineFileAction.FileServerInitFinish:
				RunRoutesDao runRoute = (RunRoutesDao) intent
				.getSerializableExtra(DefineFileAction.InitFinish_Key.RunningMsg);
				System.err.println("-----------FileServerInitFinish,,,runRoute="+runRoute.toString());
				break;
			case DefineFileAction.FileServerRouteSwitchResponse:
				RunRoutesDao rd = (RunRoutesDao) intent
						.getSerializableExtra(DefineFileAction.RouteSwitch_Key.RouteSwitch);
				break;
			case DefineFileAction.FileServerSearchResponse:
				String routeName=intent.getStringExtra(DefineFileAction.Search_Key.RouteName);
				System.err.println("-----------routeName="+routeName);
				int sourceId3 = intent.getIntExtra(
						DefineFileAction.Search_Key.SourceId, 1);
				ArrayList<StationDao> list2 = (ArrayList<StationDao>) intent
						.getSerializableExtra(DefineFileAction.Search_Key.Value);
				for (int i = 0; i < list2.size(); i++) {
					System.err.println(list2.get(i).toString());
				}
				break;
			case DefineFileAction.FileServerUpdateResponse:
				String routeName2=intent.getStringExtra(DefineFileAction.Search_Key.RouteName);
				int sourceId4 = intent.getIntExtra(
						DefineFileAction.Update_Key.SourceId, 1);
				break;
			case DefineFileAction.FileServerDeleteResponse:
				RoutesDao route = (RoutesDao) intent
				.getSerializableExtra(DefineFileAction.Delete_Key.DeleteRoute);
				break;
			default:
				break;
			}
		}
	}

	@Override
	protected void onDestroy() {
		// TODO Auto-generated method stub
		super.onDestroy();
		unregisterReceiver(mBroadcastReceiver);
	}
	
}
