package com.uninew.file.json;

/**
 * 站点相关常量类
 * 
 * @author Administrator
 * 
 */
public interface StationConstant {
	// 站点类型
	public static String STATION_TYPE_BIG = "大站";
	public static String STATION_TYPE_LITTLE = "小站";
	public static String STATION_TYPE_START = "起点站";
	public static String STATION_TYPE_END = "终点站";
	/**
	 * 类型
	 * 路口: 0:转弯 1:路口 2:直行 3:停车场 4:首站 5:场站一体 6:虚站
	 * 场站: 0:停车场
	 */
	
	public static String POINT_STATE_PARK = "场站";
	public static String POINT_STATE_CROSS = "路口";
	
	/**转弯*/
	public static int POINT_TYPE_TURNNING = 0;
	/**路口*/
	public static int POINT_TYPE_CROSS = 1;
	/**直行*/
	public static int POINT_TYPE_STRAIGHT = 2;
	/**停车场*/
	public static int POINT_TYPE_PARK = 3;
	/**首站*/
	public static int POINT_TYPE_START = 4;
	/**场站一体*/
	public static int POINT_TYPE_TERMINALONE = 5;
	/**虚站*/
	public static int POINT_TYPE_VIRTUAL = 6;
}
