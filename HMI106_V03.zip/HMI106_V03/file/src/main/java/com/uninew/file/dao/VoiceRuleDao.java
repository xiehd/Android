package com.uninew.file.dao;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;

/**
 * 语音播报规则类
 * 
 * @author Administrator
 * 
 */
public class VoiceRuleDao implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 5072902149908039314L;
	/** 起点出站 */
	private ArrayList<String> startOut;
	/** 进站播报 */
	private ArrayList<String> arriveStation;
	/** 出站播报 */
	private ArrayList<String> outStation;
	/** 终点前站出站播报 */
	private ArrayList<String> lastSencondOut;
	/** 终点进站播报 */
	private ArrayList<String> arriveTheEnd;
	/** 起点外音 */
	private ArrayList<String> startOutVoice;
	/** 进站外音 */
	private ArrayList<String> arriveOutVoice;
	/** 出站外音 */
	private ArrayList<String> outStationVoice;

	public VoiceRuleDao() {
		super();
	}

	public VoiceRuleDao(ArrayList<String> startOut,
			ArrayList<String> arriveStation, ArrayList<String> outStation,
			ArrayList<String> lastSencondOut, ArrayList<String> arriveTheEnd,
			ArrayList<String> startOutVoice, ArrayList<String> arriveOutVoice,
			ArrayList<String> outStationVoice) {
		super();
		this.startOut = startOut;
		this.arriveStation = arriveStation;
		this.outStation = outStation;
		this.lastSencondOut = lastSencondOut;
		this.arriveTheEnd = arriveTheEnd;
		this.startOutVoice = startOutVoice;
		this.arriveOutVoice = arriveOutVoice;
		this.outStationVoice = outStationVoice;
	}

	public ArrayList<String> getStartOut() {
		return startOut;
	}

	public void setStartOut(ArrayList<String> startOut) {
		this.startOut = startOut;
	}

	public ArrayList<String> getArriveStation() {
		return arriveStation;
	}

	public void setArriveStation(ArrayList<String> arriveStation) {
		this.arriveStation = arriveStation;
	}

	public ArrayList<String> getOutStation() {
		return outStation;
	}

	public void setOutStation(ArrayList<String> outStation) {
		this.outStation = outStation;
	}

	public ArrayList<String> getLastSencondOut() {
		return lastSencondOut;
	}

	public void setLastSencondOut(ArrayList<String> lastSencondOut) {
		this.lastSencondOut = lastSencondOut;
	}

	public ArrayList<String> getArriveTheEnd() {
		return arriveTheEnd;
	}

	public void setArriveTheEnd(ArrayList<String> arriveTheEnd) {
		this.arriveTheEnd = arriveTheEnd;
	}

	public ArrayList<String> getStartOutVoice() {
		return startOutVoice;
	}

	public void setStartOutVoice(ArrayList<String> startOutVoice) {
		this.startOutVoice = startOutVoice;
	}

	public ArrayList<String> getArriveOutVoice() {
		return arriveOutVoice;
	}

	public void setArriveOutVoice(ArrayList<String> arriveOutVoice) {
		this.arriveOutVoice = arriveOutVoice;
	}

	public ArrayList<String> getOutStationVoice() {
		return outStationVoice;
	}

	public void setOutStationVoice(ArrayList<String> outStationVoice) {
		this.outStationVoice = outStationVoice;
	}

	@Override
	public String toString() {
		return "VoiceRuleDao [startOut=" + startOut + ", arriveStation="
				+ arriveStation + ", outStation=" + outStation
				+ ", lastSencondOut=" + lastSencondOut + ", arriveTheEnd="
				+ arriveTheEnd + ", startOutVoice=" + startOutVoice
				+ ", arriveOutVoice=" + arriveOutVoice + ", outStationVoice="
				+ outStationVoice + "]";
	}

}
