package com.uninew.file.dao;

import java.io.Serializable;

/**
 * 系统设置类
 * @author Administrator
 *
 */
public class SettingsDao implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = -3657288856514810811L;
	/** 车牌号 */
	private String licensePlate;
	/** 驾驶员 */
	private String driver;
	/** 工号 */
	private String jobNumber;
	/** 乘务员 */
	private String ticketSeller;
	/** 限乘人数 */
	private int limitedNumber;

	public SettingsDao() {
		super();
	}

	public SettingsDao(String licensePlate, String driver,
			String jobNumber, String ticketSeller, int limitedNumber) {
		super();
		this.licensePlate = licensePlate;
		this.driver = driver;
		this.jobNumber = jobNumber;
		this.ticketSeller = ticketSeller;
		this.limitedNumber = limitedNumber;
	}

	public String getLicensePlate() {
		return licensePlate;
	}

	public void setLicensePlate(String licensePlate) {
		this.licensePlate = licensePlate;
	}

	public String getDriver() {
		return driver;
	}

	public void setDriver(String driver) {
		this.driver = driver;
	}

	public String getJobNumber() {
		return jobNumber;
	}

	public void setJobNumber(String jobNumber) {
		this.jobNumber = jobNumber;
	}

	public String getTicketSeller() {
		return ticketSeller;
	}

	public void setTicketSeller(String ticketSeller) {
		this.ticketSeller = ticketSeller;
	}

	public int getLimitedNumber() {
		return limitedNumber;
	}

	public void setLimitedNumber(int limitedNumber) {
		this.limitedNumber = limitedNumber;
	}

	@Override
	public String toString() {
		return "SettingsDao [licensePlate=" + licensePlate + ", driver="
				+ driver + ", jobNumber=" + jobNumber
				+ ", ticketSeller=" + ticketSeller + ", limitedNumber="
				+ limitedNumber + "]";
	}

}
