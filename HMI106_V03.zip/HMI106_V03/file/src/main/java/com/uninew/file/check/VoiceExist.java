package com.uninew.file.check;

import java.io.File;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Map;

/**
 * 遍历语音文件下的所有子文件，并并获取其绝对路径
 * @author rong
 *
 */ 

public class VoiceExist {

	private File voiceFile;
	private LinkedList<File> files;
	private Map<String, String> paths;

	public VoiceExist(File voiceFile) {
		this.voiceFile = voiceFile;
		files = new LinkedList<>();
		if(voiceFile.exists()){
			if (this.voiceFile.isDirectory()) {
				File[] son_Files = this.voiceFile.listFiles();
				getFile(son_Files);
			}
			paths = new HashMap<>();
			judge();
		}
	}

	private void judge() {
		for (File file : files) {
			paths.put(file.getName(), file.getAbsolutePath());
		}
	}
	
	/**
	 * 获取语音目录下的所有文件
	 * @param son_files
	 */
	private void getFile(File[] son_Files){
		if(son_Files != null && son_Files.length > 0){
			for(File file : son_Files){
				if(file.isDirectory()){
					getFile(file.listFiles());
				}else if(file.isFile()){
					files.add(file);
				}
			}
		}
	}
	
	/**
	 * 并获取绝对路径
	 * 是用map来存储的，key值为文件名，value值为绝对路径
	 * @return
	 */
	public Map<String, String> getPaths() {
		return paths;
	}
}
