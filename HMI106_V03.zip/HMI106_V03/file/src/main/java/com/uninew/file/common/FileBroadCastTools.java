package com.uninew.file.common;

import java.io.Serializable;
import java.util.ArrayList;

import android.content.Context;
import android.content.Intent;
import android.util.Log;

import com.uninew.file.dao.MarkerDao;
import com.uninew.file.dao.RoutesDao;
import com.uninew.file.dao.RunRoutesDao;
import com.uninew.file.dao.SettingsDao;
import com.uninew.file.dao.StationDao;
import com.uninew.file.dao.VoiceRuleDao;

public class FileBroadCastTools {
	private static final String TAG = "FileBroadCastTools";
	private static boolean D=true;
	private Context mContext;

	public FileBroadCastTools(Context mContext) {
		super();
		this.mContext = mContext;
	}
///////////////////////////////////以下方法为FileServer端发送/////////////////////////////////////
	/**
	 * 资源文件初始化完成通知
	 * @param runRoute 运行线路
	 * @param routes 线路列表
	 * @param stations 站点列表
	 * @param settings 设置信息
	 * @param serviceVoices 服务语音
	 * @param corners 路口列表
	 * @param voiceRule 语音规则
	 * @param reverseStations 反向站点信息
	 * @param reverseCorners 反向路口信息
	 */
	public void sendFileInitFinish(RunRoutesDao runRoute, ArrayList<RoutesDao> routes,
			ArrayList<StationDao> stations, SettingsDao settings,
			ArrayList<String> serviceVoices, ArrayList<MarkerDao> corners,
			VoiceRuleDao voiceRule,ArrayList<StationDao> reverseStations,ArrayList<MarkerDao> reverseCorners) {
		if(D)Log.d(TAG, "sendFileInitFinish");
		Intent intent = new Intent(DefineFileAction.FileServerInitFinish);
		if (null != runRoute)
			intent.putExtra(DefineFileAction.InitFinish_Key.RunningMsg, runRoute);
		if (null != routes)
			intent.putExtra(DefineFileAction.InitFinish_Key.RoutesMsg, (Serializable) routes);
		if (null != stations)
			intent.putExtra(DefineFileAction.InitFinish_Key.StationsMsg, (Serializable) stations);
		if (null != settings)
			intent.putExtra(DefineFileAction.InitFinish_Key.SettingsMsg, settings);
		if (null != serviceVoices)
			intent.putExtra(DefineFileAction.InitFinish_Key.ServiceVoices, (Serializable) serviceVoices);
		if (null != corners)
			intent.putExtra(DefineFileAction.InitFinish_Key.CornersMsg, (Serializable) corners);
		if (null != voiceRule)
			intent.putExtra(DefineFileAction.InitFinish_Key.VoiceRuleMsg, voiceRule);
		if (null != reverseStations)
			intent.putExtra(DefineFileAction.InitFinish_Key.ReverseStationsMsg, (Serializable) reverseStations);
		if (null != reverseCorners)
			intent.putExtra(DefineFileAction.InitFinish_Key.ReverseCornersMsg, (Serializable) reverseCorners);
		mContext.sendBroadcast(intent);
	}
	
	/**
	 * 线路切换应答
	 * @param result 切换结果 0-失败，1-成功
	 * @param switchType 切换类型 ：0-上下行切换，1-线路切换
	 * @param runRoute 运行线路
	 * @param routes 线路列表
	 * @param stations 站点列表
	 * @param corners 拐点列表
	 */
	public void sendRouteSwitchResponse(int result,int switchType,RunRoutesDao runRoute, ArrayList<RoutesDao> routes,
			ArrayList<StationDao> stations,ArrayList<MarkerDao> corners){
		if(D)Log.d(TAG, "sendRouteSwitchResponse");
		Intent intent = new Intent(DefineFileAction.FileServerRouteSwitchResponse);
		intent.putExtra(DefineFileAction.RouteSwitch_Key.SwitchResult, result);
		intent.putExtra(DefineFileAction.RouteSwitch_Key.SwitchType, switchType);
		intent.putExtra(DefineFileAction.RouteSwitch_Key.RunningMsg, runRoute);
		intent.putExtra(DefineFileAction.RouteSwitch_Key.RoutesMsg, (Serializable)routes);
		intent.putExtra(DefineFileAction.RouteSwitch_Key.StationsMsg, (Serializable)stations);
		intent.putExtra(DefineFileAction.RouteSwitch_Key.CornersMsg, (Serializable)corners);
		mContext.sendBroadcast(intent);
	}
	
	/**
	 * 当前资源信息查询应答
	 * @param result 结果 0-失败，1-成功
	 * @param routeName 线路名称，如：704路上行
	 * @param sourceId(01：运行信息，02：线路信息,03：站点信息,04：设置参数,05：,06,07)
	 * @param objects
	 */
	public void sendFileSearchResponse(int result,String routeName,int sourceId,ArrayList<?> objects){
		if(D)Log.d(TAG, "sendFileSearchResponse");
		Intent intent = new Intent(DefineFileAction.FileServerSearchResponse);
		intent.putExtra(DefineFileAction.Search_Key.RouteName, routeName);
		intent.putExtra(DefineFileAction.Search_Key.SearchResult, result);
		intent.putExtra(DefineFileAction.Search_Key.SourceId, sourceId);
		intent.putExtra(DefineFileAction.Search_Key.Value, objects);
		mContext.sendBroadcast(intent);
	}
	
	
	/**
	 * 当前资源信息更新应答
	 * @param result 结果 0-失败，1-成功
	 * @param routeName 线路名称，如：704路上行
	 * @param sourceId(01：运行信息，02：线路信息,03：站点信息,04：设置参数,05：,06,07)
	 * @param objects
	 */
	public void sendFileUpdateResponse(int result,String routeName,int sourceId,ArrayList<?> objects){
		if(D)Log.d(TAG, "sendFileUpdateResponse");
		Intent intent = new Intent(DefineFileAction.FileServerUpdateResponse);
		intent.putExtra(DefineFileAction.Update_Key.RouteName, routeName);
		intent.putExtra(DefineFileAction.Update_Key.UpdateResult, result);
		intent.putExtra(DefineFileAction.Update_Key.SourceId, sourceId);
		intent.putExtra(DefineFileAction.Update_Key.Value, objects);
		mContext.sendBroadcast(intent);
	}
	
	/**
	 * 线路删除应答
	 * @param result 结果 0-失败，1-成功
	 */
	public void sendFileDeleteResponse(int result){
		if(D)Log.d(TAG, "sendFileDeleteResponse");
		Intent intent = new Intent(DefineFileAction.FileServerDeleteResponse);
		intent.putExtra(DefineFileAction.Delete_Key.DeleteResult, result);
		mContext.sendBroadcast(intent);
	}
	
	
///////////////////////////////////以下方法为FileClient端发送/////////////////////////////////////

	/**
	 * 文件初始化请求
	 */
	public void sendFileInitRequest(){
		if(D)Log.d(TAG, "sendFileInitRequest");
		Intent intent = new Intent(DefineFileAction.FileServerInitRequest);
		mContext.sendBroadcast(intent);
	}
	
	/**
	 * 线路切换
	 * @param runRoute 需要切换的线路信息
	 */
	public void sendRouteSwitch(RunRoutesDao runRoute){
		if(D)Log.d(TAG, "sendRouteSwitch");
		Intent intent = new Intent(DefineFileAction.FileServerRouteSwitchRequest);
		intent.putExtra(DefineFileAction.RouteSwitch_Key.RouteSwitch, runRoute);
		mContext.sendBroadcast(intent);
	}
	
	/**
	 * 当前资源信息查询
	 * @param routeName 线路名称，如：704路上行
	 * @param sourceId(01：运行信息，02：线路信息,03：站点信息,04：设置参数,05：服务用语,06：拐点信息,07：播报规则)
	 */
	public void sendFileSearch(String routeName,int sourceId){
		if(D)Log.d(TAG, "sendFileSearch");
		Intent intent = new Intent(DefineFileAction.FileServerSearch);
		intent.putExtra(DefineFileAction.Search_Key.RouteName, routeName);
		intent.putExtra(DefineFileAction.Search_Key.SourceId, sourceId);
		mContext.sendBroadcast(intent);
		
	}
	
	/**
	 * 当前资源信息更新
	 * @param routeName 线路名称，如：704路上行
	 * @param sourceId(01：运行信息，02：线路信息,03：站点信息,04：设置参数,05：,06,07)
	 * @param objects 更新信息
	 */
	public void sendFileUpdate(String routeName,int sourceId,ArrayList<?> objects){
		if(D)Log.d(TAG, "sendFileUpdate");
		Intent intent = new Intent(DefineFileAction.FileServerUpdate);
		intent.putExtra(DefineFileAction.Update_Key.RouteName, routeName);
		intent.putExtra(DefineFileAction.Update_Key.SourceId, (Serializable)sourceId);
		intent.putExtra(DefineFileAction.Update_Key.Value, (Serializable)objects);
		mContext.sendBroadcast(intent);
		
	}
	
	/**
	 * 线路删除
	 * @param route
	 */
	public void sendFileDelete(RoutesDao route){
		if(D)Log.d(TAG, "sendFileDelete");
		Intent intent = new Intent(DefineFileAction.FileServerDelete);
		intent.putExtra(DefineFileAction.Delete_Key.DeleteRoute, (Serializable)route);
		mContext.sendBroadcast(intent);
	}
	
	
}
