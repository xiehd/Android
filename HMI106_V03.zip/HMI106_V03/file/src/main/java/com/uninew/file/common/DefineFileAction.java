package com.uninew.file.common;

/**
 * 定义文件交互相关的Action
 * 
 * @author Administrator
 * 
 */
public interface DefineFileAction {

	/** 文件初始化请求 */
	String FileServerInitRequest = "Com.FileServer.InitRequest";
	/** 文件初始化完成 */
	String FileServerInitFinish = "Com.FileServer.InitFinish";

	public interface InitFinish_Key {
		/** 运行信息 */
		String RunningMsg = "RunningMsg";
		/** 路线信息 */
		String RoutesMsg = "RoutesMsg";
		/** 站点信息 */
		String StationsMsg = "StationsMsg";
		/** 设置参数 */
		String SettingsMsg = "SettingsMsg";
		/** 服务语音 */
		String ServiceVoices = "ServiceVoices";
		/** 拐点信息 */
		String CornersMsg = "CornersMsg";
		/** 语音播报规则 */
		String VoiceRuleMsg = "VoiceRuleMsg";
		
		/** 站点信息（反向） */
		String ReverseStationsMsg = "ReverseStationsMsg";
		/** 拐点信息 （反向）*/
		String ReverseCornersMsg = "ReverseCornersMsg";
	}
//--------------------------------------------------------------------
	/** 线路切换 */
	String FileServerRouteSwitchRequest = "Com.FileServer.RouteSwitch.Request";
	/** 线路切换通知 */
	String FileServerRouteSwitchResponse = "Com.FileServer.RouteSwitch.Response";

	public interface RouteSwitch_Key {
		/** 线路切换Key */
		String RouteSwitch = "RouteSwitch";
		
		/** 线路切换结果 */
		String SwitchResult = "Result";
		/** 线路切换类型：0：上下行切换，1：线路切换 */
		String SwitchType = "SwitchType";
		/** 运行信息 */
		String RunningMsg = "RunningMsg";
		/** 路线信息 */
		String RoutesMsg = "RoutesMsg";
		/** 站点信息 */
		String StationsMsg = "StationsMsg";
		/** 拐点信息 */
		String CornersMsg = "CornersMsg";
	}
//---------------------------------------------------------------------
	/** 线路资源信息查询 */
	String FileServerSearch = "Com.FileServer.Search";
	/** 资源信息查询应答 */
	String FileServerSearchResponse = "Com.FileServer.Search.Response";

	public interface Search_Key {
		/** 结果0-失败，1-成功 */
		String SearchResult = "Result";
		String RouteName="RouteName";
		/** 资源ID */
		String SourceId = "SourceId";
		String Value = "Value";
	}
//-------------------------------------------------------------------
	/** 线路资源信息更新 */
	String FileServerUpdate = "Com.FileServer.Update";
	/** 资源信息更新应答 */
	String FileServerUpdateResponse = "Com.FileServer.Update.Response";

	public interface Update_Key {
		/** 结果0-失败，1-成功 */
		String UpdateResult = "Result";
		String RouteName="RouteName";
		/** 资源ID */
		String SourceId = "SourceId";
		String Value = "Value";
	}
	

	public interface SourceId {
		/** 运行信息 */
		int RunningMsg = 0x01;
		/** 路线信息 */
		int RoutesMsg = 0x02;
		/** 站点信息 */
		int StationsMsg = 0x03;
		/** 设置参数 */
		int SettingsMsg = 0x04;
		/** 服务语音 */
		int ServiceVoices = 0x05;
		/** 标记信息 */
		int CornersMsg = 0x06;
		/** 语音播报规则 */
		int VoiceRuleMsg = 0x07;
	}
	
//-----------------------------------------------------------------------
	/** 线路资源信息删除*/
	String FileServerDelete = "Com.FileServer.Delete";
	/** 资源信息删除应答 */
	String FileServerDeleteResponse = "Com.FileServer.Delete.Response";
	
	public interface Delete_Key {
		/**删除线路键值*/
		String DeleteRoute = "DeleteRoute";
		/** 结果0-失败，1-成功 */
		String DeleteResult = "Result";
	}
	
	/**
	 * 成功失败常量
	 * @author Administrator
	 *
	 */
	public interface Result{
		/** 失败 */
		int Result_Failure = 0x00;
		/** 成功 */
		int Result_Success = 0x01;
	}
	

}
