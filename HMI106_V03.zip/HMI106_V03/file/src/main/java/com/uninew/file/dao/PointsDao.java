package com.uninew.file.dao;

/**
 * 轨迹点
 * @author Administrator
 * 
 */
public class PointsDao {
	/** 路口标识*/
	private int crossID;
	/** 路口编号 */
	private int pid;
	/** 上站点编号 */
	private int lastStationId;
	/** 下站点编号 */
	private int nextStationId;
	/** 经度 */
	private double longitude;
	/** 纬度 */
	private double latitude;	
	/**
	 * 属性(0:转弯  1:路口  2:直行  3:停车场  4:首站  5:场站一体)
	 */
	private int crossType;
	/**
	 * 路口名称
	 */
	private String crossName;
	
	/** 与参考点的距离--排序使用 */
	private int distance;
	private byte[] data;

	public PointsDao() {
		super();
	}

	
	public PointsDao(int crossID, int pid, int lastStationId,
			int nextStationId, double longitude, double latitude, int crossType , String crossName) {
		super();
		this.crossID = crossID;
		this.pid = pid;
		this.lastStationId = lastStationId;
		this.nextStationId = nextStationId;
		this.longitude = longitude;
		this.latitude = latitude;
		this.crossType = crossType;
		this.crossName = crossName;
		try {
			parseData();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * 数据解析
	 */
	private void parseData() {
		
	}

	public int getPid() {
		return pid;
	}

	public void setPid(int pid) {
		this.pid = pid;
	}

	public int getLastStationId() {
		return lastStationId;
	}

	public void setLastStationId(int lastStationId) {
		this.lastStationId = lastStationId;
	}

	public int getNextStationId() {
		return nextStationId;
	}

	public void setNextStationId(int nextStationId) {
		this.nextStationId = nextStationId;
	}

	public double getLongitude() {
		return longitude;
	}

	public void setLongitude(double longitude) {
		this.longitude = longitude;
	}

	public double getLatitude() {
		return latitude;
	}

	public void setLatitude(double latitude) {
		this.latitude = latitude;
	}

	public int getDistance() {
		return distance;
	}

	public void setDistance(int distance) {
		this.distance = distance;
	}
	
	public int getCrossID() {
		return crossID;
	}


	public void setCrossID(int crossID) {
		this.crossID = crossID;
	}


	public int getCrossType() {
		return crossType;
	}


	public void setCrossType(int crossType) {
		this.crossType = crossType;
	}


	public byte[] getData() {
		return data;
	}


	public void setData(byte[] data) {
		this.data = data;
	}


	@Override
	public String toString() {
		return "PointsDao [pid=" + pid + ", lastStationId=" + lastStationId
				+ ", nextStationId=" + nextStationId + ", longitude="
				+ longitude + ", latitude=" + latitude +", crossName=" + crossName + "]";
	}


	public String getCrossName() {
		return crossName;
	}


	public void setCrossName(String crossName) {
		this.crossName = crossName;
	}
	
}
