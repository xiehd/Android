package com.uninew.mms.hz;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.util.Arrays;

import com.uninew.mms.interfaces.IProtocolPacket;
import com.uninew.mms.protocol.McuCheckSum;
import com.uninew.mms.toyou.CheckTools;
import com.uninew.mms.toyou.DefineTYRoadSigns;
import com.uninew.mms.toyou.EscapeTools;
import com.uninew.mms.util.LogTool;

/**
 * 杭正协议解包封包
 * @author Administrator
 *
 */
public class HzRoadSignsPacket implements IProtocolPacket{
	private static final String TAG="HzRoadSignsPacket";
	private static boolean D=true;
	/** 帧头 */
	private byte startFlag;
	/** 包类型 */
	private byte pkgType;
	/** 包长度*/
	private short pkgLength;
	/** 屏ID*/
	private short screenId;
	/** 报文命令 */
	private String msgCmd;
	/** 命令类型 */
	private byte cmdType;
	/** 消息内容*/
	private byte[] body;
	/**CRC校验*/
	private short crc;
	/**结束标识符*/
	private byte endFlag;
	
	public HzRoadSignsPacket(int screenId,byte[] body) {
		super();
		this.screenId=(short) screenId;
		this.body = body;
		//以下均为协议固定参数
		this.startFlag=DefineHzRoadSigns.MSG_FLAG;
		this.endFlag=DefineHzRoadSigns.MSG_FLAG;
		this.pkgType=DefineHzRoadSigns.DEFAULT_PKGTYPE;
		this.pkgLength=(short) (body.length+10);
		this.msgCmd=DefineHzRoadSigns.DEFAULT_MSGCMD;
		this.cmdType=DefineHzRoadSigns.DEFAULT_CMDTYPE;
	}
	@Override
	public byte[] getBytes() {
		// TODO Auto-generated method stub
		ByteArrayOutputStream bis = new ByteArrayOutputStream();
		DataOutputStream dos = new DataOutputStream(bis);
		try {
			dos.writeByte(startFlag);
			dos.writeByte(pkgType);
			dos.writeShort(pkgLength);
			dos.writeShort(screenId);
			dos.write(msgCmd.getBytes(DefineHzRoadSigns.ENCODE_ASCII));
			dos.writeByte(cmdType);
			dos.write(body);
			dos.flush();
			byte[] msgBytes = bis.toByteArray();
			crc = McuCheckSum.check(msgBytes, 1); // 校验码
			LogTool.logV(TAG,
					"CheckNum=" + Integer.toHexString(crc & 0xffff));
			dos.writeShort(crc);
			dos.writeByte(endFlag);
			byte[] msg = bis.toByteArray(); 
			msg = HZEscapeTools.escape(msg, 1, msg.length - 1); // 标识位不参与转义
			return msg;
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	@Override
	public Object getProtocolPacket(byte[] datas) {
		if (datas.length < 13) {
			LogTool.logE(TAG, "datas is Error!!!");
			return null;
		}
		try {
			ByteArrayInputStream bis = new ByteArrayInputStream(datas);
			DataInputStream dis = new DataInputStream(bis);
			startFlag = dis.readByte();
			if (DefineTYRoadSigns.MSG_FLAG==startFlag) {
				pkgType = dis.readByte();
				pkgLength = dis.readShort();
				screenId=dis.readShort();
				byte[] msgCmd=new byte[4];
				dis.read(msgCmd);
				this.msgCmd=new String(msgCmd, DefineHzRoadSigns.ENCODE_ASCII);
				cmdType=dis.readByte();
				body = new byte[datas.length - 5];
				dis.read(body, 0, pkgLength - 10);
				crc = dis.readShort();
				short realCheck=McuCheckSum.check(datas, 1, datas.length-3);
				if (crc != realCheck) {
					LogTool.logE(TAG, "Datas check Error!! check="+crc+" ,realCheck="+realCheck);
					return null;
				}
				endFlag=dis.readByte();
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
		return this;
	}
	
	
	public byte getStartFlag() {
		return startFlag;
	}
	public void setStartFlag(byte startFlag) {
		this.startFlag = startFlag;
	}
	public byte getPkgType() {
		return pkgType;
	}
	public void setPkgType(byte pkgType) {
		this.pkgType = pkgType;
	}
	public short getPkgLength() {
		return pkgLength;
	}
	public void setPkgLength(short pkgLength) {
		this.pkgLength = pkgLength;
	}
	public short getScreenId() {
		return screenId;
	}
	public void setScreenId(short screenId) {
		this.screenId = screenId;
	}
	public String getMsgCmd() {
		return msgCmd;
	}
	public void setMsgCmd(String msgCmd) {
		this.msgCmd = msgCmd;
	}
	public byte getCmdType() {
		return cmdType;
	}
	public void setCmdType(byte cmdType) {
		this.cmdType = cmdType;
	}
	public byte[] getBody() {
		return body;
	}
	public void setBody(byte[] body) {
		this.body = body;
	}
	public short getCrc() {
		return crc;
	}
	public void setCrc(short crc) {
		this.crc = crc;
	}
	public byte getEndFlag() {
		return endFlag;
	}
	public void setEndFlag(byte endFlag) {
		this.endFlag = endFlag;
	}
	@Override
	public String toString() {
		return "HzRoadSignsPacket [startFlag=" + startFlag + ", pkgType="
				+ pkgType + ", pkgLength=" + pkgLength + ", screenId="
				+ screenId + ", msgCmd=" + msgCmd + ", cmdType=" + cmdType
				+ ", body=" + Arrays.toString(body) + ", crc=" + crc
				+ ", endFlag=" + endFlag + "]";
	}
	
}
