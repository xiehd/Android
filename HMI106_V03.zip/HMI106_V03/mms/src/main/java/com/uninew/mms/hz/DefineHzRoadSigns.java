package com.uninew.mms.hz;

public interface DefineHzRoadSigns {

	/**编码格式*/
	public String ENCODE_GB2312="GB2312";
	public String ENCODE_GBK="GB2312";
	public String ENCODE_ASCII="ASCII";
	
	/**开始结束标志*/
	public byte MSG_FLAG = 0x7e;
	/**转义标志*/
	public byte ESCAPE = 0x7d;
	/**7E转义标志*/
	public byte FOLLOW_ESCAPE_7E = 0x02;
	/**7D转义标志*/
	public byte FOLLOW_ESCAPE_7D = 0x01;
	
	/**包类型*/
	public byte DEFAULT_PKGTYPE=0x43;
	/**屏ID*/
	public byte DEFAULT_SCREENID=0x0000;
	/**报文命令*/
	public String DEFAULT_MSGCMD="NBGJ";
	/**命令类型*/
	public byte DEFAULT_CMDTYPE=0x07;
	
	/**正确应答，错误应答*/
	public byte RESPONSE_OK=(byte) 0xAA;
	
}
