package com.uninew.mms.eyesdata;

import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.IOException;

import com.uninew.mms.interfaces.IProtocolPacket;

/***
 * 客流量应答
 * 
 * @author Administrator
 */
public class PPassengerFlow implements IProtocolPacket{
	private static final String TAG="PPassengerFlow";
	/**数据帧类型*/
	private byte dataFrameType;
	/**数据帧长度*/
	private short dataFrameLength;
	/**上车人数*/
	private int upNumber;
	/**下车人数*/
	private int downNumber;
	/**车内人数*/
	private int totalNumber;
	
	
	@Override
	public byte[] getBytes() {
		// TODO Auto-generated method stub
		
		return null;
	}
	@Override
	public PPassengerFlow getProtocolPacket(byte[] datas) {
		try {
			ByteArrayInputStream bis = new ByteArrayInputStream(datas);
			DataInputStream dis = new DataInputStream(bis);
			dataFrameType = dis.readByte();
			dataFrameLength = dis.readShort();
			upNumber = dis.readUnsignedByte();
			downNumber = dis.readUnsignedByte();
			totalNumber = dis.readUnsignedByte();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return this;
	}
	public byte getDataFrameType() {
		return dataFrameType;
	}
	public void setDataFrameType(byte dataFrameType) {
		this.dataFrameType = dataFrameType;
	}
	public short getDataFrameLength() {
		return dataFrameLength;
	}
	public void setDataFrameLength(short dataFrameLength) {
		this.dataFrameLength = dataFrameLength;
	}
	public int getUpNumber() {
		return upNumber;
	}
	public void setUpNumber(int upNumber) {
		this.upNumber = upNumber;
	}
	public int getDownNumber() {
		return downNumber;
	}
	public void setDownNumber(int downNumber) {
		this.downNumber = downNumber;
	}
	public int getTotalNumber() {
		return totalNumber;
	}
	public void setTotalNumber(int totalNumber) {
		this.totalNumber = totalNumber;
	}
	@Override
	public String toString() {
		return "PPassengerFlow [dataFrameType=" + dataFrameType
				+ ", dataFrameLength=" + dataFrameLength + ", upNumber="
				+ upNumber + ", downNumber=" + downNumber + ", totalNumber="
				+ totalNumber + "]";
	}
	
}
