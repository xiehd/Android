package com.uninew.mms.protocol;

import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.IOException;
import java.util.Arrays;

import com.uninew.mms.interfaces.IProtocolPacket;

/**
 * MCU与ARM协议解析
 * 
 * @author Administrator
 * 
 */
public class ProtocolPacket implements IProtocolPacket{
	/** 开始标志 */
	private short startFlag;
	/** TypeId */
	private byte typeId;
	/** GroupId */
	private byte groupId;
	/** commandId */
	private byte commandId = -1;
	/** 消息体 */
	private byte[] body;
	/** 消息长度 */
	private byte length;
	/** CRC校验 */
	private short crc;

	public ProtocolPacket() {
		super();
	}

	public ProtocolPacket(byte typeId, byte groupId, byte[] body) {
		super();
		this.typeId = typeId;
		this.groupId = groupId;
		this.body = body;
		if (commandId == -1) {
			length = (byte) (5 + body.length);
		} else {
			length = (byte) (6 + body.length);
		}
	}

	public ProtocolPacket(byte typeId, byte groupId, byte commandId, byte[] body) {
		super();
		this.typeId = typeId;
		this.groupId = groupId;
		this.commandId = commandId;
		this.body = body;
		if (commandId == -1) {
			length = (byte) (5 + body.length);
		} else {
			length = (byte) (6 + body.length);
		}
	}

	/**
	 * 转换成字节数组
	 * 
	 * @return
	 * @throws IOException
	 */
	public byte[] getBytes() {
		byte[] datas = null;
		if (commandId == -1) {
			datas = new byte[7 + body.length];
		} else {
			datas = new byte[8 + body.length];
		}
		try {
			// 标志
			datas[0] = (byte) (0xff & (DefineMcu.MCU_FLAG >> 8));
			datas[1] = (byte) (0xff & DefineMcu.MCU_FLAG);
			// 长度
			datas[2] = (byte) (0xff & length);
			// typeId
			datas[3] = typeId;
			// groupId
			datas[4] = groupId;
			if (commandId == -1) {
				// 消息体
				System.arraycopy(body, 0, datas, 5, body.length);
				// 校验位
				crc = McuCheckSum.check(datas, 2, datas.length - 2);
				datas[datas.length - 2] = (byte) (0xff & (crc >> 8));
				datas[datas.length - 1] = (byte) (0xff & (crc));
			} else {
				datas[5] = commandId;
				// 消息体
				System.arraycopy(body, 0, datas, 6, body.length);
				// 校验位
				crc = McuCheckSum.check(datas, 2, datas.length - 2);
				datas[datas.length - 2] = (byte) (0xff & (crc >> 8));
				datas[datas.length - 1] = (byte) (0xff & (crc));
			}
		} catch (Exception e) {
			// TODO: handle exception
		}
		return datas;
	}

	/**
	 * 将字节数组转化成协议对象
	 * 
	 * @param datas
	 * @return
	 */
	public ProtocolPacket getProtocolPacket(byte[] datas) {
		try {
			ByteArrayInputStream bis = new ByteArrayInputStream(datas);
			DataInputStream dis = new DataInputStream(bis);
			startFlag = dis.readShort();
			length = dis.readByte();
			typeId = dis.readByte();
			groupId = dis.readByte();
			body = new byte[length - 5];
			dis.read(body, 0, length - 5);
			crc = dis.readShort();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return this;
	}

	public byte getTypeId() {
		return typeId;
	}

	public void setTypeId(byte typeId) {
		this.typeId = typeId;
	}

	public byte getGroupId() {
		return groupId;
	}

	public void setGroupId(byte groupId) {
		this.groupId = groupId;
	}

	public byte[] getBody() {
		return body;
	}

	public void setBody(byte[] body) {
		this.body = body;
	}

	public short getStartFlag() {
		return startFlag;
	}

	public void setStartFlag(short startFlag) {
		this.startFlag = startFlag;
	}

	public short getLength() {
		return length;
	}

	public void setLength(byte length) {
		this.length = length;
	}

	@Override
	public String toString() {
		return "ProtocolPacket [startFlag=" + startFlag + ", typeId=" + typeId
				+ ", groupId=" + groupId + ", body=" + Arrays.toString(body)
				+ ", length=" + length + ", crc=" + crc + "]";
	}

}
