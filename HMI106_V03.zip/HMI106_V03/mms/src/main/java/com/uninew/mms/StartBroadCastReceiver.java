package com.uninew.mms;

import com.uninew.mms.util.LogTool;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class StartBroadCastReceiver extends BroadcastReceiver{

	@Override
	public void onReceive(Context context, Intent intent) {
		// TODO Auto-generated method stub
		LogTool.logD("yzb", "Boot complete!!!!");
		Intent mmsService = new Intent(context,McuService.class);
		context.startService(mmsService);
	}

}
