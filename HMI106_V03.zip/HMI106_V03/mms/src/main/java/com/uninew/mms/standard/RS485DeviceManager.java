package com.uninew.mms.standard;

import com.uninew.mms.interfaces.IRoadSignsDatas;

public class RS485DeviceManager {
	private RS485DevicePacket mDevicePacket;

	public RS485DeviceManager() {
		mDevicePacket=new RS485DevicePacket();
	}

	/**
	 * 处理路牌数据
	 * 
	 * @param datas
	 */
	public void handle(byte[] datas, IRoadSignsDatas iReceiveDatas) {
		mDevicePacket=mDevicePacket.getProtocolPacket(datas);
		byte[] body=mDevicePacket.getBody();
		switch (mDevicePacket.getMsgId()) {
		case DefineRS485.MsgId.COMMON_RESPONSE:
			//通用应答
			if (body==null) {
				iReceiveDatas.roadSignsResponse(PCommonResponse.SUCCUSS);
			}else{
				PCommonResponse pResponse=new PCommonResponse();
				pResponse=pResponse.getPCommonResponse(body);
				iReceiveDatas.roadSignsResponse(pResponse.getResult());
			}
			break;
		default:
			break;
		}
		
	}
	
}
