package com.uninew.mms.protocol;

import com.uninew.mms.eyesdata.EyesDataManager;
import com.uninew.mms.interfaces.IPassengerFlowDatas;
import com.uninew.mms.interfaces.IReceiveDatas;
import com.uninew.mms.traffic.TrafficProtocol;

/**
 * 客流量协议处理类
 * 
 * @author Administrator
 * 
 */
public class PassengerFlowProtocolManager {

	private TrafficProtocol trafficProtocol;
	private EyesDataManager eyesDataManager;

	public PassengerFlowProtocolManager() {
		super();
		trafficProtocol = new TrafficProtocol();
		eyesDataManager=new EyesDataManager();
	}

	public void protocolManager(byte[] receiveDatas,
			IPassengerFlowDatas mPassengerFlowDatas) {
		protocolVersionControl(receiveDatas, mPassengerFlowDatas);
	}

	// --------------------协议解析-------------------------------------------------------
	/**
	 * 协议版本控制
	 * 
	 * @param datas
	 * @param mReceiveDatas
	 */
	private void protocolVersionControl(byte[] datas,
			IPassengerFlowDatas mReceiveDatas) {
		switch (DefineProtocolVersion.currentPassengerFlowVersion) {
		case DefineProtocolVersion.PASSENGERFLOWVERSION_NATIONAL_STANDARD:
			// 国标协议
			
			break;
		case DefineProtocolVersion.PASSENGERFLOWVERSION_DEFINE_OLD:
			// 老版本协议解析
			trafficProtocol.handle(datas, mReceiveDatas);
			break;
		case DefineProtocolVersion.PASSENGERFLOWVERSION_JSHY:
			// 江苏慧眼数据科技
			eyesDataManager.handle(datas, mReceiveDatas);
			break;
		default:
			break;
		}
	}

	// --------------------------协议封装-------------------------------------------------
	/**
	 * 客流量查询指令
	 * 
	 * @param doorId
	 *            485ID地址 0x0001表示前门 0x0002表示后门
	 * 
	 */
	public byte[] getQueryPassengerInfo(int doorId) {
		byte[] body = null;
		switch (DefineProtocolVersion.currentPassengerFlowVersion) {
		case DefineProtocolVersion.PASSENGERFLOWVERSION_NATIONAL_STANDARD:
			// 国标协议
			break;
		case DefineProtocolVersion.PASSENGERFLOWVERSION_DEFINE_OLD:
			// 老版本协议解析
			body = trafficProtocol.queryPassengerInfo(doorId);
			break;
		case DefineProtocolVersion.PASSENGERFLOWVERSION_JSHY:
			// 江苏慧眼数据科技
			body=eyesDataManager.getSendQueryDatas(doorId);
			break;
		default:
			break;
		}
		return body;
	}

	/**
	 * 客流量数据清零
	 * 
	 * @param doorId
	 *            0x0001表示前门 0x0002表示后门
	 */
	public byte[] getPassClearDatas(int doorId) {
		byte[] body = null;
		switch (DefineProtocolVersion.currentPassengerFlowVersion) {
		case DefineProtocolVersion.PASSENGERFLOWVERSION_NATIONAL_STANDARD:
			// 国标协议
			break;
		case DefineProtocolVersion.PASSENGERFLOWVERSION_DEFINE_OLD:
			// 老版本协议解析
			body = trafficProtocol.sendClearData(doorId);
			break;
		case DefineProtocolVersion.PASSENGERFLOWVERSION_JSHY:
			// 江苏慧眼数据科技
			break;
		default:
			break;
		}
		return body;
	}

	/**
	 * 门状态查询
	 * 
	 * @param doorId
	 *            0x0001表示前门 0x0002表示后门
	 */
	public byte[] getDoorStateRequestDatas(int doorId) {
		byte[] body = null;
		switch (DefineProtocolVersion.currentPassengerFlowVersion) {
		case DefineProtocolVersion.PASSENGERFLOWVERSION_NATIONAL_STANDARD:
			// 国标协议
			break;
		case DefineProtocolVersion.PASSENGERFLOWVERSION_DEFINE_OLD:
			// 老版本协议解析
			body = trafficProtocol.sendDoorStateRequest(doorId);
			break;
		case DefineProtocolVersion.PASSENGERFLOWVERSION_JSHY:
			// 江苏慧眼数据科技
			break;
		default:
			break;
		}
		return body;
	}

}
