package com.uninew.mms.traffic;
import java.util.ArrayList;




public class Check {
	private  ArrayList<Integer> alist;
	private static Check check=null;
	private Check(){
	this.alist=new ArrayList<Integer>();
	}
	public static Check getNewInstance(){
	     if(check==null){
	    	 return new Check();
	     }
	     return check;
	}
	public void clear(){
		alist.clear();
	}
	public void add(int data){
		alist.add(data);
	}
	public void printL(){
//		for(Integer in:alist){
//			System.out.print("daying");
//			System.out.println(in);
//		}
	}
	public String checkSum(){
		if(alist==null){
			return "";
		}
		int sum=0;
		for(int in :alist){
			sum+=in;
			
		}

		return Integer.toHexString(sum&0xffff);
	}
}
