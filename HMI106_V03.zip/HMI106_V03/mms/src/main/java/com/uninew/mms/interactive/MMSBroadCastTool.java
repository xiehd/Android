package com.uninew.mms.interactive;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;

import com.uninew.mms.util.LogTool;

public class MMSBroadCastTool {
	
	private boolean D=true;
	private static final String TAG = "BroadCastTool";
	private Context mContext;

	public MMSBroadCastTool(Context mContext) {
		super();
		this.mContext = mContext;
	}

	/**
	 * MCU版本查询
	 */
	public void sendMCUVersionRequest() {
		if(D)Log.d(TAG, "sendMCUVersionRequest");
		Intent intent = new Intent();
		intent.setAction(DefineMMSAction.MCULinkVersionRequest);
		mContext.sendBroadcast(intent);
	}

	/**
	 * MCU版本查询应答
	 */
	public void sendMCUVersionResponse(String version) {
		if(D)Log.d(TAG, "sendMCUVersionResponse");
		Intent intent = new Intent();
		intent.setAction(DefineMMSAction.MCULinkVersionResponse);
		intent.putExtra(DefineMMSAction.MCUVersion.KEY_VERSION, version);
		mContext.sendBroadcast(intent);
	}

	/**
	 * OS升级通知
	 */
	public void sendOSUpdateNotify() {
		if(D)Log.d(TAG, "sendOSUpdateNotify");
		Intent intent = new Intent();
		intent.setAction(DefineMMSAction.MCULinkOSUpdateNotify);
		mContext.sendBroadcast(intent);
	}

	/**
	 * ACC状态通知
	 * 
	 * @param state
	 *            0-ACC_OFF, 1-ACC_ON
	 */
	public void sendAccStateNotify(int state) {
		if(D)Log.d(TAG, "sendAccStateNotify");
		Intent intent = new Intent();
		intent.setAction(DefineMMSAction.MCULinkAccState);
		intent.putExtra(DefineMMSAction.AccState.KEY_STATE, state);
		mContext.sendBroadcast(intent);
	}

	/**
	 * 设置休眠时间
	 * 
	 * @param time
	 *            单位：分钟
	 */
	public void SetSleepTime(int time) {
		if(D)Log.d(TAG, "SetSleepTime");
		Intent intent = new Intent();
		intent.setAction(DefineMMSAction.MCULinkSleepTimeSet);
		intent.putExtra(DefineMMSAction.SleepTime.KEY_TIME, time);
		mContext.sendBroadcast(intent);
	}

	/**
	 * 发送按键值
	 * 
	 * @param keyCode
	 */
	public void sendKeyBroadCast(int keyCode) {
		Intent intent = new Intent();
		intent.setAction(DefineMMSAction.MCULinkKeys);
		intent.putExtra("key", keyCode);
		int result=(keyCode>>7) & 1;
		intent.putExtra("state", (result==1)?1:0);// 默认值
		mContext.sendBroadcast(intent);
	}

	// ////////////////////////////客流量//////////////////////////////////////////
	/**
	 * 客流量发送
	 * 
	 * @param doorID
	 * @param upNumber
	 * @param downNumber
	 */
	public void sendDoorPass(int doorID, int upNumber, int downNumber) {
		if(D)Log.d(TAG, "sendDoorPass doorID=" + doorID + " ,upNumber="
				+ upNumber + " ,downNumber=" + downNumber);
		Intent intent = new Intent();
		intent.setAction(DefineMMSAction.MCULinkPass);
		intent.putExtra(DefineMMSAction.pass.DoorId, doorID);
		intent.putExtra(DefineMMSAction.pass.UpNumber, upNumber);
		intent.putExtra(DefineMMSAction.pass.DownNumber, downNumber);
		mContext.sendBroadcast(intent);
	}

	/**
	 * 门状态发送
	 * 
	 * @param doorID
	 * @param isOpen
	 */
	public void sendDoorState(int doorID, int doorState) {
		Intent intent = new Intent();
		intent.setAction(DefineMMSAction.MCULinkDoorState);
		intent.putExtra(DefineMMSAction.Door.DoorId, doorID);
		intent.putExtra(DefineMMSAction.Door.DoorState, doorState);
		mContext.sendBroadcast(intent);
	}

	/**
	 * 门状态查询
	 * 
	 * @param doorID
	 * @param isOpen
	 */
	public void sendDoorStateRequest(int doorID) {
		Intent intent = new Intent();
		intent.setAction(DefineMMSAction.MCULinkDoorStateRequest);
		intent.putExtra(DefineMMSAction.Door.DoorId, doorID);
		mContext.sendBroadcast(intent);
	}

	/**
	 * 客流量查询
	 * 
	 * @param doorID
	 * @param isOpen
	 */
	public void sendPassRequest() {
		Intent intent = new Intent();
		intent.setAction(DefineMMSAction.MCULinkPassRequest);
		mContext.sendBroadcast(intent);
	}

	// ////////////////////////////路牌/////////////////////////////////////
	/**
	 * 发送路牌信息（线路信息）
	 * 
	 * @param roadName
	 * @param startStation
	 * @param endStation
	 */
	public void sendRoadSigns(byte[] roadId,String roadName, String startStation,
			String endStation) {
		if(D)Log.d(TAG, "sendRoadSigns,roadName=" + roadName);
		Intent intent = new Intent();
		intent.setAction(DefineMMSAction.MCULinkRoadSigns);
		intent.putExtra(DefineMMSAction.RoadSigns.Type, DefineMMSAction.RoadSigns.TYPE_ROUTE);
		intent.putExtra(DefineMMSAction.RoadSigns.RoadId, roadId);
		intent.putExtra(DefineMMSAction.RoadSigns.RoadName, roadName);
		intent.putExtra(DefineMMSAction.RoadSigns.StartStation, startStation);
		intent.putExtra(DefineMMSAction.RoadSigns.EndStation, endStation);
		mContext.sendBroadcast(intent);
	}
	
	/**
	 * 发送路牌信息（文本信息）
	 * 
	 * @param roadId
	 * @param content
	 */
	public void sendRoadSigns(byte[] roadId,String content) {
		if(D)Log.d(TAG, "sendRoadSigns,content=" + content);
		Intent intent = new Intent();
		intent.setAction(DefineMMSAction.MCULinkRoadSigns);
		intent.putExtra(DefineMMSAction.RoadSigns.Type, DefineMMSAction.RoadSigns.TYPE_TXT);
		intent.putExtra(DefineMMSAction.RoadSigns.RoadId, roadId);
		intent.putExtra(DefineMMSAction.RoadSigns.TxtContent, content);
		mContext.sendBroadcast(intent);
	}
	// /////////////////////////////////////////////////////////////////
}
