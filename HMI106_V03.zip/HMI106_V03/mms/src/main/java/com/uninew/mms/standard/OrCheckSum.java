package com.uninew.mms.standard;

/**
 * 异或校验
 * 
 * @author Administrator
 * 
 */
public class OrCheckSum {

	public static byte checkSum(byte[] datas) {
		return checkSum(datas, 0, datas.length);
	}

	/**
	 * 
	 * @param datas
	 * @param start 数据开始下标
	 * @return
	 */
	public static byte checkSum(byte[] datas, int start) {
		return checkSum(datas, start, datas.length);
	}

	/**
	 * 
	 * @param datas
	 * @param start 数据开始下标
	 * @param end  数据结束下标+1
	 * @return
	 */
	public static byte checkSum(byte[] datas, int start, int end) {
		byte result = 0;
		for (int i = start; i < end; i++) {
			result ^= datas[i];
		}
		return result;
	}

}
