package com.uninew.mms;

import java.util.Timer;
import java.util.TimerTask;

import android.app.ProgressDialog;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Binder;
import android.os.Bundle;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.Looper;
import android.os.Message;
import android.util.Log;
import android.view.WindowManager;
import android.widget.Toast;

import com.uninew.mms.interactive.DefineMMSAction;
import com.uninew.mms.interactive.MMSBroadCastTool;
import com.uninew.mms.interactive.SendSignsDistribute;
import com.uninew.mms.interfaces.IAdDatas;
import com.uninew.mms.interfaces.IPassengerFlowDatas;
import com.uninew.mms.interfaces.IReceiveDatas;
import com.uninew.mms.interfaces.IRoadSignsDatas;
import com.uninew.mms.protocol.DefineProtocolVersion;
import com.uninew.mms.protocol.MCUUpdataManager;
import com.uninew.mms.protocol.MCUUpdataManager.McuUpdataState;
import com.uninew.mms.protocol.ProtocolSendManager;
import com.uninew.mms.socket.TCPLinkErrorEnum;
import com.uninew.mms.socket.TCPRunStateEnum;
import com.uninew.mms.util.LogTool;

public class McuService extends Service implements IReceiveDatas,IPassengerFlowDatas,IAdDatas,IRoadSignsDatas {
	private static final String TAG = "MainService";
	private ProtocolSendManager pm;
	private MMSBroadCastTool mBroadCastTool;
	private MCULinkServiceBroadcastReceiver mBroadcastReceiver;
    
	private HandlerThread mHandlerThread;
	private Handler mHandler;

	private MCUUpdataManager mUpdata;
	
	private long mCurrentTime ,mLastTime;
	
	@Override
	public IBinder onBind(Intent arg0) {
		return new MyBinder();
	}

	public class MyBinder extends Binder {
		public McuService getService() {
			return new McuService();
		}
	}

	@Override
	public void onCreate() {
		// TODO Auto-generated method stub
		super.onCreate();
		LogTool.logD(TAG, "----onCreate----");
		init();
	}

	private void init() {
		// TODO Auto-generated method stub
		mBroadCastTool = new MMSBroadCastTool(this);
		pm = new ProtocolSendManager(this);
		pm.setmReceiveDatas(this);
		pm.setmPassengerFlowDatas(this);
		pm.setmAdDatas(this);
		pm.setmRoadSignsDatas(this);
		openSocket();
		registerBroadCast();

		mHandlerThread = new HandlerThread("McuService");
		mHandlerThread.start();
		mHandler = new MyHandler(mHandlerThread.getLooper());
		mUpdata=new MCUUpdataManager(mHandler, pm);
//		sendDoorRequest();
//		sendHeartBeat();
	}

	private Timer timer = new Timer();
	private TimerTask timerTask = new TimerTask() {
		@Override
		public void run() {
			// TODO Auto-generated method stub
//			try {
//				pm.doorStateRequest(DefineTraffic.FRONT_DOORID);// 前门
//				Thread.sleep(2000);
//				pm.doorStateRequest(DefineTraffic.BEBIND_DOORID);// 后门
//			} catch (InterruptedException e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			}
			pm.sendHeartBeat();
		}
	};

	private void sendDoorRequest() {
		// TODO Auto-generated method stub
//		timer.schedule(timerTask, 1000, 4000);
	}
	
	private void sendHeartBeat(){
		timer.schedule(timerTask, 2000, 5000);
	}
	
	/** 发送键值 */
	private static final int WHAT_SENDKEY = 0;
	/** 发送门状态 */
	private static final int WHAT_SENDDOORSTATE = 1;
	/** 发送客流量 */
	private static final int WHAT_SENDPASS = 2;
	/** 门状态查询 */
	private static final int WHAT_DOORSTATEREQUEST = 3;
	/** 客流量查询 */
	private static final int WHAT_PASSREQUEST = 4;
	/** 路牌下发 */
	private static final int WHAT_ROADSIGNS = 5;
	/** MCU版本查询*/
	private static final int WHAT_MCU_VERSION_REQUEST = 6;
	/** MCU版本升级*/
	private static final int WHAT_MCU_UPDATE=7;
	/** 休眠时间设置*/
	private static final int WHAT_SLEEPTIME_SET=8;

	class MyHandler extends Handler {
		public MyHandler(Looper lp) {
			super(lp);
		}

		@Override
		public void handleMessage(Message msg) {
			// TODO 该方法运行于子线程，可执行耗时操作
			switch (msg.what) {
			case WHAT_SENDKEY:
				// 键值
				if ((msg.arg1 & 0x80 )== 0x00) {
					//按下
					mCurrentTime = System.currentTimeMillis();
					if (mCurrentTime - mLastTime < 500) {
						mLastTime = mCurrentTime;
						LogTool.logE(TAG, "按键太快了哦！！！！");
						break;
					}
					mLastTime = mCurrentTime;
				}
				mBroadCastTool.sendKeyBroadCast(msg.arg1);
				break;
			case WHAT_SENDDOORSTATE:
				// 门状态
				mBroadCastTool.sendDoorState(msg.arg1, msg.arg2);
				break;
			case WHAT_SENDPASS:
				// 客流量
				Bundle bundle = (Bundle) msg.getData();
				mBroadCastTool.sendDoorPass(
						bundle.getInt(DefineMMSAction.pass.DoorId),
						bundle.getInt(DefineMMSAction.pass.UpNumber),
						bundle.getInt(DefineMMSAction.pass.DownNumber));
				if (DefineProtocolVersion.currentPassengerFlowVersion==
						DefineProtocolVersion.PASSENGERFLOWVERSION_DEFINE_OLD) {
					// 发送清零指令
					pm.passClear(bundle.getInt(DefineMMSAction.pass.DoorId));
				}				
				break;
			case WHAT_DOORSTATEREQUEST:
				// 门状态查询
				pm.doorStateRequest(msg.arg1);
				break;
			case WHAT_PASSREQUEST:
				// 客流量查询
				pm.queryPassengerInfo(0x0001);
				try {
					if (DefineProtocolVersion.currentPassengerFlowVersion==
							DefineProtocolVersion.PASSENGERFLOWVERSION_DEFINE_OLD) {
						Thread.sleep(100);
					}else{
						Thread.sleep(2000);
					}			
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
				pm.queryPassengerInfo(0x0002);
				break;
			case WHAT_ROADSIGNS:
				new SendSignsDistribute(pm, (Intent)msg.obj);
				break;
			case WHAT_MCU_VERSION_REQUEST:
				pm.queryMcuVersion();
				break;
			case WHAT_MCU_UPDATE:
				  int arg=msg.arg1;
				  Log.i("meij", "mcu sheng ji:what:"+msg.what+"arg1:"+msg.arg1);
				  if(arg==0){
					Toast.makeText(getApplicationContext(), "mcu升级失败！", 1).show();  
				  }else if(arg==1){
					  Toast.makeText(getApplicationContext(), "mcu在升级，请勿断电和操作！", 1).show(); 
					  if(pd == null){
						  progressDialogShow();
					  }else{
						  pd.show();
					  }
				  }else if(arg==2){
					  Toast.makeText(getApplicationContext(), "sd卡或者mcu升级文件不存在！", 1).show();
				  }else if(arg==3){
					  Toast.makeText(getApplicationContext(), "mcu版本太低，无法升级！", 1).show();
				  }else if(arg==4){
					  Toast.makeText(getApplicationContext(), "mcu升级成功", 1).show();
					  if(pd!=null){
						  pd.dismiss();
					  }
				  }
				break;
			case WHAT_SLEEPTIME_SET:
				//休眠时间设置
				pm.setSleepTime(msg.arg1);
				break;
			default:
				break;
			}
		}

	}

	/**
	 * progressDialog显示
	 */
    protected ProgressDialog pd;
	protected void progressDialogShow() {
		
		if (pd == null) {
			pd = new ProgressDialog(getApplicationContext());
		}
		pd.setTitle("升级中...");
		pd.setCancelable(false);
		pd.getWindow().setType(WindowManager.LayoutParams.TYPE_SYSTEM_ALERT);
		pd.show();
	}
	private void registerBroadCast() {
		IntentFilter iFilter = new IntentFilter();
		iFilter.addAction(DefineMMSAction.MCULinkDoorStateRequest);
		iFilter.addAction(DefineMMSAction.MCULinkPassRequest);
		iFilter.addAction(DefineMMSAction.MCULinkRoadSigns);
		iFilter.addAction(DefineMMSAction.MCULinkUpdateCommand);
		iFilter.addAction(DefineMMSAction.MCULinkVersionRequest);
		iFilter.addAction(DefineMMSAction.MCULinkOSUpdateNotify);
		iFilter.addAction(DefineMMSAction.MCULinkSleepTimeSet);
		mBroadcastReceiver = new MCULinkServiceBroadcastReceiver();
		this.registerReceiver(mBroadcastReceiver, iFilter);
	}

	public class MCULinkServiceBroadcastReceiver extends BroadcastReceiver {
		@Override
		public void onReceive(Context context, Intent intent) {
			String action = intent.getAction();
			Message msg = new Message();
			switch (action) {
			case DefineMMSAction.MCULinkDoorStateRequest:
				// 门状态查询
				int doorId = intent.getIntExtra(DefineMMSAction.Door.DoorId, 0);
				msg.what = WHAT_DOORSTATEREQUEST;
				msg.arg1 = doorId;
				break;
			case DefineMMSAction.MCULinkPassRequest:
				// 客流量查询
				msg.what = WHAT_PASSREQUEST;
				break;
			case DefineMMSAction.MCULinkRoadSigns:
				// 路牌信息发送
				msg.what = WHAT_ROADSIGNS;
				msg.obj=intent;
				break;
			case DefineMMSAction.MCULinkVersionRequest:
				msg.what = WHAT_MCU_VERSION_REQUEST;
				break;
			case DefineMMSAction.MCULinkUpdateCommand:
				MainApplication.mcu_version=intent.getStringExtra("mcu_version");
				pm.sendMcuUpdate();
				break;
			case DefineMMSAction.MCULinkOSUpdateNotify:
				pm.sendOSUpdateNotify();
				break;
			case DefineMMSAction.MCULinkSleepTimeSet:
				int time = intent.getIntExtra(DefineMMSAction.SleepTime.KEY_TIME, 30);
				msg.what=WHAT_SLEEPTIME_SET;
				msg.arg1=time;
				break;
			default:
				break;
			}
			mHandler.sendMessage(msg);
		}
	}

	public void openSocket() {
		pm.openSocket();
	}

	public void closeSocket() {
		pm.closeSocket();
	}

	@Override
	@Deprecated
	public void onStart(Intent intent, int startId) {
		// TODO Auto-generated method stub
		LogTool.logD(TAG, "----onStart----");
		super.onStart(intent, startId);
	}

	@Override
	public int onStartCommand(Intent intent, int flags, int startId) {
		// TODO Auto-generated method stub
		LogTool.logD(TAG, "----onStartCommand----");
		return super.onStartCommand(intent, flags, startId);
	}

	@Override
	public void onDestroy() {
		// TODO Auto-generated method stub
		super.onDestroy();
		LogTool.logD(TAG, "----onDestroy----");
	}

	@Override
	public boolean onUnbind(Intent intent) {
		// TODO Auto-generated method stub
		LogTool.logD(TAG, "----onUnbind----");
		return super.onUnbind(intent);
	}

	@Override
	public void onRebind(Intent intent) {
		// TODO Auto-generated method stub
		LogTool.logD(TAG, "----onRebind----");
		super.onRebind(intent);
	}

	@Override
	public void keyReceive(int keyValue) {
		// TODO Auto-generated method stub
		LogTool.logD(TAG,
				"----keyReceive----keyValue=" + Integer.toHexString(keyValue));
		Message msg = new Message();
		msg.what = WHAT_SENDKEY;
		msg.arg1 = keyValue;
		mHandler.sendMessage(msg);
	}

	@Override
	public void receivePass(int id, int upNumber, int downNumber) {
		// TODO Auto-generated method stub
		LogTool.logD(TAG, "----receivePass----id=" + id + " ,upNumber="
				+ upNumber + ",downNumber=" + downNumber);
		Message msg = new Message();
		msg.what = WHAT_SENDPASS;
		Bundle bundle = new Bundle();
		bundle.putInt(DefineMMSAction.pass.DoorId, id);
		bundle.putInt(DefineMMSAction.pass.UpNumber, upNumber);
		bundle.putInt(DefineMMSAction.pass.DownNumber, downNumber);
		msg.setData(bundle);
		mHandler.sendMessage(msg);
	}

	@Override
	public void updateDoorState(int id, int state) {
		// TODO Auto-generated method stub
		LogTool.logD(TAG, "----updateDoorState----id=" + id + ",state=" + state);
		Message msg = new Message();
		msg.what = WHAT_SENDDOORSTATE;
		msg.arg1 = id;
		msg.arg2 = state;
		mHandler.sendMessage(msg);
	}

	@Override
	public void roadSignsResponse(int result) {
		// TODO Auto-generated method stub
		LogTool.logD(TAG, "----roadSignsResponse----result=" + result);
	}

	@Override
	public void adScreenResponse(byte[] datas) {
		// TODO Auto-generated method stub
		LogTool.logD(TAG, "----adScreenResponse----");
	}

	@Override
	public void onTCPRunStateChangeder(TCPRunStateEnum vValue,
			TCPLinkErrorEnum error) {
		// TODO TCP连接状态通知
		LogTool.logD(TAG, "----onTCPRunStateChangeder----TCPRunStateEnum="
				+ vValue + ",TCPLinkErrorEnum=" + error);
		switch (vValue) {
		case OPEN_SUCCESS:
			break;
		case OPEN_FAILURE:
			break;
		case RUN_STOPED:
			// openSocket();
			break;
		default:
			break;
		}
	}

	@Override
	public void passClearResponse(int id, int result) {
		// TODO Auto-generated method stub
		LogTool.logD(TAG, "----passClearResponse----id=" + id + ",result="
				+ result);
	}

	@Override
	public void McuVersion(String version) {
		// TODO Auto-generated method stub
		LogTool.logE(TAG, "MCU Version="+version);
		mBroadCastTool.sendMCUVersionResponse(version);
	}

	@Override
	public void mcuUpdataResponse(byte[] datas) {
		// TODO Auto-generated method stub
		LogTool.logBytes("meij__bytes", datas);
		// TODO Auto-generated method stub
		mUpdata.setReceivedTime(System.currentTimeMillis());
		switch (datas[0]) {
		case 0x01:
			if (datas[1] == 0x01) {
				mUpdata.setMcuUpdateState(McuUpdataState.updataInit);
				mUpdata.createMcuUpdateThread();
			} else {
				if (datas[1] == 0x00) {
					mUpdata.setMcuUpdateState(McuUpdataState.updataEnd);
				}
			}
			break;
		case 0x02:
		     mUpdata.addMcuUpdataQuene(datas);
			break;
		default:
			break;
		}
	}

	@Override
	public void onSleepTime(int sleepTime) {
		// TODO Auto-generated method stub
		LogTool.logD(TAG, "sleepTime="+sleepTime);
	}

	@Override
	public void onAccState(int state) {
		// TODO Auto-generated method stub
		LogTool.logD(TAG, "onAccState="+state);
		mBroadCastTool.sendAccStateNotify(state);
	}

	@Override
	public void receivePass(int id, int upNumber, int downNumber,
			int totalNumber) {
		// TODO Auto-generated method stub
		
	}

}
