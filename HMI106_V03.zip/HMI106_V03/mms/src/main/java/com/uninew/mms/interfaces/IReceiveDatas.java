package com.uninew.mms.interfaces;

import com.uninew.mms.socket.TCPLinkErrorEnum;
import com.uninew.mms.socket.TCPRunStateEnum;

public interface IReceiveDatas {
	
	/**MCU版本信息*/
	void McuVersion(String version);
	
	/** 按键信息 */
	void keyReceive(int keyValue);

	/** 状态上报接口 */
	void onTCPRunStateChangeder(TCPRunStateEnum vValue, TCPLinkErrorEnum error);

	/** MCU升级上报接口 */
	void mcuUpdataResponse(byte[] datas);
	
	/** MCU休眠时间设置应答接口 */
	void onSleepTime(int sleepTime);
	
	/** ACC 状态（ACC_ON，ACC_OFF）上报接口:0x00:OFF,0x01:ON */
	void onAccState(int state);
}
