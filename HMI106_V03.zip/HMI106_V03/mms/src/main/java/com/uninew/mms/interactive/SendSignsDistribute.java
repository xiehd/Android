package com.uninew.mms.interactive;

import java.util.Arrays;

import android.content.Intent;
import android.os.Bundle;

import com.uninew.mms.protocol.DefineProtocolVersion;
import com.uninew.mms.protocol.ProtocolSendManager;
import com.uninew.mms.util.LogTool;

/**
 * 路牌发送分发管理(此处主要处理不同协议的不同点处理)
 * @author Administrator
 *
 */
public class SendSignsDistribute {

	private static final String TAG="SendSignsDistribute";
	private static boolean D=true;

	public SendSignsDistribute(ProtocolSendManager pm,Intent intent) {
		super();
		messageDistribute(pm, intent);
	}
	
	private void messageDistribute(ProtocolSendManager pm,Intent intent){
		int type=intent.getExtras().getInt(DefineMMSAction.RoadSigns.Type);
		if (DefineMMSAction.RoadSigns.TYPE_ROUTE==type) {
			//线路发送
			Routemanage(pm, intent);
		}else if(DefineMMSAction.RoadSigns.TYPE_TXT==type){
			//文本发送
			Txtmanage(pm, intent);
		}
		
	}
	
	private void Routemanage(ProtocolSendManager pm,Intent intent){
		byte[] ids=intent.getExtras().getByteArray(DefineMMSAction.RoadSigns.RoadId);
		String roadName=intent.getExtras().getString(DefineMMSAction.RoadSigns.RoadName);
		String startStation=intent.getExtras().getString(DefineMMSAction.RoadSigns.StartStation);
		String endStation=intent.getExtras().getString(DefineMMSAction.RoadSigns.EndStation);
		if (D)LogTool.logD(TAG, "Routemanage，ids="+Arrays.toString(ids)+",startStation="+startStation+" ,endStation="+endStation);
		switch (DefineProtocolVersion.currentRoadSignsVersion) {
		case DefineProtocolVersion.ROADSIGNSVERSION_NATIONAL_STANDARD:
			//标准协议
//			for (int i = 0; i < ids.length; i++) {
//				pm.sendRoadSigns(ids[i], roadName, startStation, endStation);
//				try {
//					Thread.sleep(100);
//				} catch (InterruptedException e) {
//					// TODO Auto-generated catch block
//					e.printStackTrace();
//				}
//			}
			break;
		case DefineProtocolVersion.ROADSIGNSVERSION_TUYUE:
			//图岳电子协议
			byte[] roadSignIds=new byte[ids.length];
			//路牌ID协议转换（标准转图岳）
			for (int i = 0; i < roadSignIds.length; i++) {
				switch (ids[i]) {
				case 0x30:
					roadSignIds[i]=0x01;
					break;
				case 0x31:
					roadSignIds[i]=0x02;			
					break;
				case 0x32:
//					roadSignIds[i]=0x02;
					break;
				case 0x33:
					roadSignIds[i]=0x03;
					break;
				default:
					break;
				}
			}
			pm.sendRoadSigns(roadSignIds, roadName, startStation, endStation);
			break;
		case DefineProtocolVersion.ROADSIGNSVERSION_HZ:
			byte[] roadSignIds2=new byte[ids.length];
			for (int i = 0; i < roadSignIds2.length; i++) {
				switch (ids[i]) {
				case 0x01:
					roadSignIds2[i]=0x01;//前牌
					break;
				case 0x02:
					roadSignIds2[i]=0x02;//侧牌		
					break;
				case 0x03:
					roadSignIds2[i]=0x05;//后牌
					break;
				case 0x04:
					roadSignIds2[i]=0x03;//内牌
					break;
				default:
					break;
				}
			}
			pm.sendRoadSigns(roadSignIds2, roadName, startStation, endStation);
			break;
		default:
			break;
		}
	}
	
	private void Txtmanage(ProtocolSendManager pm,Intent intent){
		byte[] ids=intent.getExtras().getByteArray(DefineMMSAction.RoadSigns.RoadId);
		String content=intent.getExtras().getString(DefineMMSAction.RoadSigns.TxtContent);
		if (D)LogTool.logD(TAG, "Txtmanage，ids="+Arrays.toString(ids)+",content="+content);
		switch (DefineProtocolVersion.currentRoadSignsVersion) {
		case DefineProtocolVersion.ROADSIGNSVERSION_NATIONAL_STANDARD:
			//标准协议
			break;
		case DefineProtocolVersion.ROADSIGNSVERSION_TUYUE:
			//图岳电子协议
			byte[] roadSignIds=new byte[ids.length];
			//路牌ID协议转换（标准转图岳）
			for (int i = 0; i < roadSignIds.length; i++) {
				switch (ids[i]) {
				case 0x30:
					roadSignIds[i]=0x01;
					break;
				case 0x31:
					roadSignIds[i]=0x02;			
					break;
				case 0x32:
//					roadSignIds[i]=0x02;
					break;
				case 0x33:
					roadSignIds[i]=0x03;
					break;
				default:
					break;
				}
			}
			pm.sendRoadSigns(roadSignIds, content);
			break;
		case DefineProtocolVersion.ROADSIGNSVERSION_HZ:
			byte[] roadSignIds2=new byte[ids.length];
			for (int i = 0; i < roadSignIds2.length; i++) {
				switch (ids[i]) {
				case 0x01:
					roadSignIds2[i]=0x01;//前牌
					break;
				case 0x02:
					roadSignIds2[i]=0x02;//侧牌		
					break;
				case 0x03:
					roadSignIds2[i]=0x05;//后牌
					break;
				case 0x04:
					roadSignIds2[i]=0x03;//内牌
					break;
				default:
					break;
				}
			}
			pm.sendRoadSigns(roadSignIds2, content);
			break;
		default:
			break;
		}
	}
}
