package com.uninew.mms.protocol;

import com.uninew.mms.interfaces.IAdDatas;
import com.uninew.mms.interfaces.IPassengerFlowDatas;
import com.uninew.mms.interfaces.IReceiveDatas;

/***
 * 广告屏协议处理类
 * @author Administrator
 *
 */
public class ADProtocolManager {
	
	public ADProtocolManager() {
		super();
		
	}
	
	public void protocolManager(byte[] receiveDatas,
			IAdDatas mAdDatas) {
		protocolVersionControl(receiveDatas, mAdDatas);
	}

	// --------------------协议解析-------------------------------------------------------
	/**
	 * 协议版本控制
	 * 
	 * @param datas
	 * @param mReceiveDatas
	 */
	private void protocolVersionControl(byte[] datas,
			IAdDatas mReceiveDatas) {
		switch (DefineProtocolVersion.currentADVersion) {
		case DefineProtocolVersion.ADVERSION_NATIONAL_STANDARD:
			// 国标协议

			break;
		case DefineProtocolVersion.ADVERSION_TUYUE:
			// 江苏慧眼数据科技

			break;
		default:
			break;
		}
	}

}
