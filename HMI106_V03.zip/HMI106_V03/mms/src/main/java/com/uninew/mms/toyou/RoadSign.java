package com.uninew.mms.toyou;

import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.Arrays;

import com.uninew.mms.interfaces.IProtocolPacket;
import com.uninew.mms.util.LogTool;

/**
 * 路牌内容（一级封装）
 * @author Administrator
 *
 */
public class RoadSign implements IProtocolPacket{
	
	private static final String TAG="RoadSigns";
	private boolean D=true;
	
	/**命令字*/
	private byte cmd;
	/**ID号--无效默认0x00,0x00*/
	private short id;
	/**数据长度*/
	private short length;
	/**路牌编号*/
	private byte roadSignId;
	/**路牌属性*/
	private byte roadSignAttribute;
	/**路号，比如320,注意目前大于3位会截取前三位*/
	private String roadName;
	/**显示风格*/
	private byte showType;
	/**几字节路牌*/
	private byte whatByte;
	/**显示内容--GB2312,以'\0'结尾*/
	private String content;
	
	public RoadSign() {
		super();
	}
	/**
	 * 
	 * @param roadSignId  路牌编号
	 * @param roadSignAttribute 路牌属性
	 * @param roadName 路号
	 * @param showType 显示风格
	 * @param whatByte 几字路牌
	 * @param content 显示内容
	 */
	public RoadSign(byte roadSignId, byte roadSignAttribute, String roadName,
			byte showType, byte whatByte,String content) {
		super();
		this.roadSignId = roadSignId;
		this.roadSignAttribute = roadSignAttribute;
		this.roadName = roadName;
		this.showType = showType;
		this.whatByte=whatByte;
		this.content = content;
	}

	@Override
	public byte[] getBytes() {
		// TODO Auto-generated method stub
		if (null==content || "".equals(content)) {
			LogTool.logE(TAG, "content is NULL !!!");
			return null;
		}
		ByteArrayOutputStream bis = new ByteArrayOutputStream();
		DataOutputStream dos = new DataOutputStream(bis);
		try {
			dos.writeByte(roadSignId);
			dos.writeByte(roadSignAttribute);
			dos.write(getRoadId(roadName));
			dos.writeByte(showType);
			if (whatByte > 0) {
				dos.writeByte(whatByte);
			}
			dos.write(content.getBytes(DefineTYRoadSigns.ENCODE_GB2312));
			dos.flush();
			return bis.toByteArray(); 
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	
	@Override
	public Object getProtocolPacket(byte[] datas) {
		return null;
	}
	
	/**
	 * 路号
	 * @param roadName2
	 * @return
	 */
	private byte[] getRoadId(String roadName2) {
		// TODO Auto-generated method stub
		byte[] roadId=new byte[3];
		byte[] roadIdTemp=null;
		try {
			roadIdTemp=roadName2.getBytes(DefineTYRoadSigns.ENCODE_ASCII);
			if (roadIdTemp.length <= 3 ) {
				roadId=Arrays.copyOfRange(roadIdTemp, 0, roadIdTemp.length);
			}else{
				roadId=Arrays.copyOfRange(roadIdTemp, 0, 3);
			}
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return roadId;
	}
	
	public byte getCmd() {
		return cmd;
	}
	public void setCmd(byte cmd) {
		this.cmd = cmd;
	}
	public short getId() {
		return id;
	}
	public void setId(short id) {
		this.id = id;
	}
	public short getLength() {
		return length;
	}
	public void setLength(short length) {
		this.length = length;
	}
	public byte getRoadSignId() {
		return roadSignId;
	}
	public void setRoadSignId(byte roadSignId) {
		this.roadSignId = roadSignId;
	}
	public byte getRoadSignAttribute() {
		return roadSignAttribute;
	}
	public void setRoadSignAttribute(byte roadSignAttribute) {
		this.roadSignAttribute = roadSignAttribute;
	}
	public String getRoadName() {
		return roadName;
	}
	public void setRoadName(String roadName) {
		this.roadName = roadName;
	}
	public byte getShowType() {
		return showType;
	}
	public void setShowType(byte showType) {
		this.showType = showType;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public byte getWhatByte() {
		return whatByte;
	}
	public void setWhatByte(byte whatByte) {
		this.whatByte = whatByte;
	}
	@Override
	public String toString() {
		return "RoadSigns [cmd=" + cmd + ", id=" + id + ", length=" + length
				+ ", roadSignId=" + roadSignId + ", roadSignAttribute="
				+ roadSignAttribute + ", roadName=" + roadName + ", showType="
				+ showType + ", whatByte=" + whatByte + ", content=" + content
				+ "]";
	}
	
}
