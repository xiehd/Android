package com.uninew.mms.standard;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

/**
 * 路牌等协议处理
 * 
 * @author Administrator
 * 
 */
public class RS485DevicePacket {
	/** 开始标志 */
	private int startFlag;
	/** 目标地址 */
	private int targetAddress;
	/** 源地址 */
	private int srcAddress;
	/** 消息帧标志 */
	private int msgId;
	/** 消息流水号 */
	private int serialNumber;
	/** 消息帧长度 */
	private int msgLength;
	/** 数据帧 */
	private byte[] body;
	/** 校验位 */
	private int check;
	/** 结束标志 */
	private int endFlag;

	public static int serial;

	public RS485DevicePacket() {
		super();
	}

	/**
	 * 
	 * @param targetAddress
	 *            目标地址
	 * @param srcAddress
	 *            源地址
	 * @param msgId
	 *            消息帧标志
	 * @param body
	 *            数据帧
	 */
	public RS485DevicePacket(int targetAddress, int srcAddress, int msgId,
			byte[] body) {
		super();
		this.targetAddress = targetAddress;
		this.srcAddress = srcAddress;
		this.msgId = msgId;
		this.body = body;
		this.msgLength = body.length + 9;
		if (serial == 255) {
			serial = 0;
		} else {
			serial++;
		}
		serialNumber = serial;
	}

	/**
	 * 转换成字节数组
	 * 
	 * @return
	 * @throws IOException
	 */
	public byte[] getBytes() {
		byte[] datas = null;
		ByteArrayOutputStream bos = null;
		DataOutputStream dos = null;
		try {
			bos = new ByteArrayOutputStream();
			dos = new DataOutputStream(bos);
			dos.writeByte(DefineRS485.START_FLAG);
			dos.writeByte(targetAddress);
			dos.writeByte(srcAddress);
			dos.writeByte(msgId);
			dos.writeByte(serialNumber);
			dos.writeShort(msgLength);
			dos.write(body);
			byte[] buf = bos.toByteArray();
			check = OrCheckSum.checkSum(buf);
			dos.writeByte(check);
			dos.writeByte(DefineRS485.END_FLAG);
			datas = bos.toByteArray();
			dos.flush();
			dos.close();
		} catch (Exception e) {
			// TODO: handle exception
		}
		return datas;
	}

	/**
	 * 将字节数组转化成协议对象
	 * 
	 * @param datas
	 * @return
	 */
	public RS485DevicePacket getProtocolPacket(byte[] datas) {
		try {
			ByteArrayInputStream bis = new ByteArrayInputStream(datas);
			DataInputStream dis = new DataInputStream(bis);
			startFlag = dis.readUnsignedByte();
			targetAddress = dis.readUnsignedByte();
			srcAddress = dis.readUnsignedByte();
			msgId = dis.readUnsignedByte();
			serialNumber = dis.readUnsignedByte();
			msgLength = dis.readUnsignedShort();
			dis.read(body, 0, msgLength);
			check = dis.readUnsignedByte();
			endFlag = dis.readUnsignedByte();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return this;
	}

	public int getStartFlag() {
		return startFlag;
	}

	public void setStartFlag(int startFlag) {
		this.startFlag = startFlag;
	}

	public int getTargetAddress() {
		return targetAddress;
	}

	public void setTargetAddress(int targetAddress) {
		this.targetAddress = targetAddress;
	}

	public int getSrcAddress() {
		return srcAddress;
	}

	public void setSrcAddress(int srcAddress) {
		this.srcAddress = srcAddress;
	}

	public int getSerialNumber() {
		return serialNumber;
	}

	public void setSerialNumber(int serialNumber) {
		this.serialNumber = serialNumber;
	}

	public int getMsgLength() {
		return msgLength;
	}

	public void setMsgLength(int msgLength) {
		this.msgLength = msgLength;
	}

	public byte[] getBody() {
		return body;
	}

	public void setBody(byte[] body) {
		this.body = body;
	}

	public int getCheck() {
		return check;
	}

	public void setCheck(int check) {
		this.check = check;
	}

	public int getEndFlag() {
		return endFlag;
	}

	public void setEndFlag(int endFlag) {
		this.endFlag = endFlag;
	}

	public int getMsgId() {
		return msgId;
	}

	public void setMsgId(int msgId) {
		this.msgId = msgId;
	}

}
