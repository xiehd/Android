package com.uninew.mms.socket;

public enum TCPRunStateEnum {
	/**
	 * TCP打开成功
	 */
	OPEN_SUCCESS,
	
	/**
	 * TCP打开失败
	 */
	OPEN_FAILURE,
	
	/**
	 * TCP运行停止
	 */
	RUN_STOPED,
	
}
