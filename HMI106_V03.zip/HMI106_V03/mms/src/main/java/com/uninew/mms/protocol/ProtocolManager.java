package com.uninew.mms.protocol;

import java.io.IOException;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.Queue;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.content.Context;
import android.os.Build;
import android.util.Log;

import com.uninew.mms.interfaces.IAdDatas;
import com.uninew.mms.interfaces.IPassengerFlowDatas;
import com.uninew.mms.interfaces.IReceiveDatas;
import com.uninew.mms.interfaces.IRoadSignsDatas;
import com.uninew.mms.socket.TCPLink;
import com.uninew.mms.socket.TCPLink.TCPCallbackInterface;
import com.uninew.mms.socket.TCPLinkErrorEnum;
import com.uninew.mms.socket.TCPRunStateEnum;
import com.uninew.mms.standard.RS485DeviceManager;
import com.uninew.mms.util.ByteTools;
import com.uninew.mms.util.LogTool;

@TargetApi(Build.VERSION_CODES.GINGERBREAD)
@SuppressLint("NewApi")
public class ProtocolManager implements TCPCallbackInterface {
	@SuppressWarnings("unused")
	private Context mContext;
	private static final String TAG="ProtocolManager";
	private ProtocolPacket protocolPacket;
	private TCPLink mLink;
	public RS485DeviceManager rs485Manager ;
	
	public RS485Control mRs485Control;

	private IReceiveDatas mReceiveDatas;
	public void setmReceiveDatas(IReceiveDatas mReceiveDatas) {
		this.mReceiveDatas = mReceiveDatas;
	}

	public void setmPassengerFlowDatas(IPassengerFlowDatas mPassengerFlowDatas) {
		mRs485Control.setmPassengerFlowDatas(mPassengerFlowDatas);
	}

	public void setmRoadSignsDatas(IRoadSignsDatas mRoadSignsDatas) {
		mRs485Control.setmRoadSignsDatas(mRoadSignsDatas);
	}

	public void setmAdDatas(IAdDatas mAdDatas) {
		mRs485Control.setmAdDatas(mAdDatas);
	}

	public ProtocolManager(Context mContext) {
		super();
		this.mContext = mContext;
		protocolPacket = new ProtocolPacket();
		rs485Manager=new RS485DeviceManager();
		mRs485Control=new RS485Control(this);
		mDataThread = new Thread(dataRunnable);
		mDataThread.start();
		mLink = new TCPLink(mContext);
		mLink.setTcpBackInterface(this);
		
	}

	public void openSocket() {
		mLink.openSocket();
	}

	public void closeSocket() {
		mLink.closeSocket();
	}

	/**
	 * 发送接口
	 * 
	 * @param packet
	 */
	public void sendMsg(ProtocolPacket packet) {
		mLink.sendMsg(packet.getBytes());
	}

	/**
	 * 发送接口
	 * 
	 * @param packet
	 */
	public void sendMsg(byte[] datas) {
		mLink.sendMsg(datas);
	}

	@Override
	public void onTCPRunStateChangeder(TCPRunStateEnum vValue,
			TCPLinkErrorEnum error) {
		// TODO Auto-generated method stub
		mReceiveDatas.onTCPRunStateChangeder(vValue, error);
	}

	@Override
	public void onTCPReceiveDataChangeder(byte[] vBuffer) {
		// TODO Auto-generated method stub
//		LogTool.logE("yzb", "onTransportReceiveDataChangeder");
		LogTool.logBytes("onTransportReceiveDataChangeder=", vBuffer);
		dataRunnable.add(vBuffer);
	}

	private Thread mDataThread;
	private DataHandleRunnable dataRunnable = new DataHandleRunnable();

	private class DataHandleRunnable implements Runnable {
		private Queue<byte[]> queue = new LinkedList<byte[]>();

		public void run() {
			Log.v(TAG, "DataHandleRunnable......run.......xxxxxxxxxxxxxx");
			while (true) {
				if (!queue.isEmpty()) {
					handleDatas(queue.poll());
				} else {
					synchronized (this) {
						try {
							wait();
						} catch (InterruptedException e) {
							//
						}
					}
				}
			}
		}

		public synchronized void add(byte[] datas) {
			queue.add(datas);
			this.notify();
		}
	}

	private void handleDatas(byte[] datas) {
		// TODO Auto-generated method stub
		short start_flag = ByteTools.byteToShort(datas[1], datas[0]);
		byte msg_length = datas[2];
	

		if (start_flag == (short) 0xAA55) {
			if (datas.length == msg_length + 2) {
				protocolPacket = protocolPacket.getProtocolPacket(datas);
				try {
					parseMsgBody(protocolPacket);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			} else {
				LogTool.logE("protocol", "Msg Length Error!!!");
			}
		} else {
			LogTool.logE("protocol", "Msg StartFlag or EndFlag Error!!!");
		}
	}

	@SuppressLint("NewApi")
	private void parseMsgBody(ProtocolPacket packet) throws IOException {
		// byte typeId = packet.getTypeId();
		byte groupId = packet.getGroupId();
		byte[] body = packet.getBody();
		
		switch (groupId) {
		case DefineMcu.GroupId.SYSTEM:
			switch (body[0]) {
			case DefineMcu.SystemCommandId.System_Info://系统信息
				systemInfoMange(body);
				break;
			case DefineMcu.SystemCommandId.System_PS://电源状态(ACC)
				systemPsMange(body);
				break;
			default:
				break;
			}
			break;
		case DefineMcu.GroupId.DISPLAY:
			switch (body[0]) {
			case DefineMcu.DiaplayCommandId.Key:
				// 按键信息上报
				mReceiveDatas.keyReceive(body[1]);
				break;
			default:
				break;
			}
			break;
		case DefineMcu.GroupId.RS485:
			mRs485Control.receive(body);
			break;
		case DefineMcu.GroupId.PARM_SET:
			//参数设置
			if (body !=null &&  body.length == 3) {
				mReceiveDatas.onSleepTime(ByteTools.byteToShort(body[2],body[1]));
			}
			break;
		case DefineMcu.GroupId.MCU_UPDATA:
			//MCU升级
            mReceiveDatas.mcuUpdataResponse(body);
            break;
		default:
			break;
		}

	}


	/**
	 * 系统信息解析
	 */
	@SuppressLint("NewApi")
	private void systemInfoMange(byte[] datas) {
		// TODO Auto-generated method stub
		switch (datas[1]) {
		case DefineMcu.SystemInfo.SystemInfo_McuVersion:
			//MCU版本
			String version=new String(Arrays.copyOfRange(datas, 2, datas.length));
			mReceiveDatas.McuVersion(version);
			break;
		default:
			break;
		}
	}
	
	/**
	 * 电源状态解析
	 */
	@SuppressLint("NewApi")
	private void systemPsMange(byte[] datas) {
		// TODO Auto-generated method stub
		switch (datas[1]) {
		case DefineMcu.SystemPs.SystemPs_normalworlk:
			//mReceiveDatas.McuVersion(version);
			LogTool.logD(TAG,"MCU正常状态：");
			break;
		case DefineMcu.SystemPs.SystemPs_sleep:
			LogTool.logD(TAG,"休眠状态：");
			break;
		case DefineMcu.SystemPs.SystemPs_offACC:
			LogTool.logD(TAG,"ACC_OFF：");
			mReceiveDatas.onAccState(0x00);
			break;
		case DefineMcu.SystemPs.SystemPs_offBAT:
			LogTool.logD(TAG,"BAT_OFF：");
			break;
		case DefineMcu.SystemPs.SystemPs_locatinInfo:
			LogTool.logD(TAG,"定位状态：");
			break;
		case DefineMcu.SystemPs.SystemPs_error:
			LogTool.logD(TAG,"异常状态：");
			break;
		case DefineMcu.SystemPs.SystemPs_ACC_ON:
			LogTool.logD(TAG,"ACC_ON：");
			mReceiveDatas.onAccState(0x01);
			break;
		default:
			break;
		}
	}
}
