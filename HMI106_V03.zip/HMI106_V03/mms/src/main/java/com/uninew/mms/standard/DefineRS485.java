package com.uninew.mms.standard;

public interface DefineRS485 {

	/** 开始标志 */
	public static final byte START_FLAG = 0x7e;
	/** 结束标志 */
	public static final byte END_FLAG = 0x7f;

	/**
	 * 目标或者源地址
	 * 
	 * @author Administrator
	 * 
	 */
	public interface TargetOrSrcAddress {
		/** 车载终端主机（0x01） */
		int TERMINAL_HOST = 0x01;
		/** 路牌 -头牌 （0x30） */
		int FRONT_ROASSIGNS = 0x30;
		/** 路牌 -左腰牌（0x31） */
		int LEFT_ROASSIGNS = 0x30;
		/** 路牌 -右腰牌（0x32） */
		int RIGHT_ROASSIGNS = 0x30;
		/** 路牌 -尾牌 （0x33） */
		int BEHIND_ROASSIGNS = 0x30;
		/** 广播地址 （0xFF） */
		int BROADCAST = 0xFF;
	}

	/**
	 * 消息帧标志
	 * @author Administrator
	 *
	 */
	public interface MsgId {
		/** 路牌显示（0x04） */
		int ROADSIGN_SHOW = 0x04;
		/** 通用应答（0x0A） */
		int COMMON_RESPONSE=0x0A;
	}

	/**
	 * 数据帧标志
	 * @author Administrator
	 *
	 */
	public interface DataId {
		/** 路牌图片显示（0x30） */
		int ROAD_PICTURE_SHOW = 0x30;
		/** 线路名称（0x31） */
		int ROUTE_NAME = 0x31;
		/** 始发站1（0x32） */
		int START_STATION1 = 0x32;
		/** 始发站2（0x33） */
		int START_STATION2 = 0x33;
		/** 终点站1（0x34） */
		int END_STATION1 = 0x34;
		/** 终点站2（0x35） */
		int END_STATION2 = 0x35;
		/** 应答（0x13） */
		int DATA_RESPONSE=0x13;
	}

}
