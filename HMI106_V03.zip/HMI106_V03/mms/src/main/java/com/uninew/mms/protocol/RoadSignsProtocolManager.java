package com.uninew.mms.protocol;

import com.uninew.mms.hz.HZManager;
import com.uninew.mms.interfaces.IRoadSignsDatas;
import com.uninew.mms.standard.StandardManager;
import com.uninew.mms.toyou.TYManager;
import com.uninew.mms.util.LogTool;

public class RoadSignsProtocolManager {
	private TYManager tyManager;
	private HZManager hzManager;
	private StandardManager standardManager;

	
	
	public RoadSignsProtocolManager() {
		super();
		// TODO Auto-generated constructor stub
		tyManager=new TYManager();
		hzManager=new HZManager();
		standardManager=new StandardManager();
	}

	public void protocolManager(byte[] receiveDatas,
			IRoadSignsDatas mroadSignsDatas) {
		tyManager=new TYManager();
		hzManager=new HZManager();
		standardManager=new StandardManager();
		protocolVersionControl(receiveDatas, mroadSignsDatas);
	}

	// --------------------协议解析-------------------------------------------------------
	/**
	 * 协议版本控制
	 * 
	 * @param datas
	 * @param mReceiveDatas
	 */
	private void protocolVersionControl(byte[] datas,
			IRoadSignsDatas mReceiveDatas) {
		switch (DefineProtocolVersion.currentRoadSignsVersion) {
		case DefineProtocolVersion.ROADSIGNSVERSION_NATIONAL_STANDARD:
			// 国标协议

			break;
		case DefineProtocolVersion.ROADSIGNSVERSION_TUYUE:
			// 图岳电子，协议无应答或上传消息，暂不解析

			break;
		case DefineProtocolVersion.ROADSIGNSVERSION_HZ:
			// 杭正协议

			break;
		default:
			break;
		}
	}

	// --------------------------协议封装-------------------------------------------------
	/**
	 * 路牌消息发送
	 * @param roadSignId 0x01头牌,0x02腰牌,(0x21左腰牌,0x22右腰牌),0x03尾牌
	 * @param roadName 线路名称
	 * @param startStation 起始站
	 * @param endStation 终点站
	 * @return
	 */
	public byte[] getRoadSignsBytes(byte roadSignIds,String roadName, String startStation,String endStation){
		byte[] datas=null;
		switch (DefineProtocolVersion.currentRoadSignsVersion) {
		case DefineProtocolVersion.ROADSIGNSVERSION_NATIONAL_STANDARD:
			// 国标协议
			datas=standardManager.getFrontRoadSigns(roadSignIds, roadName, startStation, endStation);
			break;
		case DefineProtocolVersion.ROADSIGNSVERSION_TUYUE:
			// 图岳电子，协议无应答或上传消息，暂不解析
			datas=tyManager.getSendRoadSignDatasForTuyue(roadSignIds, true, roadName, startStation, endStation);
			break;
		case DefineProtocolVersion.ROADSIGNSVERSION_HZ:
			// 杭正协议
//			for (int i = 0; i < roadSignIds.length; i++) {
				System.err.println("-----------roadSignIds="+roadSignIds);
				datas=hzManager.getRouteDatasForHZ(roadSignIds, roadName, startStation, endStation);
//				LogTool.logBytes("datas=", datas);
//			}
//			datas=hzManager.getTestDatasForHZ(roadSignIds[0], roadName, startStation, endStation);
			break;
		default:
			break;
		}
		return datas;
	}
	
	/**
	 * 路牌消息发送
	 * @param roadSignId 0x01头牌,0x02腰牌,(0x21左腰牌,0x22右腰牌),0x03尾牌
	 * @param roadName 线路名称
	 * @param startStation 起始站
	 * @param endStation 终点站
	 * @return
	 */
	public byte[] getRoadSignsBytes(byte roadSignIds,String content){
		byte[] datas=null;
		switch (DefineProtocolVersion.currentRoadSignsVersion) {
		case DefineProtocolVersion.ROADSIGNSVERSION_NATIONAL_STANDARD:
			// 国标协议
			break;
		case DefineProtocolVersion.ROADSIGNSVERSION_TUYUE:
			// 图岳电子，协议无应答或上传消息，暂不解析
			break;
		case DefineProtocolVersion.ROADSIGNSVERSION_HZ:
			// 杭正协议
			System.err.println("datas="+datas+" ,hzManager="+hzManager);
//			datas=hzManager.getTestDatasForHZ(roadSignIds[0], roadName, startStation, endStation);
			datas=hzManager.getSendDatasForHZ(roadSignIds, content);
			break;
		default:
			break;
		}
		return datas;
	}
	
	
	
	
	
	
//-----------------------------------------------------------------------------

//---------------------杭正协议----------------------------------------------------------
	
	
}
