package com.uninew.mms.traffic;

import java.util.Arrays;
import android.annotation.SuppressLint;

import com.uninew.mms.interfaces.IPassengerFlowDatas;
import com.uninew.mms.util.LogTool;

/**
 * 客流量协议解析
 * 
 * @author Administrator
 * 
 */
public class TrafficProtocol {
	private static final String TAG = "TrafficProtocol";

	public void handle(byte[] data, IPassengerFlowDatas iReceiveDatas) {
		if (dataChecks(data, iReceiveDatas) == false) {
			return;
		}
		String str = null;
		int position = 0;
		try {
			str = new String(data, 1, data.length - 2, "US-ASCII");// 将RS-485协议的起始符和结束符去掉，其余ascii字节转化为字符串
		} catch (Exception e) {
			LogTool.logE(TAG, "datas Error!!!");
			return;
		}
		if (data[position] == 0x02) {// STX 起始符
			Check check = Check.getNewInstance(); // 校验类
			check.clear();
			int id = Integer.valueOf(str.substring(0, 4), 16).intValue();// 485ID地址
			check.add(id);
			int cm = Integer.valueOf(str.substring(4, 6), 16).shortValue();// 命令字符，区分不同的命令
			check.add(cm);
			int len = Integer.valueOf(str.substring(6, 8), 16).shortValue();// 数据长度
			check.add(len);
			if (data.length >= 2 * len + 12) {
				String datas = str.substring(8, 8 + 2 * len); // 数据
				for (int i = 0; i < 2 * len; i = i + 2) {
					int da = Integer.valueOf(datas.substring(i, 2 + i), 16);
					check.add(da);
				}
				int ck = Integer.valueOf(
						str.substring(8 + 2 * len, 10 + 2 * len), 16);
				if (ck == Integer.valueOf(check.checkSum(), 16)) {// 校验是否正确
					if (data[11 + 2 * len] == 0x03) {// 结束符
						parse(id, cm, datas, iReceiveDatas);
					}
				}
			}
		}
	}

	@SuppressLint("NewApi")
	private boolean dataChecks(byte[] datas, IPassengerFlowDatas iReceiveDatas) {
		if (iReceiveDatas == null) {
			return false;
		}
		if (dataCheck(Arrays.copyOfRange(datas, 1, datas.length - 1)) == false) {
			LogTool.logI(TAG, "数据异常！！！！！！！！");
			return false;
		}
		return true;
	}

	private static boolean dataCheck(byte[] datas) {
		for (int i = 0; i < datas.length; i++) {
			if (datas[i] < 48) {
				return false;
			}
			if (datas[i] > 57 && datas[i] < 65) {
				return false;
			}
			if (datas[i] > 70 && datas[i] < 97) {
				return false;
			}
			if (datas[i] > 102) {
				return false;
			}
		}
		return true;
	}

	/**
	 * 
	 * @param idInt
	 *            485ID地址(门ID)
	 * @param cmShort
	 *            命令字符，区分不同的命令
	 * @param body
	 *            data数据
	 * @param dataCallBack
	 */
	private void parse(int idInt, int cmShort, String body,
			IPassengerFlowDatas iReceiveDatas) {
		switch (cmShort) {
		case DefineTraffic.CM_TRAFFIC_RESPONSE:// 客流数据处理器数据返回
			int upNumber = Integer.valueOf(body.substring(0, 8), 16).intValue();
			int downNumber = Integer.valueOf(body.substring(9, 16), 16)
					.intValue();
			iReceiveDatas.receivePass(idInt, upNumber, downNumber);
			break;
		case DefineTraffic.CM_DOOR_RESPONSE:// 客流处理器车门状态答应
			int state = 0;
			if (body.equals("010101010101")) {
				// 开
				state = 1;
			} else if (body.equals("010000000000")) {
				// 关
				state = 0;
			}
			iReceiveDatas.updateDoorState(idInt, state);
			break;
		case DefineTraffic.CM_CLEAR_RESPONSE:// 客流处理器答应
			int result = 0;
			if (body.equals("06")) {
				result = 1;
				LogTool.logI(TAG, "Clear response Success!!!");
			} else if (body.equals("15")) {
				result = 0;
				LogTool.logI(TAG, "Clear response Failure !!!");
			}
			iReceiveDatas.passClearResponse(idInt, result);
			break;
		default:
			break;
		}
	}

	// //////////////////////////////////以下为数据发送接口///////////////////////////////////////////////
	/**
	 * 客流量查询指令
	 * 
	 * @param srId
	 *            485ID地址 0x0001表示前门 0x0002表示后门
	 * 
	 */
	public byte[] queryPassengerInfo(int srId) {
		byte[] mcuCmd = cmdBytes(srId, (short) 0x13);
		return mcuCmd;
	}

	/**
	 * 发送车门状态读取客流信息
	 * 
	 * @param rsId
	 *            485ID地址 0X0001表示前面 0x00002 表示后门
	 */
	public byte[] sendDoorStateRequest(int rsId) {
		byte[] mcuCmd = cmdBytes(rsId, (short) 0x66);
		return mcuCmd;
	}

	/**
	 * 数据清零指令
	 * 
	 * @param doorId
	 * @return
	 */
	public byte[] sendClearData(int doorId) {
		byte[] mcuCmdclear = cmdBytes(doorId, (short) 0x12);
		return mcuCmdclear;
	}

	/**
	 * 发送封装了RS-485 协议的mcu指令
	 * 
	 * @param srId
	 *            485ID地址 0X0001表示前面 0x00002 表示后门
	 * @param srCm
	 *            命令字符 区分不同的指令 例：0x12 表示 数据清零 0x 92 表示客流处理器应答
	 * @return
	 */

	private byte[] cmdBytes(int srId, short srCm) {
		RsCmd rsCmd = new RsCmd(srId, srCm);
		byte[] cmdData = rsCmd.toArray();
		return cmdData;
	}

}
