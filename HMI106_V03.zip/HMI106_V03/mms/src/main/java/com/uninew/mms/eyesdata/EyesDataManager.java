package com.uninew.mms.eyesdata;

import com.uninew.mms.interfaces.IPassengerFlowDatas;
import com.uninew.mms.util.LogTool;

public class EyesDataManager {
	private static final String TAG="EyesDataManager";

	public EyesDataManager() {
	}

	/**
	 * 处理客流量数据
	 * 
	 * @param datas
	 */
	public void handle(byte[] datas, IPassengerFlowDatas iReceiveDatas) {
		PassengerFlowPacket p=new PassengerFlowPacket();
		p=p.getProtocolPacket(datas);
		PPassengerFlow pf=new PPassengerFlow();
		if (p.getBody()==null) {
			return;
		}
		pf=pf.getProtocolPacket(p.getBody());
//		LogTool.logD(TAG, "pf="+pf.toString());
		int id=0x00;
		switch (p.getSrcAddress()) {
		case DefineEyePassenger.TargetOrSrcAddress.FRONT_DOOR:
			id=0x00;//前门
			break;
		case DefineEyePassenger.TargetOrSrcAddress.AFTER_DOOR:
			id=0x01;//后门
			break;
		default:
			break;
		}
		iReceiveDatas.receivePass(id, pf.getUpNumber(), pf.getDownNumber());
	}
	
	
	/**
	 * 获取客流量查询协议发送数据
	 * @param doorId 前门：0x00，后门：0x01
	 * @return
	 */
	public byte[] getSendQueryDatas(int doorId){
		int targetAddress=DefineEyePassenger.TargetOrSrcAddress.FRONT_DOOR;
		switch (doorId) {
		case 0x01:
			targetAddress=DefineEyePassenger.TargetOrSrcAddress.FRONT_DOOR;
			break;
		case 0x02:
			targetAddress=DefineEyePassenger.TargetOrSrcAddress.AFTER_DOOR;
			break;
		default:
			break;
		}
		PassengerFlowPacket plp=new PassengerFlowPacket(targetAddress, 
				DefineEyePassenger.TargetOrSrcAddress.TERMINAL_HOST, 
				DefineEyePassenger.FIXED_MSGID, null);
		return plp.getBytes();
	}
	
}
