package com.uninew.mms.traffic;


public class RsSendReadCMDMethod {

	/**
	 * 客流量查询指令
	 * 
	 * @param srId
	 *            485ID地址 0x0001表示前门 0x0002表示后门
	 * 
	 */
	public byte[] queryPassengerInfo(int srId) {
		byte[] mcuCmd = cmdBytes(srId, (short) 0x13);
		return mcuCmd;
	}

	/**
	 * 发送车门状态读取客流信息
	 * 
	 * @param rsId
	 *            485ID地址 0X0001表示前面 0x00002 表示后门
	 */
	public byte[] sendDoorStateRequest(int rsId) {
		byte[] mcuCmd = cmdBytes(rsId, (short) 0x66);
		return mcuCmd;
	}

	/**
	 * 数据清零指令
	 * 
	 * @param doorId
	 * @return
	 */
	public byte[] sendClearData(int doorId) {
		byte[] mcuCmdclear = cmdBytes(doorId, (short) 0x12);
		return mcuCmdclear;
	}

	/**
	 * 发送封装了RS-485 协议的mcu指令
	 * 
	 * @param srId
	 *            485ID地址 0X0001表示前面 0x00002 表示后门
	 * @param srCm
	 *            命令字符 区分不同的指令 例：0x12 表示 数据清零 0x 92 表示客流处理器应答
	 * @return
	 */

	private byte[] cmdBytes(int srId, short srCm) {
		RsCmd rsCmd = new RsCmd(srId, srCm);
		byte[] cmdData = rsCmd.toArray();
		return cmdData;
	}

}
