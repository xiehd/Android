package com.uninew.mms.protocol;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import android.util.Log;

import com.uninew.mms.interfaces.IAdDatas;
import com.uninew.mms.interfaces.IPassengerFlowDatas;
import com.uninew.mms.interfaces.IRoadSignsDatas;
import com.uninew.mms.util.LogTool;

public class RS485Control {
	private static final String TAG="RS485Control";
	private static boolean D=true;
	public PassengerFlowProtocolManager mPassengerFlowProtocolManager;
	public RoadSignsProtocolManager mRoadSignsProtocolManager;
	public ADProtocolManager mAdProtocolManager;
	private IPassengerFlowDatas mPassengerFlowDatas;
	private IRoadSignsDatas mRoadSignsDatas;
	private IAdDatas mAdDatas;
	private ProtocolManager pm;
	private List<byte[]> sendMsgs;
	private byte[] sendMsg;
	private static long pTime;
	//等待应答时间ms
	private static final  int RESPONSE_INTERVAL=1000;

	public RS485Control(ProtocolManager pm) {
		super();
		this.pm = pm;
		mPassengerFlowProtocolManager = new PassengerFlowProtocolManager();
		mRoadSignsProtocolManager = new RoadSignsProtocolManager();
		mAdProtocolManager = new ADProtocolManager();
		sendMsgs = new ArrayList<byte[]>();
		new Thread(controlRunnable).start();
	}
	

	public void setmPassengerFlowDatas(IPassengerFlowDatas mPassengerFlowDatas) {
		this.mPassengerFlowDatas = mPassengerFlowDatas;
	}


	public void setmRoadSignsDatas(IRoadSignsDatas mRoadSignsDatas) {
		this.mRoadSignsDatas = mRoadSignsDatas;
	}


	public void setmAdDatas(IAdDatas mAdDatas) {
		this.mAdDatas = mAdDatas;
	}


	public void send(byte[] datas) {
		synchronized (sendMsgs) {
			sendMsgs.add(datas);
		}
	}

	private byte[] getTop() {
		byte[] datas = null;
		synchronized (sendMsgs) {
			if (sendMsgs.size() > 0) {
				datas = sendMsgs.remove(0);
			}
		}
		return datas;
	}

	public void receive(byte[] body) {
		byte[] receiveDatas = Arrays.copyOfRange(body, 1, body.length);
		switch (body[0]) {
		case DefineMcu.RS485CommandId.Traffic_Detection:
			// 客流量
			mPassengerFlowProtocolManager.protocolManager(receiveDatas,
					mPassengerFlowDatas);
			break;
		case DefineMcu.RS485CommandId.Road_Signs:
			// 路牌
			mRoadSignsProtocolManager.protocolManager(receiveDatas,
					mRoadSignsDatas);
			break;
		case DefineMcu.RS485CommandId.Ad_Screen:
			// 广告屏
			mAdProtocolManager.protocolManager(receiveDatas, mAdDatas);
			break;
		default:
			break;
		}
		RS485_Control.setState(RS485_Control.SEND_SUCCESS);
		stateControl();
	}

	private Runnable controlRunnable = new Runnable() {

		@Override
		public void run() {
			// TODO Auto-generated method stub
			try {
				while (true) {
					stateControl();
					Thread.sleep(100);
				}
			} catch (Exception e) {
				// TODO: handle exception
			}
		}
	};

	private void stateControl() {
		switch (RS485_Control.getState()) {
		case IDLE:
			RS485_Control.setState(RS485_Control.BEFORE_SEND);
			break;
		case BEFORE_SEND:
			sendMsg=getTop();
			if (sendMsg != null) {
				RS485_Control.setState(RS485_Control.SEND);
				stateControl();
			}else{
				//
			}
			break;
		case SEND:
			pm.sendMsg(sendMsg);
			RS485_Control.setState(RS485_Control.WAIT_RESPONSE);
			pTime=System.currentTimeMillis();
			if (D) LogTool.logD(TAG, "startTime="+pTime);
			stateControl();
			break;
		case WAIT_RESPONSE:
			if (System.currentTimeMillis()-pTime > RESPONSE_INTERVAL ) {
				//超时处理
				RS485_Control.setState(RS485_Control.SEND_FAILURE);
			}
			break;
		case SEND_SUCCESS:
			if(D)LogTool.logV(TAG, "Send Success !!!!!!");
			RS485_Control.setState(RS485_Control.BEFORE_SEND);
			break;
		case SEND_FAILURE:
			if(D)LogTool.logE(TAG, "Send over time !!!!!!,time="+System.currentTimeMillis());
			RS485_Control.setState(RS485_Control.BEFORE_SEND);
			break;
		default:
			break;
		}
	}

	private enum RS485_Control {
		IDLE, // 空闲状态
		BEFORE_SEND, // 发送前状态
		SEND, // 发送
		WAIT_RESPONSE, // 等待应答
		SEND_SUCCESS, // 发送成功
		SEND_FAILURE;// 发送失败

		private static RS485_Control state = IDLE;

		public static RS485_Control getState() {
			return state;
		}

		public static void setState(RS485_Control state) {
			if(D)Log.v("RS485_Control", String.format(
					"###### State Changed: %s ==> %s ######",
					RS485_Control.state, state));
			RS485_Control.state = state;
		}
	}
}
