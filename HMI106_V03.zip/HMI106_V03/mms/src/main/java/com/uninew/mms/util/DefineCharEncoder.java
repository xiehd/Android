package com.uninew.mms.util;

public class DefineCharEncoder {
	public static final String GB2312="GB2312";
	public static final String UTF_8="UTF-8";
	public static final String ASCII="ASCII";
	public static final String GBK="GBK";
}
