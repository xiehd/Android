package com.uninew.mms;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RadioGroup.OnCheckedChangeListener;
import android.widget.TextView;
import android.widget.Toast;

import com.uninew.mms.McuService.MyBinder;
import com.uninew.mms.interactive.DefineMMSAction;
import com.uninew.mms.interactive.MMSBroadCastTool;
import com.uninew.mms.interfaces.IAdDatas;
import com.uninew.mms.interfaces.IPassengerFlowDatas;
import com.uninew.mms.interfaces.IReceiveDatas;
import com.uninew.mms.interfaces.IRoadSignsDatas;
import com.uninew.mms.protocol.MCUUpdataManager;
import com.uninew.mms.protocol.MCUUpdataManager.McuUpdataState;
import com.uninew.mms.protocol.ProtocolSendManager;
import com.uninew.mms.socket.TCPLink;
import com.uninew.mms.socket.TCPLink.TCPCallbackInterface;
import com.uninew.mms.socket.TCPLinkErrorEnum;
import com.uninew.mms.socket.TCPRunStateEnum;
import com.uninew.mms.util.LogTool;

public class MainActivity extends Activity implements OnClickListener,
		TCPCallbackInterface, IReceiveDatas,IPassengerFlowDatas,IRoadSignsDatas,IAdDatas,OnCheckedChangeListener{
	private static final String TAG = "MainActivity";
	private McuService mService;
	private Button btn_openSocket, btn_closeSocket, btn_send, btn_passRequest,
			btn_mcuupdate, btn_osupdate, btn_doorStateRequest, btn_dataClear,txt_LED_NO,txt_LED_sendmsg,
			txt_LED_OFF,btn_roadSigns, btn_init, btn_close, btn_version;
	private TextView textView, txt_upnumber, txt_downnumber, txt_upnumber_hou,
			txt_downnumber_hou, txt_cardNumber,txt_getoutNumber,txt_getinNumber;
	private EditText et_sleepTime;
	private Button btn_setSleepTime;
	private TCPLink mTcpLink;
	private ProtocolSendManager pm;
	private MCUUpdataManager mUpdata;
	private MyBroadCast mMyBroadcastReceiver;
	//页面选择
	private RadioButton page_passenger,page_roadsigns,page_mcu,page_led;
	private RadioGroup radiogroup;
	//页面
	private LinearLayout ll_passenger,ll_roadsigns,ll_mcu,ll_led;
	//路牌
	private Button btn_roadsigns_outSide,btn_roadsigns_front,btn_roadsigns_after,
	btn_roadsigns_inSide,btn_roadsigns_middle;

	private static int getinNumber;// 上车人数
	private static int getoutNumber;// 下车人数
	private static int cardNumber;// 车内人数
	private static int onedoor_getinNumber;// 前门上车人数
	private static int onedoor_getoutNumber;// 前门下车人数
	private static int twodoor_getinNumber;// 后门上车人数
	private static int twodoor_getoutNumber;// 后门下车人数
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		findViews();
		setListeners();
		// mTcpLink=new TCPLink(this);
		// mTcpLink.setTcpBackInterface(this);
		pm = new ProtocolSendManager(this);
		pm.setmReceiveDatas(this);
		pm.setmPassengerFlowDatas(this);
		pm.setmAdDatas(this);
		pm.setmRoadSignsDatas(this);
		mUpdata = new MCUUpdataManager(mHandler, pm);
		startService();
		registerBroadCast();
	}

	Handler myhand = new Handler(){
		@Override
		public void dispatchMessage(Message msg) {
			super.dispatchMessage(msg);
		}
	};
	
	/**
	 * 注册广播
	 */
	private void registerBroadCast() {
		IntentFilter iFilter = new IntentFilter();
		iFilter.addAction(DefineMMSAction.MCULinkPass);
		mMyBroadcastReceiver = new MyBroadCast();
		this.registerReceiver(mMyBroadcastReceiver, iFilter);
	}

	/**
	 * 开启服务
	 */
	Intent service;
	private void startService() {
		// TODO Auto-generated method stub
		service = new Intent("com.uninew.mms.McuService");
		startService(service);
		bindService(service, conn, Context.BIND_AUTO_CREATE);
	}
	
	private void stopService(){
		if (service!=null) {
			stopService(service);
		}
	}

	private ServiceConnection conn = new ServiceConnection() {
		@Override
		public void onServiceConnected(ComponentName name, IBinder service) {
			mService = ((MyBinder) service).getService();
			LogTool.logI(TAG, "Binder MainService Success!!! mService="
					+ mService);
		}

		@Override
		public void onServiceDisconnected(ComponentName name) {
			LogTool.logI(TAG, "MainService onServiceDisconnected!!!");
		}
	};

	private void findViews() {
		// TODO Auto-generated method stub
		btn_openSocket = (Button) findViewById(R.id.btn_openSocket);
		btn_closeSocket = (Button) findViewById(R.id.btn_closeSocket);
		btn_send = (Button) findViewById(R.id.btn_send);
		btn_openSocket.setOnClickListener(this);
		btn_closeSocket.setOnClickListener(this);
		btn_send.setOnClickListener(this);

		btn_version = (Button) findViewById(R.id.btn_version);
		btn_version.setOnClickListener(this);
		btn_mcuupdate = (Button) findViewById(R.id.btn_mcuupdate);
		btn_mcuupdate.setOnClickListener(this);
		btn_osupdate = (Button) findViewById(R.id.btn_osupdate);
		btn_osupdate.setOnClickListener(this);
		// textView = (TextView) findViewById(R.id.textView1);
		txt_downnumber = (TextView) findViewById(R.id.txt_downnumber);
		txt_upnumber = (TextView) findViewById(R.id.txt_upnumber);
		txt_upnumber_hou = (TextView) findViewById(R.id.txt_upnumber_hou);
		txt_downnumber_hou = (TextView) findViewById(R.id.txt_downnumber_hou);
		txt_cardNumber = (TextView) findViewById(R.id.txt_cardNumber);
		txt_getoutNumber = (TextView) findViewById(R.id.txt_getoutNumber);
		txt_getinNumber = (TextView) findViewById(R.id.txt_getinNumber);
		
		btn_passRequest = (Button) findViewById(R.id.btn_passRequest);
		btn_doorStateRequest = (Button) findViewById(R.id.btn_doorStateRequest);
		btn_dataClear = (Button) findViewById(R.id.btn_dataClear);
		btn_roadSigns = (Button) findViewById(R.id.btn_roadsigns_outSide);
		btn_init = (Button) findViewById(R.id.btn_init);
		//led
		txt_LED_NO = (Button) findViewById(R.id.txt_LED_NO);
		txt_LED_OFF = (Button) findViewById(R.id.txt_LED_OFF);
		txt_LED_sendmsg = (Button) findViewById(R.id.txt_LED_sendmsg);
		
		txt_LED_NO.setOnClickListener(this);
		txt_LED_OFF.setOnClickListener(this);
		txt_LED_sendmsg.setOnClickListener(this);

		btn_passRequest.setOnClickListener(this);
		btn_doorStateRequest.setOnClickListener(this);
		btn_dataClear.setOnClickListener(this);
		btn_roadSigns.setOnClickListener(this);
		btn_init.setOnClickListener(this);

		btn_close = (Button) findViewById(R.id.btn_close);
		btn_close.setOnClickListener(this);

		et_sleepTime = (EditText) findViewById(R.id.et_sleepTime);
		btn_setSleepTime = (Button) findViewById(R.id.btn_setSleepTime);
		btn_setSleepTime.setOnClickListener(this);
		
		//页面控制
		page_passenger=(RadioButton) findViewById(R.id.page_passenger);
		page_roadsigns=(RadioButton) findViewById(R.id.page_roadsigns);
		page_mcu=(RadioButton) findViewById(R.id.page_mcu);
		page_led = (RadioButton) findViewById(R.id.page_led);
		radiogroup = (RadioGroup) findViewById(R.id.radiogroup);
		
		radiogroup.setOnCheckedChangeListener(this);
		
		//页面
		ll_mcu = (LinearLayout) findViewById(R.id.ll_mcu);
		ll_passenger = (LinearLayout) findViewById(R.id.ll_passenger);
		ll_roadsigns = (LinearLayout) findViewById(R.id.ll_roadsigns);
		ll_led = (LinearLayout) findViewById(R.id.ll_led);
		//路牌
	}

	private void setListeners() {
		// TODO Auto-generated method stub
	}
	
	//清除页面
	private void cleanLinlayout(){
		ll_mcu.setVisibility(View.GONE);
		ll_passenger.setVisibility(View.GONE);
		ll_roadsigns.setVisibility(View.GONE);
		ll_led.setVisibility(View.GONE);
	}
	@Override
	public void onCheckedChanged(RadioGroup group, int arg1) {
		switch (group.getCheckedRadioButtonId()) {
		case R.id.page_passenger://客流页面
			cleanLinlayout();
			ll_passenger.setVisibility(View.VISIBLE);
			break;
		case R.id.page_mcu://MCU页面
			cleanLinlayout();
			ll_mcu.setVisibility(View.VISIBLE);
			break;
		case R.id.page_roadsigns://路牌页面
			cleanLinlayout();
			ll_roadsigns.setVisibility(View.VISIBLE);
			break;
		case R.id.page_led://LED页面
			cleanLinlayout();
			ll_led.setVisibility(View.VISIBLE);
			break;

		default:
			break;
		}
		
		
	}
	
	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		switch (v.getId()) {
		case R.id.btn_openSocket:
//			pm.openSocket();
			startService();
			break;
		case R.id.btn_closeSocket:
//			pm.closeSocket();
			stopService();
			break;
		case R.id.btn_send:
			// ProtocolPacket pp = new ProtocolPacket(DefineMcu.TypeId.GID_EVT,
			// DefineMcu.GroupId.DISPLAY, new byte[] { 0x02, (byte) 0xb0 });
			// pm.sendMsg(pp.getBytes());
			break;
		case R.id.btn_init:
			startService();
			registerBroadCast();
			break;
		case R.id.btn_passRequest:// 客流量
			new MMSBroadCastTool(this).sendPassRequest();
			break;
		case R.id.btn_doorStateRequest:
			new MMSBroadCastTool(this).sendDoorStateRequest(0x0001);
			new MMSBroadCastTool(this).sendDoorStateRequest(0x0002);
			break;
		case R.id.btn_dataClear:
			txt_downnumber.setText("0");
			txt_upnumber.setText("0");
			txt_upnumber_hou.setText("0");
			txt_downnumber_hou.setText("0");
			
			cardNumber = 0;
			txt_cardNumber.setText(String.valueOf(cardNumber));
			txt_getoutNumber.setText(String.valueOf(0));
			txt_getinNumber.setText(String.valueOf(0));
			
			break;
		case R.id.btn_close:
			mService.closeSocket();
			break;
		case R.id.btn_roadsigns_outSide:
			new MMSBroadCastTool(this).sendRoadSigns(new byte[]{0x01,0x02,0x03},"704", "南头小关", "宝安桃花源");
			break;
		case R.id.btn_version:
			LogTool.logE("yzb", "btn_version");
			new MMSBroadCastTool(this).sendMCUVersionRequest();
			break;
		case R.id.btn_mcuupdate:
			pm.sendMcuUpdate();
			LogTool.logE("meij", "btn_mcuupdate");
			break;
		case R.id.btn_osupdate:
			new MMSBroadCastTool(this).sendOSUpdateNotify();
			break;
		case R.id.btn_setSleepTime:
			// 设置MCU休眠时间
			String sTime = et_sleepTime.getText().toString();
			if (sTime == null || "".equals(sTime)) {
				Toast.makeText(this, "请先设置休眠时间！", Toast.LENGTH_SHORT).show();
				break;
			}
			int time = Integer.parseInt(sTime);
			pm.setSleepTime(time);
			break;
		case R.id.txt_LED_NO://打开LED
			//new MMSBroadCastTool(this).sendLEDState((byte)0x01);
			break;
		case R.id.txt_LED_OFF://关闭LED
			//new MMSBroadCastTool(this).sendLEDState((byte)0x00);
			break;
		case R.id.txt_LED_sendmsg://发送LED信息
			//new MMSBroadCastTool(this).sendLEDState((byte)0x02);
			break;
		default:
			break;
		}
	}

	/**
	 * 广播接收器
	 * 
	 * @author jiami
	 * 
	 */
	class MyBroadCast extends BroadcastReceiver {

		@Override
		public void onReceive(Context context, Intent intent) {
			String action = intent.getAction();
			switch (action) {
			case DefineMMSAction.MCULinkPass:// 客流量请求应答
				int dir = intent.getIntExtra(DefineMMSAction.pass.UpNumber, 0);
				int num = intent.getIntExtra(DefineMMSAction.pass.DownNumber, 0);
				int doorId = intent.getIntExtra(DefineMMSAction.pass.DoorId, 0);
				if (doorId == 0x0000) {
					txt_downnumber.setText(String.valueOf(num));
					txt_upnumber.setText(String.valueOf(dir));
					onedoor_getinNumber = dir;
					onedoor_getoutNumber = num;
				}
				if (doorId == 0x0001) {
					txt_downnumber_hou.setText(String.valueOf(num));
					txt_upnumber_hou.setText(String.valueOf(dir));
					twodoor_getinNumber = dir;
					twodoor_getoutNumber = num;
				}
				getinNumber = onedoor_getinNumber + twodoor_getinNumber;
				getoutNumber = onedoor_getoutNumber + twodoor_getoutNumber;
				cardNumber = getinNumber - getoutNumber + cardNumber;
				onedoor_getinNumber = 0;
				onedoor_getoutNumber = 0;
				twodoor_getinNumber = 0;
				twodoor_getoutNumber = 0;
				txt_cardNumber.setText(String.valueOf(cardNumber));
				txt_getoutNumber.setText(String.valueOf(getoutNumber));
				txt_getinNumber.setText(String.valueOf(getinNumber));
				break;
			}

		}

	}

	@Override
	protected void onDestroy() {
		// TODO Auto-generated method stub
		super.onDestroy();
		if (conn != null) {
			 unbindService(conn);
		}
		unregisterReceiver(mMyBroadcastReceiver);
	}

	@Override
	public void onTCPRunStateChangeder(TCPRunStateEnum vValue,
			TCPLinkErrorEnum error) {
		// TODO Auto-generated method stub
		LogTool.logD("yzb", "onTCPRunStateChangeder,TCPRunStateEnum=" + vValue
				+ ",TCPLinkErrorEnum=" + error);
		str = "onTCPRunStateChangeder,TCPRunStateEnum=" + vValue
				+ ",TCPLinkErrorEnum=" + error;
		mHandler.sendEmptyMessage(0);
	}

	@Override
	public void onTCPReceiveDataChangeder(byte[] vBuffer) {
		// TODO Auto-generated method stub
		LogTool.logBytes("onTCPReceiveDataChangeder,datas=", vBuffer);
	}

	@Override
	public void keyReceive(int keyValue) {
		// TODO Auto-generated method stub
		LogTool.logD("yzb",
				"keyReceive,keyValue=0x" + Integer.toHexString(keyValue & 0xff));
	}

	@Override
	public void roadSignsResponse(int result) {
		// TODO Auto-generated method stub

	}
//////////////////////////////////////////广告屏//////////////////////////////////////////////////////////
	@Override
	public void adScreenResponse(byte[] datas) {
		// TODO Auto-generated method stub

	}
//////////////////////////////客流量/////////////////////////////////////////////////////////
	private synchronized void  mypeopleNumber(){
		getinNumber = onedoor_getinNumber + twodoor_getinNumber;
	}
	
	@Override
	public void receivePass(int id, int upNumber, int downNumber) {
		// TODO Auto-generated method stub
		str = "receivePass,id=" + id + ",upNumber=" + upNumber + ",downNumber="
				+ downNumber;
		mHandler.sendEmptyMessage(0);
	}

	@Override
	public void updateDoorState(int id, int state) {
		// TODO Auto-generated method stub
		str = "updateDoorState,id=" + id + ",state=" + state;
		mHandler.sendEmptyMessage(0);
	}

	@Override
	public void passClearResponse(int id, int result) {
		// TODO Auto-generated method stub
		str = "passClearResponse,id=" + id + ",result=" + result;
		mHandler.sendEmptyMessage(0);
	}
	
	@Override
	public void receivePass(int id, int upNumber, int downNumber,
			int totalNumber) {
		// TODO Auto-generated method stub
		
	}
///////////////////////////////////MCU////////////////////////////////////////////////////////////////
	/** MCU版本升级 */
	private static final int WHAT_MCU_UPDATE = 7;
	String str;
	private Handler mHandler = new Handler() {

		@Override
		public void handleMessage(Message msg) {
			// TODO Auto-generated method stub
			// textView.setText(str);
			switch (msg.what) {
			case WHAT_MCU_UPDATE:
				int arg = msg.arg1;
				if (arg == 0) {
					Toast.makeText(getApplicationContext(), "mcu升级失败！", 1)
							.show();
				} else if (arg == 1) {
					Toast.makeText(getApplicationContext(), "mcu升级成功！", 1)
							.show();
				} else if (arg == 2) {
					Toast.makeText(getApplicationContext(), "sd卡或者mcu升级文件不存在！",
							1).show();
				} else if (arg == 3) {
					Toast.makeText(getApplicationContext(), "mcu版本太低，无法升级！", 1)
							.show();
				}
				break;

			default:
				break;
			}
		}

	};

	@Override
	public void McuVersion(String version) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mcuUpdataResponse(byte[] datas) {
		// TODO Auto-generated method stub

		// TODO Auto-generated method stub
		LogTool.logBytes("meij__", datas);
		// TODO Auto-generated method stub
		Log.i("meij", "mcurespons--1");
		mUpdata.setReceivedTime(System.currentTimeMillis());
		switch (datas[0]) {
		case 0x01:
			if (datas[1] == 0x01) {
				mUpdata.setMcuUpdateState(McuUpdataState.updataInit);
				mUpdata.createMcuUpdateThread();
			} else {
				if (datas[1] == 0x00) {
					mUpdata.setMcuUpdateState(McuUpdataState.updataEnd);
				}
			}
			break;
		case 0x02:
			mUpdata.addMcuUpdataQuene(datas);
			break;
		default:
			break;
		}

	}

	@Override
	public void onSleepTime(int sleepTime) {
		// TODO Auto-generated method stub
		str = "onSleepTime,sleepTime=" + sleepTime;
		mHandler.sendEmptyMessage(0);
	}

	@Override
	public void onAccState(int state) {
		// TODO Auto-generated method stub

	}
	
}
