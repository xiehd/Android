package com.uninew.mms.toyou;

import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import com.uninew.mms.interfaces.IProtocolPacket;
import com.uninew.mms.util.LogTool;

/**
 * 路牌协议（二级封装）
 * @author Administrator
 *
 */
public class RoadSigns implements IProtocolPacket {

	private static final String TAG = "RoadSigns";
	private boolean D = true;

	/** 命令字 */
	private byte cmd;
	/** ID号--无效默认0x00,0x00 */
	private short id;
	/** 数据长度 */
	private short length;
	/** 路牌数据 */
	List<RoadSign>  roadSigns;

	public RoadSigns() {
		super();
	}

	/**
	 * 
	 * @param roadSigns
	 *            路牌数据对象集（可同时发送多个路牌）
	 */
	public RoadSigns(List<RoadSign> roadSigns) {
		super();
		this.cmd = 0x03;
		this.id = 0;
		this.roadSigns=roadSigns;
	}

	@Override
	public byte[] getBytes() {
		// TODO Auto-generated method stub
		if (null == roadSigns || roadSigns.size() <= 0) {
			LogTool.logE(TAG, "datas is NULL !!!");
			return null;
		}
		for (int i = 0; i < roadSigns.size(); i++) {
			length=(short) (length+roadSigns.get(i).getBytes().length);
		}
		ByteArrayOutputStream bis = new ByteArrayOutputStream();
		DataOutputStream dos = new DataOutputStream(bis);
		try {
			dos.writeByte(cmd);
			dos.writeShort(id);
			dos.writeShort(length);
			for (int i = 0; i < roadSigns.size(); i++) {
				dos.write(roadSigns.get(i).getBytes());
			}
			dos.flush();
			return bis.toByteArray();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public Object getProtocolPacket(byte[] datas) {
		// TODO Auto-generated method stub
		return null;
	}

	public byte getCmd() {
		return cmd;
	}

	public void setCmd(byte cmd) {
		this.cmd = cmd;
	}

	public short getId() {
		return id;
	}

	public void setId(short id) {
		this.id = id;
	}

	public short getLength() {
		return length;
	}

	public void setLength(short length) {
		this.length = length;
	}

	public List<RoadSign> getRoadSigns() {
		return roadSigns;
	}

	public void setRoadSigns(List<RoadSign> roadSigns) {
		this.roadSigns = roadSigns;
	}

	@Override
	public String toString() {
		return "RoadSigns [cmd=" + cmd + ", id=" + id + ", length=" + length
				+ ", roadSigns=" + roadSigns + "]";
	}

}
