package com.uninew.mms.protocol;

public class DefineProtocolVersion {
	
//--------------------客流量协议版本-----------------------------------------
	/**国家通用标准协议《公共交通车载信息终端与外围设备通讯协议》*/
	public static final int PASSENGERFLOWVERSION_NATIONAL_STANDARD=0x00;
	/**客流量处理器与RS485通讯协议*/
	public static final int PASSENGERFLOWVERSION_DEFINE_OLD=0x01;
	/**江苏慧眼数据科技*/
	public static final int PASSENGERFLOWVERSION_JSHY=0x02;
	/**客流量协议管理*/
	public static int currentPassengerFlowVersion=PASSENGERFLOWVERSION_JSHY;
	
	
//---------------------路牌协议版本-----------------------------------------	
	/**国家通用标准协议《公共交通车载信息终端与外围设备通讯协议》*/
	public static final int ROADSIGNSVERSION_NATIONAL_STANDARD=0x00;
	/**图岳电子协议*/
	public static final int ROADSIGNSVERSION_TUYUE=0x01;
	/**杭正协议*/
	public static final int ROADSIGNSVERSION_HZ=0x02;
	/**路牌协议管理*/
	public static int currentRoadSignsVersion=ROADSIGNSVERSION_HZ;

	
//---------------------广告屏协议版本-----------------------------------------	
	/**国家通用标准协议《公共交通车载信息终端与外围设备通讯协议》*/
	public static final int ADVERSION_NATIONAL_STANDARD=0x00;
	/**图岳电子协议*/
	public static final int ADVERSION_TUYUE=0x01;
	/**广告屏协议管理*/
	public static int currentADVersion=ADVERSION_NATIONAL_STANDARD;
	
}
