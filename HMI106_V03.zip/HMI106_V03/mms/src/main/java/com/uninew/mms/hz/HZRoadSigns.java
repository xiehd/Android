package com.uninew.mms.hz;

import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;

import com.uninew.mms.interfaces.IProtocolPacket;
import com.uninew.mms.protocol.McuCheckSum;
import com.uninew.mms.util.LogTool;

public class HZRoadSigns implements IProtocolPacket{
	private static final String TAG="HZRoadSigns";
	private static boolean D=true;
	/** 路牌ID*/
	private byte roadSignId;
	/**内容*/
	private String content;
	
	/***
	 * 
	 * @param roadSignsId 路牌ID:0x01-头牌+腰牌+尾牌；0x02-头牌+尾牌；0x03-内牌
	 * @param content
	 */
	public HZRoadSigns(byte roadSignId, String content) {
		super();
		this.roadSignId = roadSignId;
		this.content = content;
	}

	@Override
	public byte[] getBytes() {
		// TODO Auto-generated method stub
		ByteArrayOutputStream bis = new ByteArrayOutputStream();
		DataOutputStream dos = new DataOutputStream(bis);
		try {
			dos.writeByte(roadSignId);
			dos.write(content.getBytes(DefineHzRoadSigns.ENCODE_GBK));
			byte[] msg = bis.toByteArray(); 
			return msg;
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public Object getProtocolPacket(byte[] datas) {
		// TODO Auto-generated method stub
		return null;
	}

}
