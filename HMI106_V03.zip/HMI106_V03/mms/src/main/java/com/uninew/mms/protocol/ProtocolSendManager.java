package com.uninew.mms.protocol;

import android.content.Context;

import com.uninew.mms.util.ByteTools;

/**
 * 消息发送管理类
 * 
 * @author Administrator
 * 
 */
public class ProtocolSendManager extends ProtocolManager {

	public ProtocolSendManager(Context mContext) {
		super(mContext);
		// TODO Auto-generated constructor stub
	}

	/**
	 * 发送心跳信息
	 */
	byte serialNumber = 0;

	public void sendHeartBeat() {
		ProtocolPacket pp = new ProtocolPacket(DefineMcu.TypeId.GID_CMD,
				DefineMcu.GroupId.SYSTEM,
				DefineMcu.SystemCommandId.System_Info, new byte[] { 1,
						serialNumber++ });
		sendMsg(pp);
		if (serialNumber == 127) {
			serialNumber = 0;
		}
	}

	/**
	 * MCU版本查看
	 */

	public void queryMcuVersion() {
		ProtocolPacket pp = new ProtocolPacket(DefineMcu.TypeId.GID_ERQ,
				DefineMcu.GroupId.SYSTEM,
				DefineMcu.SystemCommandId.System_Info, new byte[] { 0x02 });
		sendMsg(pp);
	}

	/**
	 * 发送mcu升级指令
	 */
	public void sendMcuUpdate() {
		byte[] bytes = new byte[0];
		ProtocolPacket pp = new ProtocolPacket(DefineMcu.TypeId.GID_CMD,
				DefineMcu.GroupId.MCU_UPDATA,
				DefineMcu.UpdateCommandId.MCU_UPDATE, bytes);
		sendMsg(pp);
	}

	/**
	 * 发送mcu升级数据包
	 * 
	 * @param packet
	 */
	public void sendMcuUpdataDate(McuUpdatePacket packet) {
		ProtocolPacket pp = new ProtocolPacket(DefineMcu.TypeId.GID_CMD,
				DefineMcu.GroupId.MCU_UPDATA,
				(byte) DefineMcu.UpdateCommandId.MCU_SEND, packet.tobytes());
		sendMsg(pp);
	}

	/**
	 * 发送OS升级通知
	 */
	public void sendOSUpdateNotify() {
		ProtocolPacket pp = new ProtocolPacket(DefineMcu.TypeId.GID_CMD,
				DefineMcu.GroupId.MCU_UPDATA,
				DefineMcu.UpdateCommandId.OS_UPDATE, new byte[] { 0x02 });
		sendMsg(pp);
	}

	/**
	 * 设置休眠时间
	 * 
	 * @param time
	 *            （分钟）
	 */
	public void setSleepTime(int time) {
		ProtocolPacket pp = new ProtocolPacket(DefineMcu.TypeId.GID_CMD,
				DefineMcu.GroupId.PARM_SET, DefineMcu.ParamSetId.MCU_SLEEP,
				ByteTools.shortToBytes((short) time));
		sendMsg(pp);
	}

	// /////////////////////////////----客流量----//////////////////////////////////////////////
	/**
	 * 客流量查询指令
	 * 
	 * @param doorId
	 *            485ID地址 0x0001表示前门 0x0002表示后门
	 * 
	 */
	public void queryPassengerInfo(int doorId) {
		byte[] body = mRs485Control.mPassengerFlowProtocolManager
				.getQueryPassengerInfo(doorId);
		ProtocolPacket pp = new ProtocolPacket(DefineMcu.TypeId.GID_ERQ,
				DefineMcu.GroupId.RS485,
				DefineMcu.RS485CommandId.Traffic_Detection, body);
//		sendMsg(pp);
		mRs485Control.send(pp.getBytes());
	}

	/**
	 * 客流量数据清零
	 * 
	 * @param doorId
	 *            0x0001表示前门 0x0002表示后门
	 */
	public void passClear(int doorId) {
		byte[] body = mRs485Control.mPassengerFlowProtocolManager.getPassClearDatas(doorId);
		ProtocolPacket pp = new ProtocolPacket(DefineMcu.TypeId.GID_ERQ,
				DefineMcu.GroupId.RS485,
				DefineMcu.RS485CommandId.Traffic_Detection, body);
//		sendMsg(pp);
		mRs485Control.send(pp.getBytes());
	}

	/**
	 * 门状态查询
	 * 
	 * @param doorId
	 *            0x0001表示前门 0x0002表示后门
	 */
	public void doorStateRequest(int doorId) {
		byte[] body = mRs485Control.mPassengerFlowProtocolManager
				.getDoorStateRequestDatas(doorId);
		if (body!=null && body.length > 0) {
			ProtocolPacket pp = new ProtocolPacket(DefineMcu.TypeId.GID_ERQ,
					DefineMcu.GroupId.RS485,
					DefineMcu.RS485CommandId.Traffic_Detection, body);
//			sendMsg(pp);
			mRs485Control.send(pp.getBytes());
		}
	}

	// /////////////////////////////----路牌----/////////////////////////////////////////////

	private void sendRoadSigns(byte[] body) {
		ProtocolPacket pp = new ProtocolPacket(DefineMcu.TypeId.GID_ERQ,
				DefineMcu.GroupId.RS485, DefineMcu.RS485CommandId.Road_Signs,
				body);
//		sendMsg(pp);
		mRs485Control.send(pp.getBytes());
	}

	/**
	 * 发送路牌信息
	 * @param roadSignIds 0x01头牌,0x02腰牌,(0x21左腰牌,0x22右腰牌),0x03尾牌
	 * @param roadName 线路名称
	 * @param startStation 起始站
	 * @param endStation 终点站
	 */
	public void sendRoadSigns(byte[] roadSignIds,String roadName,String startStation,String endStation) {
		for (int i = 0; i < roadSignIds.length; i++) {
			byte[] body = mRs485Control.mRoadSignsProtocolManager.getRoadSignsBytes(roadSignIds[i],roadName,startStation,endStation);
			sendRoadSigns(body);
		}
	}
	
	/**
	 * 发送路牌信息
	 * @param roadSignIds 0x01头牌,0x02腰牌,(0x21左腰牌,0x22右腰牌),0x03尾牌
	 * @param roadName 线路名称
	 * @param startStation 起始站
	 * @param endStation 终点站
	 */
	public void sendRoadSigns(byte[] roadSignIds,String content) {
		for (int i = 0; i < roadSignIds.length; i++) {
			byte[] body = mRs485Control.mRoadSignsProtocolManager.getRoadSignsBytes(roadSignIds[i],content);
			sendRoadSigns(body);
		}
	}
	// /////////////////////////////----广告屏----///////////////////////////////////////////

}
