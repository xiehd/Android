package com.uninew.mms.standard;

import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;

import com.uninew.mms.util.DefineCharEncoder;

/**
 * 路牌信息
 * 
 * @author Administrator
 * 
 */
public class TRoadSigns {
	/** 头牌图片信息 */
	private byte[] pictures;
	/** 线路名称 */
	private String roadName;
	/** 起始站1 */
	private String startStation1;
	/** 起始站2 说明：两个名称用于显示中英文循环显示，如果一致则填写相同内容 */
	private String startStation2;
	/** 终点站1 */
	private String endStation1;
	/** 终点站2 */
	private String endStation2;

	public TRoadSigns() {
		super();
	}

	
	/**
	 * 无图片，后续数据帧有效,起点站2与起点站1相同
	 * @param roadName 线路名称
	 * @param startStation1 起始站1
	 * @param startStation2 起始站2
	 * @param endStation1  终点站1
	 * @param endStation2  终点站2
	 */
	public TRoadSigns(String roadName, String startStation1, String endStation1) {
		super();
		this.roadName = roadName;
		this.startStation1 = startStation1;
		this.startStation2=startStation1;
		this.endStation1 = endStation1;
		this.endStation2=endStation1;
	}

	/**
	 * 无图片，后续数据帧有效
	 * @param roadName 线路名称
	 * @param startStation1 起始站1
	 * @param startStation2 起始站2
	 * @param endStation1  终点站1
	 * @param endStation2  终点站2
	 */
	public TRoadSigns(String roadName, String startStation1,
			String startStation2, String endStation1, String endStation2) {
		super();
		this.roadName = roadName;
		this.startStation1 = startStation1;
		this.startStation2 = startStation2;
		this.endStation1 = endStation1;
		this.endStation2 = endStation2;
	}

	/**
	 * 有图片则无需后续数据帧
	 * @param pictures 图片帧数据 （点阵）
	 */
	public TRoadSigns(byte[] pictures) {
		super();
		this.pictures = pictures;
	}

	/**
	 * 获取数据
	 * 
	 * @return
	 */
	public byte[] getBytes() {
		byte[] datas = null;
		ByteArrayOutputStream bos = new ByteArrayOutputStream();
		DataOutputStream dos = new DataOutputStream(bos);
		try {
			if (pictures != null) {
				// 路牌图片（点阵数据）
				dos.writeByte(DefineRS485.DataId.ROAD_PICTURE_SHOW);
				dos.writeShort(pictures.length);
				dos.write(pictures);
			} else {
				// 线路名称
				dos.writeByte(DefineRS485.DataId.ROUTE_NAME);
				byte[] name = roadName.getBytes(DefineCharEncoder.GBK);
				dos.writeShort(name.length);
				dos.write(name);
				// 起始站1
				dos.writeByte(DefineRS485.DataId.START_STATION1);
				byte[] start1 = startStation1.getBytes(DefineCharEncoder.GBK);
				dos.writeShort(start1.length);
				dos.write(start1);
				// 起始站2
				dos.writeByte(DefineRS485.DataId.START_STATION2);
				byte[] start2 = startStation2.getBytes(DefineCharEncoder.GBK);
				dos.writeShort(start2.length);
				dos.write(start2);
				// 终点站 1
				dos.writeByte(DefineRS485.DataId.END_STATION1);
				byte[] end1 = endStation1.getBytes(DefineCharEncoder.GBK);
				dos.writeShort(end1.length);
				dos.write(end1);
				// 终点站2
				dos.writeByte(DefineRS485.DataId.END_STATION2);
				byte[] end2 = endStation2.getBytes(DefineCharEncoder.GBK);
				dos.writeShort(end2.length);
				dos.write(end2);
			}
			datas = bos.toByteArray();
			dos.flush();
			dos.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return datas;
	}

	public byte[] getPictures() {
		return pictures;
	}

	public void setPictures(byte[] pictures) {
		this.pictures = pictures;
	}

	public String getRoadName() {
		return roadName;
	}

	public void setRoadName(String roadName) {
		this.roadName = roadName;
	}

	public String getStartStation1() {
		return startStation1;
	}

	public void setStartStation1(String startStation1) {
		this.startStation1 = startStation1;
	}

	public String getStartStation2() {
		return startStation2;
	}

	public void setStartStation2(String startStation2) {
		this.startStation2 = startStation2;
	}

	public String getEndStation1() {
		return endStation1;
	}

	public void setEndStation1(String endStation1) {
		this.endStation1 = endStation1;
	}

	public String getEndStation2() {
		return endStation2;
	}

	public void setEndStation2(String endStation2) {
		this.endStation2 = endStation2;
	}

}
