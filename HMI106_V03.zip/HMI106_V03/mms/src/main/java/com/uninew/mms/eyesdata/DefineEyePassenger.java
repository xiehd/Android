package com.uninew.mms.eyesdata;

public interface DefineEyePassenger {

	/** 开始标志 */
	public static final byte START_FLAG = 0x7e;
	/** 结束标志 */
	public static final byte END_FLAG = 0x7f;
	
	/**固定消息帧类型*/
	public byte FIXED_MSGID=0x34;
	/**固定流水号*/
	public byte FIXED_SERIALNUMBER=0x01;
	/**固定数据帧类型*/
	public byte FIXED_DATA=0x62;
	
	
	/**
	 * 目标或者源地址
	 * 
	 * @author Administrator
	 * 
	 */
	public interface TargetOrSrcAddress {
		/** 车载终端主机（0x01） */
		int TERMINAL_HOST = 0x01;
		/** 客流设备前门（0xA0） */
		int FRONT_DOOR = 0xA0;
		/** 客流设备后门（0xA2） */
		int AFTER_DOOR = 0xA2;
	}
}
