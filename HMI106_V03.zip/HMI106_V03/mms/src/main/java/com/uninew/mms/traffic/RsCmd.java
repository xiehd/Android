package com.uninew.mms.traffic;

import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;

/**
 * @author pc
 * 
 */

public class RsCmd {
	private int srId;// 485ID地址�?
	private short srCm;// 命令字符，区分不同的�?
	private int len = 0x00;// data 数据长度
	private byte[] data;// 数据
	private byte[] date;// 时间
	private long excTime;// 执行时间
	private short chk;// 校验�?
	private static final String TAG = "RsCmd";
	private int current;// 当前执行次数
	private int total;// 请求总次�?
	private int time;// 超时时间
	private boolean isJuge;// 是否�?��超时处理

	public RsCmd(int srId, short srCm, int total, int time) {
		super();
		this.srId = srId;
		this.srCm = srCm;
		this.total = total;
		this.time = time;
	}

	public RsCmd(int srId, short srCm) {
		super();
		this.srId = srId;
		this.srCm = srCm;

	}

	public int getSrId() {
		return srId;
	}

	public void setSrId(int srId) {
		this.srId = srId;
	}

	public short getSrCm() {
		return srCm;
	}

	public void setSrCm(Short srCm) {
		this.srCm = srCm;

	}

	public int getLen() {
		return len;
	}
   public void setLen(short len){
	   this.len=len;
   }
	public byte[] getData() {
		return data;
	}

	public void setData(byte[] data) {
		if (data == null) {
			return;
		}
		this.data = data;
		if (data.length == 0) {
			data = null;
			date = null;
			len = 0x00;
		} else {
			len = data.length * 2;

		}
	}

	public void setDate(byte[] date) {
		if (len == 0) {
			this.date = null;
		}
		this.date = date;

	}

	public boolean reExc() {
		boolean isRec = current < total;
//		System.out.println("reExe------------->" + current + "---------"
//				+ total);
		if (isRec) {
			current++;
		}
		return isRec;
	}

	public long getExcTime() {
		return excTime;
	}

	public void setExcTime(long excTime) {
		this.excTime = excTime;
	}

	public short getChk() {
		return chk;
	}

	public void setChk(short chk) {
		this.chk = chk;
	}

	public int getCurrent() {
		return current;
	}

	public void setCurrent(int current) {
		this.current = current;
	}

	public int getTotal() {
		return total;
	}

	public void setTotal(int total) {
		this.total = total;
	}

	public int getTime() {
		return time;
	}

	public void setTime(int time) {
		this.time = time;
	}

	public boolean isJuge() {
		return isJuge;
	}

	public void setJuge(boolean isJuge) {
		this.isJuge = isJuge;
	}

	public byte[] toArray() {
		Check check = Check.getNewInstance();
		check.clear();

		check.add(srId);
		check.add(srCm);
		check.add(len);
		ByteArrayOutputStream arrayOutputStream = new ByteArrayOutputStream();
		DataOutputStream dataOutputStream = new DataOutputStream(
				arrayOutputStream);
		try {
//			dataOutputStream.writeByte((byte) 0x03);
			dataOutputStream.writeByte((byte) 0x02);
			dataOutputStream.write(convertToASCII(srId, 4));
			dataOutputStream.write(convertToASCII(srCm, 2));
			dataOutputStream.write(convertToASCII(len, 2));
			if (data != null) {
				for (int i = 0; i < data.length; i++) {
					check.add(data[i]);

					dataOutputStream.write(ConvertHexTo
							.convertHexToASCII(ConvertHexTo.convertHexToString(
									data[i], 2)));
				}
			}
			if (date != null) {
				for (int i = 0; i < date.length; i++) {
					check.add(date[i]);
					dataOutputStream.write(ConvertHexTo
							.convertHexToASCII(ConvertHexTo.convertHexToString(
									date[i], 2)));
				}
			}

			chk = Integer.valueOf(check.checkSum(), 16).shortValue();
//			System.out.println(chk);
//			System.out.println(ConvertHexTo.convertHexToString(chk, 2));
			dataOutputStream.write(convertToASCII(chk, 2));
			dataOutputStream.writeByte(0x03);
			dataOutputStream.flush();
		} catch (Exception e) {
			// TODO: handle exception
		}
		return arrayOutputStream.toByteArray();

	}

	/*
	 * �?6进制的数据转换为ascii字节数组
	 * 
	 * @param data 输入的数�?
	 * 
	 * @param length 要转换的数组长度
	 */
	private byte[] convertToASCII(int data, int length) {
		return ConvertHexTo.convertHexToASCII(ConvertHexTo.convertHexToString(
				data, length));
	}

}
