package com.uninew.mms.standard;

public class StandardManager {

	
	public StandardManager() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * 发送路牌信息
	 * @param targetId 目标地址(头牌、左腰牌、右腰牌、尾牌、广播地址)
	 * @param roadName 线路名称
	 * @param startStation 起点站
	 * @param endStation 终点站
	 * @return
	 */
	public byte[] getFrontRoadSigns(int targetId,String roadName,
			String startStation,String endStation) {
		TRoadSigns tRoadSigns=new TRoadSigns(roadName, startStation, endStation);
		RS485DevicePacket dp = new RS485DevicePacket(
				targetId,
				DefineRS485.TargetOrSrcAddress.TERMINAL_HOST,
				DefineRS485.MsgId.ROADSIGN_SHOW, tRoadSigns.getBytes());
		return dp.getBytes();
	}
}
