package com.uninew.mms.traffic;


public class ConvertHexTo {
  public static byte[] convertHexToASCII(String hex){
	   byte[] b = hex.getBytes();
	   byte[] in=new byte[b.length];
	   for (int i = 0; i < b.length; i++) {
	   in[i] = (byte) (b[i]&0xff);
	   }
	  return in;
  }
  public static String convertHexToString(int hx ,int length){
		String hex=Integer.toHexString(hx);
		StringBuffer buffer=new StringBuffer();
		if(hex.length()<length){
			for(int i=0;i<length-hex.length();i++){
				buffer.append("0");
			}
			
		}
		return buffer.append(hex).toString();
	}
  public static int bytesToInt(byte[] src, int offset) {  
	    int value;    
	    value = (int) ((src[offset] & 0xFF)   
	            | ((src[offset+1] & 0xFF)<<8)   
	            | ((src[offset+2] & 0xFF)<<16)   
	            | ((src[offset+3] & 0xFF)<<24));  
	    return value;  
	} 
}
