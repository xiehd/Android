package com.uninew.mms.interfaces;

public interface IRoadSignsDatas {
	
	/** 路牌消息应答 执行成功：0x01 ,执行失败： 0x02 , 命令重发： 0x03 */
	void roadSignsResponse(int result);
}
