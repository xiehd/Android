package com.uninew.mms.traffic;

public interface DefineTraffic {
	/**开始标志*/
	public static final int START_FLAG = 0x02;
	/**结束标志*/
	public static final int END_FLAG=0x03;
	/**清零指令*/
	public static final int CM_CLEAR_REQUEST = 0x12;
	/**清零應答*/
	public static final int CM_CLEAR_RESPONSE = 0x92;
	/**客流量查询*/
	public static final int CM_TRAFFIC_REQUEST = 0x13;
	/**客流量查询应答*/
	public static final int CM_TRAFFIC_RESPONSE =  0x93;
	/**门状态查询*/
	public static final int CM_DOOR_REQUEST = 0x66;
	/**门状态查询应答*/
	public static final int CM_DOOR_RESPONSE = 0xe6;
	
	/**前门设备Id*/
	public static final int FRONT_DOORID=0x0001;
	/**后门设备ID*/
	public static final int BEBIND_DOORID=0x0002;
	
}
