package com.uninew.mms.interfaces;

public interface IPassengerFlowDatas {
	/**
	 * 接收客流量应答数据
	 * 
	 * @param id
	 *            门ID 0001-门 0002-后门
	 * @param upNumber
	 *            上车人数
	 * @param downNumber
	 *            下车人数
	 */
	void receivePass(int id, int upNumber, int downNumber);
	
	
	/**
	 * 接收客流量应答数据
	 * 
	 * @param id
	 *            门ID 0001-门 0002-后门
	 * @param upNumber
	 *            上车人数
	 * @param downNumber
	 *            下车人数
	 * @param downNumber
	 *            车内人数         
	 */
	void receivePass(int id, int upNumber, int downNumber,int totalNumber);
	

	/**
	 * 门状态数据
	 * 
	 * @param id
	 *            门ID 0001-门 0002-后门
	 * @param state
	 *            0-关，1-开
	 */
	void updateDoorState(int id, int state);

	/**
	 * 客流量清除应答
	 * 
	 * @param id
	 *            门ID 0001-门 0002-后门
	 * @param result
	 *            0-失败，1-成功
	 */
	void passClearResponse(int id, int result);
}
