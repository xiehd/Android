package com.uninew.mms.toyou;

import java.util.ArrayList;
import java.util.List;

public class TYManager {
	
	public TYManager() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * 路牌发送（图岳电子）-发送给单个路牌
	 * 
	 * @param roadSignId
	 *            路牌编号（头牌：0x01；腰牌：0x02；尾牌：0x03）
	 * @param isShow
	 *            路牌属性（显示：true-0x80；不显示：false-0x00）
	 * @param roadName
	 *            路号（如704）
	 * @param content
	 *            内容（以'\0'结尾的字符串）
	 * @return
	 */
	public byte[] getSendRoadSignDatasForTuyue(byte roadSignId, boolean isShow,
			String roadName, String content) {
		RoadSign mRoadSign = null;
		List<RoadSign> roadSigns = new ArrayList<RoadSign>();
		mRoadSign = new RoadSign(roadSignId, (byte) (isShow == true ? 0x80
				: 0x00), roadName, DefineTYRoadSigns.DEFAULT_SHOWTYPE,
				DefineTYRoadSigns.DEFAULT_WHATBYTE, content + "\0");
		roadSigns.add(mRoadSign);
		RoadSigns mRoadSigns = new RoadSigns(roadSigns);
		RoadSignsPacket rsp = null;
		byte[] datas = null;
		if (mRoadSigns != null) {
			rsp = new RoadSignsPacket(DefineTYRoadSigns.DEFAULT_ADDRESS,
					DefineTYRoadSigns.DEFAULT_PROTOCOLID, mRoadSigns.getBytes());
			datas = rsp.getBytes();
		}
		return datas;
	}

	/**
	 * 路牌发送（图岳电子）---同时发送给多个路牌内容
	 * 
	 * @param roadSignId
	 *            路牌编号（头牌：0x01；腰牌：0x02；尾牌：0x03）
	 * @param isShow
	 *            路牌属性（显示：true-0x80；不显示：false-0x00）
	 * @param roadName
	 *            路号（如704）
	 * @param content
	 *            内容
	 * @return
	 */
	public byte[] getSendRoadSignDatasForTuyue(byte[] roadSignIds,
			boolean isShow, String roadName, String content) {
		RoadSign mRoadSign = null;
		List<RoadSign> roadSigns = new ArrayList<RoadSign>();
		for (int i = 0; i < roadSignIds.length; i++) {
			mRoadSign = new RoadSign(roadSignIds[i],
					(byte) (isShow == true ? 0x80 : 0x00), roadName,
					DefineTYRoadSigns.DEFAULT_SHOWTYPE,
					DefineTYRoadSigns.DEFAULT_WHATBYTE, content + "\0");
			roadSigns.add(mRoadSign);
		}
		RoadSigns mRoadSigns = new RoadSigns(roadSigns);
		RoadSignsPacket rsp = null;
		byte[] datas = null;
		if (mRoadSigns != null) {
			rsp = new RoadSignsPacket(DefineTYRoadSigns.DEFAULT_ADDRESS,
					DefineTYRoadSigns.DEFAULT_PROTOCOLID, mRoadSigns.getBytes());
			datas = rsp.getBytes();
		}
		return datas;
	}

	/**
	 * 路牌发送（图岳电子）-发送给单个路牌
	 * 
	 * @param roadSignId
	 *            路牌编号（头牌：0x01；腰牌：0x02；尾牌：0x03）
	 * @param isShow
	 *            路牌属性（显示：0x80；不显示：0x00）
	 * @param roadName
	 *            路号（如704）
	 * @param startStation
	 *            起点站名称
	 * @param endStation
	 *            终点站名称
	 * @return
	 */
	public byte[] getSendRoadSignDatasForTuyue(byte roadSignId, boolean isShow,
			String roadName, String startStation, String endStation) {
		// 起点站[线路号]终点站
		StringBuilder sb = new StringBuilder();
		sb.append(startStation);
		sb.append("[" + roadName + "]");
		sb.append(endStation);
		return getSendRoadSignDatasForTuyue(roadSignId, isShow, roadName,
				sb.toString());
	}

	/**
	 * 路牌发送（图岳电子）---同时发送给多个路牌内容
	 * 
	 * @param roadSignId
	 *            路牌编号（头牌：0x01；腰牌：0x02；尾牌：0x03）
	 * @param isShow
	 *            路牌属性（显示：true-0x80；不显示：false-0x00）
	 * @param roadName
	 *            路号（如704）
	 * @param startStation
	 *            起点站名称
	 * @param endStation
	 *            终点站名称
	 * @return
	 */
	public byte[] getSendRoadSignDatasForTuyue(byte[] roadSignIds,
			boolean isShow, String roadName, String startStation,
			String endStation) {
		// 起点站[线路号]终点站
		StringBuilder sb = new StringBuilder();
		sb.append(startStation);
		sb.append("[" + roadName + "]");
		sb.append(endStation);
		return getSendRoadSignDatasForTuyue(roadSignIds, isShow, roadName,
				sb.toString());
	}
}
