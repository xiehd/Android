package com.uninew.mms.interfaces;

public interface IAdDatas {
	
	/** 广告屏消息应答 */
	void adScreenResponse(byte[] datas);
}
