package com.uninew.mms.standard;

import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.IOException;

public class PCommonResponse {

	/**成功*/
	public static int SUCCUSS=0x01;
	/**成功*/
	public static int FAILURE=0x02;
	/**重发*/
	public static int RESEND=0x03;
	
	/** 数据帧标志 */
	private int dataId;
	/** 数据长度 */
	private int length;
	/** 执行结果 */
	private int result;

	public PCommonResponse() {
		super();
	}

	public PCommonResponse getPCommonResponse(byte[] datas) {
		if (datas == null) {
			return null;
		}
		ByteArrayInputStream bis = new ByteArrayInputStream(datas);
		DataInputStream dis = new DataInputStream(bis);
		try {
			dataId = dis.readUnsignedByte();
			length = dis.readUnsignedShort();
			result = dis.readUnsignedByte();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return this;
	}

	public int getDataId() {
		return dataId;
	}

	public void setDataId(int dataId) {
		this.dataId = dataId;
	}

	public int getResult() {
		return result;
	}

	public void setResult(int result) {
		this.result = result;
	}

}
