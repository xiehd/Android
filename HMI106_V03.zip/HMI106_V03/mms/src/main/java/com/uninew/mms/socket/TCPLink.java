package com.uninew.mms.socket;

import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.SocketTimeoutException;
import java.net.UnknownHostException;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.Queue;

import android.content.Context;
import android.net.LocalSocket;
import android.net.LocalSocketAddress;
import android.util.Log;

import com.uninew.mms.util.LogTool;


public class TCPLink{

	@SuppressWarnings("unused")
	private Context mContext;
	private TCPRunStateEnum SocketState = TCPRunStateEnum.OPEN_FAILURE;
	/** 待发送的指令 */
	private Queue<byte[]> msgBeans = new LinkedList<byte[]>();
	/** Socket客户端 */
	private LocalSocket socket = null;
	/** Socket输出流 */
	private OutputStream outputStream = null;
	/** Socket输入流 */
	private InputStream inputStream = null;
	/** Socket写线程 */
	private SocketWriteThread writeThread = null;
	/** Socket读线程 */
	private SocketReadThread readThread = null;
	private TCPCallbackInterface tcpCallback;

	public void setTcpBackInterface(TCPCallbackInterface tcpCallback) {
		this.tcpCallback = tcpCallback;
	}

	/**
	 * 构造方法
	 * 
	 * @param serverIP
	 * @param serverPort
	 */
	public TCPLink(Context mContext) {
		this.mContext = mContext;
		writeThread = new SocketWriteThread();
		writeThread.start();
		readThread = new SocketReadThread();
		readThread.start();
	}

	public void openSocket() {
		try {
			closeSocket();
			socket = new LocalSocket();
			LocalSocketAddress address = new LocalSocketAddress("uninewd", LocalSocketAddress.Namespace.RESERVED);
			socket.connect(address);
//			socket.setSoTimeout(30 * 1000);
			Log.d("yzb", "----------打开链接成功-------");
			
			inputStream = socket.getInputStream();
			outputStream = socket.getOutputStream();
			byte[] mBuffer = new byte[2];
			mBuffer[0] = 2;
			mBuffer[1] = 2;
			outputStream.write(mBuffer, 0, 2); // 开启通讯的初始化
			outputStream.flush();
			// 初始化线程流
			writeThread.createStream();
			readThread.createStream();
			SocketState = TCPRunStateEnum.OPEN_SUCCESS;
			tcpCallback.onTCPRunStateChangeder(TCPRunStateEnum.OPEN_SUCCESS,TCPLinkErrorEnum.NORMAL);
			// sendMsg(new TAuth(NetUtil.DEFAULT_AUTHORIZATION_CODE), null);
		} catch (UnknownHostException e) {
			SocketState = TCPRunStateEnum.OPEN_FAILURE;
			tcpCallback.onTCPRunStateChangeder(TCPRunStateEnum.OPEN_FAILURE,TCPLinkErrorEnum.ERROR_IPORPORT);
			e.printStackTrace();
		} catch (IOException e) {
			SocketState = TCPRunStateEnum.OPEN_FAILURE;
			tcpCallback.onTCPRunStateChangeder(TCPRunStateEnum.OPEN_FAILURE,TCPLinkErrorEnum.ERROR_OTHERS);
			e.printStackTrace();
		}
	}

	/**
	 * 关闭Socket链接
	 */
	public void closeSocket() {
		try {
			if (socket != null && socket.isConnected()) {
				socket.close();
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/**
	 * 发送消息
	 * 
	 * @param bodyParse
	 * @param optionCallBack
	 */
	public void sendMsg(byte[] datas) {
		if (SocketState != TCPRunStateEnum.OPEN_SUCCESS) {
			openSocket();
		}
		try {
			writeThread.addMsgBean(datas);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Socket客户端写线程
	 * 
	 * @author Macro
	 * 
	 */
	public class SocketWriteThread extends Thread {
		private byte[] msgBean = null;
		private DataOutputStream dataOutputStream = null;

		public void createStream() {
			if (outputStream != null) {
				dataOutputStream = new DataOutputStream(outputStream);
			}
		}

		public void addMsgBean(byte[] bean) {
			msgBeans.offer(bean);
			synchronized (this) {
				this.notify();
			}
		}

		@Override
		public void run() {
			while (!isInterrupted()) {
				while (dataOutputStream != null
						&& (msgBean = msgBeans.poll()) != null) {
					try {
						dataOutputStream.write(msgBean);
						dataOutputStream.flush();
						LogTool.logBytes("yzb", "Send msg=", msgBean);
					} catch (Exception e) {
//						try {
//							dataOutputStream.close();
//							dataOutputStream = null;
//							outputStream.close();
//							outputStream = null;
//						} catch (Exception e1) {
//							e1.printStackTrace();
//						}
						SocketState=TCPRunStateEnum.RUN_STOPED;
						e.printStackTrace();
					}
					try {
						Thread.sleep(10);
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
				try {
					synchronized (this) {
						this.wait();
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
	}

	/**
	 * Socket客户端读线程
	 * 
	 * @author Macro
	 * 
	 */
	public class SocketReadThread extends Thread {
		private byte buffer[] = new byte[256];
		private int length = -1;
		private byte[] datas=null;
		
		
		public void createStream() {
			synchronized (this) {
				this.notify();
			}
		}

		@Override
		public void run() {
			while (!isInterrupted()) {
				while (inputStream != null) {
					try {
						length = inputStream.read(buffer);
						LogTool.logD("yzb", "-------Read MSG-----lenght=" + length);
						if (length > 0) {
							datas=Arrays.copyOf(buffer, length);
							if (tcpCallback != null) {
								tcpCallback.onTCPReceiveDataChangeder(datas);
							}
							try {
								Thread.sleep(50);
							} catch (InterruptedException e) {
								e.printStackTrace();
							}
						} else {
//							SocketState = TCPRunStateEnum.RUN_STOPED;
//							tcpCallback
//									.onTCPRunStateChangeder(TCPRunStateEnum.RUN_STOPED,TCPLinkErrorEnum.ERROR_SERVER_CLOSED);
//							try {
//								inputStream.close();
//								inputStream = null;
//							} catch (Exception e1) {
//								e1.printStackTrace();
//							}
							openSocket();
						}
					}catch (SocketTimeoutException e) {
						LogTool.logE("ReadThread", "-----SocketTimeoutException----");
					}catch (Exception e) {
						LogTool.logE("yzb", "-------Read-----Exception");
						e.printStackTrace();
						SocketState = TCPRunStateEnum.RUN_STOPED;
						tcpCallback.onTCPRunStateChangeder(TCPRunStateEnum.RUN_STOPED,TCPLinkErrorEnum.ERROR_OTHERS);
						try {
							inputStream.close();
							inputStream = null;
						} catch (Exception e1) {
							e1.printStackTrace();
						}
					}
				}
				try {
					synchronized (this) {
						this.wait();
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
	}

	public boolean isConnected() {
		if (socket != null && socket.isConnected()) {
			return true;
		} else {
			return false;
		}
	}

	public interface TCPCallbackInterface {

		/**
		 * 状态上报接口
		 * 
		 * @param vValue
		 * @pdOid 5b2906d8-c0a5-437f-a682-ec956c6853dc
		 */
		void onTCPRunStateChangeder(TCPRunStateEnum vValue,TCPLinkErrorEnum error);

		/**
		 * 接收数据上报接口
		 * 
		 * @param vBuffer
		 * @pdOid 067f155d-4b07-43a8-909d-405a0cd5e49d
		 */
		void onTCPReceiveDataChangeder(byte[] vBuffer);

	}

	/** @pdOid 7302a882-d4ca-4c14-809f-d7b2a359c344 */
	public interface SetDataInterface {
		/**
		 * @param vData
		 * @pdOid 7a3ed9ce-55c8-4505-8284-73bec4642311
		 */
		int SetSendData(byte[] vData);

	}
}
