package com.uninew.mms.interactive;


public interface DefineMMSAction {
	/** 向MCU发送数据 */
	String MCULinkSendData = "Com.MCULink.SendData";

	/** 从MCU接受数据 */
	String MCULinkReceiveData = "Com.MCULink.ReceiveData";

	/** MCULink状态 */
	String MCULinkState = "Com.MCULink.ReceiveData";

	/** 请求客流量数据 */
	String MCULinkPassRequest = "Com.MCULink.PassRequest";

	/** 发送客流量数据 */
	String MCULinkPass = "Com.MCULink.Pass";

	/** 发送门状态查询 */
	String MCULinkDoorStateRequest = "Com.MCULink.Doors.Request";

	/** 发送门状态 */
	String MCULinkDoorState = "Com.MCULink.Doors.Response";

	/** 发送门状态变化通知 */
	String MCULinkDoorsChange = "Com.MCULink.Doors.Change";

	/** 发送键盘值 */
	String MCULinkKeys = "uninew.key";

	/** 发送信息 */
	String TCPLinkSendData = "Com.TCPLink.SendData";

	/** 发送路牌信息 */
	String MCULinkRoadSigns = "Com.MCULink.RoadSigns";
	
	/** MCU版本查询 */
	String MCULinkVersionRequest = "Com.MCULink.Version.Request";
	
	/** ACC状态通知 */
	String MCULinkAccState = "Com.MCULink.AccState";
	
	/**  MCU版本查询应答 */
	String MCULinkVersionResponse = "Com.MCULink.Version.Response";
	
	/** MCU升级 */
	String MCULinkUpdateCommand="Com.MCULink.Update.Command";
	
	/** OS升级通知 */
	String MCULinkOSUpdateNotify = "Com.MCULink.OSUpdate.Notify";
	
	/**  OS升级通知应答 */
	String MCULinkOSUpdateResponse = "Com.MCULink.OSUpdate.Response";
	
	/**  设置休眠时间 */
	String MCULinkSleepTimeSet = "Com.MCULink.SleepTime.Set";
	
	/** 定位状态 */
	String LocationState = "Com.LocationService.RespondState";
	/** 通讯状态 */
	String ServerLinkState = "Com.ServerLink.State";
	
	/**
	 * 门状态
	 * 
	 * @author Administrator
	 * 
	 */
	public interface Door {
		/** 门Id ：0-前门，1-后门 */
		String DoorId = "DoorId";
		/** 门状态 ：0-关，1-开 */
		String DoorState = "DoorState";
	}

	/**
	 * 客流量
	 * 
	 * @author Administrator
	 * 
	 */
	public interface pass {
		/** 门Id ：0-前门，1-后门 */
		String DoorId = "DoorId";
		/** 方向：0-上车，1-下车 */
		String UpNumber = "UpNumber";
		/** 人数 */
		String DownNumber = "DownNumber";
	}

	/**
	 * 路牌信息
	 * 
	 * @author Administrator
	 * 
	 */
	public interface RoadSigns {
		/** 文本类型*/
		int TYPE_TXT=0;
		/** 线路类型*/
		int TYPE_ROUTE=1;
		/** 类型：0-文本，1-线路*/
		String Type = "Type";
		/** 路牌编号*/
		String RoadId = "RoadId";
		/** 线路名称*/
		String RoadName = "RoadName";
		/** 起始站名称 */
		String StartStation = "StartStation";
		/** 终点站名称 */
		String EndStation = "EndStation";
		/** 文本内容 */
		String TxtContent = "TxtContent";
	}
	
	/**
	 * MCU版本信息
	 * 
	 * @author Administrator
	 * 
	 */
	public interface MCUVersion {
		/** 线路名称*/
		String KEY_VERSION = "version";
	}
	
	/**
	 * ACC状态信息
	 * 
	 * @author Administrator
	 * 
	 */
	public interface AccState {
		/** 状态*/
		String KEY_STATE = "state";
	}
	
	/**
	 * 设置休眠时间
	 * 
	 * @author Administrator
	 * 
	 */
	public interface SleepTime {
		/** 时间*/
		String KEY_TIME = "Time";
	}
	
}
