package com.uninew.mms.toyou;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.util.Arrays;

import com.uninew.mms.interfaces.IProtocolPacket;
import com.uninew.mms.util.LogTool;
/**
 * 路牌协议框架解析和封装（三级）
 * @author Administrator
 *
 */
public class RoadSignsPacket implements IProtocolPacket {
	private static final String TAG = "RoadSignsPacket";
	/** 帧头 */
	private byte startFlag;
	/** 地址 */
	private byte address;
	/** 协议 ：固定位0x10 */
	private byte protocolId;
	/** 消息体 */
	private byte[] body;
	/** 消息长度 */
	private byte length;
	/** 和校验 */
	private byte check;
	/** 帧尾 */
	private byte endFlag;

	public RoadSignsPacket() {
		super();
	}
	/**
	 * 路牌协议
	 * 
	 * @param address
	 *            地址
	 * @param body
	 *            消息体
	 */
	public RoadSignsPacket(byte address, byte protocolId,  byte[] body) {
		super();
		this.address = address;
		this.protocolId = protocolId;
		this.body = body;
	}

	@Override
	public byte[] getBytes() {
		// TODO Auto-generated method stub
		ByteArrayOutputStream bis = new ByteArrayOutputStream();
		DataOutputStream dos = new DataOutputStream(bis);
		try {
			dos.writeByte(DefineTYRoadSigns.MSG_FLAG);
			dos.writeByte(address);
			dos.writeByte(protocolId);
			dos.write(body);
			dos.flush();
			byte[] msgBytes = bis.toByteArray();
			byte checksum = CheckTools.xor(msgBytes, 1); // 校验码
			LogTool.logV(TAG,
					"CheckNum=" + Integer.toHexString(checksum & 0xff));
			dos.writeByte(checksum);
			dos.writeByte(DefineTYRoadSigns.MSG_FLAG);
			byte[] msg = bis.toByteArray(); 
			msg = EscapeTools.escape(msg, 1, msg.length - 1); // 标识位不参与转义
			return msg;
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public Object getProtocolPacket(byte[] datas) {
		if (datas.length < 5) {
			LogTool.logE(TAG, "datas is Error!!!");
			return null;
		}
		try {
			ByteArrayInputStream bis = new ByteArrayInputStream(datas);
			DataInputStream dis = new DataInputStream(bis);
			startFlag = dis.readByte();
			if (DefineTYRoadSigns.MSG_FLAG==startFlag) {
				address = dis.readByte();
				protocolId = dis.readByte();
				body = new byte[datas.length - 5];
				dis.read(body, 0, length - 5);
				check = dis.readByte();
				byte realCheck=CheckTools.xor(datas, 1, datas.length-3);
				if (check != realCheck) {
					LogTool.logE(TAG, "Datas check Error!! check="+check+" ,realCheck="+realCheck);
					return null;
				}
				endFlag=dis.readByte();
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return this;
	}

	public byte getStartFlag() {
		return startFlag;
	}

	public void setStartFlag(byte startFlag) {
		this.startFlag = startFlag;
	}

	public byte getAddress() {
		return address;
	}

	public void setAddress(byte address) {
		this.address = address;
	}

	public byte getProtocolId() {
		return protocolId;
	}

	public void setProtocolId(byte protocolId) {
		this.protocolId = protocolId;
	}

	public byte[] getBody() {
		return body;
	}

	public void setBody(byte[] body) {
		this.body = body;
	}

	public byte getLength() {
		return length;
	}

	public void setLength(byte length) {
		this.length = length;
	}

	public byte getCheck() {
		return check;
	}

	public void setCheck(byte check) {
		this.check = check;
	}

	public byte getEndFlag() {
		return endFlag;
	}

	public void setEndFlag(byte endFlag) {
		this.endFlag = endFlag;
	}

	@Override
	public String toString() {
		return "RoadSignsPacket [startFlag=" + startFlag + ", address="
				+ address + ", protocolId=" + protocolId + ", body="
				+ Arrays.toString(body) + ", length=" + length + ", check="
				+ check + ", endFlag=" + endFlag + "]";
	}

}
