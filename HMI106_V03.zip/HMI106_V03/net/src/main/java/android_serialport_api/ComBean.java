package android_serialport_api;

import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;

public class ComBean
{
  public byte[] bRec = null;
  public String sComPort = "";
  public String sRecTime = "";

  public ComBean(String paramString, byte[] paramArrayOfByte, int paramInt)
  {
    this.sComPort = paramString;
    this.bRec = new byte[paramInt];
    for (int i = 0; ; i++)
    {
      if (i >= paramInt)
      {
        this.sRecTime = new SimpleDateFormat("hh:mm:ss").format(new Date());
        return;
      }
      this.bRec[i] = paramArrayOfByte[i];
    }
  }

@Override
public String toString() {
	return "ComBean [bRec=" + Arrays.toString(bRec) + ", sComPort=" + sComPort
			+ ", sRecTime=" + sRecTime + "]";
}
  
}
