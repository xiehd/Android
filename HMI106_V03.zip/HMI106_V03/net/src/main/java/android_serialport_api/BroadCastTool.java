package android_serialport_api;

import android.content.Context;
import android.content.Intent;

import com.uninew.net.common.ActionDefine;

public class BroadCastTool {

	private static final String TAG = "BroadCastTool";
	private Context mContext;

	public BroadCastTool(Context mContext) {
		super();
		this.mContext = mContext;
	}

	/**
	 * dvr状态通知
	 * @param dvr dvr为null表示与dvr连接断开
	 */
	public void sendDVRType(DVRStateNotice dvr){
		Intent intent = new Intent(ActionDefine.DvrState);
		intent.putExtra(ActionDefine.DvrState_Key, dvr);
		mContext.sendBroadcast(intent);
	}
	
}
