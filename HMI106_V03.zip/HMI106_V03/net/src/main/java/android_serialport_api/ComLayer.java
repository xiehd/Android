package android_serialport_api;

import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.security.InvalidParameterException;

import android.content.Context;
import android.util.Log;

import com.uninew.JT808.util.ByteTools;

/**
 * COM层状态管理
 * 
 * @author Administrator
 * 
 */
public class ComLayer {
	
	private static boolean D=true;
	private static final String TAG = "ComLayer";
	private Context mContext;
	private SerialHelper sh;
	private IReceiveData iReceiveData;
	private ControlThread pControlThread;
	private CurrentState mCurrentState = CurrentState.DISCONNECTED;
	private DVRStateNotice dvr;
	public ComLayer(Context mContext,IReceiveData iReceiveData) {
		super();
		this.mContext=mContext;
		this.iReceiveData = iReceiveData;
		init();
	}

	private void init() {
		pControlThread = new ControlThread();
		pControlThread.start();
		if (sh == null) {
			sh = new ComHelper();
		}

	}

	class ComHelper extends SerialHelper {
		@Override
		protected void onPassThroughDown(byte[] receiveDatas) {
//			LogTool.logBytes("onPassThroughDown,datas=", receiveDatas);
			iReceiveData.onPassThroughDown(receiveDatas);
			onPassThroughDownResponse();
		}

		@Override
		protected void onConnectPlatResponse(byte result) {
//			LogTool.logD(TAG, "onConnectPlatResponse,result=" + result);
			iReceiveData.onConnectPlatResponse(result);
		}

		@Override
		protected void onDisConnectPlatResponse(byte result) {
//			LogTool.logD(TAG, "onDisConnectPlatResponse,result=" + result);
			iReceiveData.onDisConnectPlatResponse(result);
		}

		@Override
		protected void onPassThroughUpResponse(byte result) {
//			LogTool.logD(TAG, "onPassThroughUpResponse,result=" + result);
			setState(ComState.COMM_NORMAL);
			mConnectNumber = 0;
		}

		@Override
		protected void onComTestResponse() {
//			LogTool.logD(TAG, "onComTestResponse");
			setState(ComState.COMM_NORMAL);
			mConnectNumber = 0;
		}

		@Override
		protected void onDvrState(byte[] dvrStates) {
			// TODO Auto-generated method stub
			dvr = new DVRStateNotice(dvrStates);
			new BroadCastTool(mContext).sendDVRType(dvr);
			if(D)Log.d(TAG, dvr.toString());
			setState(ComState.COMM_NORMAL);
			mConnectNumber = 0;
		}

		@Override
		protected void onDownLoadFileResponse(byte response) {
			iReceiveData.onFileDownResponse(response);
		}

		@Override
		protected void onDownLoadFinishedNotify(byte result) {
			// TODO Auto-generated method stub
			iReceiveData.onFileDownFinish(result);
		}

		@Override
		protected void onTransFile(byte[] datas) {
			// TODO Auto-generated method stub
			iReceiveData.onFileDown(datas);
		}

		@Override
		protected void onGpsResponse(byte result) {
			// TODO Auto-generated method stub
			setState(ComState.COMM_NORMAL);
			mConnectNumber = 0;
		}
	}

	/**
	 * 打开串口
	 * 
	 * @return
	 */
	public int openPort() {
		int r = 0;
		try {
			r = sh.open();
		} catch (InvalidParameterException e) {
			e.printStackTrace();
		} catch (SecurityException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return r;
	}

	/**
	 * 关闭串口
	 */
	public void closePort() {
		sh.close();
	}

	/**
	 * 连接公交平台
	 * 
	 * @param ip
	 * @param port
	 * @param type
	 *            0x00:TCP 0x02:UDP 默认0x01
	 */
	public void connectPlat(String ip, short port, byte type) {
		if(D)Log.d(TAG, "ip=" + ip + " ,port=" + port + " ,type="
				+ type);
		byte[] send = null;
		try {
			byte[] ips = ip.getBytes("ASCII");
			
//-----------------福泽儿DVR，ip固定十五位，不足的补0.--------------------------
//			byte[] ips2 = new byte[15];
//			if (ips.length < 15) {
//				for (int i = 0; i < ips2.length; i++) {
//					ips2[i] = 0x30;
//				}
//			}
//			System.arraycopy(ips, 0, ips2, 15 - ips.length, ips.length);
//			ByteArrayOutputStream bos = new ByteArrayOutputStream();
//			DataOutputStream os = new DataOutputStream(bos);
//			os.write(ips2);
//------------------------over------------------------------------------------			

//--------------大华DVR部分，直接发送默认ip-------------------------------------
			ByteArrayOutputStream bos = new ByteArrayOutputStream();
			DataOutputStream os = new DataOutputStream(bos);
			os.write(ips);
//-----------------------over---------------------------		
			os.writeShort(port);
			os.writeByte(type);
			os.writeByte(0x01);// 默认长连接
			send = bos.toByteArray();
			if(D)Log.d(TAG, "connectPlat,datas="+ByteTools.logBytes(send));
			os.flush();
			os.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		if (send != null) {
			sh.sendMsg(MsgId.CONNECT_PLATFORM_ID, send);
		}

	}

	/**
	 * 断开公交平台
	 */
	public void disConnectPlat() {
		sh.sendMsg(MsgId.DISCONNECT_PLATFORM_ID, null);
	}

	byte[] datas = null;

	/**
	 * 上行透传数据
	 */
	public void passThroughUp(byte[] datas) {
		if(D)Log.d(TAG, "上行透传数据------------");
		// this.datas = datas;
		// setState(ComState.SEND_PASS_DATAS);
		if (datas != null) {
			sh.sendMsg(MsgId.PASSTHROUGH_UP_ID, datas);
		}
	}

	/**
	 * 下行透传应答
	 */
	private void onPassThroughDownResponse() {
		sh.sendMsg(MsgId.PASSTHROUGH_DOWN_RESPONSE_ID, null);
	}

	private void sendTest() {
		sh.sendMsg(MsgId.COM_TEST_ID, null);
	}
	
	
	/**
	 * 发送原始gps数据给DVR
	 * @param rmc
	 * @param gga
	 */
	public void sendGpsToDVR(String rmc,String gga){
		byte[] send = null;
		try {
			byte[] rmcs = rmc.getBytes("GBK");
			byte[] ggas = gga.getBytes("GBK");
			ByteArrayOutputStream bos = new ByteArrayOutputStream();
			DataOutputStream os = new DataOutputStream(bos);
			os.writeByte(rmcs.length);
			os.write(rmcs);
			os.writeByte(ggas.length);
			os.write(ggas);
			send = bos.toByteArray();
			os.flush();
			os.close();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if (send != null) {
			sh.sendMsg(MsgId.GPS_ID, send);
		}
	}
	
	/**
	 * DVR模式設置
	 * @param split 1-单画面 ，2-双画面，4-四画面，8-八画面，以此类推
	 * @param pass 
	 */
	public void setDvrMode(int split,int pass){
		if(D)Log.d(TAG, "-----------DVR模式設置---------split="+split+",pass="+pass);
		byte[] send=null;
		try {
			ByteArrayOutputStream bos = new ByteArrayOutputStream();
			DataOutputStream os = new DataOutputStream(bos);
			os.writeShort(split);
			os.writeShort(pass);
			send = bos.toByteArray();
			os.flush();
			os.close();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if (send != null) {
			sh.sendMsg(MsgId.DVR_TYPE_ID, send);
		}
	}
	
	/**
	 * 发送升级请求给DVR
	 * @param downRequest
	 */
//	public void sendFileUpdate(FileDownRequest downRequest){
//		if((downRequest != null) && ((downRequest.getData()) != null) &&( (downRequest.getData()).length > 0)){
//			sh.sendMsg(MsgId.FILE_DOWNLOAD_REQUEST_ID, downRequest.getData());
//		}
//	}
	
	/**
	 * 发送文件下发应答给DVR
	 * @param downResponse
	 */
//	public void sendFileDownResponse(FileDownResponse downResponse){
//		if((downResponse != null) && ((downResponse.getData()) != null) &&( (downResponse.getData()).length > 0)){
//			sh.sendMsg(MsgId.TRANSFER_FILE_RESPONSE_ID, downResponse.getData());
//		}
//	}
	
	/**
	 * 文件下载请求
	 * @param filePath 文件路径（文件下载路径+文件名称）
	 * @param fileName 文件名称
	 */
	public void sendDownLoadFileRequest(String filePath,String fileName){
		byte[] send=null;
		byte[] filepath=new byte[224];
		byte[] filename=new byte[32];
		byte[] path=null;
		byte[] name=null;
		try {
			path=filePath.getBytes("GBK");
			name=fileName.getBytes("GBK");
			if (path.length > 224) {
				System.arraycopy(path, 0, filepath, 0, 224);
			}else{
				System.arraycopy(path, 0, filepath, 0, path.length);
			}
			if (name.length > 32) {
				System.arraycopy(name, 0, filename, 0, 32);
			}else{
				System.arraycopy(name, 0, filename, 0, name.length);
			}
			ByteArrayOutputStream bos = new ByteArrayOutputStream();
			DataOutputStream os = new DataOutputStream(bos);
			os.write(filepath);
			os.write(filename);
			send = bos.toByteArray();
			os.flush();
			os.close();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if (send != null) {
			sh.sendMsg(MsgId.FILE_DOWNLOAD_REQUEST_ID, send);
		}
	}
	
	/**
	 * 文件下发应答
	 * @param result
	 */
	public void sendTransferFileResponse(byte result){
		sh.sendMsg(MsgId.TRANSFER_FILE_RESPONSE_ID, new byte[]{result});
	}
	
	
	public enum CurrentState {
		/** 通讯正常 */
		CONNECTED,
		/** 通讯异常 */
		DISCONNECTED;
	}

	public enum ComState {

		/** 初始化 */
		INIT,
		/** 打开串口 */
		START_COM,
		/** 打开串口成功 */
		START_COM_SUCCESS,
		/** 打开串口失败 */
		START_COM_FAILURE,
		/** 发送透传测试指令 */
		SEND_TEST_CMD,
		/** 等待透传应答 */
		WAITE_PASS_RESPONSE,
		/** 等待接收指令 */
		WAITE_COMMAND,
		/** 透传上发 */
		SEND_PASS_DATAS,
		/** 通讯正常 */
		COMM_NORMAL,
		/** 通讯异常 */
		COMM_DISCONECTED,
		/** 结束 */
		OVER

	}

	ComState pState = ComState.INIT;

	public ComState getState() {
		return pState;
	}

	public void setState(ComState state) {
		pState = state;
//		LogTool.logV(TAG, "运行状态:" + pState);
	}

	boolean pIsRun = true;

	private class ControlThread extends Thread {

		@Override
		public void run() {
			super.run();

			while (pIsRun) {
				HandleState();
				try {
					Thread.sleep(50);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
	}

	int mOpenNumber = 0;
	int mConnectNumber = 0;
	long pTime1, pTime2;
	boolean isTest = false;

	private void HandleState() {
		switch (pState) {
		case INIT:
			setState(ComState.START_COM);
			mOpenNumber = 0;
			mConnectNumber = 0;
			break;
		case START_COM:
			if(D)Log.d(TAG, "START_COM");
			int x = 0;
			try {
				x = openPort();
			} catch (InvalidParameterException e) {
				e.printStackTrace();
			} catch (SecurityException e) {
				e.printStackTrace();
			}
			if(D)Log.d(TAG, "开启COM  result=" + x);
			switch (1) {
			case 1:
				setState(ComState.START_COM_SUCCESS);
				mOpenNumber = 0;
				break;
			case 0:
				setState(ComState.START_COM_FAILURE);
				mOpenNumber++;
				pTime1 = System.currentTimeMillis();
				break;
			default:
				break;
			}
			break;
		case START_COM_SUCCESS:
			iReceiveData.onComState(DefineState.COM_OPEN_SUCCESS);
			setState(ComState.SEND_TEST_CMD);
			break;
		case START_COM_FAILURE:
			if (mOpenNumber > 3) {
				// 连续三次打开失败，停止打开
				iReceiveData.onComState(DefineState.COM_OPEN_FAILURE);
				setState(ComState.OVER);
			} else if (System.currentTimeMillis() - pTime1 > 5000) {
				// 等待三秒后再次开启COM
				setState(ComState.START_COM);
			}
			break;
		case SEND_TEST_CMD:
			isTest = true;
			sendTest();
			setState(ComState.WAITE_PASS_RESPONSE);
			pTime2 = System.currentTimeMillis();
			break;
		case WAITE_PASS_RESPONSE:
			// //////////test/////////////
			// setState(ComState.COMM_NORMAL);
			// //////////////////////
			if (mConnectNumber > 2) {
				// 连续三次接收失败，结束
				mConnectNumber = 0;
				setState(ComState.COMM_DISCONECTED);
			} else if (System.currentTimeMillis() - pTime2 > 15000) {
				if (isTest) {
					isTest = false;
					setState(ComState.SEND_TEST_CMD);
				} else {
					mConnectNumber++;
					if(D)Log.d(TAG, "mConnectNumber=" + mConnectNumber);
				}
			}
			break;
		case WAITE_COMMAND:
			if (System.currentTimeMillis()-pTime1 > 30000) {
				setState(ComState.COMM_DISCONECTED);
			}
			break;
		case SEND_PASS_DATAS:
			if (datas != null) {
				sh.sendMsg(MsgId.PASSTHROUGH_UP_ID, datas);
			}
			setState(ComState.WAITE_PASS_RESPONSE);
			break;
		case COMM_NORMAL:// 通讯正常
			if (mCurrentState == CurrentState.DISCONNECTED) {
				iReceiveData.onComState(DefineState.COM_CONN_SUCCESS);
				new BroadCastTool(mContext).sendDVRType(dvr);
			}
			mCurrentState = CurrentState.CONNECTED;
			setState(ComState.WAITE_COMMAND);
			pTime1=System.currentTimeMillis();
			break;
		case COMM_DISCONECTED:
//			if (mCurrentState == CurrentState.CONNECTED) {
				 iReceiveData.onComState(DefineState.COM_CONN_FAILURE);
				 new BroadCastTool(mContext).sendDVRType(null);
//			}
			mCurrentState = CurrentState.DISCONNECTED;
			setState(ComState.SEND_TEST_CMD);
			break;
		case OVER:

			break;
		default:
			setState(ComState.INIT);
			break;
		}
	}
}
