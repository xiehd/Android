package android_serialport_api;


public interface IReceiveData {
	/**
	 * 下行透传数据
	 */
	public void onPassThroughDown(byte[] receiveDatas);

	/**
	 * 连接公交平台应答
	 * 0x00 false , 0x01 true
	 */
	public void onConnectPlatResponse(int result);

	/**
	 * 断开公交平台应答
	 * 0x00 false , 0x01 true
	 */
	public void onDisConnectPlatResponse(int result);

	/**
	 * COM通讯状态
	 * 0x00  串口打开失败, 0x01串口打开成功 ,0x02串口通讯异常 ,0x03串口通讯正常,0x04 平台连接异常,0x05 平台连接正常
	 */
	public void onComState(int state);
	
	/**
	 * 连接公交平台应答
	 * 0x00 失败 , 0x01 成功 ,0x02 已有文件在更新
	 */
	public void onFileDownResponse(int response);
	
	/**
	 * 文件下发
	 * @param file
	 */
	public void onFileDown(byte[] file);
	
	/**
	 * 文件下载完成通知
	 * @param result
	 */
	public void onFileDownFinish(int result);
	
}
