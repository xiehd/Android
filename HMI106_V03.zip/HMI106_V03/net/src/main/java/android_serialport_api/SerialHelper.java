package android_serialport_api;


import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.security.InvalidParameterException;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.Queue;

import android.util.Log;

import com.uninew.JT808.util.ByteTools;


public abstract class SerialHelper {
	
	private static boolean D=true;
	private static final String TAG="SerialHelper";
	
	private byte[] _bLoopData = { 48 };
	private boolean _isOpen = false;
	private InputStream mInputStream;
	private OutputStream mOutputStream;
	private ReadThread mReadThread;
	private JniWriteThread writeThread ;
	private SerialPort mSerialPort;
	private ComDataHandle comDataHandle;
	private static int iBaudRate = 9600;
	private static String sPort = "/dev/ttymxc2";

	public SerialHelper() {
		this(sPort, iBaudRate);
	}

	public SerialHelper(String paramString) {
		this(paramString, iBaudRate);
	}

	public SerialHelper(String paramString, int paramInt) {
		this.sPort = paramString;
		this.iBaudRate = paramInt;
	}

	public SerialHelper(String paramString1, String paramString2) {
		this(paramString1, Integer.parseInt(paramString2));
	}

	public void close() {
		if (this.mReadThread != null)
			this.mReadThread.interrupt();
		if (this.mSerialPort != null) {
			this.mSerialPort.close();
			this.mSerialPort = null;
		}
		stopWrite();
		this._isOpen = false;
	}

	public int getBaudRate() {
		return this.iBaudRate;
	}

	public String getPort() {
		return this.sPort;
	}

	public byte[] getbLoopData() {
		return this._bLoopData;
	}

	public boolean isOpen() {
		return this._isOpen;
	}
	
	/**
	 * 串口测试应答
	 */
	protected abstract void onComTestResponse();
	
	/**
	 * 下行透传数据
	 */
	protected abstract void onPassThroughDown(byte[] receiveDatas);

	/**
	 * 连接公交平台应答
	 */
	protected abstract void onConnectPlatResponse(byte result);

	/**
	 * 断开公交平台应答
	 */
	protected abstract void onDisConnectPlatResponse(byte result);

	/**
	 * 上行透传数据应答
	 */
	protected abstract void onPassThroughUpResponse(byte result);
	
	/**
	 * DVR状态通知
	 */
	protected abstract void onDvrState(byte[] dvrStates);
	
	/**
	 * GPS消息应答
	 */
	protected abstract void onGpsResponse(byte result);
	
	
	/**
	 * 文件下载请求应答
	 */
	protected abstract void onDownLoadFileResponse(byte result);
	
	/**
	 * 文件下载完成通知
	 */
	protected abstract void onDownLoadFinishedNotify(byte result);
	
	/**
	 * 文件下发
	 */
	protected abstract void onTransFile(byte[] datas);
	

	/**
	 * 打开串口
	 * 
	 * @return 1-成功 0-失败
	 * @throws SecurityException
	 * @throws IOException
	 * @throws InvalidParameterException
	 */
	public int open() throws SecurityException, IOException,
			InvalidParameterException {
		this.mSerialPort = new SerialPort();
		comDataHandle = new ComDataHandle(SerialHelper.this);
		int result = mSerialPort.openPort(new File(this.sPort), this.iBaudRate,
				0);
		if (result == 0) {
			return 0;
		}
		this.mOutputStream = this.mSerialPort.getOutputStream();
		this.mInputStream = this.mSerialPort.getInputStream();
		this.mReadThread = new ReadThread();
		mReadThread.setName("ComReadThread");
		this.mReadThread.start();
//		startWrite();
		mDataThread = new Thread(dataRunnable);
		mDataThread.setName("ComDataThread");
		mDataThread.setPriority(Thread.MAX_PRIORITY);
		if (mDataThread != null) {
			mDataThread.start();
		}
		this._isOpen = true;
		return 1;
	}

	private void send(byte[] paramArrayOfByte) {
		try {
			this.mOutputStream.write(paramArrayOfByte);
		} catch (IOException localIOException) {
			localIOException.printStackTrace();
		}
	}

	public void sendHex(String paramString) {
		// send(MyFunc.HexToByteArr(paramString));
	}

	public void sendTxt(String paramString) {
		send(paramString.getBytes());
	}

	public boolean setBaudRate(int paramInt) {
		if (this._isOpen)
			return false;
		this.iBaudRate = paramInt;
		return true;
	}

	public boolean setBaudRate(String baudRate) {
		return setBaudRate(Integer.parseInt(baudRate));
	}

	public boolean setPort(String com) {
		if (this._isOpen)
			return false;
		this.sPort = com;
		return true;
	}

	private void startWrite() {
		stopWrite();
		writeThread = new JniWriteThread();
		writeThread.setName("ComWriteThread");
		writeThread.start();
	}

	private void stopWrite() {
		if (writeThread != null) {
			writeThread.interrupt();
		}
		writeThread = null;
	}

	private class ReadThread extends Thread {
		private ReadThread() {
		}
    
		public void run()  {
			super.run();
			while (true) {
				 
				if (isInterrupted())
					return;
				try {
					Thread.sleep(200L);
				 try {
					if (SerialHelper.this.mInputStream == null)
						break;
					byte[] arrayOfByte = new byte[3072];
					int i = SerialHelper.this.mInputStream.read(arrayOfByte);
				
		            if (i > 0)
		            {   
						ComBean localComBean = new ComBean(
								SerialHelper.this.sPort, arrayOfByte, i);
					    if(D)Log.d(TAG, "datas="+ByteTools.logBytes(localComBean.bRec));
						dataRunnable.dataput(localComBean.bRec,
								localComBean.bRec.length);}else{
									continue;
								}
		           
				} catch (Throwable e) {
					
					e.printStackTrace();
				}
				} catch (InterruptedException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		}
	}

	private Thread mDataThread;
	private DataHandleRunnable dataRunnable = new DataHandleRunnable();

	private class DataHandleRunnable implements Runnable {
		private Queue<Byte> queue = new LinkedList<Byte>();
        private Object queueLock=new Object();
		public void run() {
			if(D)Log.v("SerialPort",
					"DataHandleRunnable......run.......xxxxxxxxxxxxxx");
			while (true) {
				if (!queue.isEmpty() && isFinish) {
					handle();
				} else {
					synchronized (this) {
						try {
							wait();
						} catch (InterruptedException e) {
							//
						}
					}
				}
			}
		}

		public synchronized void dataput(byte[] buffer, int length) {
		
			for (int i = 0; i < length; i++) {
			
			
				synchronized (queueLock) {
					queue.add(buffer[i]);
					this.notify();
				}
				
			
			}

				
		
			
		}

		synchronized void handle() {
			// 合并并上报数据
			long startTime=System.currentTimeMillis();
			handleDatas();
		}

		private boolean isFinish = true;
	    Queue<Byte> remains=new LinkedList<Byte>();
		private void handleDatas() {
			isFinish = false;
			if (queue.size() > 0) {
				resolveQueue(queue);
			}
     
			// LogTool.logE("com", "-------------over");
			isFinish = true;
		}
       
         
		private  void resolveQueue(Queue<Byte> queue) {
			byte x;
			for (int i = 0; i < queue.size(); i++) {
				synchronized (queueLock){
				x = queue.peek();
				switch (pReceiveHandleState) {
				case 开始:
					if (x == FLAG) {
					
						pReceiveHandleBufferOffset = 0;
						pReceiveHandleBuffer[pReceiveHandleBufferOffset++] = x;
						pReceiveHandleState = ReceiveHandleState.接收命令;
				         queue.remove();

					}else{
						if(x!=FLAG){
							queue.remove();
						}
					}
					break;
				case 接收命令:
					if (x != FLAG) {
						if (pReceiveHandleBufferOffset >= pReceiveHandleBufferSize ) {
							pReceiveHandleState = ReceiveHandleState.开始;
						}else{
							pReceiveHandleBuffer[pReceiveHandleBufferOffset++] = x;
							queue.remove();
						}
					} else {
					
						if (pReceiveHandleBufferOffset > 5) {
							// 结束了
							pReceiveHandleBuffer[pReceiveHandleBufferOffset++] = x;
							if (endReceive()) {
								queue.remove();
							}
							pReceiveHandleBufferOffset=0;
							pReceiveHandleState = ReceiveHandleState.开始;
						} else {
							// 重新开始
								pReceiveHandleState = ReceiveHandleState.开始;//修改前	

						}

					}
					break;
				case 接收结束:
					pReceiveHandleBufferOffset = 0;

					pReceiveHandleState = ReceiveHandleState.开始;
					break;
				default:
					break;
				}
				}
			}
		}

		private boolean endReceive() {
			return comDataHandle.dataHandle(Arrays.copyOfRange(pReceiveHandleBuffer,
					0, pReceiveHandleBufferOffset));
		}
	}

	private static final byte FLAG = 0x7e;
	static final int pReceiveHandleBufferSize = 4096;
	static byte[] pReceiveHandleBuffer = new byte[pReceiveHandleBufferSize];
	private static int pReceiveHandleBufferOffset = 0;

	private enum ReceiveHandleState {
		开始, 接收命令, 接收结束
	}

static	ReceiveHandleState pReceiveHandleState = ReceiveHandleState.开始;

	/**
	 * 消息发送接口
	 * 
	 * @param datas
	 */
	public void sendMsg2(byte type, byte[] datas) {
		if (writeThread != null) {
			byte[] dd = SendDataPacket.toBytes(type, datas);
			byte[] dt = null;
			// 转义
			try {
				dt = ByteTools.escape(dd, 1, dd.length - 1);
			} catch (IOException e) {
				e.printStackTrace();
			}
//			LogTool.logBytes("sendMsg=", dt);
			writeThread.addMsgBean(dt);
		}
	}
	/**
	 * 消息发送接口
	 * 
	 * @param datas
	 */
	public void sendMsg(byte type, byte[] datas) {
		if (this.mOutputStream != null) {
			byte[] dd = SendDataPacket.toBytes(type, datas);
			byte[] dt = null;
			// 转义
			try {
				dt = ByteTools.escape(dd, 1, dd.length - 1);
			} catch (IOException e) {
				e.printStackTrace();
			}
			if(D)Log.d(TAG, "sendMsg="+ByteTools.logBytes(dt));
			SerialHelper.this.send(dt);
		}
	}
	/** 待发送的指令 */
	private Queue<byte[]> msgBeans = new LinkedList<byte[]>();

	public class JniWriteThread extends Thread {
		private byte[] msgBean = null;

		public void addMsgBean(byte[] bean) {
			msgBeans.offer(bean);
			synchronized (this) {
				this.notify();
			}
		}

		@Override
		public void run() {
			while (!isInterrupted()) {
				while (!msgBeans.isEmpty() && (msgBean = msgBeans.poll()) != null) {
					SerialHelper.this.send(msgBean);
					try {
						Thread.sleep(10);
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
				try {
					synchronized (this) {
						this.wait();
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
	}

}
