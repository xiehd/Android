package android_serialport_api;

public class MsgId {
	/**
	 * 转义
	 */
	public static final byte ESCAPE = 0x7d;

	/**
	 * 转义 0X7E->0X7D 0X02
	 */
	public static final byte ESCAPE_E = 0x02;

	/**
	 * 转义 0X7D->0X7D 0X01
	 */
	public static final byte ESCAPE_D = 0x01;

	/**
	 * 标识位
	 */
	public static final byte MSG_FLAG = 0x7e;

	/**
	 * 连接公交平台
	 */
	public static final byte CONNECT_PLATFORM_ID = 0x01;
	
	/**
	 * 连接公交平台应答
	 */
	public static final byte CONNECT_PLATFORM_RESPONSE_ID = 0x11;

	/**
	 * 断开公交平台
	 */
	public static final byte DISCONNECT_PLATFORM_ID = 0x02;
	
	/**
	 * 断开公交平台应答
	 */
	public static final byte DISCONNECT_PLATFORM_RESPONSE_ID = 0x12;

	/**
	 * 透传数据（上行）
	 */
	public static final byte  PASSTHROUGH_UP_ID = 0x03;
	/**
	 * 透传数据应答（上行）
	 */
	public static final byte PASSTHROUGH_UP_RESPONSE_ID = 0x13;
	/**
	 * 透传数据（下行）
	 */
	public static final byte  PASSTHROUGH_DOWN_ID = 0x19;
	/**
	 * 透传数据应答（下行）
	 */
	public static final byte PASSTHROUGH_DOWN_RESPONSE_ID = 0x09;
	/**
	 *  串口测试指令（上行）
	 */
	public static final byte  COM_TEST_ID = 0x04;
	/**
	 *  串口测试指令应答
	 */
	public static final byte  COM_TEST_RESPONSE_ID = 0x14;
	/**
	 * 设置dvr显示模式
	 */
	public static final byte DVR_TYPE_ID = 0x05;
	/**
	 * 设置显示模式应答
	 */
	public static final byte DVR_TYPE_RESPONSE_ID = 0x15;
	/**
	 * DVR状态通知应答	
	 */
	public static final byte DVR_STATE_RESPONSE_ID = 0x06;
	/**
	 * DVR状态通知
	 */
	public static final byte DVR_STATE_ID = 0x16;
	/**
	 * GPS信息
	 */
	public static final byte GPS_ID = 0x07;
	/**
	 * GPS应答
	 */
	public static final byte GPS_RESPONSE_ID = 0x17;
	
	/**
	 * 文件下载请求
	 */
	public static final byte FILE_DOWNLOAD_REQUEST_ID = 0x08;
	/**
	 * 文件下载请求应答
	 */
	public static final byte FILE_DOWNLOAD_RESPONSE_ID = 0x18;
	
	/**
	 * 文件下发
	 */
	public static final byte TRANSFER_FILE_ID = 0x1A;
	/**
	 * 文件下发应答
	 */
	public static final byte TRANSFER_FILE_RESPONSE_ID = 0x0A;
	
	/**
	 * 文件下载完成通知
	 */
	public static final byte FILE_DOWNLOAD_FINISH_NOTIFY_ID = 0x1B;
}
