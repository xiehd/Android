package android_serialport_api;

public class DefineState {
	/** 串口打开失败 */
	public static final int COM_OPEN_FAILURE = 0x00;
	/** 串口打开成功 */
	public static final int COM_OPEN_SUCCESS = 0x01;
	/** 串口通讯异常 */
	public static final int COM_CONN_FAILURE = 0x02;
	/** 串口通讯正常 */
	public static final int COM_CONN_SUCCESS = 0x03;
	/** 平台连接异常 */
	public static final int PLATFORM_CONN_FAILURE = 0x04;
	/** 平台连接正常 */
	public static final int PLATFORM_CONN_SUCCESS = 0x05;
}
