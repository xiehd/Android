package android_serialport_api;

import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;


/**
 * 对发送的消息体进行包装
 * 
 * @author Administrator
 * 
 */
public class SendDataPacket {

	/**
	 * 数据封装
	 * 
	 * @param type
	 * @param srcDatas 如果数据为null 填写null
	 * @return
	 */
	public static byte[] toBytes(byte type, byte[] srcDatas) {
		byte[] dstDatas = null;
		ByteArrayOutputStream bos = new ByteArrayOutputStream();
		DataOutputStream os = new DataOutputStream(bos);

		try {
			os.writeByte(MsgId.MSG_FLAG);
			os.writeByte(type);
			if (srcDatas == null) {
				os.writeShort(0x00);	
				byte[] temp = new byte[3];
				temp[0] = type;
				temp[1] = 0x00;
				temp[2] = 0x00;
				short crs = CrcCheckSum.check(temp, 0);
				os.writeShort(crs);
			} else {
				os.writeShort(srcDatas.length);
				os.write(srcDatas);
				byte[] temp = new byte[srcDatas.length + 3];
				temp[0] = type;
				temp[1] = (byte) ((srcDatas.length >> 8) & 0xff);
				temp[2] = (byte) ((srcDatas.length) & 0xff);
				System.arraycopy(srcDatas, 0, temp, 3, srcDatas.length);
				short crs = CrcCheckSum.check(temp, 0);
				os.writeShort(crs);
			}
			os.writeByte(MsgId.MSG_FLAG);
			dstDatas = bos.toByteArray();
//			LogTool.logBytes("test,datas=", dstDatas);
			os.flush();
			os.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return dstDatas;

	}

}
