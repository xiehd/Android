package android_serialport_api;

import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.IOException;
import java.util.Arrays;

import android.util.Log;

import com.uninew.JT808.util.ByteTools;


/**
 * 主要处理数据
 * 
 * @author Administrator
 * 
 */
public class ComDataHandle {
	
	private static final String TAG="ComDataHandle";
	private static boolean D=true;
	private SerialHelper sp;
	
	public ComDataHandle(SerialHelper sp) {
		super();
		this.sp = sp;
	}

	public boolean dataHandle(byte[] datas) {
		byte[] dealDatas = null;
		try {
			// 数据反转义
			dealDatas = ByteTools.escapeReduction(datas, 0, datas.length);
			short rchk=CrcCheckSum.check(Arrays.copyOfRange(dealDatas, 1, dealDatas.length-3), 0);
			short chk= byteToShort(dealDatas[dealDatas.length-2], dealDatas[dealDatas.length-3]);
			if (chk==rchk) {
//				LogTool.logV(TAG, "校验通过！！！");
				dataParse(dealDatas);
				return true;
			}else{
				Log.e(TAG, "校验失败！！！");
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		return false;
	}
	/**
	 * byte数组转short  低位
	 * @param high
	 * @param low
	 * @return
	 */
	public static short byteToShort(byte low,byte high){
//		LogTool.logE("yzb", "low=0x"+Integer.toHexString(low)+",high=0x"+Integer.toHexString(high));
		return (short) (low & 0xff | (high<<8));
	}
	
	private void dataParse(byte[] datas) throws IOException {
		// 0x7e+类型（byte）+数据长度（word）+应答字（byte）+数据+chk（word）+7e
//		LogTool.logBytes("receivemsg=", datas);
		ByteArrayInputStream bis=new ByteArrayInputStream(datas);
		DataInputStream dis=new DataInputStream(bis);
		byte flag=dis.readByte();
		if (flag!=MsgId.MSG_FLAG) {
			Log.e(TAG, "datas Error!!!");
			return;
		}
		int type=dis.readByte();
		int length=dis.readShort();
		if(D)Log.d("COM", "receiveMsg type="+type+",length="+length);
		switch (type) {
		case MsgId.CONNECT_PLATFORM_RESPONSE_ID:
			//连接平台应答
			sp.onConnectPlatResponse(dis.readByte());
			break;
		case MsgId.DISCONNECT_PLATFORM_RESPONSE_ID:
			//断开平台应答
			sp.onDisConnectPlatResponse(dis.readByte());
			break;
			
		case MsgId.PASSTHROUGH_DOWN_ID:
			//下行透传
			byte[] receive=new byte[length];
			dis.read(receive, 0, length);
			sp.onPassThroughDown(receive);
			break;
		case MsgId.PASSTHROUGH_UP_RESPONSE_ID:
			//上行透传应答
			sp.onPassThroughUpResponse(dis.readByte());
			break;
		case MsgId.COM_TEST_RESPONSE_ID:
			//上行透传应答
			sp.onComTestResponse();
			break;
		case MsgId.DVR_STATE_ID:
			//DVR状态通知
			byte[] receive2=new byte[length];
			dis.read(receive2, 0, length);
			sp.onDvrState(receive2);
			break;
		case MsgId.GPS_RESPONSE_ID:
			//GPS应答
			sp.onGpsResponse(dis.readByte());
			break;
		case MsgId.FILE_DOWNLOAD_RESPONSE_ID:
			//文件下发请求应答
			sp.onDownLoadFileResponse(dis.readByte());
			break;
		case MsgId.FILE_DOWNLOAD_FINISH_NOTIFY_ID:
			//文件下载完成通知
			sp.onDownLoadFinishedNotify(dis.readByte());
			break;
		case MsgId.TRANSFER_FILE_ID:
			//传输文件
			byte[] fileDatas=new byte[length];
			dis.read(fileDatas, 0, length);
			sp.onTransFile(fileDatas);
			break;
		default:
			break;
		}
	}

}
