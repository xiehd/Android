package com.uninew.JT808.bean;

import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.IOException;

import com.uninew.net.common.BaseMsgID;

public class P_BusArriveStation extends MessageBaseData{

	/**
	 * 
	 */
	private static final long serialVersionUID = 2244170038045377122L;
	private int stationNum;//站点序号
	private int inOutFlage;//进出站标志 0：进站 1：出站
	private String busFlage;//车辆标志
	
	public P_BusArriveStation(int serialNumber, byte[] datas) {
		super(BaseMsgID.STATION_MESSAGE_NOTICE, serialNumber, datas);
		setMsgId(BaseMsgID.STATION_MESSAGE_NOTICE);
		setSerialNumber(serialNumber);
	}

	@Override
	public int getMsgId() {
		return BaseMsgID.STATION_MESSAGE_NOTICE;
	}
	
	@Override
	public void setDatas(byte[] datas) {
		super.setDatas(datas);
		ByteArrayInputStream stream = new ByteArrayInputStream(datas);
		DataInputStream in = new DataInputStream(stream);
		try {
			stationNum = in.readUnsignedByte();
			inOutFlage = in.readUnsignedByte();
			int length = in.available();
			byte[] b = new byte[length];
			in.read(b);
			busFlage = new String(b,"GBK");
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (stream != null) {
					stream.close();
				}
				if (in != null) {
					in.close();
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	/**
	 * @return 站点序号
	 */
	public int getStationNum() {
		return stationNum;
	}

	/**
	 * @return 进出站标志 0：进站 1：出站
	 */
	public int getInOutFlage() {
		return inOutFlage;
	}

	/**
	 * @return 车辆标志
	 */
	public String getBusFlage() {
		return busFlage;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "P_BusArriveStation [stationNum=" + stationNum + ", inOutFlage=" + inOutFlage + ", "
				+ (busFlage != null ? "busFlage=" + busFlage : "") + "]";
	}
	
	
}
