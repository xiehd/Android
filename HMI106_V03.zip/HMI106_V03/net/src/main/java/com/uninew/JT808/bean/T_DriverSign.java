package com.uninew.JT808.bean;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

import com.uninew.net.common.BaseMsgID;
import com.uninew.net.common.ProtocolTool;
/**
 * 司机签到签退上报
 * @author rong
 *
 */
public class T_DriverSign extends MessageBaseData{
	/**
	 * 
	 */
	private static final long serialVersionUID = -8671788545555438819L;
	/** 纬度 **/
	private double latitude;
	/** 经度 **/
	private double longitude;
	private long time; //时间
	private int angle;//角度
	private int type;//类型 0：签到 1：签退
	private String driverId;//司机卡号
	
	/**
	 * 司机签到签退上报
	 * @param latitude 纬度
	 * @param longitude 经度
	 * @param time 时间
	 * @param angle 角度
	 * @param type 类型 0：签到 1：签退
	 * @param driverId 司机卡号
	 */
	public T_DriverSign(double latitude, double longitude, long time, int angle, int type, String driverId) {
		super();
		this.latitude = latitude;
		this.longitude = longitude;
		this.time = time;
		this.angle = angle;
		this.type = type;
		this.driverId = driverId;
		setMsgId(BaseMsgID.SIGN_REPORT);
	}
	
	@Override
	public int getMsgId() {
		return BaseMsgID.SIGN_REPORT;
	}
	
	@Override
	public byte[] getDatas() {
		byte[] bytes = null;
		ByteArrayOutputStream byteStream = new ByteArrayOutputStream();
		DataOutputStream out = new DataOutputStream(byteStream);
		try {
			out.writeInt((int) (latitude * 1000000));
			out.writeInt((int) (longitude * 1000000));
			out.write(ProtocolTool.getBCD12TimeBytes(time));
			
			out.writeShort(angle);
			out.writeByte(type);
			byte[] b = driverId.getBytes("GBK");
			out.write(b);
			bytes = byteStream.toByteArray();
			out.flush();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (byteStream != null) {
					byteStream.close();
				}
				if (out != null) {
					out.close();
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		super.setDatas(bytes);
		return bytes;
	}

	/**
	 * @return 纬度
	 */
	public double getLatitude() {
		return latitude;
	}

	/**
	 * @return 经度
	 */
	public double getLongitude() {
		return longitude;
	}

	/**
	 * @return 时间
	 */
	public long getTime() {
		return time;
	}

	/**
	 * @return 角度
	 */
	public int getAngle() {
		return angle;
	}

	/**
	 * @return 类型 0：签到 1：签退
	 */
	public int getType() {
		return type;
	}

	/**
	 * @return 司机卡号
	 */
	public String getDriverId() {
		return driverId;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "T_DriverSign [latitude=" + latitude + ", longitude=" + longitude + ", time=" + time + ", angle=" + angle
				+ ", type=" + type + ", " + (driverId != null ? "driverId=" + driverId : "") + "]";
	}
	
	
	@Override
	public Object getObject(byte[] datas) {
		ByteArrayInputStream stream = new ByteArrayInputStream(datas);
		DataInputStream in = new DataInputStream(stream);
		try {
			latitude = in.readInt();
			longitude = in.readInt();
			byte[] b = new byte[6];
			in.read(b);
			time = ProtocolTool.getTimeFromBCD12(ProtocolTool.bcd2Str(b));
			angle = in.readUnsignedShort();
			type = in.readUnsignedByte();
			int lenght = in.available();
			byte[] d = new  byte[lenght];
			in.read(d);
			driverId = new String(d, "GBK");
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (stream != null) {
					stream.close();
				}
				if (in != null) {
					in.close();
				}
			} catch (IOException e) {
				e.printStackTrace();
			}

		}
		return this;
	}
	
}
