package com.uninew.JT808.bean;

import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.IOException;

import com.uninew.net.common.BaseMsgID;
/**
 * 资源文件升级指令
 * @author rong
 *
 */
public class P_ResourceUpdate extends MessageBaseData{

	/**
	 * 
	 */
	private static final long serialVersionUID = 8613905361356585538L;
	
	private String username;//ftp登录用户名
	private String password;//ftp登录密码
	private String host;//ftp下载地址
	/**
	 * 资源文件升级指令
	 * @param serialNumber 流水号
	 * @param datas 消息体
	 */
	public P_ResourceUpdate(int serialNumber, byte[] datas) {
		super(BaseMsgID.TERMINAL_RESOURCE_UPDATE, serialNumber, datas);
		setDatas(datas);
		setMsgId(BaseMsgID.TERMINAL_RESOURCE_UPDATE);
		setSerialNumber(serialNumber);
	}
	
	@Override
	public void setDatas(byte[] datas) {
		super.setDatas(datas);
		ByteArrayInputStream stream = new ByteArrayInputStream(datas);
		DataInputStream in = new DataInputStream(stream);
		try {
			byte[] b = new byte[10];
			in.read(b);
			username = new String(b,"GBK");
			byte[] rn = new byte[15];
			in.read(rn);
			password = new String(rn, "GBK");
			int length = in.available();
			byte[] sp = new byte[length];
			in.read(sp);
			host = new String(sp, "GBK");
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (stream != null) {
					stream.close();
				}
				if (in != null) {
					in.close();
				}
			} catch (IOException e) {
				e.printStackTrace();
			}

		}
	}

	/**
	 * @return ftp登录用户名
	 */
	public String getUsername() {
		return username;
	}

	/**
	 * @return ftp登录密码
	 */
	public String getPassword() {
		return password;
	}

	/**
	 * @return ftp下载地址
	 */
	public String getHost() {
		return host;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "P_ResourceUpdate [" + (username != null ? "username=" + username + ", " : "")
				+ (password != null ? "password=" + password + ", " : "") + (host != null ? "host=" + host : "") + "]";
	}

	
	
}
