package com.uninew.JT808.bean;

import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.IOException;

import com.uninew.net.common.BaseMsgID;
/**
 * 车辆报站信息通知
 * @author rong
 *
 */
public class P_BusStopsNotify extends MessageBaseData{

	/**
	 * 
	 */
	private static final long serialVersionUID = 6414551211284370144L;
	private int stationNum;//当前站点序号
	private int inOutMack;//进出站标识 0：进站 1：出站
	private String busPlate;//车牌号码
	/**
	 * 车辆报站信息通知
	 * @param serialNumber 流水号
	 * @param datas 消息体
	 */
	public P_BusStopsNotify(int serialNumber, byte[] datas) {
		super(BaseMsgID.STATION_MESSAGE_NOTICE,serialNumber, datas);
		setMsgId(BaseMsgID.STATION_MESSAGE_NOTICE);
		setDatas(datas);
	}
	
	@Override
	public int getMsgId() {
		return BaseMsgID.STATION_MESSAGE_NOTICE;
	}
	
	@Override
	public void setDatas(byte[] datas) {
		super.setDatas(datas);
		ByteArrayInputStream stream = new ByteArrayInputStream(datas);
		DataInputStream in = new DataInputStream(stream);
		try {
			stationNum = in.readShort();
			inOutMack = in.readByte();
			int length = in.available();
			byte[] b = new byte[length];
			in.read(b);
			busPlate = new String(b,"GBK");
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (stream != null) {
					stream.close();
				}
				if (in != null) {
					in.close();
				}
			} catch (IOException e) {
				e.printStackTrace();
			}

		}
	}

	/**
	 * @return 当前站点序号
	 */
	public int getStationNum() {
		return stationNum;
	}

	/**
	 * @return 进出站标识 0：进站 1：出站
	 */
	public int getInOutMack() {
		return inOutMack;
	}

	/**
	 * @return 车牌号码
	 */
	public String getBusPlate() {
		return busPlate;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "P_BusStopsNotify [stationNum=" + stationNum + ", inOutMack=" + inOutMack + ", "
				+ (busPlate != null ? "busPlate=" + busPlate : "") + "]";
	}
	
	
}
