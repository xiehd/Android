package com.uninew.ftp;

import java.io.File;

import it.sauronsoftware.ftp4j.FTPDataTransferListener;

public interface IFTPSerManage {
	/**
	 * @return 连接状态
	 */
	boolean isConnet();
	/**
	 * @return 是否正在下载
	 */
	boolean isDownload();
	/**
	 * 连接ftp服务器
	 * 
	 * @param host
	 *            服务地址
	 * @param port
	 *            端口号
	 * @param username
	 *            用户名
	 * @param password
	 *            密码
	 * @return 服务器欢迎消息
	 */
	String[] connetFTPSer(String host,int port, String username, String password);
	/**
	 * ftp文件下载
	 * 
	 * 此方法将远程文件从服务器下载到本地文件。 调用此方法会阻塞当前线程，直到操作完成。
	 * 该操作可能被另一个调用abortCurrentDataTransfer（）的线程中断。 该方法将与FTPAbortedException中断。
	 * 
	 * @param remoteFileName
	 *            下载文件名称
	 * @param localFile
	 *            存放本地文件
	 * @return true：完成 false：失败
	 */
	boolean downloadFile(String remoteFileName, File localFile,FTPDataTransferListener listener);
	/**
	 * 中断ftp服务器的数据传输
	 * 
	 * @param sendAborCommand
	 *            如果为true，客户端将通过标准FTP ABOR命令与服务器协商中止过程。
	 *            否则，打开的数据传输连接将关闭，而没有任何建议已发送到服务器。
	 */
	void abortCurrentDataTransfer(boolean sendAborCommand);
	/**
	 * 断开ftp服务器连接
	 * @param sendQuitCommand
	 *            如果为true，将执行与服务器的QUIT过程，否则客户端突然关闭连接，而不向服务器发送任何建议。
	 */
	void disConnet(boolean sendQuitCommand);

	/**
	 * 获取文件大小
	 * @param path 文件路径
	 * @return 文件大小（以字节为单位）
	 */
	long getFileSize(String path);
	
	/**
	 * 断点续传
	 * @param path 下载地址
	 * @param localFile 原文件
	 * @param listener 监听器
	 * @return
	 */
	boolean continueDownload(String path,File localFile,FTPDataTransferListener listener);
}
