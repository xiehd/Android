package com.uninew.JT808.bean;

import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.IOException;

import com.uninew.net.common.BaseMsgID;
/**
 * 文本信息
 * @author rong
 *
 */
public class P_TextMessage extends MessageBaseData{
	/**
	 * 
	 */
	private static final long serialVersionUID = -5013844258251418506L;
	private boolean isExigency;//true ：紧急
	private boolean isViewShow;//true ：终端显示屏显示
	private boolean isTTS;//true ： tts播报
	private boolean isADShow;//true ：广告屏显示
	private int isMsgType; // 0：中心导航信息 1：CAN 故障码信息
	private boolean isRequired;//true ：必读信息
	private String msg;//信息内容
	
	/**
	 * 文本信息
	 * @param datas 消息体
	 */
	public P_TextMessage(int serialNumber, byte[] datas) {
		super(BaseMsgID.TEXT_MSG_ISSUED,serialNumber,datas);
		setSerialNumber(serialNumber);
		setDatas(datas);
	}

	@Override
	public int getMsgId() {
		return BaseMsgID.TEXT_MSG_ISSUED;
	}
	
	@Override
	public void setDatas(byte[] datas) {
		super.setDatas(datas);
		ByteArrayInputStream stream = new ByteArrayInputStream(datas);
		DataInputStream in = new DataInputStream(stream);
		try {
			int mark = in.readByte();
			if((mark & 0x01) == 1){
				isExigency = true;
			}
			if((mark & 0x04) == 0x04){
				isViewShow = true;
			}
			if((mark & 0x08 ) == 0x08){
				isTTS = true;
			}
			if((mark & 0x10) == 0x10){
				isADShow = true;
			}
			if((mark & 0x20) == 0x20){
				isMsgType = 1;
			}else{
				isMsgType = 0;
			}
			if((mark & 0x40) == 0x40){
				isRequired = true;
			}
			int length = in.available();
			if(length > 0 ){
				byte[] bs = new byte[length];
				in.read(bs);
				if(bs != null){
					msg = new String(bs, "GBK");
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			try {
				if (stream != null) {
					stream.close();
				}
				if (in != null) {
					in.close();
				}
			} catch (IOException e) {
				e.printStackTrace();
			}

		}
	}

	/**
	 * @return true ：紧急
	 */
	public boolean isExigency() {
		return isExigency;
	}

	/**
	 * @return true ：终端显示屏显示
	 */
	public boolean isViewShow() {
		return isViewShow;
	}

	/**
	 * @return true ： tts播报
	 */
	public boolean isTTS() {
		return isTTS;
	}

	/**
	 * @return true ：广告屏显示
	 */
	public boolean isADShow() {
		return isADShow;
	}

	/**
	 * @return  0：中心导航信息 1：CAN 故障码信息
	 */
	public int getIsMsgType() {
		return isMsgType;
	}

	/**
	 * @return true ：必读信息
	 */
	public boolean isRequired() {
		return isRequired;
	}

	/**
	 * @return 消息内容
	 */
	public String getMsg() {
		return msg;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "P_TextMessage [isExigency=" + isExigency + ", isViewShow=" + isViewShow + ", isTTS=" + isTTS
				+ ", isADShow=" + isADShow + ", isMsgType=" + isMsgType + ", isRequired=" + isRequired + ", "
				+ (msg != null ? "msg=" + msg : "") + "]";
	}
	
	
	
}
