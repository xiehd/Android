package com.uninew.ftp;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;


import android.util.Log;
import it.sauronsoftware.ftp4j.FTPAbortedException;
import it.sauronsoftware.ftp4j.FTPClient;
import it.sauronsoftware.ftp4j.FTPDataTransferException;
import it.sauronsoftware.ftp4j.FTPDataTransferListener;
import it.sauronsoftware.ftp4j.FTPException;
import it.sauronsoftware.ftp4j.FTPIllegalReplyException;
/**
 * FTP文件下载的管理方法
 * @author rong
 *
 */
public class FTPServiceManage implements IFTPSerManage{

	private static final String TAG = "FTPServiceManage";
	private static final boolean D = true;
	private volatile static FTPServiceManage instance;
	private FTPClient ftpClient;//ftp下载器
	private boolean isConnet = false;//连接状态
	private boolean isDownload = false;//下载状态

	public static FTPServiceManage getInstance(){
		if(instance != null){
			
		}else{
			synchronized (FTPServiceManage.class) {
				if(instance == null){
					instance = new FTPServiceManage();
				}
			}
		}
		return instance;
	}
	
	private FTPServiceManage() {
		super();
		ftpClient = new FTPClient();
	}

	/**
	 * @return 连接状态
	 */
	@Override
	public boolean isConnet() {
		return isConnet;
	}



	/**
	 * @return 是否正在下载
	 */
	@Override
	public boolean isDownload() {
		return isDownload;
	}



	/**
	 * 连接ftp服务器
	 * 
	 * @param host
	 *            服务地址
	 * @param username
	 *            用户名
	 * @param password
	 *            密码
	 * @return 服务器欢迎消息
	 */
	@Override
	public String[] connetFTPSer(String host,int port, String username, String password) {
		String[] msg = null;
		if(!isConnet){
			try {
				ftpClient.setSecurity(FTPClient.SECURITY_FTP);// 设置安全级别
				msg = ftpClient.connect(host,port);// 连接服务器
				ftpClient.setType(FTPClient.TYPE_BINARY);//以二进制传输
				ftpClient.setCharset("GBK");//防止中文乱码
				ftpClient.login(username, password);// 登录服务器
				isConnet = true;
			} catch (IllegalStateException e) {
				e.printStackTrace();
				isConnet = false;
				if (D)Log.e(TAG, "the client is already connected to a remote host");
			} catch (IOException e) {
				e.printStackTrace();
				isConnet = false;
				if (D)Log.e(TAG, "an I/O occurs");
			} catch (FTPIllegalReplyException e) {
				e.printStackTrace();
				isConnet = false;
				if (D)Log.e(TAG, "the server replies in an illegal way");
			} catch (FTPException e) {
				e.printStackTrace();
				isConnet = false;
				if (D)Log.e(TAG, "the server refuses the connection.");
			}
		}
		return msg;
	}

	
	/**
	 * ftp文件下载
	 * 
	 * 此方法将远程文件从服务器下载到本地文件。 调用此方法会阻塞当前线程，直到操作完成。
	 * 该操作可能被另一个调用abortCurrentDataTransfer（）的线程中断。 该方法将与FTPAbortedException中断。
	 * 
	 * @param remoteFileName
	 *            下载文件名称
	 * @param localFile
	 *            存放本地文件
	 * @return true：完成 false：失败
	 */
	@Override
	public synchronized boolean downloadFile(String remoteFileName, File localFile,FTPDataTransferListener listener) {
		boolean isFinish = false;
		if (isConnet && !isDownload) {
			try {
				isDownload = true;
//				if (!localFile.exists()) {
//					localFile.createNewFile();
//				}
				ftpClient.download(remoteFileName, localFile,listener);
				isFinish = true;
			} catch (IllegalStateException e) {
				if (D)Log.e(TAG, "the client is not connected or not authenticated");
				isFinish = false;
				e.printStackTrace();
			} catch (FileNotFoundException e) {
				if (D)Log.e(TAG, "the supplied file cannot be found");
				isFinish = false;
				e.printStackTrace();
			} catch (IOException e) {
				if (D)Log.e(TAG, "an I/O error occurs");
				isFinish = false;
				e.printStackTrace();
			} catch (FTPIllegalReplyException e) {
				if (D)Log.e(TAG, "the server replies in an illegal way");
				isFinish = false;
				e.printStackTrace();
			} catch (FTPException e) {
				if (D)Log.e(TAG, "the operation fails.");
				isFinish = false;
				e.printStackTrace();
			} catch (FTPDataTransferException e) {
				if (D)Log.e(TAG,
							"If a I/O occurs in the data transfer connection. If you receive this exception the transfer failed,"
									+ " but the main connection with the remote FTP server is in theory still working. ");
				e.printStackTrace();
				isFinish = false;
			} catch (FTPAbortedException e) {
				if (D)Log.e(TAG, "operation is aborted by another thread.");
				e.printStackTrace();
				isFinish = false;
			} finally {
				isDownload = false;
			}
		} else {
			if (D)Log.e(TAG, "The server is not connected or Downloading file is in progress");
		}
		return isFinish;
	}

	/**
	 * 中断ftp服务器的数据传输
	 * 
	 * @param sendAborCommand
	 *            如果为true，客户端将通过标准FTP ABOR命令与服务器协商中止过程。
	 *            否则，打开的数据传输连接将关闭，而没有任何建议已发送到服务器。
	 */
	@Override
	public synchronized void abortCurrentDataTransfer(boolean sendAborCommand) {
		if (isDownload) {
			try {
				ftpClient.abortCurrentDataTransfer(sendAborCommand);
			} catch (IOException e) {
				if (D)Log.e(TAG,
							"the ABOR command cannot be sent due to any I/O error. This could happen only if force is false. ");
				e.printStackTrace();
			} catch (FTPIllegalReplyException e) {
				if (D)Log.e(TAG,
							"the server reply to the ABOR command is illegal. This could happen only if force is false");
				e.printStackTrace();
			}
		}
	}

	/**
	 * 断开ftp服务器连接
	 * @param sendQuitCommand
	 *            如果为true，将执行与服务器的QUIT过程，否则客户端突然关闭连接，而不向服务器发送任何建议。
	 */
	@Override
	public void disConnet(boolean sendQuitCommand){
		if(isConnet){
			abortCurrentDataTransfer(sendQuitCommand);
			try {
				ftpClient.logout();
				ftpClient.disconnect(sendQuitCommand);
			} catch (IllegalStateException e) {
				if (D)Log.e(TAG, "the client is not connected to a remote host");
				e.printStackTrace();
			} catch (IOException e) {
				if (D)Log.e(TAG, "an I/O occurs ");
				e.printStackTrace();
			} catch (FTPIllegalReplyException e) {
				if (D)Log.e(TAG, "the server replies in an illegal way");
				e.printStackTrace();
			} catch (FTPException e) {
				if (D)Log.e(TAG, "the server refuses the QUIT command");
				e.printStackTrace();
			}finally {
				isConnet = false;
			}
		}
	}

	@Override
	public long getFileSize(String path) {
		long size = 0;
		if(isConnet){
			try {
				size = ftpClient.fileSize(path);
			} catch (IllegalStateException e) {
				if (D)Log.e(TAG, " the client is not connected or not authenticated");
				e.printStackTrace();
			} catch (IOException e) {
				if (D)Log.e(TAG, "an I/O error occurs");
				e.printStackTrace();
			} catch (FTPIllegalReplyException e) {
				if (D)Log.e(TAG, "the server replies in an illegal way");
				e.printStackTrace();
			} catch (FTPException e) {
				if (D)Log.e(TAG, "the operation fails");
				e.printStackTrace();
			}
		}
		return size;
	}

	@Override
	public boolean continueDownload(String path, File localFile, FTPDataTransferListener listener) {
		boolean isFinish = false;
		OutputStream outputStream = null;
		if(localFile != null && isConnet){
			try {
				isDownload = true;
				long size = localFile.length();
				outputStream = new FileOutputStream(localFile, true);
				ftpClient.download(path, outputStream, size, listener);
			} catch (IllegalStateException e) {
				if (D)Log.e(TAG, "the client is not connected or not authenticated");
				isFinish = false;
				e.printStackTrace();
			} catch (FileNotFoundException e) {
				if (D)Log.e(TAG, "the supplied file cannot be found");
				isFinish = false;
				e.printStackTrace();
			} catch (IOException e) {
				if (D)Log.e(TAG, "an I/O error occurs");
				isFinish = false;
				e.printStackTrace();
			} catch (FTPIllegalReplyException e) {
				if (D)Log.e(TAG, "the server replies in an illegal way");
				isFinish = false;
				e.printStackTrace();
			} catch (FTPException e) {
				if (D)Log.e(TAG, "the operation fails.");
				isFinish = false;
				e.printStackTrace();
			} catch (FTPDataTransferException e) {
				if (D)Log.e(TAG,
							"If a I/O occurs in the data transfer connection. If you receive this exception the transfer failed,"
									+ " but the main connection with the remote FTP server is in theory still working. ");
				e.printStackTrace();
				isFinish = false;
			} catch (FTPAbortedException e) {
				if (D)Log.e(TAG, "operation is aborted by another thread.");
				e.printStackTrace();
				isFinish = false;
			} finally {
				isDownload = false;
				try {
					if(outputStream != null){
						outputStream.flush();
						outputStream.close();
					}
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
		return isFinish;
	}
}
