package com.uninew.JT808.bean;

import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.IOException;

import com.uninew.net.common.BaseMsgID;
/**
 * 司机签到签退上报
 * @author rong
 *
 */
public class P_DriverSignAns extends MessageBaseData{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -6040186497857798011L;
	private int ansSerialNumber;//应答流水号
	private int result;//结果 0：识别 1：未识别
	private String driverNam = null; //司机名称
	
	/**
	 * 司机签到签退上报
	 * @param serialNumber 流水号
	 * @param datas 消息体
	 */
	public P_DriverSignAns(int serialNumber, byte[] datas) {
		super(BaseMsgID.SIGN_REPORT_ANS, serialNumber, datas);
		setMsgId(BaseMsgID.SIGN_REPORT_ANS);
		setDatas(datas);
	}
	
	@Override
	public int getMsgId() {
		return BaseMsgID.SIGN_REPORT_ANS;
	}
	
	@Override
	public void setDatas(byte[] datas) {
		super.setDatas(datas);
		ByteArrayInputStream stream = new ByteArrayInputStream(datas);
		DataInputStream in = new DataInputStream(stream);
		try {
			ansSerialNumber = in.readShort();
			result = in.readUnsignedByte();
			if(result == 0){
				int lengh = in.available();
				byte[] b = new byte[lengh];
				in.read(b);
				driverNam = new String(b,"GBK");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			try {
				if (stream != null) {
					stream.close();
				}
				if (in != null) {
					in.close();
				}
			} catch (IOException e) {
				e.printStackTrace();
			}

		}
	}

	/**
	 * @return 应答流水号
	 */
	public int getAnsSerialNumber() {
		return ansSerialNumber;
	}

	/**
	 * @return 结果 0：识别 1：未识别
	 */
	public int getResult() {
		return result;
	}

	/**
	 * @return 司机名称
	 */
	public String getDriverNam() {
		return driverNam;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "P_DriverSignAns [ansSerialNumber=" + ansSerialNumber + ", result=" + result + ", "
				+ (driverNam != null ? "driverNam=" + driverNam : "") + "]";
	}
	
}
