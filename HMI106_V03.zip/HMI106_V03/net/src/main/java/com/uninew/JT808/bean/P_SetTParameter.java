package com.uninew.JT808.bean;

import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.IOException;

import com.uninew.net.common.BaseMsgID;

public class P_SetTParameter extends MessageBaseData {

	private int num;// 终端参数总数
	private long heartbeatTime;//心跳间隔时间
	private long msgTimeout;//消息应答超时
	private int maxReSendTimes;//消息最大重发次数
	private String mainIp;//主服务器Ip
	private String spareIp;//备用服务器Ip
	private int port;//端口号

	public P_SetTParameter(int serialNumber, byte[] datas) {
		super(BaseMsgID.TERMINAL_SET, serialNumber, datas);
		setMsgId(BaseMsgID.TERMINAL_SET);
		setSerialNumber(serialNumber);
	}

	public class ParameterID {
		/** 心跳间隔时间 */
		public static final int HEART_BEAT_TIME = 0x0001;
		/** tcp消息应答超时时间 */
		public static final int TCP_MSG_ANS_TIMEOUT = 0x0002;
		/** tcp消息重传次数 */
		public static final int TCP_MSG_RESEND_TIMES = 0x0003;
		/** udp消息应答超时时间 */
		public static final int UDP_MSG_ANS_TIMEOUT = 0x0004;
		/** udp消息重传次数 */
		public static final int UDP_MSG_RESEND_TIMES = 0x0005;
		/** SMS消息应答超时时间 */
		public static final int SMS_MSG_ANS_TIMEOUT = 0x0006;
		/** SMS消息重传次数 */
		public static final int SMS_MSG_RESEND_TIMES = 0x0007;
		
		/** 主服务器APN*/
		public static final int MAIN_SERVICER_APN = 0x0010;
		/** 主服务器无线通信拨号用户名*/
		public static final int MAIN_SERVICER_NAME = 0x0011;
		/** 主服务器无线通信拨号密码*/
		public static final int MAIN_SERVICER_PWD = 0x0012;
		/** 主服务器IP*/
		public static final int MAIN_SERVICER_IP = 0x0013;
		/** 备用服务器APN*/
		public static final int SPARE_SERVICER_APN = 0x0014;
		/** 备用服务器无线通信拨号用户名*/
		public static final int SPARE_SERVICER_NAME = 0x0015;
		/** 备用服务器无线通信拨号密码*/
		public static final int SPARE_SERVICER_PWD = 0x0016;
		/** 备用服务器IP*/
		public static final int SPARE_SERVICER_IP = 0x0017;
		/** 服务器TCP端口 */
		public static final int SERVICE_TCP_PORT = 0x0018;
		/** 服务器UDP端口 */
		public static final int SERVICE_UDP_PORT = 0x0019;
		
		/** 道路运输证IC 卡认证主服务器IP 地址或域名 */
		public static final int IC_MAIN_SERVICER_IP = 0x001A;
		/** 道路运输证IC 卡认证主服务器TCP 端口 */
		public static final int IC_SERVICE_TCP_PORT = 0x001B;
		/** 道路运输证IC 卡认证主服务器UDP 端口 */
		public static final int IC_SERVICE_UDP_PORT = 0x001C;
		/** 道路运输证IC 卡认证备份服务器IP 地址或域名，端口同主服务器*/
		public static final int IC_SPARE_SERVICER_IP = 0x001D;
		/** 位置汇报策略，0：定时汇报；1：定距汇报；2：定时和定距汇报 */
		public static final int LOCATION_REPORT_STRATEGY = 0x0020;
		/** 位置汇报方案，0：根据ACC状态；1：根据登录状态和ACC状态，先判断登录状态，若登录再根据ACC状态 */
		public static final int LOCATION_REPORT_PROGRAM = 0x0021;
		/** 驾驶员未登录汇报时间间隔，单位为秒(s),>0 */
		public static final int DRIVER_UNSIGN_REPORT_TIME = 0x0021;
		/** 休眠时汇报时间间隔，单位为秒(s),>0 */
		public static final int SLEEP_REPORT_TIME = 0x0027;
		/** 紧急报警时汇报时间间隔，单位为秒(s),>0 */
		public static final int ALARM_REPORT_TIME = 0x0028;
		/** 缺省时间汇报间隔，单位为秒(s),>0 */
		public static final int DEFAULT_REPORT_TIME = 0x0029;
		/** 缺省距离汇报间隔，单位为米(m),>0 */
		public static final int DEFAULT_REPORT_DISTANCE = 0x002C;
		/** 驾驶员未登录汇报距离间隔，单位为米(m),>0 */
		public static final int DRIVER_UNSIGN_REPORT_DISTANCE = 0x002D;
		/** 休眠时汇报距离间隔，单位为米(m),>0*/
		public static final int SLEEP_REPORT_DISTANCE = 0x002E;
		/** 紧急报警时汇报距离间隔，单位为米(m),>0 */
		public static final int ALARM_REPORT_DISTANCE = 0x002F;
		/** 标记点补传角度，<180° */
		public static final int MACKER_REPORT_ANGLE = 0x0030;
		/** 电子围栏半径（非法位移阈值），单位为米 */
		public static final int ELECTRONIC_FENCE_RADIUS = 0x0031;

	}

	@Override
	public int getMsgId() {
		return BaseMsgID.TERMINAL_SET;
	}

	@Override
	public void setDatas(byte[] datas) {
		super.setDatas(datas);
		ByteArrayInputStream stream = new ByteArrayInputStream(datas);
		DataInputStream in = new DataInputStream(stream);
		try {
			num = in.readUnsignedByte();
			for(int i = 0;i<num;i++){
				int id = in.readInt();
				int length = in.readUnsignedByte();
				switch (id) {
				case ParameterID.HEART_BEAT_TIME:
					heartbeatTime = in.readInt();
					break;
				case ParameterID.MAIN_SERVICER_IP:
					byte[] b = new byte[length];
					in.read(b);
					mainIp = new String(b);
					break;
				case ParameterID.SERVICE_TCP_PORT:
					port = in.readInt();
					break;
				case ParameterID.TCP_MSG_ANS_TIMEOUT:
					msgTimeout = in.readInt();
					break;
				case ParameterID.TCP_MSG_RESEND_TIMES:
					maxReSendTimes = in.readInt();
					break;
				case ParameterID.IC_SPARE_SERVICER_IP:
					byte[] b1 = new byte[length];
					in.read(b1);
					spareIp = new String(b1);
					break;
				default:
					byte[] b2 = new byte[length];
					in.read(b2);
					break;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (stream != null) {
					stream.close();
				}
				if (in != null) {
					in.close();
				}
			} catch (IOException e) {
				e.printStackTrace();
			}

		}
	}

	@Override
	public Object getObject(byte[] datas) {
		// TODO Auto-generated method stub
		return null;
	}
}
