package com.uninew.JT808.bean;

import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;

import com.uninew.net.common.BaseMsgID;
import com.uninew.net.common.ProtocolTool;
/***
 * 车辆进出场站上报
 * @author rong
 *
 */
public class T_InOutParking extends MessageBaseData{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -1960860206294387124L;
	private String routeId;//线路Id
	private String planceId;//场站Id
	private int planceMack;//进出场站标识 0：进场站 1：出场站
	private long time; //时间
	private int angle;//角度
	/** 纬度 **/
	private double latitude;
	/** 经度 **/
	private double longitude;
	/** 速度 1/10km/h **/
	private float speed;
	
	/**
	 * 车辆进出场站上报
	 * @param routeId 线路Id
	 * @param planceId 场站Id
	 * @param planceMack 进出场站标识 0：进场站 1：出场站
	 * @param time 时间
	 * @param angle 角度
	 * @param latitude 纬度
	 * @param longitude 经度
	 * @param speed 速度 1/10km/h
	 */
	public T_InOutParking(String routeId, String planceId, int planceMack, long time, int angle, double latitude,
			double longitude, float speed) {
		super();
		this.routeId = routeId;
		this.planceId = planceId;
		this.planceMack = planceMack;
		this.time = time;
		this.angle = angle;
		this.latitude = latitude;
		this.longitude = longitude;
		this.speed = speed;
	}



	@Override
	public int getMsgId() {
		return BaseMsgID.INOUT_PARKING_REPORT;
	}
	
	@Override
	public byte[] getDatas() {
		byte[] bytes = null;
		ByteArrayOutputStream byteStream = new ByteArrayOutputStream();
		DataOutputStream out = new DataOutputStream(byteStream);
		try {
			out.write(ProtocolTool.stringToByte(routeId, "ISO8859-1", 8));
			out.write(ProtocolTool.stringToByte(planceId, "ISO8859-1", 8));
			out.writeByte(planceMack);
			out.writeInt((int) (latitude * 1000000));
			out.writeInt((int) (longitude * 1000000));
			out.writeShort((int) (speed * 10));
			out.write(ProtocolTool.getBCD12TimeBytes(time));
			out.writeShort(angle);
			bytes = byteStream.toByteArray();
			out.flush();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (byteStream != null) {
					byteStream.close();
				}
				if (out != null) {
					out.close();
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		super.setDatas(bytes);
		return bytes;
	}

	/**
	 * @return 线路Id
	 */
	public String getRouteId() {
		return routeId;
	}

	/**
	 * @return 场站Id
	 */
	public String getPlanceId() {
		return planceId;
	}

	/**
	 * @return 进出场站标识 0：进场站 1：出场站
	 */
	public int getPlanceMack() {
		return planceMack;
	}

	/**
	 * @return 时间
	 */
	public long getTime() {
		return time;
	}

	/**
	 * @return 角度
	 */
	public int getAngle() {
		return angle;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "T_InOutPlance [routeId=" + routeId + ", planceId=" + planceId + ", planceMack=" + planceMack + ", time="
				+ time + ", angle=" + angle + "]";
	}
	
	
}
