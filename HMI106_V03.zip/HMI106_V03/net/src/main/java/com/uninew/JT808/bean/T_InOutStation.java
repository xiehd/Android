package com.uninew.JT808.bean;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

import com.uninew.net.common.BaseMsgID;
import com.uninew.net.common.ProtocolTool;
/**
 * 进出站上报
 * @author rong
 *
 */
public class T_InOutStation extends MessageBaseData {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -2748016800294273311L;
	private String routeId;//线路ID
	private int direction;//方向 0：上行 1：下行 2：环行
	private int stationNum;//站点序号
	private String stationCoding; //站点编码
	private int mark;//进出站标识 0：进站 1：出站 3：标记点
	private long time;//时间
	private int angle;//角度 0-359
	private int uponPassenger;//上客人数 0-255
	private int downPassenger;//下客人数 0-255
	private int consume;//涮卡金额  单位：10分之1元
	private int stationType;//站点类型 0：起点站，1：中间站 2 ：倒数第二站 3：终点站
	/** 纬度 **/
	private double latitude;
	/** 经度 **/
	private double longitude;
	/** 速度 1/10km/h **/
	private float speed;
	
	/**
	 * 进出站上报
	 * 
	 * @param routeId 线路ID
	 * @param direction 方向 0：上行 1：下行 2：环行
	 * @param stationNum 站点序号
	 * @param stationCoding 站点编码
	 * @param mark 进出站标识 0：进站 1：出站 3：标记点
	 * @param time 时间
	 * @param angle  角度 0-359
	 * @param uponPassenger 上客人数 0-255
	 * @param downPassenger 下客人数 0-255
	 * @param consume  涮卡金额 单位：10分之1元
	 * @param stationType 站点类型 0：起点站，1：中间站 2 ：倒数第二站 3：终点站
	 * @param latitude 纬度
	 * @param longitude 经度
	 * @param speed 速度 1/10km/h
	 */
	public T_InOutStation(String routeId, int direction, int stationNum, String stationCoding, int mark, long time,
			int angle, int uponPassenger, int downPassenger, int consume, int stationType, double latitude,
			double longitude, float speed) {
		super();
		this.routeId = routeId;
		this.direction = direction;
		this.stationNum = stationNum;
		this.stationCoding = stationCoding;
		this.mark = mark;
		this.time = time;
		this.angle = angle;
		this.uponPassenger = uponPassenger;
		this.downPassenger = downPassenger;
		this.consume = consume;
		this.stationType = stationType;
		this.latitude = latitude;
		this.longitude = longitude;
		this.speed = speed;
	}
	


	@Override
	public int getMsgId() {
		return BaseMsgID.INOUT_STATION_REPORT;
	}
	


	@Override
	public byte[] getDatas() {
		byte[] bytes = null;
		ByteArrayOutputStream byteStream = new ByteArrayOutputStream();
		DataOutputStream out = new DataOutputStream(byteStream);
		try {
			out.write(ProtocolTool.stringToByte(routeId, "ISO8859-1", 8));
			out.writeByte(direction);
			out.writeByte(stationNum);
			out.write(ProtocolTool.stringToByte(stationCoding, "ISO8859-1", 8));
			out.writeByte(mark);
			out.writeInt((int) (latitude * 1000000));
			out.writeInt((int) (longitude * 1000000));
			out.writeShort((int) (speed * 10));
			out.write(ProtocolTool.getBCD12TimeBytes(time));
			out.writeShort(angle);
			if(mark == 1){
				out.writeByte(uponPassenger);
				out.writeByte(downPassenger);
				out.writeShort(consume);
			}
			bytes = byteStream.toByteArray();
			out.flush();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (byteStream != null) {
					byteStream.close();
				}
				if (out != null) {
					out.close();
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		super.setDatas(bytes);
		return bytes;
	}

	
	
	/**
	 * @return 站点类型 0：起点站，1：中间站 2 ：倒数第二站 3：终点站
	 */
	public int getStationType() {
		return stationType;
	}



	/**
	 * @param 站点类型 0：起点站，1：中间站 2 ：倒数第二站 3：终点站
	 */
	public void setStationType(int stationType) {
		this.stationType = stationType;
	}


	/**
	 * @return 线路ID
	 */
	public String getRouteId() {
		return routeId;
	}

	
	
	/**
	 * @return 站点编码
	 */
	public String getStationCoding() {
		return stationCoding;
	}

	/**
	 * @return 方向 0：上行 1：下行 2：环行
	 */
	public int getDirection() {
		return direction;
	}

	/**
	 * @return 站点序号
	 */
	public int getStationNum() {
		return stationNum;
	}

	/**
	 * @return 进出站标识 0：进站 1：出站 3：标记点
	 */
	public int getMark() {
		return mark;
	}

	/**
	 * @return 时间
	 */
	public long getTime() {
		return time;
	}
	
	/**
	 * @return 角度 0-359
	 */
	public int getAngle() {
		return angle;
	}



	/**
	 * @return 上客人数 0-255
	 */
	public int getUponPassenger() {
		return uponPassenger;
	}



	/**
	 * @return 下客人数 0-255
	 */
	public int getDownPassenger() {
		return downPassenger;
	}



	/**
	 * @return 涮卡金额  单位：10分之1元
	 */
	public int getConsume() {
		return consume;
	}



	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "T_InOutStation [routeId=" + routeId + ", direction=" + direction + ", stationNum=" + stationNum
				+ ", mark=" + mark + ", time=" + time + ", angle=" + angle + ", uponPassenger=" + uponPassenger
				+ ", downPassenger=" + downPassenger + ", consume=" + consume + "]";
	}

	@Override
	public Object getObject(byte[] datas) {
		ByteArrayInputStream stream = new ByteArrayInputStream(datas);
		DataInputStream in = new DataInputStream(stream);
		try {
			byte[] bc = new byte[8];
			in.read(bc);
			routeId = new String(bc, "GBK");
			direction = in.readUnsignedByte();
			stationNum = in.readUnsignedByte();
			byte[] bcd = new byte[8];
			in.read(bcd);
			stationCoding = new String(bcd, "GBK");
			mark = in.readUnsignedByte();
			latitude = in.readInt();
			longitude = in.readInt();
			speed = in.readUnsignedShort();
			byte[] b = new byte[6];
			in.read(b);
			time = ProtocolTool.getTimeFromBCD12(ProtocolTool.bcd2Str(b));
			angle = in.readUnsignedShort();
			if(mark == 1){
				uponPassenger = in.readUnsignedByte();
				downPassenger = in.readUnsignedByte();
				consume = in.readUnsignedShort();
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (stream != null) {
					stream.close();
				}
				if (in != null) {
					in.close();
				}
			} catch (IOException e) {
				e.printStackTrace();
			}

		}
		return this;
	}
	
}
