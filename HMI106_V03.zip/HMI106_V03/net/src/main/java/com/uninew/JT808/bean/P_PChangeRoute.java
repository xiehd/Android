package com.uninew.JT808.bean;

import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.IOException;

import com.uninew.net.common.BaseMsgID;

/**
 * 线路切换指令
 * 
 * @author rong
 *
 */
public class P_PChangeRoute extends MessageBaseData {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1509722541286324971L;
	private String routeId;// 线路Id
	private int changeType;//切换类型 0：切换上下行 1：切换线路
	private int direction;//方向 0：上行 1：下行 
	private int routeType;// 线路类型 0：双向 2：环线
	private int uponStationNum;// 上行站点总数
	private int uponMarkerNum;// 上行标记点总数
	private int downStationNum;// 下行站点总数
	private int downMarkerNum;// 下行标记点总数
	private String routeName;// 线路名称
	private String startPlace;// 始发场站
	private String endPlace;// 终点场站

	
	public P_PChangeRoute() {
		super();
	}

	/**
	 * 
	 * @param serialNumber
	 *            流水号
	 * @param datas
	 *            消息体
	 */
	public P_PChangeRoute(int serialNumber, byte[] datas) {
		super(BaseMsgID.CHANGE_ROUTE_ORDER, serialNumber, datas);
		setDatas(datas);
		setSerialNumber(serialNumber);
		setMsgId(BaseMsgID.CHANGE_ROUTE_ORDER);
	}

	@Override
	public int getMsgId() {
		return BaseMsgID.CHANGE_ROUTE_ORDER;
	}

	@Override
	public void setDatas(byte[] datas) {
		super.setDatas(datas);
		ByteArrayInputStream stream = new ByteArrayInputStream(datas);
		DataInputStream in = new DataInputStream(stream);
		try {
			changeType = in.readUnsignedByte();
			byte[] b = new byte[8];
			in.read(b);
			routeId = new String(b,"GBK");
			routeType = in.readByte();
			if (routeType == 0) {
				direction = in.readUnsignedByte();
			}
			uponStationNum = in.readByte();
			uponMarkerNum = in.readByte();
			if (routeType == 0) {
				downStationNum = in.readByte();
				downMarkerNum = in.readByte();
			}
			byte[] rn = new byte[20];
			in.read(rn);
			routeName = new String(rn, "GBK");
			byte[] sp = new byte[20];
			in.read(sp);
			startPlace = new String(sp, "GBK");
			byte[] ep = new byte[20];
			in.read(ep);
			endPlace = new String(ep, "GBK");
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (stream != null) {
					stream.close();
				}
				if (in != null) {
					in.close();
				}
			} catch (IOException e) {
				e.printStackTrace();
			}

		}
	}

	/**
	 * @return 线路Id
	 */
	public String getRouteId() {
		return routeId;
	}

	/**
	 * @return 线路类型 0：双向 2：环线
	 */
	public int getRouteType() {
		return routeType;
	}

	/**
	 * @return 上行站点总数
	 */
	public int getUponStationNum() {
		return uponStationNum;
	}

	/**
	 * @return 上行标记点总数
	 */
	public int getUponMarkerNum() {
		return uponMarkerNum;
	}

	/**
	 * @return 下行站点总数
	 */
	public int getDownStationNum() {
		return downStationNum;
	}

	/**
	 * @return 下行标记点总数
	 */
	public int getDownMarkerNum() {
		return downMarkerNum;
	}

	/**
	 * @return 线路名称
	 */
	public String getRouteName() {
		return routeName;
	}

	/**
	 * @return 始发场站
	 */
	public String getStartPlace() {
		return startPlace;
	}

	/**
	 * @return 终点场站
	 */
	public String getEndPlace() {
		return endPlace;
	}

	/**
	 * @return 切换类型 0：切换上下行 1：切换线路
	 */
	public int getChangeType() {
		return changeType;
	}

	
	
	public void setRouteId(String routeId) {
		this.routeId = routeId;
	}

	public void setDirection(int direction) {
		this.direction = direction;
	}

	public void setRouteType(int routeType) {
		this.routeType = routeType;
	}

	public void setRouteName(String routeName) {
		this.routeName = routeName;
	}

	/**
	 * @return 方向 0：上行 1：下行 
	 */
	public int getDirection() {
		return direction;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "P_PChangeRoute [" + (routeId != null ? "routeId=" + routeId + ", " : "") + "changeType=" + changeType
				+ ", direction=" + direction + ", routeType=" + routeType + ", uponStationNum=" + uponStationNum
				+ ", uponMarkerNum=" + uponMarkerNum + ", downStationNum=" + downStationNum + ", downMarkerNum="
				+ downMarkerNum + ", " + (routeName != null ? "routeName=" + routeName + ", " : "")
				+ (startPlace != null ? "startPlace=" + startPlace + ", " : "")
				+ (endPlace != null ? "endPlace=" + endPlace : "") + "]";
	}

}
