package com.uninew.ftp;

import it.sauronsoftware.ftp4j.FTPDataTransferListener;

import java.io.File;
import java.util.List;

import android.app.ProgressDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.WindowManager;

import com.uninew.JT808.util.NetUtils;
import com.uninew.JT808.util.UnzipTools;
import com.uninew.JT808.util.UnzipTools.IUnzipFinishCallBack;
import com.uninew.file.check.VoiceIntegrity;
import com.uninew.file.json.FilePushPoll;

public class FileDownloadByFTP implements IUnzipFinishCallBack{

	private static final String TAG = "FileDownloadByFTP";
	private static final boolean D = true;
	private volatile static FileDownloadByFTP instance;
	private String mHost;
	private int mPort = 21;
	private String mUsername;
	private String mPassword;
	private String mRemoteFileName;
	private File mLocalFile;
	private IFTPSerManage ftpServiceManage;
	private ProgressDialog pd = null;
	private Context mContext;
	private UnzipTools unzipTools;
	private String mPath;
	private long fileSize;
	private static final String savePath = "/mnt/sdcard/download";
	private static final int WHAT_START_DOWNLOAD = 0x01;
	private static final int WHAT_FINISH_DOWNLOAD = 0x02;
	private static final int WHAT_UPDATE_DOWNLOAD = 0x03;
	private IUpdateFileCallBack mCallBack;
	private UpdateApkReceiver mReceiver;
	private boolean isDownFailure = false;
	private Handler mHandler = new Handler(){
		public void handleMessage(Message msg) {
			switch (msg.what) {
			case WHAT_START_DOWNLOAD:
				openDailog();
				break;
			case WHAT_FINISH_DOWNLOAD:
				closeDailog();
				break;
			case WHAT_UPDATE_DOWNLOAD:
				int size = msg.arg1;
				if(pd != null){
					pd.incrementProgressBy(size);
				}
				break;
			default:
				break;
			}
		};
	};
	
	public void setCallBack(IUpdateFileCallBack mCallBack){
		this.mCallBack = mCallBack;
	}
	
	public interface IUpdateFileCallBack{
		void onDownLoadFinish(boolean isSuccess,String savePath);
		void onUpdateFinish(boolean isSuccess,String updateName);
	}
	
	private FileDownloadByFTP(Context context){
		ftpServiceManage = FTPServiceManage.getInstance();
		unzipTools = UnzipTools.getInstance();
		unzipTools.setCallBack(this);
		mContext = context;
	}
	
	public static FileDownloadByFTP getInstance(Context context){
		if(instance != null){
			
		}else{
			synchronized (FileDownloadByFTP.class) {
				if(instance == null){
					instance = new FileDownloadByFTP(context);
				}
			}
		}
		return instance;
	}

	public synchronized void downFile(String host,String username,String password){
		File file = new File(savePath);
		if(!file.exists()){
			file.mkdirs();
		}
		String[] paths = host.replace("ftp://", "").split("/");
		if(paths[0].contains(":")){
			String[] url =  paths[0].split(":");
			mHost =url[0];
			mPort = getInteger(url[1]);
			mPath =  host.replace("ftp://", "").replace(paths[0]+"/", "");
		}else{
			mHost = paths[0];
			mPath =  host.replace("ftp://", "").replace(mHost+"/", "");
		}
		mRemoteFileName = paths[paths.length -1].replace("/", "");
		
//		String[] s = mRemoteFileName.split("/");
//		if(s != null && s.length > 1){
//			String src = s[s.length - 1];
//			File file2 = new File(mRemoteFileName.replace(src, ""));
//			if(!file2.exists()){}
//		}
		mUsername = username;
		mPassword = password;
		register();
		mLocalFile = new File(savePath+File.separator+mRemoteFileName);
		if(mLocalFile.exists()){
			mLocalFile.delete();
		}
		Thread thread = new Thread(downRunnable);
		thread.start();
	}
	
	private Runnable downRunnable = new Runnable() {
		
		@Override
		public void run() {
			ftpServiceManage.connetFTPSer(mHost,mPort, mUsername, mPassword);
			if(ftpServiceManage.isConnet()){
				fileSize = ftpServiceManage.getFileSize(mPath);
				ftpServiceManage.downloadFile(mPath, mLocalFile, transferListener);
			}
		}
	};
	
	private FTPDataTransferListener transferListener = new FTPDataTransferListener() {
		
		@Override
		public void transferred(int arg0) {
			if(D)Log.d(TAG, "接收数据："+arg0+"总大小："+fileSize);
			Message msg = Message.obtain();
			msg.arg1 = arg0;
			msg.what = WHAT_UPDATE_DOWNLOAD;
			mHandler.sendMessage(msg);
		}
		
		
		@Override
		public void started() {
			if(D)Log.d(TAG, "开始下载");
			mHandler.sendEmptyMessage(WHAT_START_DOWNLOAD);
		}
		
		@Override
		public void failed() {
//			ftpServiceManage.disConnet(true);
//			mCallBack.onDownLoadFinish(false, null);
//			mHandler.sendEmptyMessage(WHAT_FINISH_DOWNLOAD);
			isDownFailure = true;
		}
		
		@Override
		public void completed() {
			if(D)Log.d(TAG, "下载完成");
			mHandler.sendEmptyMessage(WHAT_FINISH_DOWNLOAD);
			mCallBack.onDownLoadFinish(true, savePath+File.separator+mRemoteFileName);
			ftpServiceManage.disConnet(true);
			if(mRemoteFileName.toLowerCase().endsWith(".zip")){
				unzipTools.unZipFile(mLocalFile, savePath);
			}else if(mRemoteFileName.toLowerCase().endsWith(".apk")){
				sendApkUpdateRequest(savePath+File.separator+mRemoteFileName,0);
			}
			isDownFailure = false;
		}
		
		@Override
		public void aborted() {
//			ftpServiceManage.disConnet(true);
//			mCallBack.onDownLoadFinish(false, null);
//			mHandler.sendEmptyMessage(WHAT_FINISH_DOWNLOAD);
			isDownFailure = true;
		}
	};
	
	private void openDailog(){
		if(pd == null){
			pd = new ProgressDialog(mContext);
			//设置最大值为100  
			pd.setMax((int)fileSize);  
			//设置进度条风格STYLE_HORIZONTAL  
			pd.setProgressStyle( ProgressDialog.STYLE_HORIZONTAL);  
			pd.setTitle("文件下载");  
			pd.getWindow().setType(WindowManager.LayoutParams.TYPE_SYSTEM_ALERT);
			pd.incrementProgressBy(1);
			pd.show();
		}
	}
	
	private void closeDailog(){
		if(pd != null){
			pd.cancel();
			pd = null;
		}
	}

	@Override
	public void onUnzipFinish(boolean isSuccess, String path) {
		if(D)Log.d(TAG, "解压："+isSuccess + "地址："+path);
		if(isSuccess){
			mLocalFile.delete();
			VoiceIntegrity integrity = null;
			if(path.contains("公交资源文件")){
				integrity = new VoiceIntegrity(path);
			}else{
				integrity = new VoiceIntegrity(path+"/公交资源文件");
			}
			List<String> missFile = integrity.getDeficiencyVoices();
			if(D)Log.d(TAG,missFile.toString());
			unRegister();
			if(missFile.size() < 4){
				FilePushPoll pushPoll = FilePushPoll.getInstance();
				File file = new File("/mnt/sdcard/公交资源文件/");
				File file2 = new File("/mnt/sdcard/公交资源文件_备份/");
				if(file.exists()){
					pushPoll.deleteFiles(file);
				}
				if(file2.exists()){
					pushPoll.deleteFiles(file2);
				}
				int result1= pushPoll.copy(path+"/公交资源文件", "/mnt/sdcard/公交资源文件/");
				int result2 =pushPoll.copy(path+"/公交资源文件", "/mnt/sdcard/公交资源文件_备份/");
				if(result1 == 0 && result2 == 0){
					mCallBack.onUpdateFinish(true, mRemoteFileName);
				}else{
					mCallBack.onUpdateFinish(false, null);
				}
			}else{
				mCallBack.onUpdateFinish(false, null);
			}
		}
	}
	
	/**
	 * apk升级应答
	 */
	private static final String ApkLinkUpdateResponse="Com.NETLink.Update.Back";
	/**
	 * 接收apk安装结果 0:失败,1:成功
	 */
	private static final String KEY_APKINSTALL_RESULT="Back";
	
	/**
	 * apk升级请求
	 */
	private static final String ApkLinkUpdateRequest = "Com.NETLink.Update";
	/**
	 * apk路径
	 */
	private static final String KEY_PATH="path";
	/**
	 * 升级类型
	 */
	private static final String KEY_TYPE="type";
	
	private void sendApkUpdateRequest(String path,int type){
		Intent intent = new Intent(ApkLinkUpdateRequest);
		intent.putExtra(KEY_PATH, path);
		intent.putExtra(KEY_TYPE, type);
		mContext.sendBroadcast(intent);
		Log.e("广播工具类", "发送apk升级广播"+path+",\t"+type);
	}
	
	
	private void register(){
		if(mReceiver == null){
			mReceiver = new UpdateApkReceiver();
		}
		IntentFilter filter = new IntentFilter();
		filter.addAction(ApkLinkUpdateResponse);
		filter.addAction(ConnectivityManager.CONNECTIVITY_ACTION);
		mContext.registerReceiver(mReceiver, filter);
	}
	private void unRegister(){
		if(mReceiver != null){
			mContext.unregisterReceiver(mReceiver);
		}
	}
	
	private class UpdateApkReceiver extends BroadcastReceiver{

		@Override
		public void onReceive(Context context, Intent intent) {
			switch (intent.getAction()) {
			case ApkLinkUpdateResponse:
				int result = intent.getIntExtra(KEY_APKINSTALL_RESULT, -1);
				if(result == 1){
					mLocalFile.delete();
					mCallBack.onUpdateFinish(true, mRemoteFileName);
				}else{
					mCallBack.onUpdateFinish(false, null);
				}
				unRegister();
				break;
			case ConnectivityManager.CONNECTIVITY_ACTION:
				if(NetUtils.isConnected(context) && isDownFailure){
					new Thread(new Runnable() {
						
						@Override
						public void run() {
							ftpServiceManage.continueDownload(mPath, mLocalFile, transferListener);
						}
					}).start();
				}
				break;
			default:
				break;
			}
			
		}
		
	}
	
	
	private int getInteger(String v){
		try {
			return Integer.parseInt(v);
		} catch (NumberFormatException e) {
			return 21;
		}
	}
}
