package com.uninew.JT808.bean;

import java.io.Serializable;

/**
 * 报警标志
 * @author rong
 *
 */
public class AlarmFlag implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 2304917061916632147L;
	
	private int isEmergency = 0;//紧急报警
	private int isSpeeding = 0;//超速报警
	private int isFatigue = 0;//疲劳驾驶
	private int isGNSSFault = 0;//GNSS故障
	private int isGNSSAerial = 0;//GNSS天线未接或被剪断
	private int isGNSSShortCircuit = 0;//GNSS天线短路
	private int isEarlySpeeding = 0;//超速预警
	
	public AlarmFlag() {
		super();
	}
	
	/**
	 * @return 紧急报警  -1：关  1：开 0：不处理 
	 */
	public int getEmergency() {
		return isEmergency;
	}
	
	/**
	 * @param  紧急报警 true：开 false：关
	 */
	public void setEmergency(boolean isEmergency) {
		if(isEmergency){
			this.isEmergency = 1;
		}else{
			this.isEmergency = -1;
		}
	}
	
	/**
	 * @return 超速报警  -1：关  1：开 0：不处理 
	 */
	public int getSpeeding() {
		return isSpeeding;
	}
	/**
	 * @param 超速报警 true：开 false：关
	 */
	public void setSpeeding(boolean isSpeeding) {
		if(isSpeeding){
			this.isSpeeding = 1;
		}else{
			this.isSpeeding = -1;
		}
	}
	/**
	 * @return 疲劳驾驶  -1：关  1：开 0：不处理 
	 */
	public int getFatigue() {
		return isFatigue;
	}
	/**
	 * @param 疲劳驾驶 true：开 false：关
	 */
	public void setFatigue(boolean isFatigue) {
		if(isFatigue){
			this.isFatigue = 1;
		}else{
			this.isFatigue = -1;
		}
	}
	/**
	 * @return GNSS故障   -1：关  1：开 0：不处理 
	 */
	public int getGNSSFault() {
		return isGNSSFault;
	}
	/**
	 * @param GNSS故障  true：开 false：关
	 */
	public void setGNSSFault(boolean isGNSSFault) {
		if(isGNSSFault){
			this.isGNSSFault = 1;
		}else{
			this.isGNSSFault = -1;
		}
	}
	/**
	 * @return GNSS天线未接或被剪断  -1：关  1：开 0：不处理 
	 */
	public int getGNSSAerial() {
		return isGNSSAerial;
	}
	/**
	 * @param GNSS天线未接或被剪断 true：开 false：关
	 */
	public void setGNSSAerial(boolean isGNSSAerial) {
		if(isGNSSAerial){
			this.isGNSSAerial = 1;
		}else{
			this.isGNSSAerial = -1;
		}
	}
	/**
	 * @return GNSS天线短路 -1：关  1：开 0：不处理 
	 */
	public int getGNSSShortCircuit() {
		return isGNSSShortCircuit;
	}
	/**
	 * @param GNSS天线短路 true：开 false：关
	 */
	public void setGNSSShortCircuit(boolean isGNSSShortCircuit) {
		if(isGNSSShortCircuit){
			this.isGNSSShortCircuit = 1;
		}else{
			this.isGNSSShortCircuit = -1;
		}
	}
	/**
	 * @return 超速预警  -1：关  1：开 0：不处理 
	 */
	public int getEarlySpeeding() {
		return isEarlySpeeding;
	}
	/**
	 * @param 超速预警 true：开 false：关
	 */
	public void setEarlySpeeding(boolean isEarlySpeeding) {

		if(isEarlySpeeding){
			this.isEarlySpeeding = 1;
		}else{
			this.isEarlySpeeding = -1;
		}
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "AlarmFlag [isEmergency=" + isEmergency + ", isSpeeding=" + isSpeeding + ", isFatigue=" + isFatigue
				+ ", isGNSSFault=" + isGNSSFault + ", isGNSSAerial=" + isGNSSAerial + ", isGNSSShortCircuit="
				+ isGNSSShortCircuit + ", isEarlySpeeding=" + isEarlySpeeding + "]";
	}
	
}
