package com.uninew.JT808.bean;

import java.io.Serializable;
import java.util.Arrays;
/**
 * 消息基类
 * @author rong
 *
 */
public class MessageBaseData implements Serializable{
	
	private int msgId;//消息ID
	private int serialNumber;//流水号
	private byte[] datas;//消息体
	
	public MessageBaseData() {
		
	}
	/**
	 * 消息基类
	 * @param msgId 消息ID
	 * @param serialNumber 流水号
	 * @param datas 消息体
	 */
	public MessageBaseData(int msgId,int serialNumber,byte[] datas) {
		super();
		this.msgId = msgId;
		this.serialNumber = serialNumber;
		this.datas = datas;
	}
	
	
	/**
	 * 消息基类
	 * @param msgId 消息ID
	 * @param datas 消息体
	 */
	public MessageBaseData(int msgId, byte[] datas) {
		super();
		this.msgId = msgId;
		this.datas = datas;
	}
	
	/**
	 * @return 流水号
	 */
	public int getSerialNumber() {
		return serialNumber;
	}
	
	/**
	 * @param 流水号
	 */
	public void setSerialNumber(int serialNumber) {
		this.serialNumber = serialNumber;
	}
	/**
	 * @return 消息ID
	 */
	public  int getMsgId() {
		return msgId;
	}
	/**
	 * @param msgId 消息Id
	 */
	public  void setMsgId(int msgId) {
		this.msgId = msgId;
	}
	/**
	 * @return 消息体
	 */
	public  byte[] getDatas() {
		return datas;
	}
	/**
	 * @param datas 消息体
	 */
	public  void setDatas(byte[] datas) {
		this.datas = datas;
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "MessageBaseData [msgId=" + msgId + ", serialNumber=" + serialNumber + ", "
				+ (datas != null ? "datas=" + Arrays.toString(datas) : "") + "]";
	}
	
	public Object getObject(byte[] datas){
		return null;
	}
	
}
