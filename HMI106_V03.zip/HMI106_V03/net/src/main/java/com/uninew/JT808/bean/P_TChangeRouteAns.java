package com.uninew.JT808.bean;

import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.IOException;

import com.uninew.net.common.BaseMsgID;

/**
 * 终端线路切换通知应答
 * 
 * @author rong
 *
 */
public class P_TChangeRouteAns extends MessageBaseData {

	/**
	 * 
	 */
	private static final long serialVersionUID = 3751841539076205077L;
	private int ansSerialNumber;// 应答对应流水号
	private int result;// 0：线路存在信息匹配；1：线路存在站点数量不匹配；2：线路存在标记点数量不匹配；3：线路不存在

	/**
	 * 注册应答
	 * 
	 * @param datas
	 *            消息体
	 */
	public P_TChangeRouteAns(int serialNumber, byte[] datas) {
		super(BaseMsgID.TERMINAL_CHANGE_ROUTE_ANS, serialNumber, datas);
		setSerialNumber(serialNumber);
		setDatas(datas);
	}

	@Override
	public int getMsgId() {
		return BaseMsgID.TERMINAL_CHANGE_ROUTE_ANS;
	}

	@Override
	public void setDatas(byte[] datas) {
		super.setDatas(datas);
		ByteArrayInputStream stream = new ByteArrayInputStream(datas);
		DataInputStream in = new DataInputStream(stream);
		try {
			ansSerialNumber = in.readShort();
			result = in.readUnsignedByte();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (stream != null) {
					stream.close();
				}
				if (in != null) {
					in.close();
				}
			} catch (IOException e) {
				e.printStackTrace();
			}

		}
	}

	/**
	 * @return 应答流水号
	 */
	public int getAnsSerialNumber() {
		return ansSerialNumber;
	}

	/**
	 * 
	 * @return 结果 0：线路存在信息匹配；1：线路存在站点数量不匹配；2：线路存在标记点数量不匹配；3：线路不存在
	 * 
	 */
	public int getResult() {
		return result;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "P_TChangeRouteAns [ansSerialNumber=" + ansSerialNumber + ", result=" + result + "]";
	}

}
