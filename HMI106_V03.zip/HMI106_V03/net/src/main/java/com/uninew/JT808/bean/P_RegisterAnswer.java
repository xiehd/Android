package com.uninew.JT808.bean;

import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.IOException;
import java.util.Arrays;

import com.uninew.net.common.BaseMsgID;
/**
 * 注册应答
 * @author rong
 *
 */
public class P_RegisterAnswer extends MessageBaseData {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 6743030803637803710L;
	private int serialNumber;//流水号
	private int result;//结果 0：成功 1：车辆已被注册 2：数据库无该车辆信息 3：终端已被注册 4：数据库无该终端信息
	private byte[] auth; // 鉴权码
	
	/**
	 * 注册应答
	 * @param datas 消息体
	 */
	public P_RegisterAnswer(int serialNumber,byte[] datas) {
		super(BaseMsgID.TERMINAL_REGIST_ANS,serialNumber, datas);
		setSerialNumber(serialNumber);
		setDatas(datas);
	}
	
	@Override
	public int getMsgId() {
		return BaseMsgID.TERMINAL_REGIST_ANS;
	}
	
	@Override
	public void setDatas(byte[] datas) {
		super.setDatas(datas);
		ByteArrayInputStream stream = new ByteArrayInputStream(datas);
		DataInputStream in = new DataInputStream(stream);
		try {
			serialNumber = in.readShort();
			result = in.readUnsignedByte();
			if(result == 0){
				int lengh = in.available();
				auth = new byte[lengh];
				in.read(auth);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			try {
				if (stream != null) {
					stream.close();
				}
				if (in != null) {
					in.close();
				}
			} catch (IOException e) {
				e.printStackTrace();
			}

		}
	}

	/**
	 * 
	 * @return 流水号
	 */
	public int getSerialNumber() {
		return serialNumber;
	}

	/**
	 * 
	 * @return 结果 0：成功 1：车辆已注册 2：数据库无该车辆信息
	 * 			3：终端已被注册 4：数据库中无该终端
	 */
	public int getResult() {
		return result;
	}

	/**
	 * 
	 * @return 鉴权码 如果为null，就是没有
	 */
	public byte[] getAuth() {
		return auth;
	}

	@Override
	public String toString() {
		return "P_RegisterAnswer [serialNumber=" + serialNumber + ", result=" + result + ", "
				+ (auth != null ? "auth=" + Arrays.toString(auth) : "") + "]";
	}
	
}
