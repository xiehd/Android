package com.uninew.common.action;

/**
 * 所有服务的Action
 * @author Administrator
 *
 */
public interface DefineServiceAction {

	/**主应用包名称*/
	public String Pkg_Main="com.uninew.bus";
	/**MMS应用包名称*/
	public String Pkg_MMS="com.uninew.mms";
	/**Net应用包名称*/
	public String Pkg_Net="com.uninew.net";
	/**Update应用包名称*/
	public String Pkg_Update="com.uninew.update";
	/**Settings应用包名称*/
	public String Pkg_Settings="com.uninew.settings";
	
	
	/**主管理服务*/
	public String Action_MainService="com.uninew.bus.MainService";
	
	/**文件管理服务*/
	public String Action_FileService="com.uninew.bus.file.FileService";
	
	/**声音管理服务*/
	public String Action_AudioService="com.uninew.audio.AudioServer";

	/**定位管理服务*/
	public String Action_LocationService="com.uninew.location.LocationService";
	
	/**设置管理服务*/
	public String Action_SettingService="com.uninew.settings.SettingService";
	
	/**MMS管理服务*/
	public String Action_MMS="com.uninew.mms.McuService";
	
	/**NET管理服务*/
	public String Action_Net="com.uninew.bus.net.NetMainService";
	
	/**Update管理服务*/
	public String Action_Update="com.uninew.update.UpdateFileService";
	
	
	
}
