package com.uninew.common.audio;
/**
 * 声道优先级
 */
public enum VoicePriority {
	/**车外喊话*/
	megaphone_out(0, 0, true),
	/**车内喊话*/
	megaphone_in(1, 1, true),
	/**报站*/
	broadcast(2, 2, false), 
	/**TTS*/
	TTS(3, 3, true);
	
	// 成员变量
	private int srcId;
	private boolean isOut;
	private int priority;

	// 构造方法
	private VoicePriority(int srcId, int priority, boolean isOut) {
		this.srcId = srcId;
		this.isOut = isOut;
		this.priority = priority;
	}

	public int getSrcId() {
		return srcId;
	}

	public int getPriority() {
		return priority;
	}

	public boolean getIsOut() {
		return isOut;
	}

}
