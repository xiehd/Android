package com.uninew.common;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.math.BigInteger;
import java.util.List;

import android.app.ActivityManager;
import android.app.ActivityManager.RunningTaskInfo;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.util.Log;

/**
 * 跟App相关的辅助类
 * 
 * 
 * 
 */
public class AppUtils {
	private static final String TAG = "AppUtils";
	public static int i = 0;
	public static final String DEL_NOTIFICATION_ACTION = "com.action.del_notification";
	public static final String DEL_NOTIFICATION_KEY = "del_notification_key";
	public static final String COLSE_MSG_ACTION = "Com.Uninew.MsgClose";
	public static final String COLSE_ALARM_ACTION = "Com.Uninew.AlarmClose";
	
	private AppUtils() {
		/* cannot be instantiated */
		throw new UnsupportedOperationException("cannot be instantiated");

	}

	/**
	 * 获取应用程序名称
	 */
	public static String getAppName(Context context) {
		try {
			PackageManager packageManager = context.getPackageManager();
			PackageInfo packageInfo = packageManager.getPackageInfo(context.getPackageName(), 0);
			int labelRes = packageInfo.applicationInfo.labelRes;
			return context.getResources().getString(labelRes);
		} catch (NameNotFoundException e) {
			e.printStackTrace();
		}
		return null;
	}

	/**
	 * [获取应用程序版本名称信息]
	 * 
	 * @param context
	 * @return 当前应用的版本名称
	 */
	public static String getVersionName(Context context) {
		try {
			PackageManager packageManager = context.getPackageManager();
			PackageInfo packageInfo = packageManager.getPackageInfo(context.getPackageName(), 0);
			return packageInfo.versionName;

		} catch (NameNotFoundException e) {
			e.printStackTrace();
		}
		return null;
	}

	
	public static String getTopActivity(Context context){
		ActivityManager manager = (ActivityManager)context.getSystemService(Context.ACTIVITY_SERVICE) ;
		List<RunningTaskInfo> runningTaskInfos = manager.getRunningTasks(1) ;
		if(runningTaskInfos != null)
			return (runningTaskInfos.get(0).topActivity).toString() ;
		else			
			return null ;
	}
	

	/**
	 * 删除文件的方法
	 * @param file
	 */
	public static void deleteFile(File file) {
		if (file.exists()) { // 判断文件是否存在
			if (file.isFile()) { // 判断是否是文件
				file.delete(); // delete()方法 你应该知道 是删除的意思;
			}else{
				Log.e(TAG, "不是文件！");
			}
		} else {
			Log.e(TAG, "文件不存在！");
		}
	}
	/**
	 * 根据名称删除对应的文件
	 * @param name
	 * @param file
	 */
	public static void deleteFiles(String name,File file){
		if (file.exists()) { // 判断文件是否存在
			if (file.isDirectory()) { // 判断是否是文件
				File[] files = file.listFiles();
				if(files != null && files.length > 0){
					for(File file2:files){
						if(file2.isFile()){
							if((file2.getName().startsWith(name))){
								deleteFile(file2);
								Log.d(TAG, "File:"+file2.getName());
							}
						}else {
							Log.e(TAG, "不是文件！");
						}
					}
				}else{
					Log.e(TAG, "不存在子文件！");
				}
			}else{
				Log.e(TAG, "不是文件夹！");
			}
		} else {
			Log.e(TAG, "文件不存在！");
		}
	}
	
    /** 
     * the traditional io way 
     *  读取文件内容将其转化为byte数组
     * @param filename 
     * @return 
     * @throws IOException 
     */  
    public static byte[] toByteArray(String filename) throws IOException {  
  
        File f = new File(filename);  
        if (!f.exists()) {  
            throw new FileNotFoundException(filename);  
        }  
  
        ByteArrayOutputStream bos = new ByteArrayOutputStream((int) f.length());  
        BufferedInputStream in = null;  
        try {  
            in = new BufferedInputStream(new FileInputStream(f));  
            int buf_size = 1024;  
            byte[] buffer = new byte[buf_size];  
            int len = 0;  
            while (-1 != (len = in.read(buffer, 0, buf_size))) {  
                bos.write(buffer, 0, len);  
            }  
            return bos.toByteArray();  
        } catch (IOException e) {  
            e.printStackTrace();  
            throw e;  
        } finally {  
            try {  
                in.close();  
            } catch (IOException e) {  
                e.printStackTrace();  
            }  
            bos.close();  
        }  
    } 
    
    /** 
     * 将byte[]转为各种进制的字符串 
     * @param bytes byte[] 
     * @param radix 基数可以转换进制的范围，从Character.MIN_RADIX到Character.MAX_RADIX，超出范围后变为10进制 
     * @return 转换后的字符串 
     */  
    public static String binary(byte[] bytes, int radix){  
        return new BigInteger(1, bytes).toString(radix);// 这里的1代表正数  
    } 
    
	/**
	  * 判断字符串是否是整数
	  */
	public static boolean isInteger(String value) {
		try {
			Double.parseDouble(value);
			return true;
		} catch (NumberFormatException e) {
			return false;
		}
	}

}
