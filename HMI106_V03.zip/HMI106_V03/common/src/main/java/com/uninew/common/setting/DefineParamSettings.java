package com.uninew.common.setting;

public interface DefineParamSettings {

	/**报站模式设置*/
	public int Type_ReportSettings=0x01;
	/**通讯模式设置*/
	public int Type_CommSettings=0x02;
	
	/**手动报站*/
	public int ReportModel_Manul=0x02;
	/**自动报站*/
	public int ReportModel_Auto=0x01;
	
	/**MP3报站音频格式*/
	public int AudioFormat_MP3=0x01;
	/**WAV报站音频格式*/
	public int AudioFormat_WAV=0x02;
	
	/**视频格式：DVR*/
	public int VideoType_DVR=0x01;
	/**视频格式：后门*/
	public int VideoType_BackDoor=0x02;
	
	/**通讯模式：网络*/
	public int CommModel_Net=0x01;
	/**通讯模式：串口*/
	public int CommModel_COM=0x02;
	
	/**营运状态：营运*/
	public int RunState_Running=0x01;
	/***营运状态：停运*/
	public int RunState_Stopped=0x02;
}
