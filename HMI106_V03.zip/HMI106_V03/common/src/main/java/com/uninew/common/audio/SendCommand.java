package com.uninew.common.audio;

import java.util.ArrayList;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

public class SendCommand {
	private Context mContext;
	public static Intent  lastIntent;

	public SendCommand(Context mContext) {
		super();
		this.mContext = mContext;
	}

	/**
	 * 请求结果应答
	 * 
	 * @param result
	 *            0x00 失败 0x01 成功
	 */
	public void sendResultResponse(int srcId, int result,int channel) {
		Intent intent = new Intent(AudioConstant.AUDIO_MANAGER_ACTION);
		Bundle bundle = new Bundle();
		bundle.putInt("id", AudioConstant.SRC_RESPONSE_ID);
		bundle.putInt("srcId", srcId);
		bundle.putInt("result", result);
		bundle.putInt(AudioConstant.KEY_CHANNEL, channel);
		intent.putExtras(bundle);
		mContext.sendBroadcast(intent);
	}

	/**
	 * 发送命令
	 * 
	 * @param command
	 *            0x00 播放 0x01 暂停 0x02 停止 0x03恢复播放
	 */
	public void sendCommand(int srcId, int command) {
		Intent intent = new Intent(AudioConstant.AUDIO_MANAGER_ACTION);
		Bundle bundle = new Bundle();
		bundle.putInt(AudioConstant.KEY_ID, AudioConstant.SRC_COMMAND_ID);
		bundle.putInt(AudioConstant.KEY_SRCID, srcId);
		bundle.putInt(AudioConstant.KEY_COMMAND, command);
		intent.putExtras(bundle);
		mContext.sendBroadcast(intent);
	}

	/**
	 * 报站SRC请求
	 * @param paths
	 */
	public void sendBroadCastSrcRequest(ArrayList<String> paths){
		if (paths==null || paths.size() <= 0) {
			return;
		}
		sendSrcRequest(VoicePriority.broadcast.getSrcId(), VoicePriority.broadcast.getPriority(), 
				VoicePriority.broadcast.getIsOut(), paths,AudioConstant.CHANNEL_BUSIN);
	}
	
	/**
	 * TTS SRC请求
	 * @param strings 需要播放的文本组合
	 * @param channel 通道选择：0-报站器 1-车内喇叭，2-车外喇叭
	 */
	public void sendTTSSrcRequest(ArrayList<String> strings,int channel){
		sendSrcRequest(VoicePriority.TTS.getSrcId(), VoicePriority.TTS.getPriority(), 
				VoicePriority.TTS.getIsOut(), strings,channel);
	}
	
	
	/**
	 * 车外喊话SRC请求
	 * @param paths
	 */
	public void sendMegaphoneOutSrcRequest(){
		sendSrcRequest(VoicePriority.megaphone_out.getSrcId(), VoicePriority.megaphone_out.getPriority(), 
				VoicePriority.megaphone_out.getIsOut(), null,AudioConstant.CHANNEL_BUSOUT);
	}
	
	/**
	 * 车内喊话SRC请求
	 * @param paths
	 */
	public void sendMegaphoneInSrcRequest(){
		sendSrcRequest(VoicePriority.megaphone_in.getSrcId(), VoicePriority.megaphone_in.getPriority(), 
				VoicePriority.megaphone_in.getIsOut(), null,AudioConstant.CHANNEL_BUSIN);
	}
	
	
	public void sendBroadCastSrcRequest(int srcId, int level, boolean isOut,
			ArrayList<String> paths){
		sendSrcRequest(srcId, level, isOut, paths, AudioConstant.CHANNEL_BUSIN);
	}
	/**
	 * 发送SRC请求命令
	 * 
	 * @param action
	 * @param channel 0-内置喇叭，1-车内 ，2-车外
	 * 
	 */
	private void sendSrcRequest(int srcId, int level, boolean isOut,
			ArrayList<String> paths,int channel) {
		Intent intent = new Intent(AudioConstant.AUDIO_MANAGER_ACTION);
		Bundle bundle = new Bundle();
		bundle.putInt(AudioConstant.KEY_ID, AudioConstant.SRC_REQUEST_ID);
		bundle.putInt(AudioConstant.KEY_CHANNEL, channel);
		bundle.putInt(AudioConstant.KEY_SRCID, srcId);
		bundle.putInt(AudioConstant.KEY_LEVEL, level);
		bundle.putBoolean(AudioConstant.KEY_ISOUT, isOut);
		bundle.putStringArrayList(AudioConstant.KEY_PATHS, paths);
		intent.putExtras(bundle);
		lastIntent=intent;
		mContext.sendBroadcast(intent);
	}

	public void sendReplay(){
		if (lastIntent!=null) {
			mContext.sendBroadcast(lastIntent);
		}
	}
	
	/**
	 * 发送SRC通知
	 * 
	 * @param action
	 *            0x00 播放 0x01 暂停 0x02 停止 0x03恢复播放
	 */
	public void sendSrcNotify(int srcId, int action) {
		Intent intent = new Intent(AudioConstant.AUDIO_MANAGER_ACTION);
		Bundle bundle = new Bundle();
		bundle.putInt(AudioConstant.KEY_ID, AudioConstant.SRC_NOTIFY_ID);
		bundle.putInt(AudioConstant.KEY_SRCID, srcId);
		bundle.putInt(AudioConstant.KEY_STATE, action);
		intent.putExtras(bundle);
		mContext.sendBroadcast(intent);
	}

}
