package com.uninew.common.action;

public interface DefineActivityAction {
	
	/**设置主Activity对应的Action*/
	public String Action_SettingsActivity="com.uninew.setting.view.SettingsActivity";
	
	/**维护主Activity对应的Action*/
	public String Action_MaintenanceActivity="com.uninew.maintenance.view.MaintenanceActivity";
	
	/**状态主Activity对应的Action*/
	public String Action_StateActivity="com.uninew.state.view.StateActivity";
	
	/**采集主Activity对应的Action*/
	public String Action_CollectActivity="com.uninew.collect.CollectActivity";
	
	/**线路主Activity对应的Action*/
	public String Action_RouteActivity="com.uninew.bus.ChangeRouteActivity";
	
	/**调度主Activity对应的Action*/
	public String Action_WorkActivity="com.uninew.bus.WorkActivity";
	
	/**历史记录主Activity对应的Action*/
	public String Action_HistoryActivity="com.uninew.history.view.HistoryActivity";
	
	/**历史记录主Activity对应的Action*/
	public String Action_EngineeringActivity="com.uninew.bus.engineering.EngineeringActivity";
	
	
}
