package com.uninew.common.audio;


/**
 * 声道切换管理相关常量类
 * @author Administrator
 *
 */

public class AudioConstant {
	/**声道切换广播Action*/
	public static final String AUDIO_MANAGER_ACTION="uninew.audio.manager";
	
	/**src请求ID*/
	public static final int SRC_REQUEST_ID =0x00;
	/**src请求应答ID*/
	public static final int SRC_RESPONSE_ID=0x01;
	/**src通知ID*/
	public static final int SRC_NOTIFY_ID  =0x02;
	/**src命令ID*/
	public static final int SRC_COMMAND_ID=0x03;
	
	/**消息类型key*/
	public static final String KEY_ID="id";
	/**通道类型*/
	public static final String KEY_CHANNEL="channel";
	/**声道ID key*/
	public static final String KEY_SRCID="srcId";
	/**src等级key*/
	public static final String KEY_LEVEL="level";
	/**src请求结果key*/
	public static final String KEY_RESULT="result";
	/**src状态key*/
	public static final String KEY_STATE="state";
	/**src命令key*/
	public static final String KEY_COMMAND="command";
	/**src是否外部播放key*/
	public static final String KEY_ISOUT="isOut";
	/**src播放路径key*/
	public static final String KEY_PATHS="paths";
	
	/**通道参数:报站器*/
	public static final int CHANNEL_SELF=0;
	/**通道参数:车内*/
	public static final int CHANNEL_BUSIN=1;
	/**通道参数:车外*/
	public static final int CHANNEL_BUSOUT=2;
	/**通道参数:报站器+车内*/
	public static final int CHANNEL_SELFBUSIN=3;
	/**通道参数:报站器+车外*/
	public static final int CHANNEL_SELFBUSOUT=4;
	/**通道参数:车内+车外*/
	public static final int CHANNEL_BUSINOUT=5;
	/**通道参数:报站器+车内+车外*/
	public static final int CHANNEL_ALL=6;
	
	
	/**应答成功*/
	public static final int RESULT_SUCCESS=0x01;
	/**应答失败*/
	public static final int RESULT_FAILURE=0x00;
	
	/**播放命令*/
	public static final int COMMAND_PLAY=0x00;
	/**暂停命令*/
	public static final int COMMAND_PAUSE=0x01;
	/**停止命令*/
	public static final int COMMAND_STOP=0x02;
	
	/**播放通知*/
	public static final int NOTIFY_PLAY=0x00;
	/**暂停通知*/
	public static final int NOTIFY_PAUSE=0x01;
	/**停止通知*/
	public static final int NOTIFY_STOP=0x02;
	
	
	
}
