package com.serialport.apis;

import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;

/**
 * 对发送的消息体进行包装
 * 
 * @author Administrator
 * 
 */
public class SendDataPacket {

	public static byte[] toBytes(byte[] srcDatas) {
		byte[] dstDatas;
		dstDatas = new byte[srcDatas.length + 2 + 2 + 2];
		ByteArrayOutputStream bos = new ByteArrayOutputStream();
		DataOutputStream os = new DataOutputStream(bos);

		try {
			os.writeShort((0xAA55));
			os.write(srcDatas.length + 4);
			os.write(srcDatas);
			byte[] temp = new byte[srcDatas.length + 2];
			temp[0] = (byte) ((srcDatas.length >> 8) & 0xff);
			temp[1] = (byte) ((srcDatas.length) & 0xff);
			System.arraycopy(srcDatas, 0, temp, 2, srcDatas.length);
			short crs = McuCheckSum.check(temp, 0);
			os.writeShort(crs);
			dstDatas = bos.toByteArray();
			os.flush();
			os.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return dstDatas;

	}

}
