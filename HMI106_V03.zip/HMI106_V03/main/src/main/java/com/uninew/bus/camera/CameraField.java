package com.uninew.bus.camera;

import java.util.ArrayList;
import java.util.List;

import com.uninew.bus.channel.VoiceChannelControl;

/**
 * 全局变量
 * 
 * @author Administrator
 * 
 */
public class CameraField {
	/**
	 * 摄像机类控制常量
	 */
	public static final int Camera_close = 1;
	public static final int Camera_destroy = 2;
	public static final int Camera_change = 3;

	/**
	 * 摄像机文字显示
	 */
	public static final String Front_Door = "前门";
	public static final String Back_Door = "后门";
	public static final String Reversing = "倒车";

	// //////////////////////////////////////////////////////////////////////////////////////////

	/**
	 * 视频源集合
	 */
	public static List<VideoState> lst = new ArrayList<VideoState>();
	/**
	 * 关闭视频源集合
	 */
	public static List<VideoState> closeLst = new ArrayList<VideoState>();
	public static VideoState openState;
	public static VideoState closeState;
	public static boolean isOpening = false;// 延时打开是否在打开时间中
	public static VideoState lastState;
	/**
	 * 按键间隔
	 */
	public static long timeInterval = 1000;

	/**
	 * 视频状态优先级
	 */
	public static enum VideoState {
		backDoor("报站后门", "1", 1),
		manual_backDoor("手动后门", "1", 1), 
		manual_DVR("DVR","3",1), 
		manual_reversing("手动倒车", "2", 1), 
		auto_backDoor("自动后门", "1", 3), 
		auto_reversing("自动倒车", "2", 4), 
		auto_backDoor_close("自动后门后门关", "2", 0), 
		auto_reversing_close("自动倒车关", "2", 0);
		// 成员变量
		private String name;
		private String write;
		private int priority;

		// 构造方法
		private VideoState(String name, String write, int priority) {
			if(VoiceChannelControl.equipment_versions == 1){
				if(write.equals("1")){
					this.write = "1";
				}else if(write.equals("3")){
					this.write = "3";
				}else{
					this.write = write;
				}
			}else if(VoiceChannelControl.equipment_versions == 0){
				if(write.equals("1")){
					this.write = "3";
				}else if(write.equals("3")){
					this.write = "1";
				}else{
					this.write = write;
				}
			}
			this.name = name;
//			this.write = write;
			this.priority = priority;
		}

		private VideoState(String name) {
			this.name = name;
		}

		public String getName() {
			return name;
		}

		public int getPriority() {
			return priority;
		}

		public String getWrite() {
			return write;
		}

	}
}
