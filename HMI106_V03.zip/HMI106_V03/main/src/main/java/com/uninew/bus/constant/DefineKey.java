package com.uninew.bus.constant;


/**
 * MCU交互协议对应键值
 * @author Administrator
 *
 */
public class DefineKey {

	/** 语音播报 down */
	public static final byte BUS_BROADCAST_DOWN = 0x30;// 按下
	/** 语音播报up */
	public static final byte BUS_BROADCAST_UP = (byte) 0xB0;// 抬起

	/** 播报停止 */
	public static final byte BUS_VOICE_STOP_DOWN = 0x31;
	/** 播报停止 */
	public static final byte BUS_VOICE_STOP_UP = (byte) 0xB1;

	/** 重新播报 */
	public static final byte BUS_VOICE_REPLAY_DOWN = 0x32;
	/** 重新播报 */
	public static final byte BUS_VOICE_REPLAY_UP = (byte) 0xB2;

	/** 上一站 */
	public static final byte BUS_LAST_DOWN = 0x33;
	/** 上一站 */
	public static final byte BUS_LAST_UP = (byte) 0xB3;
	
	/** 下一站 */
	public static final byte BUS_NEXT_DOWN = 0x34;
	/** 下一站 */
	public static final byte BUS_NEXT_UP = (byte) 0xB4;
	
	/** F6 */
	public static final byte F6_DOWN = 0x35;
	/** F6 */
	public static final byte F6_UP = (byte) 0xB5;
	
	/** F2 */
	public static final byte F2_DOWN = 0x36;
	/** F2*/
	public static final byte F2_UP = (byte) 0xB6;
	
	/** F3 */
	public static final byte F3_DOWN = 0x39;
	/** F3 */
	public static final byte F3_UP = (byte) 0xB9;
	
	/**F1 压下*/
	public static final byte F1_DOWN = 0x37;
	/**F1 抬起*/
	public static final byte F1_UP = (byte) 0xB7;
	
	/**F5*/
	public static final byte F5_DOWN = 0x38;
	/**F5*/
	public static final byte F5_UP = (byte) 0xB8;
	
	/** F4*/
	public static final byte F4_DOWN = 0x3A;
	/** F4 */
	public static final byte F4_UP = (byte) 0xBA;
	
	/** 音乐 */
	public static final byte MUSIC_SWITCH_DOWN = 0x3B;
	
	/** 音乐 */
	public static final byte MUSIC_SWITCH_UP  = (byte) 0xBB;
	
	/** 视频、摄像头切换 */
	public static final byte CAMERA_SWITCH_DOWN = 0x3C;
	/** 视频、摄像头切换 */
	public static final byte CAMERA_SWITCH_UP = (byte) 0xBC;
	
	/** 菜单 */
	public static final byte MENU_DOWN = 0x3D;
	/** 菜单 */
	public static final byte MENU_UP = (byte) 0xBD;
	
	/** 坐标采集 */
	public static final byte COLLECT_LOCATION_DOWN = 0x3E;
	/** 坐标采集 */
	public static final byte COLLECT_LOCATION_UP = (byte) 0xBE;
	
	/** 手麦按下 */
	public static final byte MICROPHONE_DOWN = 0x41;
	/** 手麦抬起 */
	public static final byte MICROPHONE_DOWN_UP = (byte) 0xC1;
	
	/** 手麦 */
	public static final int MICROPHONE = 172;
	
	
	/** 倒车 */
	public static final int BACK_UP = 138;
	/** 前门 */
	public static final int FRONT_DOOR = 139;
	/** 后门 */
	public static final int BEHIND_DOOR = 140;
	
	/** 返回 */
	public static final int BACK = 4;
	
}
