package com.uninew.web;

import com.tencent.smtt.sdk.QbSdk;
import com.tencent.smtt.sdk.TbsListener;

import android.app.Application;
import android.util.Log;

public class HtmApplication extends Application {

	@Override
	public void onCreate() {
		super.onCreate();
		QbSdk.PreInitCallback cb = new QbSdk.PreInitCallback() {

			@Override
			public void onViewInitFinished(boolean arg0) {
				Log.e("app", " 浏览器视图初始化完成onViewInitFinished is " + arg0);
			}

			@Override
			public void onCoreInitFinished() {
				Log.e("app", "核心库初始化完成onCoreInitFinished");
			}
		};
		QbSdk.setTbsListener(new TbsListener() {
			@Override
			public void onDownloadFinish(int i) {
				Log.d("app", "下载完成onDownloadFinish");
			}

			@Override
			public void onInstallFinish(int i) {
				Log.d("app", "安装完成onInstallFinish");
			}

			@Override
			public void onDownloadProgress(int i) {
				Log.d("app", "下载进度onDownloadProgress:" + i);
			}
		});

		QbSdk.initX5Environment(getApplicationContext(), cb);
	}

}
