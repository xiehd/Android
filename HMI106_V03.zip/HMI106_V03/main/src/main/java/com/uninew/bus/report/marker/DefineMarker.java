package com.uninew.bus.report.marker;

public interface DefineMarker {
	
	/**进标记点*/
	public int InOutState_In=0x00;
	/**到标记点*/
	public int InOutState_Arrive=0x01;
	/**出标记点*/
	public int InOutState_Out=0x02;
	
	/** 标记点处理关 */
	int OnOFF_OFF = 0x00;
	/** 标记点处理开*/
	int OnOFF_ON =0x01;
	
	/**
	 * 类型
	 * 路口: 0:转弯 1:路口 2:直行 3:停车场 4:首站 5:场站一体 6:虚站
	 * 场站: 0:停车场
	 */
	
	public static String MARKER_STATE_PARK = "场站";
	public static String MARKER_STATE_CROSS = "路口";
	
	/**转弯:0x00*/
	public static int MARKER_TYPE_TURNNING = 0;
	/**路口:0x01*/
	public static int MARKER_TYPE_CROSS = 1;
	/**直行:0x02*/
	public static int MARKER_TYPE_STRAIGHT = 2;
	/**停车场:0x03*/
	public static int MARKER_TYPE_PARK = 3;
	/**首站:0x04*/
	public static int MARKER_TYPE_START = 4;
	/**场站一体:0x05*/
	public static int MARKER_TYPE_TERMINALONE = 5;
	/**虚站:0x06*/
	public static int MARKER_TYPE_VIRTUAL = 6;
}
