package com.uninew.bus.main;
/***********************************************************************
 * Module:  ISignView.java
 * Author:  Administrator
 * Purpose: Defines the Interface ISignView
 ***********************************************************************/

import java.util.*;

/** @pdOid a8e6b316-ccff-4242-b22a-b69078e7da13 */
public interface ISignView {
   /** @pdOid ed9f0e01-942b-4469-b069-5b1f856dbca6 */
   void showJobNumber();

}