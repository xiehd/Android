package com.uninew.bus.report.manul;

import java.util.ArrayList;


import android.util.Log;

import com.uninew.bus.constant.DefineKey;
import com.uninew.bus.report.DefineReportStation;
import com.uninew.file.dao.StationDao;

/**
 * 手动报站处理页面
 * 
 * @author Administrator
 * 
 */
public class ManulReportStation implements IManulReportStation {

	private static final String TAG = "ManulReportStation";
	private IManulReportListener mReportListener;
	private ArrayList<StationDao> stations;
	private int mCurrentIndex;
	private boolean isSwitch;
	private boolean isRun;

	public ManulReportStation(IManulReportListener mReportListener) {
		super();
		this.mReportListener = mReportListener;
		isRun=true;
	}

	@Override
	public void syncAutoReport(int currentIndex) {
		// TODO Auto-generated method stub
		mCurrentIndex=currentIndex;
		System.err.println("--------syncAutoReport-----------");
	}
	
	@Override
	public void onOffManulReport(int state) {
		// TODO Auto-generated method stub
		if (state==0) {
			isRun=false;
		}else{
			isRun=true;
		}
	}
	/**
	 * 设置站点信息
	 * 
	 * @param stations
	 */
	@Override
	public void setStations(ArrayList<StationDao> stations) {
		this.stations = stations;
		State_Hand.state = State_Hand.DETERMINE_STATION;
	}

	@Override
	public void switchUpDownNotify() {
		// TODO Auto-generated method stub
		if (isSwitch) {
			mCurrentIndex=stations.size()-1;
			isSwitch=false;
		}else{
			mCurrentIndex = 0;
		}
		State_Hand.state = State_Hand.DETERMINE_STATION;
	}

	/**
	 * 设置执行手动报站功能
	 * 
	 * @param keyCode
	 */
	@Override
	public void setKeyCode(int keyCode) {
		if(isRun){
			switch (keyCode) {
			case DefineKey.BUS_BROADCAST_DOWN:
				// 模拟自动报站键值
				handMove();
				break;
			case DefineKey.BUS_LAST_DOWN:// 切到上一站
				moveToLast();
				break;
			case DefineKey.BUS_NEXT_DOWN:// 切到下一站
				moveToNext();
				break;
			default:
				break;
		}
		}
	}

	private void moveToNext() {
		// TODO Auto-generated method stub
		if (mCurrentIndex < stations.size() - 2) {
			System.err.println("--------moveToNext-----111-----mCurrentIndex="+mCurrentIndex);
			mCurrentIndex++;
			System.err.println("--------moveToNext------2222----mCurrentIndex="+mCurrentIndex);
			mReportListener.MoveToLastOrNext(DefineReportStation.StationType_Middle,
					stations.get(mCurrentIndex),
					stations.get(mCurrentIndex + 1));
			State_Hand.setState(State_Hand.INTO_STATION);
		} else if (mCurrentIndex == stations.size() - 2) {// 倒数第二站
			mCurrentIndex++;
			mReportListener.MoveToLastOrNext(DefineReportStation.StationType_End,
					stations.get(mCurrentIndex),
					null);
			State_Hand.setState(State_Hand.DETERMINE_STATION);
		} else {// 调到起始站
			State_Hand.setState(State_Hand.DETERMINE_STATION);
			mReportListener.SwitchUpDownForManul(DefineReportStation.Move_Next);
		}
	}

	private void moveToLast() {
		// TODO Auto-generated method stub
		if (mCurrentIndex > 1) {
			mCurrentIndex--;
			System.err.println("------moveToLast---------mCurrentIndex="+mCurrentIndex);
			mReportListener.MoveToLastOrNext(DefineReportStation.StationType_Middle,
					stations.get(mCurrentIndex),
					stations.get(mCurrentIndex + 1));
			State_Hand.setState(State_Hand.INTO_STATION);
		} else if (mCurrentIndex == 1) {// 进入起始站
			mCurrentIndex--;
			mReportListener.MoveToLastOrNext(DefineReportStation.StationType_Start,
					stations.get(mCurrentIndex),
					stations.get(mCurrentIndex + 1));
			State_Hand.setState(State_Hand.STARTING_OUT);
		} else {
			// 调到终点站
			isSwitch=true;
			mReportListener.SwitchUpDownForManul(DefineReportStation.Move_Last);
			State_Hand.setState(State_Hand.DETERMINE_STATION);
		}
	}

	/**
	 * 状态控制
	 */
	void handMove() {
		Log.e(TAG, "handMove----" + State_Hand.getState());
		switch (State_Hand.getState()) {
		case IDLE:
			break;
		case DETERMINE_STATION: // 判断站点
			determineState();
			break;
		case STARTING_OUT:// 起点出站
			startOut();
			State_Hand.setState(State_Hand.INDEX_INCREASE);
			break;
		case INDEX_INCREASE:// 索引增加
			mCurrentIndex++;
			State_Hand.setState(State_Hand.INTO_STATION);
			handMove();
			break;
		case INTO_STATION:// 进站
			intoStation();
			State_Hand.setState(State_Hand.OUT_STATION);
			break;
		case OUT_STATION:// 出站
			outStation();
			State_Hand.setState(State_Hand.DETERMINE_STATION);
			break;
		case INTO_ENDING:// 终点进站
			intoEnding();
			State_Hand.setState(State_Hand.UPDOWN_SWITCH);
			break;
		case UPDOWN_SWITCH:
			mCurrentIndex = 0;
			mReportListener.SwitchUpDownForManul(DefineReportStation.Move_Next);
			State_Hand.setState(State_Hand.DETERMINE_STATION);
			break;
		default:
			break;
		}
	}

	/**
	 * 终点站进站
	 */
	private void intoEnding() {
		mReportListener.InOutStationForManul(DefineReportStation.StationType_End,
				DefineReportStation.InOutState_In, stations.get(mCurrentIndex),
				null);
	}

	/**
	 * 出站
	 */
	private void outStation() {
		if (mCurrentIndex == stations.size() - 2) {
			// 倒数第二站出站
			mReportListener.InOutStationForManul(
					DefineReportStation.StationType_LastButOne,
					DefineReportStation.InOutState_Out,
					stations.get(mCurrentIndex),
					stations.get(mCurrentIndex + 1));
		} else {
			mReportListener.InOutStationForManul(
					DefineReportStation.StationType_Middle,
					DefineReportStation.InOutState_Out,
					stations.get(mCurrentIndex),
					stations.get(mCurrentIndex + 1));
		}
	}

	/**
	 * 进站
	 */
	private void intoStation() {
		// TODO Auto-generated method stub
		mReportListener.InOutStationForManul(
				DefineReportStation.StationType_Middle,
				DefineReportStation.InOutState_In, stations.get(mCurrentIndex),
				stations.get(mCurrentIndex + 1));
	}

	/**
	 * 起始站出站
	 */
	private void startOut() {
		// TODO Auto-generated method stub
		mReportListener.InOutStationForManul(
				DefineReportStation.StationType_Start,
				DefineReportStation.InOutState_Out, stations.get(mCurrentIndex),
				stations.get(mCurrentIndex + 1));
	}

	/**
	 * 站点判定
	 */
	private void determineState() {
		// TODO Auto-generated method stub
		if (stations != null) {
			if (mCurrentIndex == 0) {// 起点出站
				State_Hand.setState(State_Hand.STARTING_OUT);
			} else if (mCurrentIndex >= stations.size() - 2) {// 终点进站
				if (mCurrentIndex == stations.size() - 2) {
					mCurrentIndex++;
				}
				State_Hand.setState(State_Hand.INTO_ENDING);
			} else {
				State_Hand.setState(State_Hand.INDEX_INCREASE);
			}
			handMove();
		}

	}

	private enum State_Hand {
		IDLE, // 空闲状态
		INDEX_INCREASE, // 索引递增
		DETERMINE_STATION, // 判断站点
		STARTING_OUT, // 起始站出站
		INTO_STATION, // 进站
		OUT_STATION, // 出站
		INTO_ENDING, // 终点进站
		UPDOWN_SWITCH;// 切换上下行
		private static State_Hand state = IDLE;

		public static State_Hand getState() {
			return state;
		}

		public static void setState(State_Hand state) {
			Log.d("State_Hand", String.format(
					"###### State Changed: %s ==> %s ######", State_Hand.state,
					state));
			State_Hand.state = state;
		}
	}

}
