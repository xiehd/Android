package com.uninew.bus.report;
/**
 * 主要针对手动报站接口定义参数
 * @author Administrator
 *
 */
public interface DefineReportStation {

	/**上行*/
	public int UpDown_Up=0x00;
	/**下行*/
	public int UpDown_Down=0x01;
	/**环行*/
	public int UpDown_Around=0x03;
	
	
	/**上一站*/
	public int Move_Last=0x00;
	/**下一站*/
	public int Move_Next=0x01;
	
	
	/**起点站*/
	public int StationType_Start=0x00;
	/**中间站*/
	public int StationType_Middle=0x01;
	/**倒数第二*/
	public int StationType_LastButOne=0x02;
	/**终点站*/
	public int StationType_End=0x03;
	
	
	/**进站*/
	public int InOutState_In=0x00;
	/**到站*/
	public int InOutState_Arrive=0x01;
	/**出站*/
	public int InOutState_Out=0x02;
	
	/** 已定位 */
	int Location_State_Positioned = 0x01;
	/** 未定位*/
	int Location_State_NotPositioned =0x00;
	
	/** 自动报站关 */
	int OnOFF_OFF = 0x00;
	/** 自动报站开*/
	int OnOFF_ON =0x01;
	
	/** 偏离路线 */
	int Exception_Yaw = 0x00;
	/** 进入路线*/
	int Exception_Normal =0x01;
}
