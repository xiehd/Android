package com.uninew.bus.channel;

import java.io.FileWriter;
import java.io.IOException;

import com.uninew.bus.constant.Constant;

public class VoiceChannelControl {
	/** 
	 * 设备版本 0:HMI106_V05 , 1:HMI106_V10
	 */
	public static int equipment_versions = 1;
	
	/**
	 * 
	 * @param state 
	 * HMI106_V05 : 内外之喇叭  21-内喇叭开  20-内喇叭关  11-外喇叭开 10-外喇叭关
	 * HMI106_V10 : 31-内喇叭开 30-内喇叭关 11-车内声道开 10-车内声道关 21-车外声道开 20-车外声道关
	 */
	private static void voidControl(int state){
		FileWriter cameraFw =null;
		try {
			if(equipment_versions == 0){
				cameraFw = new FileWriter(Constant.FILEPATH_GPS_SWITCH_V05);
			}else if(equipment_versions == 1){
				cameraFw = new FileWriter(Constant.FILEPATH_GPS_SWITCH_V10);
			}
			cameraFw.write(state+"");
			cameraFw.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * 打开内喇叭
	 */
	public static void openIn(){
		if(equipment_versions == 0){
			voidControl(21);
		}else if(equipment_versions == 1){
			voidControl(31);
		}
	}
	
	/**
	 * 打开车内与车外喇叭
	 */
	public static void openOut(){
		if(equipment_versions == 0){
			voidControl(11);
		}else if(equipment_versions == 1){
			voidControl(11);
			voidControl(21);
		}
	}
	
	
	/**
	 * 关闭内喇叭
	 */
	public static void closeIn(){
		if(equipment_versions == 0){
			voidControl(20);
		}else if(equipment_versions == 1){
			voidControl(30);
		}
	}
	
	/**
	 * 关闭车内车外喇叭
	 */
	public static void closeOut(){	
		if(equipment_versions == 0){
			voidControl(10);
		}else if(equipment_versions == 1){
			voidControl(10);
			voidControl(20);
		}
	}
	
	/**
	 * 打开内置车内车位喇叭
	 */
	public static void openInOut(){
		if(equipment_versions == 0){
			voidControl(21);
			voidControl(11);
		}else if(equipment_versions == 1){
			voidControl(31);
			voidControl(21);
			voidControl(11);
		}
	}
	/**
	 * 打开内喇叭关闭外喇叭
	 */
	public static void openInCloseOut(){
		if(equipment_versions == 0){
			voidControl(21);
			voidControl(10);
		}else if(equipment_versions ==1){
			voidControl(31);
			voidControl(10);
			voidControl(20);
		}
	}
	/**
	 * 打开外喇叭关闭内喇叭
	 */
	public static void openOutCloseIn(){
		if(equipment_versions == 0){
			voidControl(11);
			voidControl(20);
		}else if(equipment_versions == 1){
			voidControl(30);
			voidControl(11);
			voidControl(20);
		}
	}
	
	/**
	 * 关闭内外喇叭
	 */
	public static void closeAll(){
		if(equipment_versions == 0){
			voidControl(10);
			voidControl(20);
		}else if(equipment_versions == 1){
			voidControl(10);
			voidControl(20);
			voidControl(30);
		}		
	}
	/**
	 * 打开车内喇叭 此时都关闭内置喇叭
	 */
	public static void openBusIn(){
		if(equipment_versions == 1){
			voidControl(11);
			voidControl(30);
		}
	}
	
	/**
	 * 打开车外喇叭 此时都关闭内置喇叭
	 */
	public static void openBusOut(){
		if(equipment_versions == 1){
			voidControl(21);
			voidControl(30);
		}
	}
	
	/**
	 * 关闭车内喇叭 此时都关闭内置喇叭
	 */
	public static void colseBusIn(){
		if(equipment_versions == 1){
			voidControl(10);
			voidControl(30);
		}
	}
	
	/**
	 * 关闭车外喇叭 此时都关闭内置喇叭
	 */
	public static void colseBusOut(){
		if(equipment_versions == 1){
			voidControl(20);
			voidControl(30);
		}
	}
	
	/**
	 * 打开车外喇叭关闭车内喇叭 此时都关闭内置喇叭
	 */
	public static void openBusOutCloseBusIn(){
		if(equipment_versions == 1){
			voidControl(21);
			voidControl(10);
			voidControl(30);
		}
	}

	/**
	 * 打开车内喇叭关闭车外喇叭 此时都关闭内置喇叭
	 */
	public static void openBusInCloseBusOut(){
		if(equipment_versions == 1){
			voidControl(11);
			voidControl(20);
			voidControl(30);
		}else{//V05，车外默认为车内
			voidControl(11);
			voidControl(20);
		}
	}
	/**
	 * 打开内置和车内，关闭车外
	 */
	public static void openSelfBusINCloseBuseOut(){
		if(equipment_versions == 1){
			voidControl(11);
			voidControl(20);
			voidControl(31);
		}else{//V05，车外默认为车内
			voidControl(11);
			voidControl(21);
		}
	}
	
	/**
	 * 打开内置和车外，关闭车内
	 */
	public static void openSelfBusOutCloseBuseIn(){
		if(equipment_versions == 1){
			voidControl(10);
			voidControl(21);
			voidControl(31);
		}else{//V05，车外默认为车内
			voidControl(11);
			voidControl(21);
		}
	}
	
	/**
	 * 打开车内和车外，关闭内置
	 */
	public static void openBusInOutCloseSelf(){
		if(equipment_versions == 1){
			voidControl(11);
			voidControl(21);
			voidControl(30);
		}else{//V05，车外默认为车内
			voidControl(11);
			voidControl(20);
		}
	}
	
	/**
	 * 打开三路
	 */
	public static void openAll(){
		if(equipment_versions == 1){
			voidControl(11);
			voidControl(21);
			voidControl(31);
		}else{//V05，车外默认为车内
			voidControl(11);
			voidControl(21);
		}
	}
	
}
