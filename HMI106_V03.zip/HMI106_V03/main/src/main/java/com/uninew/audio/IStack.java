package com.uninew.audio;

public interface IStack {
	/**
	 * 判断栈是否为空
	 */
	boolean isEmpty();

	/**
	 * 清空栈
	 */
	void clear();

	/**
	 * 栈的长度
	 */
	int length();

	/**
	 * 数据入栈
	 */
	boolean push(Object data);

	/**
	 * 数据出栈
	 */
	Object pop();
	
	/**
	 * 获取栈顶数据
	 */
	Object getTop();
}
