package com.uninew.bus.work;

import java.util.List;

import com.uninew.db.dh.dao.PlanWork;

public interface IQueryPlanWorksCallBack {

	/**
	 * 查询排班回调
	 * @param planWorks
	 */
	void planWorksCallBack(List<PlanWork> planWorks);
}
