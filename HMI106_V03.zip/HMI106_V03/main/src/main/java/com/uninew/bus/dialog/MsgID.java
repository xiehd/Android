package com.uninew.bus.dialog;

import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.Map;

public class MsgID {
	public static Map<Short, String> map = new HashMap<Short, String>();
	static {
		Class cls = MsgID.class;
		Field[] fields = cls.getFields();
		for (Field f : fields) {
			if (f.getName().contains("ID_")) {
				try {
					map.put(f.getShort(null), f.getName());
				} catch (IllegalArgumentException e) {
 					e.printStackTrace();
				} catch (IllegalAccessException e) {
 					e.printStackTrace();
				}
			}
		}
	}

	/**
	 * 转义
	 */
	public static final byte ESCAPE = 0x7d;

	/**
	 * 转义 0X7E->0X7D 0X02
	 */
	public static final byte ESCAPE_E = 0x02;

	/**
	 * 转义 0X7D->0X7D 0X01
	 */
	public static final byte ESCAPE_D = 0x01;

	/**
	 * 标识位
	 */
	public static final byte MSG_FLAG = 0x7e;
	/**
	 * 终端通用应答
	 */
	public static final short ID_TERMINAL_ANS = 0x0001;
	/**
	 * 使用前锁定，快速开户
	 */
	public static final short ID_QUICK_OPEN = 0x0110;
	/**
	 * 平台通用应答
	 */
	public static final short ID_PLAT_ANS = (short) 0x8001;
	/**
	 * 终端心跳
	 */
	public static final short ID_TERMINAL_HEARBEAT = 0x0002;
	/**
	 * 补传分包请求
	 */
	public static final short ID_COMPL_PASS = (short) 0x8003;
	/**
	 * 终端注册
	 */
	public static final short ID_TERMINAL_REGIST = 0x0100;
	/**
	 * 终端注册应答
	 */
	public static final short ID_TERMINAL_REGIST_ANS = (short) 0x8100;
	/**
	 * 终端注销
	 */
	public static final short ID_TERMINAL_CANCEL = 0x0003;
	/**
	 * 终端鉴权
	 */
	public static final short ID_TERMINAL_AUTHENT = 0x0102;
	/**
	 * 设置终端参数
	 */
	public static final short ID_TERMINAL_SET = (short) 0x8103;
	/**
	 * 查询终端参数
	 */
	public static final short ID_TERMINAL_QUERY = (short) 0x8104;
	/**
	 * 查询终端参数应答
	 */
	public static final short ID_TERMINAL_QUERY_ANS = 0x0104;
	/**
	 * 终端控制
	 */
	public static final short ID_TERMINAL_CONTROL = (short) 0x8105;
	/**
	 * 查询指定终端参数
	 */
	public static final short ID_TERMINAL_SPECIFIC_QUERY = (short) 0x8106;
	/**
	 * 查询终端属性
	 */
	public static final short ID_TERMINAL_QUERY_PROPERTY = (short) 0x8107;
	/**
	 * 查询终端属性应答
	 */
	public static final short ID_TERMINAL_QUERY_PROPERTY_ANS = 0x0107;
	/**
	 * 下发终端升级包
	 */
	public static final short ID_ISSUED_TERMINAL_UPGRADE_PACKAGE = (short) 0x8108;
	/**
	 * 终端升级结果通知
	 */
	public static final short ID_ISSUED_TERMINAL_UPGRADE_RESULT_NOTIFICATION = 0x0108;
	/**
	 * 位置信息汇报
	 */
	public static final short ID_LOCATION_INFORMATION_REPORTING = 0x0200;
	/**
	 * 位置信息查询
	 */
	public static final short ID_LOCATION_INFORMATION_REPORTING_INQUIRY = (short) 0x8201;
	/**
	 * 位置信息查询应答
	 */
	public static final short ID_LOCATION_INFORMATION_REPORTING_INQUIRY_ANS = 0x0201;
	/**
	 * 临时位置跟踪控制
	 */
	public static final short ID_TEMPORARY_POSITION_TRACKING_CONTROL = (short) 0x8202;
	/**
	 * 人工确认报警消息
	 */
	public static final short ID_ACKNOWLEDGE_ALARM_MSG_MANUALLY = (short) 0x8203;
	/**
	 * 文本信息下发
	 */
	public static final short ID_TEXT_MSG_ISSUED = (short) 0x8300;
	/**
	 * 事件设置
	 */
	public static final short ID_EVENT_SET = (short) 0x8301;
	/**
	 * 事件报告
	 */
	public static final short ID_EVENT_REPORT = 0x0301;
	/**
	 * 提问下发
	 */
	public static final short ID_ASKED_ISSUED = (short) 0x8302;
	/**
	 * 提问应答
	 */
	public static final short ID_ASKED_ANS = 0x0302;
	/**
	 * 信息点播菜单设置
	 */
	public static final short ID_INFORMATION_DEMAND_MENU_SET = (short) 0x8303;
	/**
	 * 信息点播/取消
	 */
	public static final short ID_INFORMATION_DEMAND_OR_CANCLE = 0x0303;
	/**
	 * 信息服务
	 */
	public static final short ID_INFORMATION_SERVICE = (short) 0x8304;
	/**
	 * 电话回拨
	 */
	public static final short ID_CALL_BACK = (short) 0x8400;
	/**
	 * 设置电话本
	 */
	public static final short ID_SET_PHONE_BOOK = (short) 0x8401;
	/**
	 * 车辆控制
	 */
	public static final short ID_VEHICLE_CONTROL = (short) 0x8500;
	/**
	 * 车辆控制应答
	 */
	public static final short ID_VEHICLE_CONTROL_ANS = 0x0500;
	/**
	 * 设置圆形区域
	 */
	public static final short ID_SET_CIRCULAR_AREA = (short) 0x8600;
	/**
	 * 删除圆形区域
	 */
	public static final short ID_DEL_CIRCULAR_AREA = (short) 0x8601;
	/**
	 * 设置矩形区域
	 */
	public static final short ID_SET_RECT_AREA = (short) 0x8602;
	/**
	 * 删除矩形区域
	 */
	public static final short ID_DEL_RECT_AREA = (short) 0x8603;
	/**
	 * 设置多边形区域
	 */
	public static final short ID_SET_POLYGON_AREA = (short) 0x8604;
	/**
	 * 删除多边形区域
	 */
	public static final short ID_DEL_POLYGON_AREA = (short) 0x8605;
	/**
	 * 设置路线
	 */
	public static final short ID_SET_ROUTE = (short) 0x8606;
	/**
	 * 删除路线
	 */
	public static final short ID_DEL_ROUTE = (short) 0x8607;
	/**
	 * 行驶记录仪数据采集命令
	 */
	public static final short ID_TACHOGRAPH_DATA_ACQUISIT_COMMAND = (short) 0x8700;
	/**
	 * 行驶记录仪数据上传
	 */
	public static final short ID_TACHOGRAPH_DATA_UPLOAD = 0x0700;
	/**
	 * 行驶记录仪参数下传命令
	 */
	public static final short ID_TACHOGRAPH_PARAM_DOWNLOAD = (short) 0x8701;
	/**
	 * 电子运单上报
	 */
	public static final short ID_WAYBILL_REPORT = 0x0701;
	/**
	 * 驾驶员身份信息采集上报
	 */
	public static final short ID_DRIVER_IDENTITY_INFORMATION_COLLECTION_SUBMITTED = 0x0702;
	/**
	 * 上报驾驶员身份信息请求
	 */
	public static final short ID_REQUEST_DRIVER_IDENTITY_INFORMATION_REPORT = (short) 0x8702;
	/**
	 * 定位数据批量上传
	 */
	public static final short ID_BULK_UPLOAD_POSITION_DATA = 0x0704;
	/**
	 * CAN总线数据上传
	 */
	public static final short ID_CAN_BUS_DATA_UPLOAD = 0x0705;
	/**
	 * 多媒体事件信息上传
	 */
	public static final short ID_UPLOAD_MULTIMEDIA_EVENT_INFORMATION = 0x0800;
	/**
	 * 多媒体数据上传
	 */
	public static final short ID_UPLOAD_MULTIMEDIA_DATA_UPLOAD = 0x0801;
	/**
	 * 多媒体数据上传应答
	 */
	public static final short ID_UPLOAD_MULTIMEDIA_DATA_UPLOAD_ANS = (short) 0x8800;
	/**
	 * 摄像头立即拍摄命令
	 */
	public static final short ID_CAMERA_SHOT_COMMAND_IMMEDIATELY = (short) 0x8801;
	/**
	 * 摄像头立即拍摄命令应答
	 */
	public static final short ID_CAMERA_SHOT_COMMAND_IMMEDIATELY_ANS = 0x0805;
	/**
	 * 存储多媒体检索
	 */
	public static final short ID_STORAGE_MULTIMEDIA_RETRIEVAL = (short) 0x8802;
	/**
	 * 存储多媒体检索应答
	 */
	public static final short ID_STORAGE_MULTIMEDIA_RETRIEVAL_ANS = 0x0802;
	/**
	 * 存储多媒体上传
	 */
	public static final short ID_STORAGE_MULTIMEDIA_UPLOAD = (short) 0x8803;
	/**
	 * 录音开始命令
	 */
	public static final short ID_RECORD_START_COMMAND = (short) 0x8804;
	/**
	 * 单条存储多媒体数据检索检索上传命令
	 */
	public static final short ID_SINGLE_STORAGE_MULTIMEDIA_DATA_RETRIEVAL_UPLOAD_COMMAND = (short) 0x8805;
	/**
	 * 数据下行透传
	 */
	public static final short ID_DOWNLINK_DATA_TRANSPARENT_TRANSMIS = (short) 0x8900;
	/**
	 * 数据上行透传
	 */
	public static final short ID_UPSTREAM_DATA_TRANSPARENT_TRANSMIS = 0x0900;
	/**
	 * 数据压缩上报
	 */
	public static final short ID_DATA_COMPRESS_REPORT = 0x0901;
	/**
	 * 平台RSA公钥
	 */
	public static final short ID_PLAT_RSA_PUBLIC_KEY = (short) 0x8A00;
	/**
	 * 终端RSA公钥
	 */
	public static final short ID_TERMINAL_RSA_PUBLIC_KEY = 0x0A00;
	/**
	 * CAN总线数据查询
	 */
	public static final short ID_CAN_DATE_QUERY = (short) 0x8F03;
	/**
	 * 终端登出。 
	 */
	public static final short ID_TERMINAL_LOGOUT = (short)0x0f01;
	/**
	 * 终端工作状态上传。 
	 */
	public static final short ID_WORKSTATE_UPLOAD = (short)0x0f05;
	/**
	 * 终端工作状态数据查询。
	 */
	public static final short ID_WORKSTATE_QUERY = (short)0x8f05;
	
	/**
	 * 终端工作状态数据查询回应。
	 */
	public static final short ID_WORKSTATE_QUERY_Answer = (short)0x0f06;
	
	/**
	 * 传感器数据上传。 
	 */
	public static final short ID_SENSORMSG_UPLOAD = (short)0x0f07;
	/**
	 * 传感器数据查询。 
	 */
	public static final short ID_SENSORMSG_Query = (short)0x8f07;
	/**
	 * 电子运单下发。 
	 */
	public static final short ID_WAYBILL = (short)0x8F00;
	/**
	 * 人工确认运单信息
	 */
	public static final short ID_WAYBILL_COMFIRM = (short)0x0F0B;
	/**
	 * 任务点人工确认
	 */
	public static final short ID_WAYBILL_TASK_CONFIRM = (short)0x0F0A;
	/**
	 * 趟次确认
	 */
	public static final short ID_WAYBILL_COUNT_CONFIRM = (short)0x0F0C;
	/**
	 * 查询运单状态
	 */
	public static final short ID_WAYBILL_QUERY= (short)0x8F0D;
	/**
	 * 查询运单状态应答
	 */
	public static final short ID_WAYBILL_QUERY_REPLY= (short)0x0F0D;
	/**
	 * 运单完成确认
	 */
	public static final short ID_WAYBILL_FIMISH_CONFIRM= (short)0x0F0E;
	
}