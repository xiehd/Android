package com.uninew.bus.main;

/*********************************************************************** 
 * Module:  IFileListener.java
 * Author:  Administrator
 * Purpose: Defines the Interface IFileListener
 ***********************************************************************/

import java.util.*;

/** @pdOid 9aa2daff-53cc-4e46-9560-801cc5d05aad */
public interface IFileListener {
	/**
	 * @param speed
	 * @pdOid 2af96ad8-5873-4c6b-9082-fccdb48c3299
	 */
	void setSpeed(int speed);

	/**
	 * @param limitSpeed
	 * @pdOid bd9e2baa-8764-496f-91b9-c25e7638ff0a
	 */
	void setLimitSpeed(int limitSpeed);

	/**
	 * @param type
	 * @pdOid 35c9857a-ef2a-41f4-ac99-6169b98872a3
	 */
	void setOverSpeed(int type);

	/**
	 * @param startStation
	 * @param endStation
	 * @param lineName
	 * @pdOid 4054a9eb-7d55-406b-9a0d-d1604ca6d6ca
	 */
	void setLineMsg(String startStation, String endStation, String lineName);

	/**
	 * @param stations
	 * @pdOid 7a607a6f-8e64-40b7-8b95-2e73206bb313
	 */
	void setStations(List<String> stations);
	/**
	 * @param id
	 * @param station
	 * @pdOid adc739ad-138b-49f9-af6d-37c6db52dc34
	 */
	void setCurrentStation(int id, String station);

	/**
	 * @param id
	 * @param station
	 * @pdOid ffc7ed1d-5d4d-4a02-b7f7-34d1fc8cb4a3
	 */
	void setNextStation(int id, String station);

	/**
	 * @param location
	 * @pdOid 369f5b5a-ee4f-47fc-aede-b96ad4c09403
	 */
	void setNearByBusPosition(int before,int after);
	
	/**
	 * 显示下一站文本
	 * @param txt
	 */
	void setNextOrEnd(String txt);
	
	/**
	 * 显示下一站文本
	 * @param txt
	 */
	void setSpeedColor(int color);
	
	/**
	 * @param upDown 0-上行 1-下行
	 * @pdOid 915cb093-4997-48b8-849b-1d4762dbe8cb
	 */
	void setUpDown(int upDown);

	/**
	 * @param style
	 * @pdOid 48488360-ded2-418a-a368-9c35aad68f5e
	 */
	void setReportStyle(boolean  isAuto);

	/**
	 * @param isRun
	 * @pdOid d0a268b7-412e-4fa7-a412-b009b172c5b3
	 */
	void setRunState(boolean isRun);

	/**
	 * @param isSigned
	 * @pdOid 980782bb-4e71-4d82-81c3-770dbcb79057
	 */
	void setSignState(boolean isSigned);

	/**
	 * @param licence
	 * @pdOid 6e8cd3ed-4bfe-4e87-afbc-0ebb329c4956
	 */
	void setLicensePlate(String license);

	/**
	 * @param jobNumber
	 * @pdOid 0ae1788f-2709-41f2-b235-6e4bf141005a
	 */
	void setJobNumber(String jobNumber);

	/**
	 * @param name
	 * @pdOid 242e87bd-b03c-43a2-9ebd-a5750bbfa6bb
	 */
	void setDriverName(String name);
	
	 /** @param mContext
	    * @pdOid 6bbd8c9f-c39e-4a0f-8ffd-887c7d979919 */
	void showSignView(boolean isSigned);

}