package com.uninew.web;

import com.tencent.smtt.export.external.interfaces.IX5WebChromeClient.CustomViewCallback;
import com.tencent.smtt.export.external.interfaces.JsResult;
import com.tencent.smtt.export.external.interfaces.WebResourceRequest;
import com.tencent.smtt.export.external.interfaces.WebResourceResponse;
import com.tencent.smtt.sdk.CookieSyncManager;
import com.tencent.smtt.sdk.ValueCallback;
import com.tencent.smtt.sdk.WebChromeClient;
import com.tencent.smtt.sdk.WebSettings;
import com.tencent.smtt.sdk.WebSettings.LayoutAlgorithm;
import com.tencent.smtt.sdk.WebView;
import com.tencent.smtt.sdk.WebViewClient;
import com.uninew.bus.R;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnLayoutChangeListener;
import android.view.Window;
import android.view.inputmethod.InputMethodManager;
import android.widget.ProgressBar;
import android.widget.TextView;

public class ShowWebActivity extends Activity {
	private X5WebView x5webview;
	private ProgressBar progressBar;
	private TextView tvLoading;
	private static final String TAG = "TBS";
	public static final String SHOW_URL = "url";
	  //屏幕高度  
    private int screenHeight = 0;  
    //软件盘弹起后所占高度阀值  
    private int keyHeight = 0;  
    private View view;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
//		getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_showweb);
		view = findViewById(R.id.rl_content);
		
		Intent intent = getIntent();
		try {
			if (Integer.parseInt(android.os.Build.VERSION.SDK) >= 11) {
				// 给window开启硬件加速
				getWindow().setFlags(android.view.WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
						android.view.WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		progressBar = (ProgressBar) findViewById(R.id.initProgressBar);
		tvLoading = (TextView) findViewById(R.id.tvLoading);
		x5webview = (X5WebView) findViewById(R.id.mWebview);
		progressBar.setProgress(1);
		init();
		if (intent != null) {
			String url = intent.getStringExtra(SHOW_URL);
			if (!TextUtils.isEmpty(url)) {
				x5webview.loadUrl(url);
			}
		}
		//获取屏幕高度  
        screenHeight = this.getWindowManager().getDefaultDisplay().getHeight();  
        //阀值设置为屏幕高度的1/3  
        keyHeight = screenHeight/3;  
        
        
	}
	
//	@Override
//	public void onLayoutChange(View v, int left, int top, int right, int bottom, int oldLeft, int oldTop, int oldRight,
//			int oldBottom) {
//
//		// old是改变前的左上右下坐标点值，没有old的是改变后的左上右下坐标点值
//
//		// System.out.println(oldLeft + " " + oldTop +" " + oldRight + " " +
//		// oldBottom);
//		// System.out.println(left + " " + top +" " + right + " " + bottom);
//
//		// 现在认为只要控件将Activity向上推的高度超过了1/3屏幕高，就认为软键盘弹起
//		if (oldBottom != 0 && bottom != 0 && (oldBottom - bottom > keyHeight)) {
//			Log.e(TAG, "dddddd");
//			InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
//			imm.hideSoftInputFromWindow(v.getWindowToken(), 0);
//		} else if (oldBottom != 0 && bottom != 0 && (bottom - oldBottom > keyHeight)) {
//
//		}
//
//	}
//
//
//	@Override
//	public void onLayoutChange(View v, int left, int top, int right, int bottom, int oldLeft,
//			int oldTop, int oldRight, int oldBottom) {
//		//现在认为只要控件将Activity向上推的高度超过了1/3屏幕高，就认为软键盘弹起
//        if(oldBottom != 0 && bottom != 0 &&(oldBottom - bottom > keyHeight)){
//              Log.e(TAG, "软键盘弹出来了");
//             /* InputMethodManager imm = (InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE);
//            //得到InputMethodManager的实例
//            if (imm.isActive()) {
//            //如果开启
//            imm.toggleSoftInput(InputMethodManager.SHOW_IMPLICIT, InputMethodManager.HIDE_NOT_ALWAYS);
//            //关闭软键盘，开启方法相同，这个方法是切换开启与关闭状态的
//            }*/
//
//                  InputMethodManager imm = (InputMethodManager)
//                  getSystemService(INPUT_METHOD_SERVICE);
//                   imm.hideSoftInputFromWindow(v.getWindowToken(), 0);
//
//
//        }else if(oldBottom != 0 && bottom != 0 &&(bottom - oldBottom > keyHeight)){
//
////            Toast.makeText(MainActivity.this, "监听到软件盘关闭...", Toast.LENGTH_SHORT).show();
//
//        }
//	}

	@Override
	protected void onResume() {
		super.onResume();
//		view.addOnLayoutChangeListener(this);
	}

	@SuppressLint({ "SetJavaScriptEnabled", "ClickableViewAccessibility" })
	private void init() {
		x5webview.setWebViewClient(new WebViewClient() {

			@Override
			public void onPageFinished(WebView arg0, String arg1) {
				super.onPageFinished(arg0, arg1);
				// Log.e(TAG, "页面加载完成"+arg0+","+arg1);
			}

			@Override
			public void onPageStarted(WebView arg0, String arg1, Bitmap arg2) {
				super.onPageStarted(arg0, arg1, arg2);
				// Log.e(TAG, "页面开始加载"+arg0+","+arg1+","+arg2);
			}

			@Override
			public void onReceivedError(WebView arg0, int arg1, String arg2, String arg3) {
				super.onReceivedError(arg0, arg1, arg2, arg3);
				// Log.e(TAG, "加载出错"+arg0+","+arg1+","+arg2+","+arg3);
			}

			@Override
			public boolean shouldOverrideUrlLoading(WebView view, String url) {
				view.loadUrl(url);
				return true;
			}

			@Override
			public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
				// Log.e(TAG, "请求资源的url: " + request.getUrl().toString());

				return super.shouldInterceptRequest(view, request);
			}

		});
		x5webview.setWebChromeClient(new WebChromeClient() {
			@Override
			public void onProgressChanged(WebView arg0, int progress) {
				super.onProgressChanged(arg0, progress);
				final int p = progress;
				// Log.e(TAG, "当前进度"+progress);
				progressBar.setProgress(progress);
				if (progress >= 50) {
					progressBar.setVisibility(View.GONE);
					tvLoading.setVisibility(View.GONE);
				}
			}

			@Override
			public boolean onJsAlert(WebView arg0, String arg1, String arg2, JsResult arg3) {
				return super.onJsAlert(arg0, arg1, arg2, arg3);
			}

			@Override
			public boolean onJsConfirm(WebView arg0, String arg1, String arg2, JsResult arg3) {
				return super.onJsConfirm(arg0, arg1, arg2, arg3);
			}

			@Override
			public void onShowCustomView(View arg0, CustomViewCallback arg1) {
				super.onShowCustomView(arg0, arg1);
			}

			@Override
			public boolean onShowFileChooser(WebView arg0, ValueCallback<Uri[]> arg1, FileChooserParams arg2) {
				return super.onShowFileChooser(arg0, arg1, arg2);
			}

			@Override
			public void openFileChooser(ValueCallback<Uri> arg0, String arg1, String arg2) {
				super.openFileChooser(arg0, arg1, arg2);
			}

		});
		// DisplayMetrics metrics = new DisplayMetrics();
		// getWindowManager().getDefaultDisplay().getMetrics(metrics);
		// int mDensity = metrics.densityDpi;
		//// WindowManager wm =
		// (WindowManager)getSystemService(Context.WINDOW_SERVICE);
		//// int width = wm.getDefaultDisplay().getWidth();
		//设置缩放比初始值
		x5webview.setInitialScale(50);
		// x5webview.clearFocus();
		WebSettings webSetting = x5webview.getSettings();
		webSetting.setAllowFileAccess(true);
		webSetting.setLayoutAlgorithm(LayoutAlgorithm.NARROW_COLUMNS);
		webSetting.setSupportZoom(true);
		webSetting.setBuiltInZoomControls(true);
		webSetting.setUseWideViewPort(true);
		webSetting.setSupportMultipleWindows(false);
		webSetting.setLoadWithOverviewMode(true);
		webSetting.setAppCacheEnabled(true);
//		webSetting.setDatabaseEnabled(true);
		webSetting.setDomStorageEnabled(true);
		webSetting.setJavaScriptEnabled(true);
		webSetting.setGeolocationEnabled(true);
		webSetting.setAppCacheMaxSize(Long.MAX_VALUE);
		webSetting.setAppCachePath(this.getDir("appcache", 0).getPath());
		webSetting.setDatabasePath(this.getDir("databases", 0).getPath());
		webSetting.setGeolocationDatabasePath(this.getDir("geolocation", 0).getPath());
		// webSetting.setPageCacheCapacity(IX5WebSettings.DEFAULT_CACHE_CAPACITY);
		webSetting.setPluginState(WebSettings.PluginState.ON_DEMAND);
		// webSetting.setRenderPriority(WebSettings.RenderPriority.HIGH);
		// webSetting.setPreFectch(true);
		CookieSyncManager.createInstance(this);
		CookieSyncManager.getInstance().sync();
	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK) {
			if (x5webview != null && x5webview.canGoBack()) {
				x5webview.goBack();
				return true;
			}
		}
		return super.onKeyDown(keyCode, event);
	}

	@Override
	protected void onDestroy() {
		if (x5webview != null) {
			x5webview.destroy();
		}
		super.onDestroy();
	}
}


