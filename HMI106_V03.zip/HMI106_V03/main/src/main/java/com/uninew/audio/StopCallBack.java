package com.uninew.audio;

/**
 * 播放结束回调接口
 * @author Administrator
 *
 */
public interface StopCallBack {
	
	
	void stopBack(AudioDao audioDao);
}
