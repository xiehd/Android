package com.uninew.bus.adapter;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.uninew.bus.R;
import com.uninew.bus.log.LogTool;
import com.uninew.file.dao.RoutesDao;
import com.uninew.file.dao.StationDao;
import com.uninew.file.json.JsonParse;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

public class MyListAdapter extends BaseAdapter {

	private Context context;
	public static Map<String, Boolean> states = new HashMap<String, Boolean>();
	static {
		states.put(String.valueOf(0), true);
	}
	private int type;
	private List<RoutesDao> routesDaos;
	public static String startStationName = null;
	public static String endStationName = null;

	public MyListAdapter(Context context, List<RoutesDao> routesDaos) {
		this.context = context;

		this.routesDaos = routesDaos;
	}

	@Override
	public int getCount() {
		return routesDaos.size();
	}

	@Override
	public Object getItem(int position) {

		return routesDaos.get(position);
	}

	@Override
	public long getItemId(int position) {

		return position;
	}

	@Override
	public int getItemViewType(int position) {

		if (position % 2 == 0) {
			type = 0;
		} else {
			type = 1;
		}
		return type;

	}

	@Override
	public int getViewTypeCount() {

		return 2;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {

		ViewHolder holderOne = null;
		if (getItemViewType(position) == 0) {
			if (convertView == null) {
				holderOne = new ViewHolder();
				convertView = LayoutInflater.from(context).inflate(R.layout.route_item_one, null);
				holderOne.bigen_station = (TextView) convertView.findViewById(R.id.tv_begin_station);
				holderOne.end_station = (TextView) convertView.findViewById(R.id.tv_end_station);
				holderOne.route_number = (TextView) convertView.findViewById(R.id.tv_route_number);
				holderOne.route_selector = (ImageView) convertView.findViewById(R.id.iv_route_selector);
				convertView.setTag(holderOne);
			} else {
				holderOne = (ViewHolder) convertView.getTag();
			}

		} else if (getItemViewType(position) == 1) {
			if (convertView == null) {
				holderOne = new ViewHolder();
				convertView = LayoutInflater.from(context).inflate(R.layout.route_item_two, null);
				holderOne.bigen_station = (TextView) convertView.findViewById(R.id.tv_begin_station);
				holderOne.end_station = (TextView) convertView.findViewById(R.id.tv_end_station);
				holderOne.route_number = (TextView) convertView.findViewById(R.id.tv_route_number);
				holderOne.route_selector = (ImageView) convertView.findViewById(R.id.iv_route_selector);
				convertView.setTag(holderOne);
			} else {
				holderOne = (ViewHolder) convertView.getTag();
			}
		}

		boolean res = false;
		if (states.get(String.valueOf(position)) == null || states.get(String.valueOf(position)) == false) {
			res = false;
			states.put(String.valueOf(position), false);
		} else
			res = true;

		if (res) {
			holderOne.bigen_station.setTextColor(Color.WHITE);
			holderOne.end_station.setTextColor(Color.WHITE);
			holderOne.route_number.setTextColor(Color.WHITE);
			holderOne.route_selector.setVisibility(View.VISIBLE);
		} else {
			holderOne.bigen_station.setTextColor(0xFFADADAD);
			holderOne.end_station.setTextColor(0xFFADADAD);
			holderOne.route_number.setTextColor(0xFFADADAD);
			holderOne.route_selector.setVisibility(View.GONE);
		}
		holderOne.route_number.setText(routesDaos.get(position).getRouteName());
		holderOne.bigen_station.setText(routesDaos.get(position).getStartStation());
		holderOne.end_station.setText(routesDaos.get(position).getEndStation());
		return convertView;
	}

	static class ViewHolder {
		TextView route_number;
		TextView bigen_station;
		TextView end_station;
		ImageView route_selector;
	}

	// @Override
	// public void onItemClick(AdapterView<?> parent, View view, int position,
	// long id) {
	//
	// this.notifyDataSetChanged();
	// clickListenerInterface.onItemClick(position);
	//
	// }
}
