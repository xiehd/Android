package com.uninew.bus.dialog;
import java.util.Timer;
import java.util.TimerTask;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.widget.TextView;

import com.uninew.bus.R;


public class NotifyToast extends Dialog {

	private String text="";
	TextView tv;
	long time;
	
	public NotifyToast(Context context) {
		super(context,R.style.FullScreenDialog);
	}
	public NotifyToast(Context context, int theme){
		super(context,R.style.FullScreenDialog);
	}
	@Override
	public void dismiss() {
		super.dismiss();
	}
	
	public void setText(String text,long time){
		this.text = text;
		this.time = time;
	}

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.public_toast);
		tv = (TextView)findViewById(R.id.tv_toast);
		
	}
	@Override
	protected void onStart() {
		super.onStart();
		tv.setText(text);
		if(time<=0){
			time = 2000;
		}
		Timer timer = new Timer();
				timer.schedule(new TimerTask() {
			@Override
			public void run() {
				dismiss();
			}
		},time);
	}

	@Override
	protected void onStop() {
		super.onStop();
	}



	

	@Override
	public void cancel() {
 		super.cancel();
	}
	

	
	@Override
	public void show() {
 		super.show();
	}
	
	

	
	
}
