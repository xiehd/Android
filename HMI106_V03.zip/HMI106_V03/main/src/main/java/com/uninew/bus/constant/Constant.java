package com.uninew.bus.constant;

import android.annotation.SuppressLint;

/**
 * 常量
 * @author Administrator
 *
 */
public interface Constant {
	/**语音文件目录*/
	@SuppressLint("SdCardPath")
	String AUDIO_PATH="/mnt/sdcard/公交资源文件/语音/";
	String PUBLIC_AUDIO_PATH="/mnt/sdcard/公交资源文件/语音/公共语/";
	String SERVICE_AUDIO_PATH="/mnt/sdcard/公交资源文件/语音/服务语/";
	/////////////////////站台列表//////////////////////////////////////
	
	/**报站站台列表每页显示站台条数*/
	int DEFAULT_PAGESIZE=10;
	
	/////////////////////站点切换通知/////////////////////////////
	/**起点出站通知*/
	int NOTIFY_START_OUT_STATION=0;
	/**进站通知*/
	int NOTIFY_IN_STATION=1;
	/**出站通知*/
	int NOTIFY_OUT_STATION=2;
	/**终点站通知*/
	int NOTIFY_END_IN_STATION=3;
	/**上下行切换通知*/
	int NOTIFY_SWITCH_UPDOWN=4;
	
	////////////////////进出状态//////////////////////////////
	/**进入站点状态*/
	int STATE_IN=1;
	/**驶出站点状态*/
	int STATE_OUT=0;
	
	/**摄像头切换控制文件目录*/
	String FILEPATH_CAMERA_SWITCH="/sys/adv7180_camera_switch/camera_switch/";
	/**摄像头打开控制文件目录*/
	String  FILEPATH_CAMERA_REG="/sys/adv7180_camera_switch/camera_reg";
	/**GPS切换控制文件目录*/
	String FILEPATH_GPS_SWITCH_V05="/sys/hmi106_gpio_control/gpio_control";
	String FILEPATH_GPS_SWITCH_V10="/sys/hmi116_gpio_control/gpio_control";

	//进出站距离值
	/**进站判定距离*/
	int DEFAUT_INSTATION_DISTANCE=60;
	/**到站判定距离*/
	 int DEFAUT_RECEIVESTATION_DISTANCE=15;
	/**出站判断距离*/
	 int DEFAUT_OUTSTATION_DISTANCE=35;
	/**出站判断距离2*/
	 int DEFAUT_OUTSTATION_DISTANCE2=50;
	/**偏航距离阈值*/
	int DEFAUT_YAW_DISTANCE=40;
	
	/**进入拐点距离值*/
	int DEFAUT_INCORNER_DISTANCE=21;
	
	/**滞站判定时间间隔 (单位分钟)*/
	int DEFAULT_DELAY_TIME=5;
	
	/**进出站双语言播报*/
	boolean BROADCAST_DOUBLE_LANGUAGE=false;
	
}
