package com.uninew.bus.work;

import java.util.List;

import com.uninew.db.dh.dao.PlanWork;

import android.content.Context;


public class PlanWorkPresenter implements IPlanWorkListener,IPlanWorkPresenter{
	
	private IPlanWorkView mPlanWorkView;
	private PlanWorkModel mPlanWorkModel;
	public PlanWorkPresenter(Context mContext, IPlanWorkView mPlanWorkView) {
		super();
		this.mPlanWorkView = mPlanWorkView;
		mPlanWorkModel=new PlanWorkModel(mContext, this);
	}
	
	
//---------------------------上传-----------------------------------------------	
	@Override
	public void showPlanWorks(List<PlanWork> planWorks) {
		// TODO Auto-generated method stub
		mPlanWorkView.showPlanWorks(planWorks);
	}
	@Override
	public void showCurrentPlanWork(PlanWork planWork) {
		// TODO Auto-generated method stub
		mPlanWorkView.showCurrentPlanWork(planWork);
	}
	
	
//--------------------------下传---------------------------------------------
	@Override
	public void queryPlanWorks(String[] times, IQueryPlanWorksCallBack planWorks) {
		// TODO Auto-generated method stub
		mPlanWorkModel.queryPlanWorks(times, planWorks);
	}

	@Override
	public void deletePlanWorks(int[] ids, IResultCallBack result) {
		// TODO Auto-generated method stub
		mPlanWorkModel.deletePlanWorks(ids, result);
	}

	@Override
	public void updatePlanWorks(List<PlanWork> planWorks, IResultCallBack result) {
		// TODO Auto-generated method stub
		mPlanWorkModel.updatePlanWorks(planWorks, result);
	}


	@Override
	public void exitManage() {
		// TODO Auto-generated method stub
		mPlanWorkModel.exitManage();
	}
	
}
