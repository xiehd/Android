package com.uninew.bus.dialog;

public class QuestionOption {

	private byte answerId;
	private String answer;
	public QuestionOption(byte answerId, String answer) {
		super();
		this.answerId = answerId;
		this.answer = answer;
	}
	public byte getAnswerId() {
		return answerId;
	}
	public String getAnswer() {
		return answer;
	}
}
