package com.uninew.bus.report.overspeed;

import java.util.ArrayList;
import java.util.List;

/**
 * 速度判定
 * 
 * @author Administrator
 * 
 */
public class SpeedJudge {
	private List<Integer> queue = new ArrayList<Integer>();
	private boolean isStart = false;
	private List<Integer> preQueue = new ArrayList<Integer>();
	private boolean isStartPre = false;
	private float lastSpeed;
	private static final float MIX_SPEED=0.1f;
	public static final int FLAG_UNSURE=0;
	public static final int FLAG_RUNING=1;
	public static final int FLAG_STOPPED=2;
	//超速时间
	public static final int OverspeedDuration=3;
	//预超速时间
	public static final int PreOverspeedDuration=3;
	//预超速差（5km/h）
	public static final int preOverSpeedInterval=5;

	
	/**
	 * 速度一旦大于超速值，开始加入队列。记录五个速度之后进行判断
	 * 
	 * @param speed
	 * @param limit
	 * @return
	 */
	public boolean speedJudge(int speed, int limit) {
		if (speed > limit) {
			isStart = true;
		}
		if (isStart) {
			queue.add(speed);
		}
		if (queue.size() >= OverspeedDuration) {
			return judge(limit);
		}
		return false;
	}

	/**
	 * 连续五个速度都大于限速值
	 * 
	 * @param limit
	 * @return
	 */
	private boolean judge(int limit) {
		int k = 0;
		for (int i = 0; i < queue.size(); i++) {
			if (queue.get(i) > limit) {
				k++;
			}
		}
		if (k == queue.size()) {
			isStart = false;
			queue.clear();
			return true;
		}else{
			queue.remove(0);
		}
		return false;
	}
	
	/**
	 * 速度一旦大于预超速值，开始加入队列。记录3个速度之后进行判断
	 * 
	 * @param speed
	 * @param limit
	 * @return
	 */
	public boolean speedJudgePre(int speed, int limit) {
		if (speed > limit-preOverSpeedInterval && speed < limit) {
			isStartPre = true;
		}
		if (isStartPre) {
			preQueue.add(speed);
		}
		if (preQueue.size() >= PreOverspeedDuration) {
			return judgePre(limit);
		}
		return false;
	}

	/**
	 * 连续五个速度都大于限速值
	 * 
	 * @param limit
	 * @return
	 */
	private boolean judgePre(int limit) {
		int k = 0;
		for (int i = 0; i < preQueue.size(); i++) {
			if (preQueue.get(i) > limit-preOverSpeedInterval) {
				k++;
			}
		}
		if (k == preQueue.size()) {
			isStartPre = false;
			preQueue.clear();
			return true;
		}else{
			preQueue.remove(0);
		}
		return false;
	}


	/**
	 * 车辆滞站甩站开始结束判定
	 * @param speed
	 * @return 1-运行  2-停止
	 */
	public int startStopJudge(float speed) {
		if (lastSpeed==-1) {
			lastSpeed=speed;
			return FLAG_UNSURE;
		}
		if (lastSpeed < MIX_SPEED && speed< MIX_SPEED) {
			return FLAG_STOPPED;
		}else if(lastSpeed > MIX_SPEED && speed > MIX_SPEED){
			return FLAG_RUNING;
		}
		return FLAG_UNSURE;
	}
	
}
