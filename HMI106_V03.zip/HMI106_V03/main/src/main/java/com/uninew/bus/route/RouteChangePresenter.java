package com.uninew.bus.route;

import java.util.List;

import com.uninew.file.dao.RoutesDao;
import com.uninew.file.dao.RunRoutesDao;

import android.content.Context;

public class RouteChangePresenter implements IRouteChangeListener,IRouteChangePresenter{

	private IRouteChangeView mRouteChangeView;
	private RouteChangeModel mRouteChangeModel;

	public RouteChangePresenter(Context mContext,IRouteChangeView mRouteChangeView) {
		super();
		this.mRouteChangeView = mRouteChangeView;
		mRouteChangeModel=new RouteChangeModel(mContext, this);
	}
	
//----------------------------向上传递-------------------------------------------------------
	@Override
	public void setRoutes(List<RoutesDao> routes) {
		// TODO Auto-generated method stub
		mRouteChangeView.showRoutes(routes);
	}

	@Override
	public void setCurrentRoutes(RunRoutesDao route) {
		// TODO Auto-generated method stub
		mRouteChangeView.showCurrentRoutes(route);
	}
//---------------------------向下传递----------------------------------------------------
	@Override
	public void switchRoute(RoutesDao route,IResultCallBack resultCallBack) {
		// TODO Auto-generated method stub
		mRouteChangeModel.switchRoute(route,resultCallBack);
	}

	@Override
	public void deleteRoute(RoutesDao route,IResultCallBack resultCallBack) {
		// TODO Auto-generated method stub
		mRouteChangeModel.deleteRoute(route,resultCallBack);
	}

	@Override
	public void exitManage() {
		// TODO Auto-generated method stub
		mRouteChangeModel.exitManage();
	}
	
	
}
