package com.uninew.bus.route;

import java.util.List;

import com.uninew.file.dao.RoutesDao;
import com.uninew.file.dao.RunRoutesDao;

public interface IRouteChangeView {
	
	/**
	 * 显示线路信息
	 * @param routes
	 */
	public void showRoutes(List<RoutesDao> routes);
	
	/**
	 * 显示当前线路
	 * @param route
	 */
	public void showCurrentRoutes(RunRoutesDao route);
	
}
