package com.uninew.bus.work;

import java.util.List;

import com.uninew.db.dh.dao.PlanWork;

public interface IPlanWorkPresenter {

	/**
	 * 查询排班信息
	 * @param times 时间点（查询某一天格式如下{"2017-02-16"}，null表示查询所有）
	 * @param planWorks
	 */
	public void queryPlanWorks(String[] times,IQueryPlanWorksCallBack planWorks);
	
	
	/**
	 * 删除排班信息
	 * @param ids 序号集合
	 * @param result
	 */
	public void deletePlanWorks(int[] ids,IResultCallBack result);
	
	/**
	 * 更新排班信息
	 * @param planWorks
	 * @param result
	 */
	public void updatePlanWorks(List<PlanWork> planWorks,IResultCallBack result);
	
	/**
	 * 页面退出处理
	 */
	public void exitManage();
	
}
