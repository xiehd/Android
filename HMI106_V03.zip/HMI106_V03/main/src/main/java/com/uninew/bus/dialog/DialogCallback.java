package com.uninew.bus.dialog;
/**
 *  用户执行用户确认操作的回调。
 * @author Administrator
 *
 */
public interface DialogCallback {
	void onUserConfirm(byte id);
}
