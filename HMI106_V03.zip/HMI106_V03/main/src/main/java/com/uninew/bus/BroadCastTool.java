package com.uninew.bus;

import android.content.Context;
import android.content.Intent;

import com.uninew.bus.constant.ActionDefine;
import com.uninew.bus.log.LogTool;

public class BroadCastTool {

	private static final String TAG = "BroadCastTool";
	private Context mContext;

	public BroadCastTool(Context mContext) {
		super();
		this.mContext = mContext;
	}
	
	/**
	 * GPS模拟测试
	 * @param state 0-start 1-stop 2 pause
	 */
	public void sendGpsTest(int state){
		Intent intent = new Intent("uninew.gps.test");
		intent.putExtra("state", state);
		mContext.sendBroadcast(intent);		
	}
	
	/**
	 * 发送当前位模拟置信息
	 */
	public void sendCurrentLocation(double lat,double lon){
		Intent intent = new Intent(ActionDefine.CurrentLocation);
		intent.putExtra(ActionDefine.GPS.Longitude, lon);
		intent.putExtra(ActionDefine.GPS.Latitude, lat);
		mContext.sendBroadcast(intent);
	}
	
	/**
	 * 发送DVR显示模式设置
	 */
	public void setDvrMode(int split,int pass){
		Intent intent = new Intent(ActionDefine.DvrDisplayMode);
		intent.putExtra(ActionDefine.DVRDisplayMode.KEY_DISPLAY_MODE, split);
		intent.putExtra(ActionDefine.DVRDisplayMode.KEY_DISPLAY_SERIAL, pass);
		mContext.sendBroadcast(intent);
	}
	
	/**
	 * 发送定位状态广播（发送至SystemUI）
	 * 
	 * @param state
	 *            0：未定位 1：已定位
	 */
	public void sendLocateStateNotify(int state) {
		Intent intent = new Intent();
		intent.setAction(ActionDefine.LocationState);
		intent.putExtra("State", state);
		mContext.sendBroadcast(intent);
	}
}
