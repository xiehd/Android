package com.uninew.bus.main;

import android.util.Log;

import com.uninew.JT808.bean.P_PChangeRoute;
import com.uninew.JT808.bean.T_PChangeRouteAns;
import com.uninew.bus.R;
import com.uninew.file.dao.RoutesDao;
import com.uninew.file.dao.RunRoutesDao;
import com.uninew.net.client.ClientReceiveManage;
import com.uninew.net.client.IClientReceiveListener.IMainListener;
import com.uninew.net.client.ClientSendManage;
import com.uninew.net.client.IClientReceiveManage;
import com.uninew.net.client.IClientSendManage;

public class NetCommManager {

	private static final boolean D=true;
	private static final String TAG="NetCommManager";
	private BusMainService service;
	private IClientSendManage mClientSendManage;
	private IClientReceiveManage mClientReceiveManage;

	public NetCommManager(BusMainService service) {
		super();
		this.service = service;
		init();
	}

	private void init() {
		mClientSendManage=new ClientSendManage(service);
		mClientReceiveManage = new ClientReceiveManage(service);
		mClientReceiveManage.registerMainListener(mainListener);
	}

	private IMainListener mainListener = new IMainListener() {

		@Override
		public void routeSwitch(P_PChangeRoute routeChange) {
			// 线路切换命令
			if(D)Log.d(TAG, "----routeSwitch----"+routeChange.toString());
			switchManage(routeChange);
		}

		@Override
		public void busInOutNotify(Object arg0) {
			// 车辆进出站通知

		}
	};
	
	private void switchManage(final P_PChangeRoute routeChange){
		int updown=routeChange.getDownMarkerNum();//待修改 0-上行，1-下行
		String upDownString = null;
		if (updown==0x00) {//上行
			upDownString=service.getResources().getString(R.string.file_up);
		}else if(updown==0x01) {//下行
			upDownString=service.getResources().getString(R.string.file_down);
		}
		boolean runSwitch=false;
		for (RoutesDao route : BusMainService.routes) {
			if ((route.getLineMark()+"").equals(routeChange.getRouteId())) {
				if (route.getRouteName().endsWith(upDownString)) {
					//线路存在,直行切换
					runSwitch=true;
					RunRoutesDao rd=new RunRoutesDao();
					rd.setRouteName(route.getRouteName());
					rd.setLineMark(route.getLineMark());
					service.switchRoute(rd, new IRouteSwitchCallBack() {
						
						@Override
						public void result(int result) {
							// TODO Auto-generated method stub
							if(D)Log.e(TAG, "--switchRoute--result-----"+result);
							routeSwitchResponse(routeChange, result^1);
						}
					});
				}
			}
		}
		if (!runSwitch) {
			routeSwitchResponse(routeChange, 0x03);
		}
		runSwitch=false;
	}

	private void routeSwitchResponse(P_PChangeRoute routeChange,int result){
		if(D)Log.e(TAG, "--routeSwitchResponse-------"+routeChange.toString());
		T_PChangeRouteAns tpa=new T_PChangeRouteAns(routeChange.getSerialNumber(), routeChange.getRouteId(), result);
		mClientSendManage.switchResponse(tpa);
	}
	
	public interface IRouteSwitchCallBack {
		
		/**
		 * 结果
		 * @param result 0-失败，1-成功
		 */
		void result(int result);
	}

}
