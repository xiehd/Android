package com.uninew.audio;

import java.io.IOException;

import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.MediaPlayer.OnCompletionListener;
import android.media.MediaPlayer.OnErrorListener;
import android.util.Log;

/**
 * 音频播放控制类
 * 
 * @author Administrator
 * 
 */
public class PlayerManager {

	private static final boolean D = true;
	private static final String TAG = "PlayerManager";
	public int id = 0;
	public int count = 0;
	private MediaPlayer mPlayer;
	private boolean isPause;
	private boolean isPlay;
	public boolean run;
	
	
	private AudioDao audio;
	private StopCallBack back;

	public PlayerManager() {
		mPlayer = new MediaPlayer();
	}

	public void PlayMusics(final AudioDao audio, final StopCallBack back) {
		this.audio=audio;
		this.back=back;
		State_Player.setState(State_Player.INIT);
		playManager();
	}

	private void playManager(){
		switch (State_Player.getState()) {
		case IDLE:
			
			break;
		case INIT:
			count=audio.getPaths().size();	
			if (audio.getPaths()==null || count <= 0) {
				Log.e(TAG,"voie files is null !!!");
				count=0;
				return ;
			}
			State_Player.setState(State_Player.START_PLAY);
			playManager();
			break;
			
		case START_PLAY:
			try {
				mPlayer.reset();
				mPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);
				if(D)Log.i(TAG, "path="+audio.getPaths().get(id));
				mPlayer.setDataSource(audio.getPaths().get(id));
				mPlayer.prepare();
				mPlayer.start();
			}catch (Exception e) {
				// TODO Auto-generated catch block
				Log.e(TAG, "Exception");
				State_Player.setState(State_Player.EXCEPTION);
				playManager();
			}
			mPlayer.setOnCompletionListener(new OnCompletionListener() {

				@Override
				public void onCompletion(MediaPlayer mp) {
					// TODO Auto-generated method stub
					State_Player.setState(State_Player.SIGNAL_OVER);
					playManager();
				}
			});
			mPlayer.setOnErrorListener(new OnErrorListener() {

				@Override
				public boolean onError(MediaPlayer mp, int what, int extra) {
					// TODO Auto-generated method stub
					State_Player.setState(State_Player.ERROR);
					playManager();
					return false;
				}
			});
			break;
		case SIGNAL_OVER:
			id++;
			if(D)Log.i(TAG, "Play over  for"+id);
			if (id < count) {
				State_Player.setState(State_Player.START_PLAY);
				playManager();
			}else {
				if(D)Log.i(TAG, "Play over!!!!");
				State_Player.setState(State_Player.OVER);
				playManager();
			}
			
			break;
		case EXCEPTION:
			id++;
			if (id < count && run) {
				State_Player.setState(State_Player.START_PLAY);
				playManager();
			}else {
				State_Player.setState(State_Player.OVER);
				playManager();
			}
			break;
		case ERROR:
			if (null != mPlayer) {
				mPlayer.release();
			}
			State_Player.setState(State_Player.START_PLAY);
			playManager();
			break;
		case OVER:
			id=0;
			count=0;
			mPlayer.release();
			isPlay=false;
			if (back!=null) {
				back.stopBack(audio);
			}
			State_Player.setState(State_Player.IDLE);
			playManager();
			break;
		default:
			break;
		}
	}
	
	
	private enum State_Player {
		IDLE, // 空闲状态
		INIT, // 资源初始化
		START_PLAY, // 开始播放
		SIGNAL_OVER, // 单个播放结束
		EXCEPTION, // 单个播报异常
		ERROR, // 单个播报错误
		CONTINUE_PLAY, // 继续播报
		OVER;	// 播报结束
		private static State_Player state = IDLE;

		public static State_Player getState() {
			return state;
		}

		public static void setState(State_Player state) {
			Log.d("State_Player", String.format(
					"###### State Changed: %s ==> %s ######", State_Player.state,
					state));
			State_Player.state = state;
		}
	}
	
	/**
	 * 停止当前播放
	 */
	boolean flag=true;
	public void stop() {
		flag=true;
		run=false;
		if (D)
			Log.v(TAG, "stop1,isPlay=" + isPlay+",flag="+flag);
		while(flag){
			Log.d(TAG, "-------------stop1,state=" + State_Player.getState());
			if (mPlayer.isPlaying()) {
					State_Player.setState(State_Player.IDLE);
					playManager();
					mPlayer.release();
					flag=false;
			}
			try {
				Thread.sleep(1);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	/**
	 * 暂停播放
	 */
	public void pause() {
		if (mPlayer.isPlaying()) {
			if (D)
				Log.i(TAG, "pause");
			mPlayer.pause();
			isPause = true;
		}
	}

	/**
	 * 恢复播放
	 */
	public void replay() {
		if (isPause) {
			isPause = false;
			if (D)
				Log.i(TAG, "replay");
			mPlayer.start();
		}
	}
}
