package com.uninew.bus.report.tools;

import com.uninew.bus.MainApplication;
import com.uninew.bus.R;

public class LedMsg {

	/**
	 * 起始站出站
	 * @param startName 起始站名称
	 * @param nextName 下一站名称
	 * @param routeName 线路名称
	 * @param endStation 终点站名称
	 * @param bigStation 途径站
	 * @return
	 */
	public String outStartStation(String startName, String nextName,
			String routeName, String endStation, String bigStation) {
		StringBuffer sb = new StringBuffer();
		sb.append(MainApplication.getInstance().getResources().getString(R.string.led_outStartStation1));
		sb.append(routeName);
		sb.append(MainApplication.getInstance().getResources().getString(R.string.led_outStartStation2));
		sb.append(startName);
		sb.append(MainApplication.getInstance().getResources().getString(R.string.led_outStartStation3));
		sb.append(endStation);
		sb.append(MainApplication.getInstance().getResources().getString(R.string.led_outStartStation4));
		sb.append(bigStation);
		sb.append(MainApplication.getInstance().getResources().getString(R.string.led_outStartStation5));
		sb.append(nextName);
		return sb.toString();
	}

	/**
	 * 进站
	 */
	public String inStation(String currentStationName) {
		StringBuffer sb = new StringBuffer();
		sb.append(currentStationName);
		sb.append(MainApplication.getInstance().getResources().getString(R.string.led_inStation));
		return sb.toString();
	}

	/**
	 * 出站
	 */
	public String outStation(String nextStationName) {
		StringBuffer sb = new StringBuffer();
		sb.append(MainApplication.getInstance().getResources().getString(R.string.led_outStation));
		sb.append(nextStationName);
		return sb.toString();
	}

	/**
	 * 倒数第二站出站
	 */
	public String outLastButOne(String nextStationName) {
		StringBuffer sb = new StringBuffer();
		sb.append(MainApplication.getInstance().getResources().getString(R.string.led_outLastButOneStation));
		sb.append(nextStationName);
		return sb.toString();
	}

	/**
	 * 终点站进站
	 */
	public String inEndStation(String endStationName) {
		StringBuffer sb = new StringBuffer();
		sb.append(MainApplication.getInstance().getResources().getString(R.string.led_inEndStation));
		sb.append(endStationName);
		sb.append(MainApplication.getInstance().getResources().getString(R.string.led_inEndStation2));
		return sb.toString();
	}

}
