package com.uninew.bus.report.marker;

import java.util.List;

import com.uninew.file.dao.MarkerDao;

/**
 * 输入类型接口
 * @author Administrator
 *
 */
public interface IMarkerRemind {
	/**
	 * 标记点处理开关
	 * 
	 * @param state
	 *            0-关，1-开
	 * @return
	 */
	public void onOffMarker(int state);

	/**
	 * 传入位置信息
	 * 
	 * @param positionState
	 *            定位状态：0-未定位，1-已定位
	 * @param longitude
	 *            经度
	 * @param latitude
	 *            纬度
	 * @param speed
	 *            速度
	 * @param direction
	 *            方向
	 * @param time
	 *            时间
	 */
	public void setGpsInfo(int positionState, double longitude,
			double latitude, float speed, int direction, long time);
	
	/**
	 * 设置标记点信息
	 * 
	 * @param markers
	 */
	public void setMarkers(List<MarkerDao> markers);
}
