package com.uninew.bus.camera;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.res.Configuration;
import android.graphics.Color;
import android.hardware.Camera;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.view.WindowManager;
import android.widget.TextView;

import com.uninew.bus.BroadCastTool;
import com.uninew.bus.KeyReceiveManage;
import com.uninew.bus.MainApplication;
import com.uninew.bus.R;
import com.uninew.bus.camera.CameraField.VideoState;
import com.uninew.bus.channel.VoiceChannelControl;
import com.uninew.bus.constant.ActionDefine;
import com.uninew.bus.constant.Constant;
import com.uninew.bus.view.SetViewDialog;
import com.uninew.bus.view.SetViewDialog.ClickListener;

import java.io.FileWriter;
import java.io.IOException;

public class CameraOpen extends Activity implements SurfaceHolder.Callback,OnClickListener,ClickListener {
	private static final boolean D=true;
	private static final String TAG = "CameraOpen";
	private SurfaceView surfaceview;
	private SurfaceHolder surfaceholder;
	private Camera camera = null;
	private IntentFilter intentFilter;
	private MyBroadCast myBroadCast;
	private TextView title;
	public FileWriter cameraFw;
	private boolean firstCameraOpen =true;
	private SurfaceHolder mholder;
	private SetViewDialog dialog;
	private boolean touchUsed;
//	private ReadStorageThread rst;//读取寄存器的值
	private String write = null;//保存当前的视频
	private  boolean isShow = false;//当前是否显示

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		Log.i(TAG, "onCreate");
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
		setContentView(R.layout.camera_main);
		firstCameraOpen =true;
//		isChangeCamer = false;
		intentFilter = new IntentFilter();
		intentFilter.addAction("camera.contral");
		intentFilter.addAction(ActionDefine.MCULinkKeys);
		myBroadCast = new MyBroadCast();
		registerReceiver(myBroadCast, intentFilter);
		setView();
		setCameraText(getIntent());
	}
	
	
	@Override
	protected void onNewIntent(Intent intent) {
		// TODO Auto-generated method stub
		super.onNewIntent(intent);
		setCameraText(intent);
	}


	@Override
	protected void onResume() {
		super.onResume();
		Log.i(TAG, "onResume");
		isShow = true;
		if(isRestart){
			if(D)Log.i(TAG, "isRestart");
			surfaceview.setBackgroundColor(Color.TRANSPARENT);
			try {
				cameraFw = new FileWriter(Constant.FILEPATH_CAMERA_SWITCH);
					cameraFw.write(write);
					cameraFw.close();
				Thread.sleep(200);
			} catch (IOException e1) {
				e1.printStackTrace();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		setCamera();
	}
	
	/**
	 * 加载摄像头视频文字
	 */
	private void setCameraText(Intent intent) {
		String videoSource = intent.getStringExtra("video source");
		write = videoSource;
		if(VoiceChannelControl.equipment_versions == 1){
			if (videoSource.equals("3")) {
				title.setText("DVR");
				touchUsed=true;
			}else if (videoSource.equals("2")) {
				title.setText(getString(R.string.reversing_car));
				touchUsed=false;
			}else if (videoSource.equals("1")) {
				title.setText(getString(R.string.backdoor));
				touchUsed=false;
			}
		}else if(VoiceChannelControl.equipment_versions == 0){
			if (videoSource.equals("1")) {
				title.setText("DVR");
				touchUsed=true;
			}else if (videoSource.equals("2")) {
				title.setText("倒车");
				touchUsed=false;
			}else if (videoSource.equals("3")) {
				title.setText("后门");
				touchUsed=false;
			}
		}
	}

	/**
	 * 加载控件
	 */
	private void setView() {
		// TODO Auto-generated method stub
		surfaceview = (SurfaceView) findViewById(R.id.surfaceview);
		title = (TextView) findViewById(R.id.title1);
		if (MainApplication.dvrState!=null) {
			dialog=new SetViewDialog(this, MainApplication.dvrState.getMaxNum());
		}else{
			dialog=new SetViewDialog(this, 4);
		}
		dialog.setClickListener(this);
		surfaceview.setOnClickListener(this);
	}

	/**
	 * 摄像头加载
	 */
	@SuppressWarnings("deprecation")
	private void setCamera() {
		// TODO Auto-generated method stub
		surfaceholder = surfaceview.getHolder();
		surfaceholder.setType(SurfaceHolder.SURFACE_TYPE_PUSH_BUFFERS);
		surfaceholder.addCallback(CameraOpen.this);
	}

	private boolean isRestart = false;//判断是否处于重启状态
	private Handler mHandler = new Handler() {
		public void handleMessage(Message msg) {
			if (msg.what == 0x01) {// 视频重启操作
				if (isRestart) {
					surfaceview.setBackgroundColor(Color.TRANSPARENT);
					surfaceCreated(mholder);
				}
			} else if (msg.what == 0x02) {//视频关闭操作
				surfaceview.setBackgroundColor(Color.BLACK);//视频置黑
				new Thread(new Runnable() {
					@Override
					public void run() {
						try {
							if (camera != null) {
								try {
									camera.lock();//将摄像头加锁
									camera.stopPreview();//停止摄像头
									camera.release();//清空视频流
									firstCameraOpen = false;
									isRestart = true;//将状态置为重启状态
								} catch (Exception e) {
									e.printStackTrace();
								}
							}
						} finally {
							if (isRestart && camera != null) {
								try {
									camera.reconnect();//将摄像头解锁
								} catch (Exception e) {
									e.printStackTrace();
								}
							}
						}
					}
				}).start();
			}
		};
	};

	@Override
	public void surfaceChanged(SurfaceHolder holder, int arg1, int arg2, int arg3) {
		if(D)Log.d(TAG, "surfaceChanged");
//		if(rst == null){
//			isRunning = true;
//			rst = new ReadStorageThread();
//			rst.start();
//		}
		try {
			cameraFw = new FileWriter(Constant.FILEPATH_CAMERA_REG);
			cameraFw.write("add");
			cameraFw.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void surfaceCreated(SurfaceHolder holder) {
		if(D)Log.d(TAG, "surfaceCreated");
		mholder = holder;
		int number = Camera.getNumberOfCameras();
		if(D)Log.d(TAG, "NumberOfCameras:"+number);
		try {
			try {
				camera = Camera.open();
			} catch (RuntimeException e) {
				if(camera != null){
					camera.release();
				}
				if(number > 0){
					camera = Camera.open(number - 1);
				}
			}
			if(camera != null){
				// 设置预览监听
				camera.setPreviewDisplay(holder);
				Camera.Parameters parameters = camera.getParameters();
				if (this.getResources().getConfiguration().orientation != Configuration.ORIENTATION_LANDSCAPE) {
					parameters.set("orientation", "portrait");
					camera.setDisplayOrientation(90);
					parameters.setRotation(90);
				} else {
					parameters.set("orientation", "landscape");
					camera.setDisplayOrientation(0);
					parameters.setRotation(0);
				}
				camera.setParameters(parameters);
				firstCameraOpen = true;
				//drawText();
				// 启动摄像头预览
				camera.startPreview();
//				if(isChangeCamer){
//					isChangeCamer = false;
//				}
				isRestart = false;
			}
		} catch (Exception e) {
			e.printStackTrace();
//			Toast.makeText(CameraOpen.this, "无视频源,请检查连接.",Toast.LENGTH_SHORT ).show();
			firstCameraOpen=false;
			surfaceview.setBackgroundColor(Color.BLACK);
//			if(isChangeCamer){
//				isChangeCamer = false;
//			}
			try{
				if(camera != null){
					camera.stopPreview();
					camera.release();
				}
			}catch (Exception e1) {
				e1.printStackTrace();
			}
			flag = 0;
			isRestart =true;
		}
	}
	
	@Override
	public void surfaceDestroyed(SurfaceHolder arg0) {
		if(D)Log.d(TAG, "surfaceDestroyed");
		if (camera != null) {
			try {
				// camera.stopPreview();
				 //camera.release();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	
	/**
	 * 广播接收器
	 * 
	 * @author jiami
	 * 
	 */
	private class MyBroadCast extends BroadcastReceiver {

		@Override
		public void onReceive(Context context, Intent intent) {
			int intExtra = intent.getIntExtra("cont", 0);
			String action = intent.getAction();
			if(action.equals("camera.contral")){
				switch (intExtra) {
				case CameraField.Camera_close:
					try {
						camera.stopPreview();
						camera.release();
						firstCameraOpen = false;
					} catch (Exception e) {
						e.printStackTrace();
					}
					break;
				case CameraField.Camera_destroy:
					finish();
					break;
				case CameraField.Camera_change:
					 changeVideo(intent);
					break;
				}
			}else if(ActionDefine.MCULinkKeys.equals(action)){
				int keyCode = intent.getIntExtra("key", 0);
				int state = intent.getIntExtra("state", 0);
				switch (keyCode) {
				case 173:
					if(state == 0){
						if (flag == 1) {
							flag = 0;// 置为关闭视频状态
							mHandler.sendEmptyMessage(0x02);
						}
					}else if(state == 1){
						if (flag == 0) {
							flag = 1;// 置为开启视频状态
							mHandler.sendEmptyMessage(0x01);
						}
					}
					break;
				}
			}
		}

		private void changeVideo(Intent intent) {
			// TODO Auto-generated method stub
			if(dialog.isShowing()){
				dialog.dismiss();
			}
			System.err.println("-----------isShow="+isShow);
//			isChangeCamer = true;
			setCameraText(intent);
			write = intent.getStringExtra("video source");
			if(D)Log.i("cameraOpen", "changeSource:"+write);
			if (firstCameraOpen && isCameraStop()) {
				//如果第一个摄像头好用
				try {
					cameraFw = new FileWriter(Constant.FILEPATH_CAMERA_SWITCH);
						cameraFw.write(write);
						cameraFw.close();
					Thread.sleep(350);
				} catch (IOException e1) {
					e1.printStackTrace();
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
				try {
					camera.release();
					surfaceCreated(mholder);
				} catch (Exception e) {
					Log.e("Tag", "notopen");
				}
			}
			else {
				//如果第一个摄像头不好用
				surfaceview.setBackgroundColor(Color.TRANSPARENT);
				try {
					cameraFw = new FileWriter(Constant.FILEPATH_CAMERA_SWITCH);
					cameraFw.write(write);
					cameraFw.close();
					Thread.sleep(350);
				} catch (IOException e) {
					e.printStackTrace();
				} catch (InterruptedException e) {
					e.printStackTrace();
				} 
				surfaceCreated(mholder);
			}			
		}
	}
	
	protected void onDestroy() {
		Log.i(TAG, "onDestroy");
		unregisterReceiver(myBroadCast);
		try{
			if(camera != null){
				camera.stopPreview();
				camera.release();
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		super.onDestroy();
	}
	
	@Override
	protected void onPause() {
		super.onPause();
		Log.i(TAG, "onPause");
		isShow = false;
		isRunning = false;
//		if(rst != null){
//			rst.interrupt();//关闭监听视频寄存器值的线程
//			rst = null;
//		}
		mHandler.sendEmptyMessage(0x02);//关闭视频流
		surfaceholder.removeCallback(CameraOpen.this);//界面显示不在视频时关闭surface的监听事件
	}
	public void onBackPressed() {
		//倒车状态点击返回无反应
		if (CameraField.lst == null || CameraField.lst.isEmpty()) {
			if(D)Log.i("CameraOpen", "isBack");
			super.onBackPressed();
		}
		if(CameraField.lst == null || CameraField.lst.isEmpty()){
			finish();
		}
	}
	/**
	 * 打开摄像头
	 * @param context
	 * @param state
	 */
	public static void openCamer(Context context, VideoState state) {
		try {
			FileWriter cameraFw = new FileWriter(
					Constant.FILEPATH_CAMERA_SWITCH);
			cameraFw.write(state.getWrite());
			cameraFw.close();
			Thread.sleep(350);
			Intent intent = new Intent(context, CameraOpen.class);
			intent.putExtra("video source", state.getWrite());
			intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
			context.startActivity(intent);
			CameraField.lst.add(0, state);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}
	/**
	 * 关闭摄像头
	 */
	public static void closeCamer(Context context,VideoState state){
		CameraField.closeState = state;
		if (CameraField.lst.size() == 1) {//直接关闭
			CameraField.lst.clear();
			Intent intent = new Intent("camera.contral");
			intent.putExtra("cont", CameraField.Camera_destroy);
			context.sendBroadcast(intent);
		} else if (CameraField.lst.size() > 1) {
			boolean result = KeyReceiveManage.hasPriority(CameraField.closeState);
			if (result) {// 存在优先级高于要关闭的优先级
				CameraField.lst.remove(CameraField.closeState);
			} else {// 如果不存在
				CameraField.lst.remove(CameraField.closeState);
				VideoState state2 = CameraField.lst.get(0);
				Intent intent2 = new Intent("camera.contral");
				intent2.putExtra("cont", CameraField.Camera_change);
				intent2.putExtra("video source", state2.getWrite());
				context.sendBroadcast(intent2);
			}
		}
	}
	
//	private  boolean isChangeCamer = false;//判断是否切换视频 是：true 否：false
	
	/**
	 * 改变摄像头
	 */
	public static void changeCamer(Context context,VideoState state){
		Intent intent = new Intent("camera.contral");
		intent.putExtra("cont", CameraField.Camera_change);
		intent.putExtra("video source", state.getWrite());
		context.sendBroadcast(intent);
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		if (touchUsed) {
			dialog.show();
		}
	}

	@Override
	public void onBackView(int type, int number) {
		// TODO Auto-generated method stub
		if (type==4) {
		    //四路
			switch (number) {
			case 0x0000:
			case 0x0001:
			case 0x0002:
			case 0x0003:
				setDvr(0, number);//单画面
				break;
			case 0x0010:
				setDvr(1, 0);//0-1通道
				break;
			case 0x0023:
				setDvr(1, 1);//2-3通道
				break;
			case 0x0011:
				setDvr(3, 0);//四通道
				break;
			default:
				break;
			}
		}else{
			switch (number) {
			case 0x0001:
			case 0x0002:
			case 0x0003:
			case 0x0004:
			case 0x0005:
			case 0x0006:
			case 0x0007:
			case 0x0008:
				setDvr(0, number);
				break;
			//双画面
			case 0x0010:
				setDvr(1, 0);
				break;
			case 0x0023:
				setDvr(1, 1);
				break;
			case 0x0045:
				setDvr(1, 2);
				break;
			case 0x0067:
				setDvr(1, 3);
				break;
			//四画面
			case 0x0123:
				setDvr(3, 0);
				break;
			case 0x4567:
				setDvr(3, 1);
				break;
			//八画面
			case 0x0111:
				setDvr(3, 0);//八画面，默认第一通道为大画面
				break;
			default:
				break;
			}
		}
	}
	/**
	 * 设置DVR显示模式
	 * @param split
	 * @param pass
	 */
	private void setDvr(int split,int pass){
		new BroadCastTool(this).setDvrMode(split, pass);
		dialog.dismiss();
	}
	//////////////////////////////// 热插拔处理  /////////////////////////////////////////
	private volatile boolean isRunning = true;
	private int flag = 1;//记录视频接入和拔出的信号
	private final static int length = 0x8000000; 
//	
//	/**
//	 * 读取寄存器值的线程
//	 * @author rong
//	 *
//	 */
//	private class ReadStorageThread extends Thread{
//		@SuppressWarnings("resource")
//		@Override
//		public void run() {
//			super.run();
//			// 线程异常退出，线程停止
//			if (Thread.interrupted()) {
//				try {
//					throw new InterruptedException();
//				} catch (InterruptedException e) {
//					e.printStackTrace();
//				}
//			}
//			File file = new File(Constant.FILEPATH_CAMERA_REG);
//			if (file.exists()) {
//				FileInputStream fis = null;
//				InputStreamReader in = null;
//				BufferedReader reader = null;
////				Properties  properties = new Properties();
//				while (isRunning) {
//					
//					try {
//						fis = new FileInputStream(file);
//						in = new InputStreamReader(fis);
//						reader = new BufferedReader(in);
////						properties.load(fis);
//						String s = reader.readLine().trim();
//						if (D)
//							Log.d(TAG, "-----------------msg--------------------" + s);
//						// new String(buffer);
//						if (!TextUtils.isEmpty(s)) {
//							int storage = Integer.parseInt(s);
//							// LogTool.logD(TAG, ""+storage);
//							// if(storage != 0){
//							if (decideVideo(storage)) {
//								if (flag == 0) {
//									try {
//										flag = 1;// 置为开启视频状态
//										mHandler.sendEmptyMessage(0x01);
//									} finally {
//										Thread.sleep(200);
//									}
//								}
//							} else {
//								if (flag == 1) {
//									try {
//										flag = 0;// 置为关闭视频状态
//										mHandler.sendEmptyMessage(0x02);
//									} finally {
//										Thread.sleep(200);
//									}
//								}
//							}
//						}
//					} catch (Exception e) {
//						e.printStackTrace();
//					} finally {
//						if(fis != null){
//							try {
//								fis.close();
//							} catch (IOException e) {
//								// TODO Auto-generated catch block
//								e.printStackTrace();
//							}
//						}
//						if(in != null){
//							try {
//								in.close();
//							} catch (IOException e) {
//								// TODO Auto-generated catch block
//								e.printStackTrace();
//							}
//						}
//						if(reader != null){
//							try {
//								reader.close();
//							} catch (IOException e) {
//								e.printStackTrace();
//							}
//						}
//						try {
//							Thread.sleep(1500);
//						}catch (InterruptedException e) {
//							e.printStackTrace();
//						}
//					}
//				}
//			} else {
//				return;
//			}
//		}
//	}
//	
	
	/**
	 * 根据寄存器的值判断是否有视频源
	 * @param storage
	 * @return true：有视频源  false：无视频源
	 */
	private boolean decideVideo(int storage){
		boolean isExist = false;
		//(storage & (0x1 << 0)) == 1
		if(storage == 1 ){
			return (isExist=true);
		}else if(storage == 0){
			isExist = false;
		}
		return isExist;
	}
	
	/**
	 * 判断是否已经停止，没有将其停止
	 * @return
	 */
	private boolean isCameraStop(){
		try {
			camera.stopPreview();
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
	}
	
}
