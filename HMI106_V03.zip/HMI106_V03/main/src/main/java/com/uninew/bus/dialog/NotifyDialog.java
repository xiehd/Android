package com.uninew.bus.dialog;

import java.util.Map;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import com.uninew.bus.R;


public class NotifyDialog extends Dialog implements android.view.View.OnClickListener{
	private AppDialog myDialog;
	private TextView title,descriable,driverdata_1,driverdata_2,driverdata_3,driverdata_4,driverdata_5;
	private Button btn_ok,btn_cancel;
	private ListView questList;
	private Context context;
	private DialogCallback callback;
	private DialogDismissListener dismissListener;
	private LinearLayout driverdataLayout;
	QuestListAdapter adapter ;
	
	public NotifyDialog(Context context){
		super(context,R.style.FullScreenDialog);
		this.context = context;
	}
	public NotifyDialog(Context context,int theme){
		super(context,R.style.FullScreenDialog);
		this.context = context;
	}
	public void setDialogType(AppDialog dialog,DialogCallback callback ){
		this.myDialog = dialog;
		this.callback = callback;
		Log.i("mmm","NotifyDialog.........setDialogType....");
	}
	@Override
	public void cancel() {
		super.cancel();
	}
	@Override
	public void dismiss() {
		Log.i("mmm","NotifyDialog.........dismiss....");
		if(dismissListener!=null){
			dismissListener.onDismiss();
		}
		super.dismiss();
	}
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		Log.i("mmm","NotifyDialog.........onCreate....");
		super.onCreate(savedInstanceState);
		setContentView(R.layout.public_dialog);
		this.title = (TextView)findViewById(R.id.title);
		this.descriable = (TextView)findViewById(R.id.discriable);
		this.btn_ok = (Button) findViewById(R.id.button_sure);
		this.btn_cancel = (Button) findViewById(R.id.button_cancel);
		this.driverdataLayout = (LinearLayout) findViewById(R.id.driverdata_layout);
		this.driverdata_1 = (TextView)findViewById(R.id.driverdata_namecontent);
		this.driverdata_2 = (TextView)findViewById(R.id.driverdata_profecontent);
		this.driverdata_3 = (TextView)findViewById(R.id.driverdata_ilPatentecontent);
		this.driverdata_4 = (TextView)findViewById(R.id.driverdata_certifycontent);
		this.driverdata_5 = (TextView)findViewById(R.id.driverdata_validitycontent);
		this.questList = (ListView) findViewById(R.id.questList);
		this.btn_cancel.setOnClickListener(this);
		this.btn_ok.setOnClickListener(this);
		Log.i("mmm","NotifyDialog.........onCreate....");
	}
	
	
	@Override
	protected void onStart() {
		super.onStart();
		if(myDialog!=null){
			descriable.setText(myDialog.getText());
			questList.setVisibility(View.GONE);
			driverdataLayout.setVisibility(View.GONE);
			this.btn_cancel.setVisibility(View.GONE);
			adapter=null;
			switch(myDialog.getDialogType()){
			case MsgID.ID_TEXT_MSG_ISSUED:
				title.setText(R.string.dialog_title_textnotify);
//				TtsUtil.getInstance(context).startSpeak(myDialog.getText().toString());
				break;
			case MsgID.ID_ASKED_ISSUED:
				title.setText(R.string.dialog_title_question);
				questList.setVisibility(View.VISIBLE);
				adapter = new QuestListAdapter(context, myDialog.getAnswerList());
				questList.setAdapter(adapter);
				this.btn_cancel.setVisibility(View.VISIBLE);
				break;
			case MsgID.ID_INFORMATION_SERVICE:
				break;
			case MsgID.ID_VEHICLE_CONTROL:
				title.setText(R.string.dialog_title_vehicle_control);
				break;
			case MsgID.ID_DRIVER_IDENTITY_INFORMATION_COLLECTION_SUBMITTED:
				Map<String ,String> driverData = myDialog.getDriverData();
				driverdataLayout.setVisibility(View.VISIBLE);
				if(driverData!=null && driverData.size()>0){
					driverdata_1.setText(driverData.get(context.getResources().getString(R.string.driverdata_name)));
					driverdata_2.setText(driverData.get(context.getResources().getString(R.string.driverdata_profe)));
					driverdata_3.setText(driverData.get(context.getResources().getString(R.string.driverdata_ilPatente)));
					driverdata_4.setText(driverData.get(context.getResources().getString(R.string.driverdata_certifyAuthority)));
					driverdata_5.setText(driverData.get(context.getResources().getString(R.string.driverdata_validity)));
				}
				break;
			}
			if(myDialog.getMsgTitle()!=null){
				title.setText(myDialog.getMsgTitle());
			}
			Log.i("mmm","NotifyDialog.........onStart....");
		}
	}
	byte getClickId(){
		if(adapter!=null){
			return adapter.getClickId();
		}
		return (byte)0xff;
	}
	@Override
	public void show() {
		super.show();
//		WindowManager.LayoutParams lp=getWindow().getAttributes();
//		lp.alpha=0.3f;
//		getWindow().setAttributes(lp);
		Log.i("mmm","NotifyDialog.........show....");
	}
	
	@Override
	public void onClick(View view) {
		// TODO Auto-generated method stub
		if(view.getId() == R.id.button_sure){
			if(myDialog!=null && (MsgID.ID_ASKED_ISSUED == myDialog.getDialogType()) && callback!=null){
				callback.onUserConfirm(getClickId());
			}
			Log.i("mmm","NotifyDialog.........onCLick...aaaa.");
			this.dismiss();
		}else if(view.getId() == R.id.button_cancel){
			Log.i("mmm","NotifyDialog.........onCLick...aaaa.");
			this.dismiss();
		}
	}
	
	public void setDismissListener(DialogDismissListener dismissListener) {
		this.dismissListener = dismissListener;
	}

	interface DialogDismissListener{
		void onDismiss();
	}
}
