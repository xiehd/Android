package com.uninew.bus.widget;

public class CustemObject {

	public String data = "";
	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return data;
	}

	
}
