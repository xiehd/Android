package com.uninew.bus.dialog;

import java.util.List;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.uninew.bus.R;

public class QuestListAdapter extends BaseAdapter {
	
	Context context;
	List <QuestionOption > questionList ;
	LayoutInflater inflater;
	ViewHolder clickHolder =null;
	DialogCallback callback;
	public QuestListAdapter(Context context,List<QuestionOption> questionList) {
		super();
		this.questionList = questionList;
		this.context = context;
		this.inflater = LayoutInflater.from(context);
	}

	public byte getClickId(){
		if(clickHolder!=null){
			return clickHolder.id;
		}
		return (byte)0xff;
	}
	@Override
	public int getCount() {
		if(questionList!=null && questionList.size()>0){
			return questionList.size();
		}
		return 0;
	}

	@Override
	public Object getItem(int position) {
		if(questionList!=null && questionList.size()>0){
			return questionList.get(position);
		}
		return null;
	}

	@Override
	public long getItemId(int position) {
		return position;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup arg2) {
		ViewHolder holder;
		QuestionOption  option = questionList.get(position);
		if (convertView == null) {
			convertView = inflater.inflate(R.layout.questitem, null);
			holder = new ViewHolder();
			holder.iv = (ImageView) convertView.findViewById(R.id.iv_item);
			holder.tv = (TextView) convertView.findViewById(R.id.tv_item);
			holder.id = option.getAnswerId();
			convertView.setTag(holder);
			if(clickHolder!=null && clickHolder.id == holder.id){
				holder.iv.setSelected(true);
			}else{
				holder.iv.setSelected(false);
			}
			convertView.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View view) {
					ViewHolder holder = (ViewHolder)view.getTag();
					if(clickHolder==null){
						holder.iv.setSelected(true);
						clickHolder=holder;
					}else if(clickHolder.id!=holder.id){
						clickHolder.iv.setSelected(false);
						holder.iv.setSelected(true);
						clickHolder=holder;
					}else{
						holder.iv.setSelected(false);
						clickHolder = null;
					}
				}
			});
		}else{
			holder = (ViewHolder) convertView.getTag();
			holder.iv.setSelected(false);
		}
			holder.position = position;
			holder.id=option.getAnswerId();
			holder.tv.setText(option.getAnswer());
			convertView.setTag(holder);
		return convertView;
	}

class ViewHolder{
	int position;
	byte id;
	ImageView iv;
	TextView tv;
}
}
