package com.uninew.bus.route;

import com.uninew.file.dao.RoutesDao;

public interface IRouteChangePresenter {
	
	/**
	 * 切换线路
	 * @param route
	 */
	public void switchRoute(RoutesDao route,IResultCallBack resultCallBack);
	
	/**
	 * 删除线路
	 */
	public void deleteRoute(RoutesDao route,IResultCallBack resultCallBack);
	
	
	/**
	 * 页面退出处理
	 */
	public void exitManage();
	
}
