package com.uninew.bus.dialog;

import java.lang.reflect.Method;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.text.InputType;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;

import com.uninew.bus.R;

public class SignDialog extends Dialog implements android.view.View.OnClickListener {

	private LayoutInflater layoutInflater;
	private View view;
	private Button sign;
	private Button one;
	private Button two;
	private Button three;
	private Button four;
	private Button five;
	private Button six;
	private Button seven;
	private Button eight;
	private Button nine;
	private Button zero;
	private Button del;
	private Button sc;
	private EditText input;// 工号输入窗口

	private DisplayMetrics d;// 通过此类来得到设备屏幕的宽高
	private Window dialogWindow;// 将LayoutParams中设置的参数实际显示
	private WindowManager.LayoutParams lp;// 设置宽高和位置的参数
	private ClickListenerInterface clickListenerInterface;
	private boolean isSigned = false;// 状态
	private String number;// 工号
	private String pwdString;

	public SignDialog(Context context) {
		super(context);
		layoutInflater = LayoutInflater.from(context);
		dialogWindow = getWindow();
		lp = dialogWindow.getAttributes();
		d = context.getResources().getDisplayMetrics(); // 获取屏幕宽、高用
	}

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		initView();
		initAction();
//		if (BusActivity.getSignState()) {
//			sign.setText("签退");
//			input.setText(MainApplication.settings.getJobNumber());
//		} else {
//			sign.setText("签到");
//		}
	}

	/**
	 * 签到或者签退按钮的点击事件
	 * 
	 * @author rong
	 *
	 */
	public interface ClickListenerInterface {
		/**
		 * 签到事件处理的方法
		 */
		void sign(String jobNumber);

		/**
		 * 签退事件处理的方法
		 */
		void unSign(String jobNumber);
	}

	/**
	 * 点击是事件初始化的方法
	 */
	private void initAction() {
		one.setOnClickListener(this);
		two.setOnClickListener(this);
		three.setOnClickListener(this);
		four.setOnClickListener(this);
		five.setOnClickListener(this);
		six.setOnClickListener(this);
		seven.setOnClickListener(this);
		eight.setOnClickListener(this);
		nine.setOnClickListener(this);
		zero.setOnClickListener(this);
		del.setOnClickListener(this);
		sc.setOnClickListener(this);
		sign.setOnClickListener(this);
	}

	/**
	 * 界面初始化的方法
	 */
	private void initView() {
		view = layoutInflater.inflate(R.layout.sign_in, null);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(view);
		sign = (Button) view.findViewById(R.id.bt_sign);
		one = (Button) view.findViewById(R.id.bt_one);
		two = (Button) view.findViewById(R.id.bt_two);
		three = (Button) view.findViewById(R.id.bt_three);
		four = (Button) view.findViewById(R.id.bt_four);
		five = (Button) view.findViewById(R.id.bt_five);
		six = (Button) view.findViewById(R.id.bt_six);
		seven = (Button) view.findViewById(R.id.bt_seven);
		eight = (Button) view.findViewById(R.id.bt_eight);
		nine = (Button) view.findViewById(R.id.bt_nine);
		zero = (Button) view.findViewById(R.id.bt_zero);
		del = (Button) view.findViewById(R.id.bt_del);
		sc = (Button) view.findViewById(R.id.bt_sc);
		input = (EditText) view.findViewById(R.id.et_input);

		// 隐藏editText的软键盘的处理
		if (android.os.Build.VERSION.SDK_INT <= 10) {
			input.setInputType(InputType.TYPE_NULL);
		} else {
			getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
			try {
				Class<EditText> cls = EditText.class;
				Method setSoftInputShownOnFocus;
				setSoftInputShownOnFocus = cls.getMethod("setShowSoftInputOnFocus", boolean.class);
				setSoftInputShownOnFocus.setAccessible(true);
				setSoftInputShownOnFocus.invoke(input, false);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		// 隐藏editText的软键盘的处理
		lp.width = d.widthPixels; // 宽度设置为屏幕的宽度
		lp.height = 455;
		dialogWindow.setAttributes(lp);
	}

	/**
	 * 设置工号框的显示参数
	 * 
	 * @param number
	 *            工号
	 */
	public void setJobNumber(String number) {
		if (!TextUtils.isEmpty(number)) {
			input.setText(number);
		}
	}

	/**
	 * 改变按钮的显示内容
	 * 
	 * @param signString
	 */
	public void setSignOrUnsign(String signString) {
		if (!TextUtils.isEmpty(signString)) {
			if (sign!=null) {
				sign.setText(signString);
			}
		}
	}

	/**
	 * 得到工号
	 * 
	 * @return
	 */
	public String getJobNumber() {

		if (!TextUtils.isEmpty(number)) {
			return number;
		}
		return null;
	}

	/**
	 * 得到密码
	 * 
	 * @return
	 */
	public String getPwdString() {
		return pwdString;
	}

	/**
	 * 添加点击事件的方法
	 * 
	 * @param clickListenerInterface
	 */
	public void setClicklistener(ClickListenerInterface clickListenerInterface) {
		this.clickListenerInterface = clickListenerInterface;
	}

	@Override
	public void onClick(View v) {

		switch (v.getId()) {
		case R.id.bt_one:
			showTextString("1");
			break;
		case R.id.bt_two:
			showTextString("2");
			break;
		case R.id.bt_three:
			showTextString("3");
			break;
		case R.id.bt_four:
			showTextString("4");
			break;
		case R.id.bt_five:
			showTextString("5");
			break;
		case R.id.bt_six:
			showTextString("6");
			break;
		case R.id.bt_seven:
			showTextString("7");
			break;
		case R.id.bt_eight:
			showTextString("8");
			break;
		case R.id.bt_nine:
			showTextString("9");
			break;
		case R.id.bt_zero:
			showTextString("0");
			break;
		/** 清空 **/
		case R.id.bt_del:
			if (input.hasFocus())
				input.setText("");
			break;
		/** 删除 **/
		case R.id.bt_sc:
			if (input.hasFocus())
				setSCText(input);
			break;
		/** 登录 **/
		case R.id.bt_sign:
			if(clickListenerInterface==null){
				break;
			}
			if (isSigned) {
				number = input.getText().toString().trim();
				clickListenerInterface.unSign(number);
			} else {
				number = input.getText().toString().trim();
				clickListenerInterface.sign(number);
			}
			break;
		default:
			break;
		}
	}

	/**
	 * 删除退格的方法
	 * 
	 * @param et
	 */
	private void setSCText(EditText et) {
		if (!TextUtils.isEmpty(et.getText())) {
			int length = et.getText().length();
			et.getText().delete((length - 1), length);
		}
	}

	/**
	 * 添加数字的方法
	 * 
	 * @param s
	 */
	private void showTextString(String s) {
		if (input.hasFocus())
			input.append(s);
	}

	/**
	 * 设置当前的状态 已签到
	 */
	public void isSign() {
		isSigned = true;
	}

	/**
	 * 设置当前的状态 未签到
	 */
	public void isUnSign() {
		isSigned = false;
	}

	/**
	 * 让返回键失效的方法
	 */
	@Override
	public void setCancelable(boolean flag) {
		super.setCancelable(flag);
	}

}
