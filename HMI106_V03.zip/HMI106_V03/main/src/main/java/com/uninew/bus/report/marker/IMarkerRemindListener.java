package com.uninew.bus.report.marker;

import com.uninew.file.dao.MarkerDao;

/**
 * 输出类型接口
 * @author Administrator
 *
 */
public interface IMarkerRemindListener {
	/**
	 * 进出标记点信息
	 * @param inOutState 0-进，1-到，2-出
	 * @param markerType 标记点类型 0-转弯，1-路口，2-直行，3-停车场，4-首站，5-场站一体，6-虚站
	 * @param marker 标记点
	 */
	public void inOutMarker( int inOutState,int markerType,MarkerDao marker);
}
