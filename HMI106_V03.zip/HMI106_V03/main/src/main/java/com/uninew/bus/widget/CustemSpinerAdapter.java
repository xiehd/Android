package com.uninew.bus.widget;

import android.content.Context;

public class CustemSpinerAdapter extends AbstractSpinerAdapter<CustemObject>{

	public CustemSpinerAdapter(Context context) {
		super(context);
	}

}
