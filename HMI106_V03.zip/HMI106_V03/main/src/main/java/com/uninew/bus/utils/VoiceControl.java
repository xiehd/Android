package com.uninew.bus.utils;

import java.io.FileWriter;
import java.io.IOException;

public class VoiceControl {
	// WM8988音量控制
	private static String FILEPATH_SETTING_VOIDCONTROL = "/sys/hmi116_snd_control/snd_control";

	/**
	 * 音量控制
	 */
	private static FileWriter cameraFw = null;

	public static void voidControl(String type, String adress, int number) {

		try {

			cameraFw = new FileWriter(FILEPATH_SETTING_VOIDCONTROL);
			// Log.i("My", type + adress + number);

			if (cameraFw != null) {
				cameraFw.write(type + adress + number);
				cameraFw.close();
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
