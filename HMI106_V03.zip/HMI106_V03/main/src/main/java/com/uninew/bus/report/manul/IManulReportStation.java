package com.uninew.bus.report.manul;

import java.util.ArrayList;

import com.uninew.file.dao.StationDao;

public interface IManulReportStation {
	
	/**
	 * 手动报站开关
	 * 
	 * @param state
	 *            0-关，1-开
	 * @return
	 */
	public void onOffManulReport(int state);
	
	/**
	 * 同步自动报站
	 * @param currentIndex 当前站编号
	 */
	public void syncAutoReport(int currentIndex);
	/**
	 * 设置站点信息
	 * @param stations 站点列表
	 */
	public void setStations(ArrayList<StationDao> stations);
	
	/**
	 * 输入播报、上行、下行切换值
	 * @param keyCode
	 */
	public void setKeyCode(int keyCode);
	
	/**
	 * 上下行切换通知
	 */
	public void switchUpDownNotify();
}
