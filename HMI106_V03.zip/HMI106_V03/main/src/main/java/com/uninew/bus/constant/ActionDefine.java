package com.uninew.bus.constant;

import android.widget.EditText;

public interface ActionDefine {

	/** 查询平台连接状态 */
	String NETLinkConnStateRequest = "Com.NETLink.ConnStateRequest";
	/** 连接平台请求 */
	String NETLinkConnRequest = "Com.NETLink.ConnRequest";
	/** 断开平台请求 */
	String NETLinkDisConnRequest = "Com.NETLink.DisConnRequest";
	/** 平台连接结果 */
	String NETLinkState = "Com.NETLink.State";
	
	/** dvr状态通知*/
	String DvrState = "Com.DVR.State";
	/** dvr状态通知键值*/
	String DvrState_Key = "DvrState";
	
	/** dvr显示模式设置*/
	String DvrDisplayMode = "Com.DVR.DisplayMode";
	
	
	/** 注册 */
	String NETLinkRegister = "Com.NETLink.Register";
	/** 注册应答 */
	String NETLinkRegisterResponse = "Com.NETLink.RegisterResponse";
	/** 注册状态查询*/
	String NETRegistState = "Com.NETLink.RegisterAsk";
	/** 报站页面更新 */
	String VIEWUpdateReportStation = "Com.VIEWUpdate.ReportStation";

	/** 切换上下行 */
	String BroadcastServiceUpDown = "Com.BroadcastService.UpDown";
	/** 切换上下行 */
	String BroadcastServiceUpDownNotify = "Com.BroadcastService.UpDown.Notify";
	
	/** GPS模拟运行位置 */
	String CurrentLocation = "Com.location.CurrentLocation";

	/** 定位信息 */
	String LocationServiceRespondLocation = "Com.LocationService.RespondLocation";

	/** 定位状态 1已定位,0未定位 */
	String LocationState = "Com.LocationService.RespondState";

	/** 向MCU发送数据 */
	String MCULinkSendData = "Com.MCULink.SendData";

	/** 从MCU接受数据 */
	String MCULinkReceiveData = "Com.MCULink.ReceiveData";

	/** MCULink状态 */
	String MCULinkState = "Com.MCULink.ReceiveData";

	/** 请求客流量数据 */
	String MCULinkPassRequest = "Com.MCULink.PassRequest";

	/** 发送客流量数据 */
	String MCULinkPass = "Com.MCULink.Pass";

	/** 发送门状态查询 */
	String MCULinkDoorStateRequest = "Com.MCULink.Doors.Request";

	/** 发送门状态 */
	String MCULinkDoorState = "Com.MCULink.Doors.Response";

	/** 发送门状态变化通知 */
	String MCULinkDoorsChange = "Com.MCULink.Doors.Change";

	/** 发送键盘值 */
	String MCULinkKeys = "uninew.key";

	/** 发送路牌信息 */
	String TCPLinkSendData = "Com.TCPLink.SendData";

	/** 发送路牌信息 */
	String MCULinkRoadSigns = "Com.MCULink.RoadSigns";
	
	/** MCU版本查询 */
	String MCULinkVersionRequest = "Com.MCULink.Version.Request";
	
	/**  MCU版本查询应答 */
	String MCULinkVersionResponse = "Com.MCULink.Version.Response";
	
	/** ACC状态通知 */
	String MCULinkAccState = "Com.MCULink.AccState";
	
	/**  MCU升级命令 */
	String MCULinkUpdateCommand = "Com.MCULink.Update.Command";
	
	/** OS升级通知 */
	String MCULinkOSUpdateNotify = "Com.MCULink.OSUpdate.Notify";
	
	/**  OS升级通知应答 */
	String MCULinkOSUpdateResponse = "Com.MCULink.OSUpdate.Response";
	
	/** 通讯状态 */
	String ServerLinkState = "Com.ServerLink.State";

	/** 注册状态 */
	String NETLinkRegistate = "Com.NETLink.RegisterState";

	/** 注销*/
	String NETCancellation = "Com.NETLink.Cancellation";
	/** 排班信息请求 */
	String T_Planed = "Com.NetService.T_Planed";

	/**
	 * 线路详细信息请求 线路站点信息请求 线路路口信息请求
	 */
	String T_LineRequest = "Com.NetService.T_LineRequest";

	/** 进出站上报 */
	String T_InOutStaion = "Com.NetService.T_InOutStaion";

	/** 进出路口上报 */
	String T_InOutCross = "Com.NetService.T_InOutCross";

	/** 司机签到签出上报 */
	String T_Sign = "Com.NetService.T_Sign";

	/** 终端自检上报 */
	String T_PluginUp = "Com.NetService.T_PluginUp";

	/** 进出场信息上报 */
	String T_InOutPlace = "Com.NetService.T_InOutPlace";

	/**
	 * 线路信息修改下发应答 保养停运下发应答
	 */
	String T_LineRevised = "Com.NetService.T_LineRevised";

	/** 调度信息下发应答 */
	String T_Dispatch = "Com.NetService.T_Dispatch";

	/** 前后车距请求 */
	String T_RequestDistance = "Com.NetService.T_RequestDistance";

	/** 上行通用应答 */
	String T_Terminal = "Com.NetService.T_T_Terminal";

	/** 分包通用请求 */
	String T_BagRequest = "Com.NetService.T_BagRequest";
	
	/** 站点采集信息上报*/
	String T_CollectStation = "Com.NetService.T_CollectStation";
	
	/** 场站信息请求*/
	String T_Place = "Com.NetService.T_Place_Request";

	/** 排班信息请求应答 */
	String P_Planed = "Com.NetService.P_Planed";

	/** 线路详细信息请求应答 */
	String P_LineAnswer = "Com.NetService.P_LineAnswer";

	/** 线路站点信息请求应答 */
	String P_StationAnswer = "Com.NetService.P_StationAnswer";

	/** 场站信息请求应答 */
	String P_PlaceAnswer = "Com.NetService.P_PlaceAnswer";

	/** 进出站数据上报应答 */
	String P_InOutStation = "Com.NetService.P_InOutStation";
	
	/** 站点采集上报应答*/
	String P_CollectStation = "Com.NetService.P_CollectStation";

	/** 进出路口信息上报应答 */
	String P_InOutCross = "Com.NetService.P_InOutCross";

	/**
	 * 司机签到签出上报应答 设备自检上报应答 进出场站信息上报应答
	 */
	String P_SignAnswer = "Com.NetService.P_SignAnswer";

	/** 线路信息修改下发 */
	String P_LineRevision = "Com.NetService.P_LineRevision";

	/** 保养停运下发 */
	String P_Maintain = "Com.NetService.P_Maintain";

	/** 调度信息下发 */
	String P_Dispatch = "Com.NetService.P_Dispatch";

	/** 前后车距请求应答 */
	String P_Distance = "Com.NetService.P_Distance";

	/** 下行通用应答 */
	String P_Down = "Com.NetService.P_Down";
	
	/** 刷新界面*/
	String reflush = "Com.NetService.reflush"; 
	
	/** 超速预警上报*/
	String SpeedAlarm = "Com.Uninew.SpeedLimit";
	
	/** 超速报警状态：0：报警结束 1：报警触发*/
	String SpeedAlarm_Key = "state";

	// ///////////////////////////////////Key//////////////////////////////////////////
	/** 注册状态*/
	String NETLinkRegistate_Key = "Registate";

	/** 排班信息请求 */
	String T_Planed_Key = "T_Planed";

	/**
	 * 线路详细信息请求 线路站点信息请求 线路路口信息请求
	 */
	String T_LineRequest_Key = "T_LineRequest";

	/** 进出站上报 */
	String T_InOutStaion_Key = "T_InOutStaion";

	/** 进出路口上报 */
	String T_InOutCross_Key = "T_InOutCross";

	/** 司机签到签出上报 */
	String T_Sign_Key = "T_Sign";

	/** 终端自检上报 */
	String T_PluginUp_Key = "T_PluginUp";

	/** 进出场信息上报 */
	String T_InOutPlace_Key = "T_InOutPlace";

	/**
	 * 线路信息修改下发应答 保养停运下发应答
	 */
	String T_LineRevised_Key = "T_LineRevised";

	/** 调度信息下发应答 */
	String T_Dispatch_Key = "T_Dispatch";

	/** 前后车距请求 */
	String T_RequestDistance_Key = "T_RequestDistance";

	/** 上行通用应答 */
	String T_Terminal_Key = "T_T_Terminal";

	/** 分包通用请求 */
	String T_BagRequest_Key = "T_BagRequest";

	/** 站点采集信息上报*/
	String T_CollectStation_Key = "T_CollectStation";
	
	/** 场站信息请求*/
	String T_Place_Key = "T_Place";
	/** 场站请求线路*/
	String T_Place_Name = "T_Place_Name";
	
	/** 排班信息请求应答 */
	String P_Planed_Key = "P_Planed";

	/** 线路详细信息请求应答 */
	String P_LineAnswer_Key = "P_LineAnswer";

	/** 线路站点信息请求应答 */
	String P_StationAnswer_Key = "P_StationAnswer";

	/** 场站信息请求应答 */
	String P_PlaceAnswer_Key = "P_PlaceAnswer";

	/** 进出站数据上报应答 */
	String P_InOutStation_Key = "P_InOutStation";

	/** 进出路口信息上报应答 */
	String P_InOutCross_Key = "P_InOutCross";

	/**
	 * 司机签到签出上报应答 设备自检上报应答 进出场站信息上报应答
	 */
	String P_SignAnswer_Key = "P_SignAnswer";

	/** 线路信息修改下发 */
	String P_LineRevision_Key = "P_LineRevision";

	/** 保养停运下发 */
	String P_Maintain_Key = "P_Maintain";

	/** 调度信息下发 */
	String P_Dispatch_Key = "P_Dispatch";

	/** 前后车距请求应答 */
	String P_Distance_Key = "P_Distance";

	/** 下行通用应答 */
	String P_Down_Key = "P_Down";
	
	/** 站点采集上报应答*/
	String P_CollectStation_Key = "P_CollectStation";

	// /** 文本信息下发 */
	// String TextMsg_Key = "TextMsg";
	//
	// /** 远程切换公交线路 */
	// String RouteSwitch_Key = "RouteSwitch";
	//
	// /** 远程切换公交线路应答Id */
	// String RouteSwitchRespond_Key = "RespondId";
	//
	// /** 远程切换公交线路应答 */
	// String SwitchResponse_Key = "SwitchResponse";
	//
	// /** 路牌信息下发 */
	// String RoadSigns_Key = "RoadSigns";
	//
	// /** 车辆到离站数据 */
	// String OutStation_Key = "OutStation";
	//
	// /** 车辆进站数据 */
	// String IntoStation_Key = "IntoStation";
	//
	// /** 驾驶员签到/签退 */
	// String DriverSign_Key = "DriverSign";
	//
	// /** 驾驶员签到应答 */
	// String SignResponse_Key = "SignResponse";
	//
	// /** 手动切换公交线路通知 */
	// String ManualSwitchResponse_Key = "ManualSwitchResponse";
	//
	// /** 车辆状态 */
	// String BusState_Key = "BusState";

	/**
	 * 门状态
	 * 
	 * @author Administrator
	 * 
	 */
	public interface Door {
		/** 门Id ：0-前门，1-后门 */
		String DoorId = "DoorId";
		/** 门状态 ：0-关，1-开 */
		String DoorState = "DoorState";
	}

	/**
	 * 客流量
	 * 
	 * @author Administrator
	 * 
	 */
	public interface pass {
		/** 门Id ：0-前门，1-后门 */
		String DoorId = "DoorId";
		/** 方向：0-上车，1-下车 */
		String UpNumber = "UpNumber";
		/** 人数 */
		String DownNumber = "DownNumber";
	}

	/**
	 * 路牌信息
	 * 
	 * @author Administrator
	 * 
	 */
	public interface RoadSigns {
		/** 文本类型*/
		int TYPE_TXT=0;
		/** 线路类型*/
		int TYPE_ROUTE=1;
		/** 类型：0-文本，1-线路*/
		String Type = "Type";
		/** 路牌编号*/
		String RoadId = "RoadId";
		/** 线路名称*/
		String RoadName = "RoadName";
		/** 起始站名称 */
		String StartStation = "StartStation";
		/** 终点站名称 */
		String EndStation = "EndStation";
		/** 文本内容 */
		String TxtContent = "TxtContent";
	}

	public interface NetState {
		/** IP */
		String IP = "IP";
		/** 端口号 */
		String Port = "Port";
		/** 连接结果 */
		String ConnResult = "ConnResult";
		/** 连接成功 */
		int CONN_SUCCESS = 1;
		/** 连接失败或断开连接 */
		int CONN_FAILURE = 0;
		/** 注册对象信息 */
		String RegisterDao = "RegisterDao";
		/** 注册结果 */
		String RegisterResponse = "RegisterResponse";
		/** 连接成功 */
		int REGISTER_SUCCESS = 1;
		/** 连接失败或断开连接 */
		int REGISTER_FAILURE = 0;

		/** 鉴权结果 */
		String AuthResponse = "AuthResponse";
		/** 鉴权成功 */
		int AUTH_SUCCESS = 1;
		/** 鉴权失败 */
		int AUTH_FAILURE = 0;

	}

	public interface GPS {
		/** 经度 */
		String Longitude = "Longitude";
		/** 纬度 */
		String Latitude = "Latitude";
		/** 方向 */
		String Direction = "Direction";
		/** 速度 */
		String Speed = "Speed";
	}
	/**
	 * MCU版本信息
	 * 
	 * @author Administrator
	 * 
	 */
	public interface MCUVersion {
		/** 线路名称*/
		String KEY_VERSION = "version";
	}
	
	/**
	 * DVR显示模式设置
	 * 
	 * @author Administrator
	 * 
	 */
	public interface DVRDisplayMode {
		/** 显示模式*/
		String KEY_DISPLAY_MODE= "split";
		/** 显示序号*/
		String KEY_DISPLAY_SERIAL= "pass";
	}
	/**
	 * ACC状态信息
	 * 
	 * @author Administrator
	 * 
	 */
	public interface AccState {
		/** 状态*/
		String KEY_STATE = "state";
	}
}
