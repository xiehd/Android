package com.uninew.bus.dialog;

import com.uninew.bus.R;
import com.uninew.bus.R.id;
import com.uninew.bus.R.layout;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.TextView;

public class WorksDialog extends Dialog implements android.view.View.OnClickListener {

	private static final String TAG = "DispatchDialog";
	private LayoutInflater layoutInflater;
	private View view;
	private TextView busLine;
	private TextView driverId;
	private TextView driverName;
	private TextView startTime;
	private TextView direction;
	private TextView notice;
	private TextView tripOrder;
	private TextView type;
	private TextView ensure;
	private TextView title;
	private DisplayMetrics d;
	private Window dialogWindow;
	private WindowManager.LayoutParams lp;
	private ClickListener clickListener;

	public WorksDialog(Context context) {
		super(context);
		layoutInflater = LayoutInflater.from(context);
		dialogWindow = getWindow();
		lp = dialogWindow.getAttributes();
		d = context.getResources().getDisplayMetrics(); // 获取屏幕宽、高用
	}

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		initView();

	}

	/** 设置触发事件 **/
	public void setClickListener(ClickListener clickListener) {
		this.clickListener = clickListener;
	}

	/** 确定按钮的触发事件 **/
	public interface ClickListener {
		public void onEnsure();
	}

	private void initView() {
		view = layoutInflater.inflate(R.layout.dailog_works, null);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(view);
		busLine = (TextView) findViewById(R.id.tv_line);
		driverId = (TextView) findViewById(R.id.tv_driverId);
		driverName = (TextView) findViewById(R.id.tv_driverName);
		startTime = (TextView) findViewById(R.id.tv_start_time);
		direction = (TextView) findViewById(R.id.tv_direction);
		tripOrder = (TextView) findViewById(R.id.tv_tripOroer);
		type = (TextView) findViewById(R.id.tv_type);
		notice = (TextView) findViewById(R.id.tv_notice);
		title = (TextView) findViewById(R.id.tv_title);
		ensure = (TextView) findViewById(R.id.ensure);
		lp.gravity = Gravity.CENTER;
		lp.width = (int) (d.widthPixels * 0.6);// 高度设置为屏幕的0.6
		lp.height = 455;
		dialogWindow.setAttributes(lp);
		ensure.setOnClickListener(this);
	}

	public void setMtitle(String mTitle) {
		title.setText(mTitle);
	}

	/**
	 * 线路
	 * 
	 * @param mbusLine
	 */
	public void setBusLine(String mbusLine) {
		busLine.setText(mbusLine);
	}

	/**
	 * 工号
	 * 
	 * @param mdriverId
	 */
	public void setDriverId(String mdriverId) {
		driverId.setText(mdriverId);
	}

	/**
	 * 司机
	 * 
	 * @param mdriverName
	 */
	public void setDriverName(String mdriverName) {
		driverName.setText(mdriverName);
	}

	/**
	 * 发车时间
	 * 
	 * @param mstartTime
	 */
	public void setStartTime(String mstartTime) {
		startTime.setText(mstartTime);
	}

	/**
	 * 方向
	 * 
	 * @param mdirection
	 */
	public void setDirection(String mdirection) {
		direction.setText(mdirection);
	}

	/**
	 * 提示方式
	 * 
	 * @param mnotice
	 */
	public void setNotice(String mnotice) {
		notice.setText(mnotice);
	}

	/**
	 * 计划趟次
	 * 
	 * @param mtripOrder
	 */
	public void setTripOrder(String mtripOrder) {
		tripOrder.setText(mtripOrder);
	}

	/**
	 * 趟次属性
	 * 
	 * @param mtype
	 */
	public void setType(String mtype) {
		type.setText(mtype);
	}

	@Override
	public void onClick(View v) {
		if (v.getId() == R.id.ensure) {
			clickListener.onEnsure();
		}

	}

}
