package com.uninew.bus.report.tools;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import com.uninew.file.dao.MarkerDao;
import com.uninew.file.dao.PointsDao;
import com.uninew.file.dao.StationDao;

/**
 * 计算两个经纬度之间的距离
 * 
 * @author Administrator
 * 
 */
public class DistanceCalculate {

	/**
	 * 将当前站点与其他点按照距离远近进进行排序，近的在前，远的在后。
	 * 
	 * @return
	 */
	public static List<StationDao> getSortedStations(StationDao currentStation,
			List<StationDao> stations) {
		List<StationDao> list = new ArrayList<StationDao>();
		double lat1 = currentStation.getLatitude();
		double lng1 = currentStation.getLongitude();
		// 计算出所有的距离
		for (StationDao sd : stations) {
			sd.setDistance(distance(lng1, lat1, sd.getLongitude(),
					sd.getLatitude()));
			list.add(sd);
		}
		// 对计算出的距离进行排序
		Collections.sort(list, new Comparator<StationDao>() {

			@Override
			public int compare(StationDao sd1, StationDao sd2) {
				// TODO Auto-generated method stub
				if (sd1.getDistance() < sd2.getDistance())
					return -1;
				else if (sd1.getDistance() == sd2.getDistance())
					return 0;
				else if (sd1.getDistance() > sd2.getDistance())
					return 1;
				return 0;
			}
		});

		return list;
	}

	/**
	 * 将当前点与其他点按照距离远近进进行排序，近的在前，远的在后。
	 * 
	 * @return
	 */
	public static List<StationDao> getSortedStations(double lat1, double lng1,
			List<StationDao> stations) {
		List<StationDao> list = new ArrayList<StationDao>();
		if (list!=null&&stations !=null) {
			// 计算出所有的距离
			for (StationDao sd : stations) {
				sd.setDistance(distance(lng1, lat1, sd.getLongitude(),
						sd.getLatitude()));
				list.add(sd);
			}
			// 对计算出的距离进行排序
			Collections.sort(list, new Comparator<StationDao>() {

				@Override
				public int compare(StationDao sd1, StationDao sd2) {
					// TODO Auto-generated method stub
					if (sd1.getDistance() < sd2.getDistance())
						return -1;
					else if (sd1.getDistance() == sd2.getDistance())
						return 0;
					else if (sd1.getDistance() > sd2.getDistance())
						return 1;
					return 0;
				}
			});
		}
		

		return list;
	}

	/**
	 * 将当前点与其他点按照距离远近进进行排序，近的在前，远的在后。
	 * 
	 * @return
	 */
	public static List<PointsDao> getSortedPoints(double lat1, double lng1,
			List<PointsDao> points) {
		List<PointsDao> list = new ArrayList<PointsDao>();
		// 计算出所有的距离
		for (PointsDao sd : points) {
			sd.setDistance(distance(lng1, lat1, sd.getLongitude(),
					sd.getLatitude()));
			list.add(sd);
		}
		// 对计算出的距离进行排序
		Collections.sort(list, new Comparator<PointsDao>() {

			@Override
			public int compare(PointsDao sd1, PointsDao sd2) {
				// TODO Auto-generated method stub
				if (sd1.getDistance() < sd2.getDistance())
					return -1;
				else if (sd1.getDistance() == sd2.getDistance())
					return 0;
				else if (sd1.getDistance() > sd2.getDistance())
					return 1;
				return 0;
			}
		});

		return list;
	}
	
	/**
	 * 将当前点与其他转弯点按照距离远近进进行排序，近的在前，远的在后。
	 * 
	 * @return
	 */
	public static List<MarkerDao> getSortedMarkers(double lat1, double lng1,
			List<MarkerDao> corners) {
		if (corners==null || corners.isEmpty()) {
			return null;
		}
		List<MarkerDao> list = new ArrayList<MarkerDao>();
		// 计算出所有的距离
		for (MarkerDao cd : corners) {
			cd.setDistance(distance(lng1, lat1, cd.getLongitude(),
					cd.getLatitude()));
			list.add(cd);
		}
		// 对计算出的距离进行排序
		Collections.sort(list, new Comparator<MarkerDao>() {

			@Override
			public int compare(MarkerDao sd1, MarkerDao sd2) {
				// TODO Auto-generated method stub
				if (sd1.getDistance() < sd2.getDistance())
					return -1;
				else if (sd1.getDistance() == sd2.getDistance())
					return 0;
				else if (sd1.getDistance() > sd2.getDistance())
					return 1;
				return 0;
			}
		});
		return list;
	}
	
	/**
	 * 计算当前位置到指定站台之间距离
	 * 
	 * @param station1
	 *            第一点经度
	 * @param station2
	 *            第一点纬度
	 * @return 返回距离 单位：米
	 */
	public static int distance(double long1, double lat1, StationDao station) {
		return (int) distance(long1, lat1, station.getLongitude(),
				station.getLatitude());
	}

	/**
	 * 计算当前位置到指定拐点之间距离
	 * @param lon1
	 * @param lat1
	 * @param cd
	 * @return
	 */
	public static int distance(double lon1,double lat1,MarkerDao cd){
		return (int) distance(lon1, lat1, cd.getLongitude(),
				cd.getLatitude());
	}
	
	
	/**
	 * 计算两个站点之间距离
	 * 
	 * @param station1
	 *            第一点经度
	 * @param station2
	 *            第一点纬度
	 * @return 返回距离 单位：米
	 */
	public static int distance(StationDao station1, StationDao station2) {
		return (int) distance(station1.getLongitude(), station1.getLatitude(),
				station2.getLongitude(), station2.getLatitude());
	}

	/**
	 * 计算地球上任意两点(经纬度)距离
	 * 
	 * @param long1
	 *            第一点经度
	 * @param lat1
	 *            第一点纬度
	 * @param long2
	 *            第二点经度
	 * @param lat2
	 *            第二点纬度
	 * @return 返回距离 单位：米
	 */
	public static int distance2(double long1, double lat1, double long2,
			double lat2) {
		double a, b, R;
		R = 6378137; // 地球半径
		lat1 = lat1 * Math.PI / 180.0;
		lat2 = lat2 * Math.PI / 180.0;
		a = lat1 - lat2;
		b = (long1 - long2) * Math.PI / 180.0;
		double d;
		double sa2, sb2;
		sa2 = Math.sin(a / 2.0);
		sb2 = Math.sin(b / 2.0);
		d = 2
				* R
				* Math.asin(Math.sqrt(sa2 * sa2 + Math.cos(lat1)
						* Math.cos(lat2) * sb2 * sb2));
		return (int) d;
	}

	// 计算距离,单位：米
	public static int distance(double x1, double y1, double x2, double y2) {
		double x;

		x = ((x1 - x2) * (x1 - x2) + (y1 - y2) * (y1 - y2));
		x *= 105 * 105;
		x *= 1000000;
		x = Math.sqrt(x);
		return (int) x;
	}

	// 计算距离,单位：米
//	public static int distance3(double long1, double lat1, double long2,
//			double lat2) {
//		return (int) DistanceUtil.getDistance(new LatLng(lat1, long1),
//				new LatLng(lat2, long2));
//	}

	/**
	 * 判断点是否在两点之间
	 * 
	 * @param station1
	 *            站点1
	 * @param station2
	 *            站点2
	 * @param lat
	 *            当前纬度
	 * @param lon
	 *            当前经度
	 * @return boolean
	 */
	public static boolean isBetween(StationDao station1, StationDao station2,
			double lat, double lon) {
		int c = distance(station1.getLongitude(), station1.getLatitude(),
				station2.getLongitude(), station2.getLatitude());
		int b = distance(lon, lat,
				station1.getLongitude(), station1.getLatitude());
		int a = distance(lon, lat,
				station2.getLongitude(), station2.getLatitude());
		return isAcuteAngle(a, b, c);
	}
	
	/**
	 * 判断点是否在两点之间
	 * @param lat1
	 * @param lon1
	 * @param lat2
	 * @param lon2
	 * @param lat
	 * @param lon
	 * @return
	 */
	public static boolean isBetween(double lat1,double lon1, double lat2,double lon2,
			double lat, double lon) {
		int c = distance(lon1, lat1,
				lon2, lat2);
		int b = distance(lon, lat,
				lon1, lat1);
		int a = distance(lon, lat,
				lon2, lat2);
		return isAcuteAngle(a, b, c);
	}
	/**
	 * 是否是锐角三角形
	 * 
	 * @param a
	 *            第一边长
	 * @param b
	 *            第二边长
	 * @param c
	 *            最长边
	 * @return
	 */
	private static boolean isAcuteAngle(int a, int b, int c) {
		//ab之间的夹角为钝角
		if (a * a + b * b < c * c) {
			return true;
		}
		return false;
	}
	/**
	 * 计算两点之间的角度
	 * @param lat_a
	 * @param lng_a
	 * @param lat_b
	 * @param lng_b
	 * @return
	 */
	public static double GPS2d(double lat_a, double lng_a, double lat_b, double lng_b)
    {
        double d = 0;
        d = (lng_b - lng_a) * (lng_b - lng_a) + (lat_b - lat_a) * (lat_b - lat_a);
        d = Math.sqrt(d);

        d = Math.acos((lat_b - lat_a) / d);
        d = (d * 180.0) / Math.PI;

        if ((lng_a>lng_b))
        {
            d = 360 -d;
        }

        //d = 360 - d;
        //d = Math.round(d*10000);
        return d;
    }
}
