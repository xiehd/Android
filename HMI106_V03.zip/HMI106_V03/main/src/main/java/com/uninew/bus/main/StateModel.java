package com.uninew.bus.main;

import android.util.Log;

import com.uninew.common.setting.DefineParamSettings;
import com.uninew.db.dh.Managers.DbSettingsManager;
import com.uninew.db.dh.interfaces.ISettingsListener.IBroadcasterCallBack;
import com.uninew.db.dh.interfaces.ISettingsListener.IBroadcasterListener;
import com.uninew.db.dh.interfaces.ISettingsListener.IRunStateCallBack;
import com.uninew.db.dh.interfaces.ISettingsListener.IRunStateListener;



/***********************************************************************
 * Module:  StateModel.java
 * Author:  Administrator
 * Purpose: Defines the Class StateModel
 ***********************************************************************/


public class StateModel{
	private static final String TAG = "StateModel";
	private boolean D = true;
	private BusMainService mBusMainService;
	private DbSettingsManager dbSettingsManager;
	//全局变量
	public static boolean isAutoReport;
	public static boolean isRunning;
	
	public StateModel(BusMainService mBusMainService) {
		super();
		this.mBusMainService = mBusMainService;
		dbSettingsManager=new DbSettingsManager(mBusMainService);
		init();
	}
	
	private void init() {
		// TODO Auto-generated method stub
		dbSettingsManager.queryRunning(mRunStateCallBack);
//		dbSettingsManager.queryBroadcaster(mBroadcasterCallBack);
		dbSettingsManager.registerNotify();
		dbSettingsManager.setmRunStateListener(mRunStateListener);
		dbSettingsManager.setmBroadcasterListener(mBroadcasterListener);
	}
	
	//报站模式
	private IBroadcasterCallBack mBroadcasterCallBack=new IBroadcasterCallBack() {
		
		@Override
		public void broadcasterState(int state) {
			// 报站模式查询结果:1-自动，2-手动，默认手动
			if(D)Log.d(TAG, "broadcasterState,state="+state);
			reportStyleManager(state);
		}
	};
	
	private IBroadcasterListener mBroadcasterListener=new IBroadcasterListener() {
		
		@Override
		public void broadcasterStateListener(int state) {
			// 监听报站模式变化
			if(D)Log.d(TAG, "broadcasterStateListener,state="+state);
			reportStyleManager(state);
		}
	};
		
	//运营状态
	private IRunStateCallBack mRunStateCallBack=new IRunStateCallBack() {
		
		@Override
		public void runState(int state) {
			// TODO Auto-generated method stub
			if(D)Log.d(TAG, "mRunStateCallBack,state="+state);
			runStateManager(state);
		}
	};
	
	private IRunStateListener mRunStateListener=new IRunStateListener() {
		
		@Override
		public void runStateListener(int state) {
			// 运营状态监听
			if(D)Log.d(TAG, "mRunStateListener,state="+state);
			runStateManager(state);
		}
	};
	/**
	 * 报站模式处理
	 * @param state
	 */
	private void reportStyleManager(int state){
		isAutoReport=(state==DefineParamSettings.ReportModel_Auto?true:false);
		mBusMainService.setReportStyle(isAutoReport);
		if(isRunning){//营运状态有效
			mBusMainService.setManulAutoReport(state);
		}
	}
	
	/**
	 * 运营状态处理
	 * @param state
	 */
	private void runStateManager(int state){
		isRunning=(state==DefineParamSettings.RunState_Running?true:false);
		mBusMainService.setRunState(isRunning);
		if (!isRunning) {
			//停运
			mBusMainService.setManulAutoReport(3);
		}else{
			dbSettingsManager.queryBroadcaster(mBroadcasterCallBack);
		}
	}
	
}