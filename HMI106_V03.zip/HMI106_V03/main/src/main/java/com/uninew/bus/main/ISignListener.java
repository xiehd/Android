package com.uninew.bus.main;

/***********************************************************************
 * Module:  ISignListener.java
 * Author:  Administrator
 * Purpose: Defines the Interface ISignListener
 ***********************************************************************/

import java.util.*;

/** @pdOid a71a6874-5565-447e-a6d3-bf2c6700511f */
public interface ISignListener {
	/**
	 * @param isSigned
	 * @pdOid 25c1f783-a97a-47b2-b3bf-a1df22703b18
	 */
	void showSignState(boolean isSigned);

	/**
	 * @param license
	 * @pdOid 394b5cb5-add4-4cd2-8f42-a6cf1627f6e3
	 */
	void showLicensePlate(String license);

	/**
	 * @param jobNumber
	 * @pdOid a02a4bcd-ebfc-4fcc-87b3-cb47f2e4b653
	 */
	void showJobNumber(String jobNumber);

	/**
	 * @param driverName
	 * @pdOid adeb4b23-3346-4016-a0cb-7bdf6ffd9a01
	 */
	void showDriverName(String driverName);

}