package com.uninew.bus.main;

/*********************************************************************** 
 * Module:  BusPresenter.java
 * Author:  Administrator
 * Purpose: Defines the Class BusPresenter
 ***********************************************************************/

import java.util.List;



import android.app.Service;
import android.content.Context;

public class BusPresenter implements IFileListener,IBusPresenter{
	/** @pdOid 3796f750-56ec-4214-9dc1-911564e1343c */
	private IBusView iBusView;
	private BusMainService mService;

	public BusPresenter(IBusView iBusView,Service s) {
		super();
		this.iBusView = iBusView;
		mService = (BusMainService) s;
		mService.setmFileListener(this);
	}

	// ----------------------------以下为上层调用方法-------------------------------------------

	@Override
	public void switchUpDown() {
		// TODO Auto-generated method stub
		mService.switchUpDown();
	}
	
	@Override
	public void initViews() {
		// TODO Auto-generated method stub
		mService.initViews();
	}
	// ----------------------------以下为上报---------------------------------------
	@Override
	public void setRunState(boolean state) {
		// TODO Auto-generated method stub
		iBusView.showRunState(state);
	}

	@Override
	public void setReportStyle(boolean isAuto) {
		// TODO Auto-generated method stub
		iBusView.showReportStyle(isAuto);
	}
	
	@Override
	public void setOverSpeed(int type) {
		// TODO Auto-generated method stub
		iBusView.showOverSpeed(type);
	}

	@Override
	public void setSignState(boolean isSigned) {
		// TODO Auto-generated method stub
		iBusView.showSignState(isSigned);
	}

	@Override
	public void setSpeed(int speed) {
		// TODO Auto-generated method stub
		iBusView.showSpeed(speed);
	}

	@Override
	public void setLimitSpeed(int limitSpeed) {
		// TODO Auto-generated method stub
		iBusView.showLimitSpeed(limitSpeed);
	}

	@Override
	public void setCurrentStation(int id, String station) {
		// TODO Auto-generated method stub
		iBusView.showCurrentStation(id, station);
	}

	@Override
	public void setNextStation(int id, String station) {
		// TODO Auto-generated method stub
		iBusView.showNextStation(id, station);
	}

	@Override
	public void setNearByBusPosition(int before, int after) {
		// TODO Auto-generated method stub
		iBusView.showNearByBusPosition(before, after);
	}

	@Override
	public void setLineMsg(String startStation, String endStation,
			String lineName) {
		// TODO Auto-generated method stub
		iBusView.showLineMsg(startStation, endStation, lineName);
	}

	@Override
	public void setStations(List<String> stations) {
		// TODO Auto-generated method stub
		iBusView.showStations(stations);
	}

	@Override
	public void setNextOrEnd(String txt) {
		// TODO Auto-generated method stub
		iBusView.showNextOrEnd(txt);
	}

	@Override
	public void setSpeedColor(int color) {
		// TODO Auto-generated method stub
		iBusView.showSpeedColor(color);
	}
	
	@Override
	public void setUpDown(int upDown) {
		// TODO Auto-generated method stub
		iBusView.showUpDown(upDown);
	}

	@Override
	public void setLicensePlate(String license) {
		// TODO Auto-generated method stub
		iBusView.showLicensePlate(license);
	}

	@Override
	public void setJobNumber(String jobNumber) {
		// TODO Auto-generated method stub
		iBusView.showJobNumber(jobNumber);
	}

	@Override
	public void setDriverName(String driverName) {
		// TODO Auto-generated method stub
		iBusView.showDriverName(driverName);
	}

	@Override
	public void showSignView(boolean isSigned) {
		// TODO Auto-generated method stub
		iBusView.showSignView(isSigned);
	}

	@Override
	public void signViewRequest() {
		// TODO Auto-generated method stub
		mService.signViewRequest();
	}

	@Override
	public void sign(String jobNumber) {
		// TODO Auto-generated method stub
		mService.sign(jobNumber);
	}

	@Override
	public void signOut(String jobNumber) {
		// TODO Auto-generated method stub
		mService.signOut(jobNumber);
	}

}