package com.uninew.bus.view;

import java.util.List;
import java.util.Map;

import android.animation.ObjectAnimator;
import android.annotation.SuppressLint;
import android.content.Context;
import android.util.ArrayMap;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.view.animation.Animation;
import android.view.animation.AnimationSet;
import android.view.animation.AnimationUtils;
import android.view.animation.TranslateAnimation;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.uninew.bus.R;
import com.uninew.bus.adapter.MyListAdapter;
import com.uninew.bus.constant.Constant;
import com.uninew.bus.log.LogTool;
import com.uninew.file.dao.StationDao;

public class HorizontalListViewAdapter extends BaseAdapter {
	private static final String TAG ="HorizontalListViewAdapter";
	// 默认每页显示条目
	private static final int DEF_PAGESIZE = Constant.DEFAULT_PAGESIZE;
	private Context mContext;
	private LayoutInflater mInflater;
	private List<String> stations;
	private int selectIndex = -1;
	// 单列显示字体数
	private int singleLen = 5;

	public  Map<Integer, Boolean> neabyBus;

	private int totalCount; // 内容总条数
	private int pageSize; // 一页显示的行数
	private int pageIndex; // 当前显示的页码
	private int pageCount; // 总页数
	private boolean showLineNum; // 显示行标

	@SuppressLint("NewApi")
	public HorizontalListViewAdapter(Context context, List<String> stations) {
		this.mContext = context;
		this.stations = stations;
		mInflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);// LayoutInflater.from(mContext);
		totalCount = stations.size();
		neabyBus = new ArrayMap<>();
		pageSize = DEF_PAGESIZE;
		showLineNum = true;
		pageIndex = 1;
		countPage();
	}

	/**
	 * 内部方法，计算总页数
	 */
	private void countPage() {
		pageCount = totalCount / pageSize; //
		if (totalCount % pageSize > 0) // 最后一页不足pagesize个
			pageCount++;
	}

	@Override
	public int getCount() {
		// 如果总行数小于一页显示的行数，返回总行数
		if (totalCount < pageSize) {
			return totalCount;
		} // 即最后一页不足5行（页面行数）
		else if (totalCount < pageIndex * pageSize) {
			return (totalCount - (pageIndex - 1) * pageSize);
		} else // 其他情况返回页面尺寸
		{
			return pageSize;
		}
	}

	@Override
	public Object getItem(int position) {
		return position;
	}

	@Override
	public long getItemId(int position) {
		return position;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		ViewHolder holder;
		int index = position + pageSize * (pageIndex - 1); // position对应到数据集中的正确位置
		if (convertView == null) {
			holder = new ViewHolder();
			convertView = mInflater.inflate(R.layout.item_station, null);
			holder.iv_busIcon = (ImageView) convertView.findViewById(R.id.iv_busIcon);
			holder.tv_num = (TextView) convertView.findViewById(R.id.tv_num);
			if(mContext.getString(R.string.string_ID).equals("0")){
			holder.tv_busName = (com.uninew.bus.view.VerticalTextView) convertView.findViewById(R.id.tv_busName);
			holder.tv_busName2 = (com.uninew.bus.view.VerticalTextView) convertView.findViewById(R.id.tv_busName2);
			}else{
				holder.tv_busName_eng = (TextView) convertView.findViewById(R.id.tv_busName);
				holder.tv_busName2_eng = (TextView) convertView.findViewById(R.id.tv_busName2);
			}
			convertView.setTag(holder);
		} else {
			holder = (ViewHolder) convertView.getTag();
		}
		boolean res = false;
		if (neabyBus.get(index) == null || neabyBus.get(index) == false) {
			res = false;
			neabyBus.put(index, false);
		} else
			res = true;
		if (res) {
			holder.iv_busIcon.setImageResource(R.mipmap.instation_bus_one);
		} else {
			holder.iv_busIcon.setImageResource(R.mipmap.instation_bus_null);
		}
		if (index == selectIndex) {// 选中突出项
			// singleLen=5;
			if(mContext.getString(R.string.string_ID).equals("0")){
			holder.tv_busName.setTextColor(mContext.getResources().getColor(R.color.white));
			holder.tv_busName2.setTextColor(mContext.getResources().getColor(R.color.white));
			}else {
				holder.tv_busName_eng.setTextColor(mContext.getResources().getColor(R.color.white));
				holder.tv_busName2_eng.setTextColor(mContext.getResources().getColor(R.color.white));
			}
			// holder.tv_busName.setTextSize(TypedValue.COMPLEX_UNIT_PX, 18);
			// holder.tv_busName2.setTextSize(TypedValue.COMPLEX_UNIT_PX, 18);
			holder.tv_num.setBackgroundResource(R.mipmap.station_current);
		} else if (index < selectIndex) {
			// singleLen=6;
			if(mContext.getString(R.string.string_ID).equals("0")){
			holder.tv_busName.setTextColor(mContext.getResources().getColor(R.color.grey_txt));
			holder.tv_busName2.setTextColor(mContext.getResources().getColor(R.color.grey_txt));
			}else{
			holder.tv_busName_eng.setTextColor(mContext.getResources().getColor(R.color.grey_txt));
			holder.tv_busName2_eng.setTextColor(mContext.getResources().getColor(R.color.grey_txt));
			}
			// holder.tv_busName.setTextSize(TypedValue.COMPLEX_UNIT_PX, 16);
			// holder.tv_busName2.setTextSize(TypedValue.COMPLEX_UNIT_PX, 16);
			holder.tv_num.setBackgroundResource(R.mipmap.station_pass);
		} else {
			// singleLen=6;
			if(mContext.getString(R.string.string_ID).equals("0")){
			holder.tv_busName.setTextColor(mContext.getResources().getColor(R.color.blue_txt));
			holder.tv_busName2.setTextColor(mContext.getResources().getColor(R.color.blue_txt));
			}else {
				holder.tv_busName_eng.setTextColor(mContext.getResources().getColor(R.color.blue_txt));
				holder.tv_busName2_eng.setTextColor(mContext.getResources().getColor(R.color.blue_txt));
			}
			// holder.tv_busName.setTextSize(TypedValue.COMPLEX_UNIT_PX, 16);
			// holder.tv_busName2.setTextSize(TypedValue.COMPLEX_UNIT_PX, 16);
			holder.tv_num.setBackgroundResource(R.mipmap.station_normal);
		}

		holder.tv_num.setText((index) + "");
		int length = stations.get(index).length();
		if (length > singleLen) {
			String[] str = null;
			if(mContext.getString(R.string.string_ID).equals("0")){
				if(stations.get(index).length() <= 12){
					holder.tv_busName2.setText(stations.get(index));
					holder.tv_busName.setVisibility(View.GONE);
				}else{
					holder.tv_busName2.setText(stations.get(index).substring(0, 10)+"-");
					holder.tv_busName.setVisibility(View.VISIBLE);
					holder.tv_busName.setText(stations.get(index).substring(10, length));
				}
			}else{
				holder.tv_busName_eng.setText(stations.get(index).substring(0, singleLen));
				holder.tv_busName2_eng.setVisibility(View.VISIBLE);
				holder.tv_busName2_eng.setText(stations.get(index).substring(singleLen, length));
			}
//			ObjectAnimator anim = ObjectAnimator.ofFloat(holder.tv_busName, "rotation", 0f, 90f);  
//			anim.setDuration(20);
//			anim.start();
//			ObjectAnimator anim2 = ObjectAnimator.ofFloat(holder.tv_busName2, "rotation", 0f, 90f);  
//			anim2.setDuration(20);
//			anim2.start();
			
		} else {
			if(mContext.getString(R.string.string_ID).equals("0")){
			holder.tv_busName.setVisibility(View.GONE);
			holder.tv_busName2.setText(stations.get(index));
			}else{
				holder.tv_busName2_eng.setVisibility(View.GONE);
				holder.tv_busName_eng.setText(stations.get(index));
			}
//			LayoutParams para;  
//	        para = holder.tv_busName.getLayoutParams(); 
			// 第二个参数"rotation"表明要执行旋转  
			// 0f -> 360f，从旋转360度，也可以是负值，负值即为逆时针旋转，正值是顺时针旋转。  
//			int h = para.height;
//			int w = para.width;
	        
//			ObjectAnimator anim = ObjectAnimator.ofFloat(holder.tv_busName, "rotation", 0f, 90f);  
//			anim.setDuration(5000);
//			anim.start();
//
//			//初始化  
//			Animation translateAnimation = new TranslateAnimation(0,0,0,30f);  
//			translateAnimation.setDuration(5000);  
//			translateAnimation.setFillAfter(true);
//			holder.tv_busName.startAnimation(translateAnimation);  			
			
//			para.height = 120;
//			para.width = 120;
//			holder.tv_busName.setLayoutParams(para);
			
//			Animation mAnimationRight; mAnimationRight = AnimationUtils.loadAnimation(mContext, R.anim.text);  
//			mAnimationRight.setFillAfter(true);   
//			holder.tv_busName.setAnimation(mAnimationRight); 
		}

		return convertView;
	}

	private static class ViewHolder {
		private ImageView iv_busIcon;
		private TextView tv_num;
		private com.uninew.bus.view.VerticalTextView tv_busName;
		private com.uninew.bus.view.VerticalTextView tv_busName2;// 长度过长时放置在该控件
		//中文版控件
		private TextView tv_busName_eng;
		private TextView tv_busName2_eng;// 长度过长时放置在该控件
	}
	
	public void setSelectIndex(int i) {
		Log.d(TAG, "setSelectIndex=" + i);
		selectIndex = i;
	}

	public void setNeabyBus(int beforeBus, int laterBus) {
		for (Integer key : neabyBus.keySet()) {
			neabyBus.put(key, false);
		}		
		Log.d(TAG, "beforeBus:"+beforeBus+"laterBus:"+laterBus);
		if(beforeBus>=0){
			neabyBus.put(beforeBus, true);
		}
		if(laterBus>=0){
			neabyBus.put(laterBus, true);
		}
		Log.d(TAG, neabyBus.toString());
		this.notifyDataSetChanged();
	}

	/**
	 * 返回列表是否有下一页
	 * 
	 * @return
	 */
	public boolean hasNextPg() {
		return pageIndex * pageSize < totalCount;
	}

	/**
	 * 返回是否有上一页
	 * 
	 * @return
	 */
	public boolean hasPrevPg() {
		return pageIndex > 1;
	}

	/**
	 * 下翻页，如果有下一页则返回成功
	 * 
	 * @return
	 */
	public boolean pgDown() {
		if (!hasNextPg())
			return false;

		pageIndex++;
		this.notifyDataSetChanged();

		return true;
	}

	/**
	 * 上翻页
	 * 
	 * @return
	 */
	public boolean pgUp() {
		if (!hasPrevPg())
			return false;

		pageIndex--;
		this.notifyDataSetChanged();

		return true;
	}

	/**
	 * 跳转到某个页码
	 * 
	 * @param pageIndex
	 */
	public void gotoPageIndex(int pageIndex) {
		this.pageIndex = pageIndex;
		this.notifyDataSetChanged();
	}

	/**
	 * 跳到第一页
	 */
	public void gotoFirstPg() {
		if (pageIndex != 1) {
			pageIndex = 1;
			this.notifyDataSetChanged();
		}
	}

	/**
	 * 跳到最后一页
	 */
	public void gotoLastPg() {
		this.pageIndex = (stations.size() - 1) / Constant.DEFAULT_PAGESIZE + 1;
		this.notifyDataSetChanged();
	}

	/**
	 * 获取一页行数
	 * 
	 * @return
	 */
	public int getPageSize() {
		return pageSize;
	}

	/**
	 * 设置一页行数
	 * 
	 * @param pageSize
	 */
	public void setPageSize(int pageSize) {
		this.pageSize = pageSize;
	}

	/**
	 * 获取总行数
	 * 
	 * @return
	 */
	public int getTotalCount() {
		return totalCount;
	}

	/**
	 * 获取当前显示的页码
	 * 
	 * @return
	 */
	public int getPageIndex() {
		return pageIndex;
	}

	/**
	 * 显示/隐藏行号 ！未实现
	 * 
	 * @param show
	 */
	public void showLineNum(boolean show) {
		this.showLineNum = show;
		this.notifyDataSetChanged();
	}
}