package com.uninew.bus.report.tools;

import java.util.Queue;

public class MyQueue { 
	private Queue<Double> queue = null;
	private static final int MAX_NUM = 4;

	public MyQueue(Queue<Double> queue) {
		super();
		this.queue = queue;
	}

	/**
	 * 添加数据到队列，队列长度限定
	 * 
	 * @param d
	 */
	public  void add(Double d) {
		if (queue.size() >= MAX_NUM) {
			queue.poll();// 移除首个
		}
		queue.offer(d);
	}

	/**
	 * 去除最大值和最小值后的序列
	 * 
	 * @return
	 */
	public  Queue<Double> getDealedQueue() {
		queue.remove(getMax(queue));
		queue.remove(getMin(queue));
		return queue;
	}

	/**
	 * 去除最大值和最小值的数组
	 * 
	 * @return
	 */
	public  double[] getDealedDatas() {
//		if (queue.size() > 5) {
//			queue.remove(getMax(queue));
//			queue.remove(getMin(queue));
//		}
		double[] dd = new double[queue.size()];
		int i = 0;
		for (Double q : queue) {
			dd[i] = q;
			i++;
		}
		i = 0;
		return dd;
	}

	/**
	 * 移除队列所有数据
	 */
	public  void removeAll() {
		queue.clear();
	}

	
	public  int trendJudge() {
		return trendJudge(getDealedDatas());
	}
	
	/**
	 * 趋势判定
	 * 
	 * @return 0-不变 1-递增 -1-递减
	 */
	public  int trendJudge(double[] dd) {
//		BusLog.v("AppServer", "dd.length=" + dd.length);
//		if (dd.length < 2) {
//			return 0;
//		} else if (dd.length == 2) {
//			if (dd[1] - dd[0] > 0) {
//				 //递增
//				return 1;
//			} else if (dd[1] - dd[0] < 0) {
//				return -1;
//			} else {
//				return 0;
//			}
//		}
		if (dd.length < 3) {
			//三个以下数据不判定
			return 0;
		}
		double sum1 = 0;
		double aver1 = 0;
		for (int i = 0; i < dd.length - 2; i++) {
			sum1 = sum1 + dd[i];
		}
		aver1 = sum1 / (dd.length - 2);
		double sum2 = 0;
		double aver2 = 0;
		for (int i = 1; i < dd.length; i++) {
			sum2 = sum2 + dd[i];
		}
		aver2 = sum2 / (dd.length - 1);
		if (aver1 > aver2) {
			// 递减
			return -1;
		} else if (aver1 < aver2) {
			return 1;
		}
		return 0;
	}

	/**
	 * 求最大值
	 * 
	 * @param arr
	 * @return
	 */
	public  double getMax(Queue<Double> queue) {
		double max = Double.MIN_VALUE;
		for (double q : queue) {
			if (q > max)
				max = q;
		}	
		return max;
	}

	/**
	 * 求最小值
	 * 
	 * @param arr
	 * @return
	 */
	public  double getMin(Queue<Double> queue) {
		double min = Double.MAX_VALUE;
		for (double q : queue) {
			if (q < min)
				min = q;
		}
		return min;
	}

}
