package com.uninew.bus.work;

import java.util.List;

import com.uninew.db.dh.dao.PlanWork;

public interface IPlanWorkView {

	/**
	 * 显示排班信息
	 * @param planWorks
	 */
	public void showPlanWorks(List<PlanWork> planWorks);
	
	/**
	 * 显示当前趟次
	 * @param planWork
	 */
	public void showCurrentPlanWork(PlanWork planWork);
	
	
}
