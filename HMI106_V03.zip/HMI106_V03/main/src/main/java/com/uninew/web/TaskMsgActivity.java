package com.uninew.web;

import java.io.UnsupportedEncodingException;
import java.util.List;

import com.uninew.JT808.bean.P_ReceivePlanWork;
import com.uninew.JT808.bean.TaskWork;
import com.uninew.bus.R;
import com.uninew.db.dh.Managers.DbRegisterManager;
import com.uninew.db.dh.Managers.DbTaskDatasManager;
import com.uninew.db.dh.dao.MsgBaseDatas;
import com.uninew.db.dh.interfaces.IRegisterListener.IQueryAuthCallBack;
import com.uninew.db.dh.interfaces.ITaskWorks;
import com.uninew.db.dh.interfaces.ITaskWorksListener.IQueryTaskListener;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class TaskMsgActivity extends Activity implements OnClickListener {

	private static final String TAG = "TaskMsgActivity";
	private static final boolean D = true;
	private LinearLayout ll_planToday;
	private LinearLayout ll_runningToday;
	private LinearLayout ll_planHistory;
	private TextView tv_route;
	private TextView tv_driver;
	private TextView tv_startTime;
	private TextView tv_times;
	private TextView tv_taskId;
	private String mAuth;
//	private ShowWorkReceiver mWorkReceiver;
	
	public static final String ROUTE_KEY = "route";
	public static final String DRIVER_KEY = "driver";
	public static final String STARTTIME_KEY = "startTime";
	public static final String TIMES_KEY = "times";
	public static final String TASKID_KEY = "taskId";
	public static final String AUTH = "auth";
	public static final String SHOW_WORK_ACTION = "show_work_what";
	
	private static final String url_web1 = "http://113.98.237.54:9013/Pages/ScheduleReport/TodaySchedule.aspx?BUSNO=";//当天排班
	private static final String url_web2 = "http://113.98.237.54:9013/Pages/ScheduleReport/TomorrowScheduleInfo.aspx?BUSNO=";//明天排班
	private static final String url_web3 = "http://113.98.237.54:9013/Pages/ScheduleReport/MonthSchedule.aspx?BUSNO=";//历史排班
	
	
	private Handler mHandler = new Handler(){
		public void handleMessage(Message msg) {
			P_ReceivePlanWork planWork  = (P_ReceivePlanWork) msg.obj;
			if(planWork != null){
				String routeName =  planWork.getRouteName();
				if (!TextUtils.isEmpty(routeName)) {
					tv_route.setText(routeName);
				} else {
					Toast.makeText(getApplicationContext(), "无调度信息", Toast.LENGTH_SHORT).show();
					tv_route.setText("000");
				}
				List<TaskWork> works = planWork.getWorks();
				if(works != null && !works.isEmpty()){
					TaskWork work = works.get(0);
					if(work != null){
						String driverName = work.getName();
						if (!TextUtils.isEmpty(driverName)) {
							tv_driver.setText(driverName);
						} else {
							tv_driver.setText("000");
						}
						String startTimeS = work.getStartTime();
						if (!TextUtils.isEmpty(startTimeS)) {
							tv_startTime.setText(startTimeS);
						} else {
							tv_startTime.setText("00:00");
						}
						int timesS = work.getPlanTimesNum();
						tv_times.setText(timesS+"");
						int task = work.getTaskId();
						tv_taskId.setText(task+"");
					}
				}
			}
		};
	};
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_taskmsg);
		init();
	}

	private void init() {
		initView();
		initListener();
		initData();
	}
	
	@Override
	protected void onDestroy() {
		super.onDestroy();
	}
	

	private void initData() {
		ITaskWorks mWorks = new DbTaskDatasManager(this);
		mWorks.queryMsgDatas(null, new IQueryTaskListener() {
			
			@Override
			public void queryCallBack(List<MsgBaseDatas> baseDatas) {
				if(baseDatas != null && !baseDatas.isEmpty()){
//					Log.d(TAG, baseDatas.toString());
					P_ReceivePlanWork planWork = new P_ReceivePlanWork(0, baseDatas.get(0).getMsgBody());
					planWork.setDatas( baseDatas.get(baseDatas.size() - 1).getMsgBody());
					Message msg = Message.obtain();
					msg.obj = planWork;
					mHandler.sendMessage(msg);
					
				}
			}
		});
		DbRegisterManager dbRegisterManager = new DbRegisterManager(getApplicationContext());
		dbRegisterManager.queryAuth(1, new IQueryAuthCallBack() {
			
			@Override
			public void queryAuthCallBack(byte[] arg0) {
				if (arg0 != null) {
					mAuth = bcd2Str(arg0);
					Log.d(TAG, (mAuth != null ? "mAuth=" + mAuth + ", " : ""));
				}
			}
		});
	}

	private void initView() {
		ll_planToday = (LinearLayout) findViewById(R.id.ll_plan_today);
		ll_runningToday = (LinearLayout) findViewById(R.id.ll_running_today);
		ll_planHistory = (LinearLayout) findViewById(R.id.ll_plan_history);
		tv_route = (TextView) findViewById(R.id.tv_route_content);
		tv_driver = (TextView) findViewById(R.id.tv_driver_content);
		tv_startTime = (TextView) findViewById(R.id.tv_startTime_content);
		tv_taskId = (TextView) findViewById(R.id.tv_task_content);
		tv_times = (TextView) findViewById(R.id.tv_times_content);
	}

	private void initListener() {
		ll_planHistory.setOnClickListener(this);
		ll_planToday.setOnClickListener(this);
		ll_runningToday.setOnClickListener(this);
	}

	@Override
	public void onClick(View v) {
		int id = v.getId();
		if (id == R.id.ll_plan_today) {
			Intent intent = new Intent(getApplicationContext(), ShowWebActivity.class);
			intent.putExtra(ShowWebActivity.SHOW_URL, url_web1 + mAuth);
			startActivity(intent);
		} else if (id == R.id.ll_plan_history) {
			Intent intent1 = new Intent(getApplicationContext(), ShowWebActivity.class);
			intent1.putExtra(ShowWebActivity.SHOW_URL, url_web3 + mAuth);
			startActivity(intent1);
		} else if (id == R.id.ll_running_today) {
			Intent intent2 = new Intent(getApplicationContext(), ShowWebActivity.class);
			intent2.putExtra(ShowWebActivity.SHOW_URL, url_web2 + mAuth);
			startActivity(intent2);
		}
	}

	public void onBackClick(View v) {
		finish();
	}
	
	/**
	 * bcd 转成 string BCD码转为10进制串(阿拉伯数据)
	 * 
	 * @param bytes
	 *            BCD码
	 * @return 10进制串
	 */
	private String bcd2Str(byte[] bytes) {
		StringBuilder builder = new StringBuilder(bytes.length * 2);
		for (int i = 0; i < bytes.length; i++) {
			builder.append((byte) ((bytes[i] & 0xf0) >> 4));
			builder.append((byte) (bytes[i] & 0x0f));
		}
		return builder.toString().substring(0, 1).equals("0") ? builder
				.toString().substring(1) : builder.toString();
	}
}
