package com.uninew.bus.main;


import android.media.MediaPlayer;
import android.os.Handler;
import android.os.Message;
import android.util.Log;

import java.util.Arrays;

import com.ndk.led.JniLed;
import com.uninew.bus.BroadCastTool;
import com.uninew.bus.log.LogTool;
import com.uninew.common.ToastUtil;

public class ReadCardThread extends Thread{
	private static final String TAG = "ReadCardThread";
	private static final boolean D = true;
	//编码格式
	private static final String Code = "UTF-8";
	//时间间隔
	private int interval = 10*60*1000;
	// private static int setVehicleNumber=0;
	private long signTime;
	private long signOutTime;
	//广播发送类
	private BroadCastTool tool;
	private Handler mHandler;
	private MediaPlayer mMediaPlayer;
	private BusMainService service;

	public ReadCardThread(Handler mHandler, BusMainService service) {
		super();
		this.mHandler = mHandler;
		this.service = service;
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		int result = JniLed.LedInit();
		tool = new BroadCastTool(service);
		while (true) {
			try {
				Thread.sleep(100);
				byte[] data = JniLed.SendRc522Data();
				if(D)Log.v(TAG, Arrays.toString(data));
				RFIDDataHandle(data);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}

	/**
	 * RFID卡数据处理
	 * 
	 * @param data
	 */
	int state = 0;
	boolean isSet = true;
	private long unSinge;//记录签退账号的

	public void RFIDDataHandle(byte[] data) {
		isSet = true;
		long carID = 0;
		long num = 0;
		byte[] nameData = new byte[12];
		byte[] nameData2 = null;
		carID = byteToInt(data);// 卡ID
		num = byteToIntId(data);// 工号
		String name = "";// 姓名
		boolean checkData = checkData(carID, num);
		Message msg = new Message();
//		msg.what = WHAT_TOAST;
		if (checkData) {
			for (int i = 0; i < nameData.length - 1; i++) {
				if (data[i + 8] != 0) {
					nameData[i] = data[i + 8];
				} else {
					LogTool.logI(TAG, "新的数组:" + i);
					nameData2 = new byte[i];
					for (int j = 0; j < nameData2.length; j++) {
						nameData2[j] = nameData[j];
					}
					break;
				}
			}
			if(nameData2!=null){
				try {
					name = new String(nameData2, Code);
					byte[] bs = name.getBytes("GBK");
					name = new String(bs,"GBK");
				} catch (Exception e) {
					e.printStackTrace();
				}
			}		
//			ToastUtil.show(service, "name:"+name+",num:"+num+",carID:"+carID);
		} else {
			msg.obj = "信息读取失败,请再次刷卡";
			msg.what = 0;
//			mHandler.sendMessage(msg);
//			ToastUtils.show(service, "信息读取失败,请再次刷卡", 1);
			service.startSpeech("信息读取失败,请再次刷卡", 0);
			return;
		}
	}

			
	/**
	 * 向平台发送签到签退请求数据
	 * @param type 0:签到 1:签退	
	 * @param driverID 司机工号
	 */
	private void sendBroadCast(int type, String driverID) {
	
	}
	/**
	 * byte数组转short 低位
	 * 
	 * @return
	 */
	private long byteToInt(byte[] b) {
		// return (int) (b[3] & 0xff | (b[2]<<8)|(b[1]<<16)|(b[0]<<24));
		return (long) (b[0] & 0xFF) << 24 | (b[1] & 0xFF) << 16
				| (b[2] & 0xFF) << 8 | (b[3] & 0xFF);// 高位
	}

	private long byteToIntId(byte[] b) {
		// return (int) (b[3] & 0xff | (b[2]<<8)|(b[1]<<16)|(b[0]<<24));
		return (long) (b[4] & 0xFF) << 24 | (b[5] & 0xFF) << 16
				| (b[6] & 0xFF) << 8 | (b[7] & 0xFF);// 高位
	}
	/**
	 * 检查数据完整性
	 * 
	 * @param carID
	 * @param num
	 */
	private boolean checkData(long carID, long num) {
		boolean result = true;
		if (carID == 0 || num == 0) {
			result = false;
		}
		return result;
	}
	/**
	 * 补零
	 * @param num
	 * @param i
	 * @return
	 */
	private String setNum(long num,int i) {
		String a = String.valueOf(num);
		if (a.length()<=i) {
			int b = i-a.length();
			for (int j = 0; j < b; j++) {
				a = "0"+a;
			}
		}
		LogTool.logI(TAG, "工号:"+a);
		return a;
	}
	private void sendMessage(int what,String toast){
		Message message = new Message();
		message.what = what;
		message.obj = toast;
		mHandler.sendMessage(message);
	}
}
