package com.uninew.bus.work;

public interface IResultCallBack {
	
	void resultCallBack(boolean result);
}
