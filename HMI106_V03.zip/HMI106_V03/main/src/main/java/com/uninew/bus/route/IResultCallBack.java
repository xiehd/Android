package com.uninew.bus.route;

public interface IResultCallBack {
	
	/**
	 * 回调结果
	 * @param success true-成功，false-失败
	 */
	void resultCallBack(boolean success);
}
