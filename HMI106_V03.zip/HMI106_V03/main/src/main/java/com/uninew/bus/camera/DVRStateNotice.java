package com.uninew.bus.camera;

import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.Serializable;
import java.sql.Date;

import android.util.Log;

import com.uninew.net.common.ProtocolTool;

/**
 * DVR状态通知
 * @author jiami
 *
 */
public class DVRStateNotice implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = -3419600393446907039L;
	/** 时间*/
	private long time;
	/** 车牌*/
	private String license;
	/** 最大通道数*/
	private int maxNum;
	/**
	 * 0: ACC关;1:ACC开
	 */
	private int accState;
	/**
	 * 0:GPS未定位;1:定位
	 */
	private int gpsState;
	/**
	 * 0: 4G网络未联网;1:已联网
	 */
	private int netState;
	/**
	 * 0:硬盘正常;1:硬盘出错
	 */
	private int diskState;
	/**
	 * 0:摄像头未连接;1:摄像头正常
	 */
	private int cameraState;
	/**
	 * 0:录像异常;1:录像正常
	 */
	private int videoState;
	private byte[] timeData = new byte[6];
	private byte[] nameData = new byte[30];
	private byte[]data;
	public DVRStateNotice() {

	}
	public DVRStateNotice(byte[] data) {
		super();
		this.data = data;
		try {
			parseData();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	/**
	 * 数据解析
	 */
	private void parseData() throws Exception{
		ByteArrayInputStream bs = new ByteArrayInputStream(data);
		DataInputStream in = new DataInputStream(bs);
		in.read(timeData);
		String tt = "";
		for (byte b : timeData) {
			if (b < 0x0F) {
				tt += "0" + Integer.toHexString(b);
			} else {
				tt += Integer.toHexString(b);
			}
		}
		time = ProtocolTool.getTimeFromBCD12(tt);// 时间
		Log.d("DVR_TIME", new Date(time).toString());
		in.read(nameData);
		license = new String(nameData, "UTF-8").trim();//车牌
		maxNum = in.readInt();//最大通道数
		int state = in.readInt();//设备状态
		accState = ProtocolTool.getBinaryData(state, 1);
		gpsState = ProtocolTool.getBinaryData(state, 2);
		netState = ProtocolTool.getBinaryData(state, 3);
		diskState = ProtocolTool.getBinaryData(state, 4);
		int state2 = in.readInt();//视频状态
//		cameraState = ProtocolTool.getBinaryData(state2, 1);
//		videoState = ProtocolTool.getBinaryData(state2, 65536);
		cameraState=state2 & 0xFF;
		videoState=(state2 >> 16) & 0xFF;
	}
	@Override
	public String toString() {
		return "DVRStateNotice [time=" + time + ", license=" + license
				+ ", maxNum=" + maxNum + ", accState=" + accState
				+ ", gpsState=" + gpsState + ", netState=" + netState
				+ ", diskState=" + diskState + ", cameraState=" + cameraState
				+ ", videoState=" + videoState +"]";
	}
	public long getTime() {
		return time;
	}
	public void setTime(long time) {
		this.time = time;
	}
	public String getLicense() {
		return license;
	}
	public void setLicense(String license) {
		this.license = license;
	}
	public int getMaxNum() {
		return maxNum;
	}
	public void setMaxNum(int maxNum) {
		this.maxNum = maxNum;
	}
	public int getAccState() {
		return accState;
	}
	public void setAccState(int accState) {
		this.accState = accState;
	}
	public int getGpsState() {
		return gpsState;
	}
	public void setGpsState(int gpsState) {
		this.gpsState = gpsState;
	}
	public int getNetState() {
		return netState;
	}
	public void setNetState(int netState) {
		this.netState = netState;
	}
	public int getDiskState() {
		return diskState;
	}
	public void setDiskState(int diskState) {
		this.diskState = diskState;
	}
	public int getCameraState() {
		return cameraState;
	}
	public void setCameraState(int cameraState) {
		this.cameraState = cameraState;
	}
	public int getVideoState() {
		return videoState;
	}
	public void setVideoState(int videoState) {
		this.videoState = videoState;
	}
	public byte[] getTimeData() {
		return timeData;
	}
	public void setTimeData(byte[] timeData) {
		this.timeData = timeData;
	}
	public byte[] getNameData() {
		return nameData;
	}
	public void setNameData(byte[] nameData) {
		this.nameData = nameData;
	}
	public byte[] getData() {
		return data;
	}
	public void setData(byte[] data) {
		this.data = data;
	}
	
}
