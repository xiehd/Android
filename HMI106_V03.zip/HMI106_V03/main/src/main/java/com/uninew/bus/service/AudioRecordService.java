package com.uninew.bus.service;

import java.util.LinkedList;

import com.uninew.bus.channel.VoiceChannelControl;

import android.app.Service;
import android.content.Intent;
import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioRecord;
import android.media.AudioTrack;
import android.media.MediaRecorder.AudioSource;
import android.os.IBinder;
import android.util.Log;

public class AudioRecordService extends Service {

	private static final String TAG = "AndioRecordService";

	protected int m_in_buf_size;
	/**
	 * 录制音频对象
	 */
	private AudioRecord m_in_rec;
	/**
	 * 录入的字节数组
	 */
	private byte[] m_in_bytes;
	/**
	 * 存放录入字节数组的大小
	 */
	private LinkedList<byte[]> m_in_q;
	/**
	 * AudioTrack 播放缓冲大小
	 */
	private int m_out_buf_size;
	/**
	 * 播放音频对象
	 */
	private AudioTrack m_out_trk;
	/**
	 * 播放的字节数组
	 */
	private byte[] m_out_bytes;
	/**
	 * 录制音频线程
	 */
	private Thread record;
	/**
	 * 播放音频线程
	 */
	private Thread play;
	/**
	 * 让线程停止的标志
	 */
	private boolean flag = true;

	@Override
	public IBinder onBind(Intent intent) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void onCreate() {
		super.onCreate();
	}

	@Override
	public void onDestroy() {
		new Thread(new Runnable() {
			@Override
			public void run() {
				try {
					Thread.sleep(200);
					if (m_in_bytes.length > 0 && !m_in_q.isEmpty()) {
						m_in_bytes.clone();
						m_in_q.clone();
					}
					flag = false;
					m_in_rec.stop();
					m_in_rec.release();
					if (VoiceChannelControl.equipment_versions == 0) {
						m_out_trk.stop();
						m_out_trk.release();
						m_out_trk.flush();
						play.interrupt();
					}
					record.interrupt();
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		}).start();
		
		// Log.v(TAG, "onDestroy"+flag);
		super.onDestroy();
	}

	public int onStartCommand(Intent intent, int flags, int startId) {
		// Log.v(TAG, "onStartCommand");
		try {
			Thread.sleep(20);
			init();
		} catch (InterruptedException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		flag = true;
		record = new Thread(new recordSound(),"recordSound");
		play = new Thread(new playRecord(),"playRecord");
		// 启动录制线程
		record.start();
		if(VoiceChannelControl.equipment_versions == 0){
			try {
				Thread.sleep(100);
				play.start();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return START_STICKY;
	}

	private void init() {
		// AudioRecord 得到录制最小缓冲区的大小
		m_in_buf_size = AudioRecord.getMinBufferSize(44100, AudioFormat.CHANNEL_IN_MONO,
				AudioFormat.ENCODING_PCM_16BIT);
		// 实例化播放音频对象
		m_in_rec = new AudioRecord(AudioSource.DEFAULT, 44100, AudioFormat.CHANNEL_IN_MONO,
				AudioFormat.ENCODING_PCM_16BIT, (int) (m_in_buf_size * 2.21));
		
		// AudioTrack 得到播放最小缓冲区的大小
		m_out_buf_size = AudioTrack.getMinBufferSize(44100, AudioFormat.CHANNEL_OUT_MONO,
				AudioFormat.ENCODING_PCM_16BIT);
		
		// 播放对象
		m_out_trk = new AudioTrack(AudioManager.STREAM_MUSIC, 44100, AudioFormat.CHANNEL_OUT_MONO,
				AudioFormat.ENCODING_PCM_16BIT, (int) (m_out_buf_size), AudioTrack.MODE_STREAM);
	
		// 实例化一个字节数组，长度为最小缓冲区的长度
		m_in_bytes = new byte[(int) (m_in_buf_size * 2.21)];
		// 实例化一个链表，用来存放字节组数
		m_in_q = new LinkedList<byte[]>();
//		m_out_bytes = new byte[(int) (m_out_buf_size)];

	}

	/**
	 * 描述 :录音线程
	 * 
	 * @author rong
	 *
	 */
	class recordSound extends Thread {
		@Override
		public void run() {
			// Log.i(TAG, "........recordSound run()......");
			byte[] bytes_pkg;
			// 开始录音
			m_in_rec.startRecording();// 开始录制
			//线程异常退出，线程停止
			if(Thread.interrupted()){
				try {
					throw new InterruptedException();
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			while (flag) {
				m_out_buf_size = m_in_rec.read(m_in_bytes, 0, (int) (m_in_buf_size * 2.21));
				bytes_pkg = m_in_bytes.clone();
				// Log.i(TAG, "........recordSound bytes_pkg==" +
				// bytes_pkg.length);
				try {
					Thread.sleep(50);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				if (!m_in_q.isEmpty() && m_in_q.size() >= 2  ) {
					m_in_q.removeFirst();
				}
				m_in_q.add(bytes_pkg);
			}
		}

	}

	/**
	 * 播放线程
	 * 
	 * @author rong
	 *
	 */
	class playRecord extends Thread {
		@Override
		public void run() {
			// 实例化一个长度为播放最小缓冲大小的字节数组
			// 开始播放
			m_out_trk.play();
			//线程异常退出，线程停止
			if(Thread.interrupted()){
				try {
					throw new InterruptedException();
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			// Log.i(TAG, "........playRecord run()......");
			byte[] bytes_pkg = null;
			while (flag) {
				try {
					// m_out_bytes = m_in_q.getFirst();
					if (!m_in_q.isEmpty()) {
						bytes_pkg = m_in_q.getFirst();
					}
					if (bytes_pkg.length > 0)
						m_out_trk.write(bytes_pkg, 0, bytes_pkg.length);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
	}

}
