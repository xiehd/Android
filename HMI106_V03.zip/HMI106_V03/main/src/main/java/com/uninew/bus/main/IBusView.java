package com.uninew.bus.main;

/***********************************************************************
 * Module:  IBusView.java
 * Author:  Administrator
 * Purpose: Defines the Interface IBusView
 ***********************************************************************/

import java.util.*;

import android.content.Context;

/** @pdOid 3fd185c0-84d9-49f1-9c78-deaf17510659 */
public interface IBusView {
	
	/**
	 * 显示当前速度
	 * @param speed
	 * @pdOid 2af96ad8-5873-4c6b-9082-fccdb48c3299
	 */
	void showSpeed(int speed);

	/**
	 * 显示当前限速值
	 * @param limitSpeed
	 * @pdOid bd9e2baa-8764-496f-91b9-c25e7638ff0a
	 */
	void showLimitSpeed(int limitSpeed);

	/**
	 * 显示超速类型
	 * @param type
	 * @pdOid 35c9857a-ef2a-41f4-ac99-6169b98872a3
	 */
	void showOverSpeed(int type);
	
	/**
	 * 显示下一站文本
	 * @param txt
	 */
	void showNextOrEnd(String txt);
	
	/**
	 * 显示线路信息
	 * @param startStation
	 * @param endStation
	 * @param lineName
	 * @pdOid 4054a9eb-7d55-406b-9a0d-d1604ca6d6ca
	 */
	void showLineMsg(String startStation, String endStation, String lineName);

	/**
	 * 显示站点信息
	 * @param stations
	 * @pdOid 7a607a6f-8e64-40b7-8b95-2e73206bb313
	 */
	void showStations(List<String> stations);

	/**
	 * 显示当前站点
	 * @param id
	 * @param station
	 * @pdOid adc739ad-138b-49f9-af6d-37c6db52dc34
	 */
	void showCurrentStation(int id, String station);

	/**
	 * 显示下一站点
	 * @param id
	 * @param station
	 * @pdOid ffc7ed1d-5d4d-4a02-b7f7-34d1fc8cb4a3
	 */
	void showNextStation(int id, String station);
	
	/**
	 * 显示速度颜色
	 * @param txt
	 */
	void showSpeedColor(int color);

	/**
	 * 显示前后车辆
	 * @param location
	 * @pdOid 369f5b5a-ee4f-47fc-aede-b96ad4c09403
	 */
	void showNearByBusPosition(int before,int after);

	/**
	 * 显示上下行
	 * @param upDown 0-上行 1-下行
	 * @pdOid 915cb093-4997-48b8-849b-1d4762dbe8cb
	 */
	void showUpDown(int upDown);

	/**
	 * 显示报站模式
	 * @param style
	 * @pdOid 48488360-ded2-418a-a368-9c35aad68f5e
	 */
	void showReportStyle(boolean  isAuto);

	/**
	 * 显示运营状态
	 * @param isRun
	 * @pdOid d0a268b7-412e-4fa7-a412-b009b172c5b3
	 */
	void showRunState(boolean isRun);

	/**
	 * 显示签到状态
	 * @param isSigned
	 * @pdOid 980782bb-4e71-4d82-81c3-770dbcb79057
	 */
	void showSignState(boolean isSigned);

	/**
	 * 显示车牌
	 * @param licence
	 * @pdOid 6e8cd3ed-4bfe-4e87-afbc-0ebb329c4956
	 */
	void showLicensePlate(String license);

	/**
	 * 显示工号
	 * @param jobNumber
	 * @pdOid 0ae1788f-2709-41f2-b235-6e4bf141005a
	 */
	void showJobNumber(String jobNumber);

	/**
	 * 显示司机姓名
	 * @param name
	 * @pdOid 242e87bd-b03c-43a2-9ebd-a5750bbfa6bb
	 */
	void showDriverName(String name);
	
	 /** @param mContext
	    * @pdOid 6bbd8c9f-c39e-4a0f-8ffd-887c7d979919 */
	 void showSignView(boolean isSigned);

}