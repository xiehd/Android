package com.uninew.bus.report.overspeed;

import java.util.ArrayList;
import java.util.List;

import android.content.Intent;

import com.uninew.bus.constant.ActionDefine;
import com.uninew.bus.main.BusMainService;
import com.uninew.bus.report.ReportStationService;
import com.uninew.common.TimeTool;
import com.uninew.common.tts.TtsUtil;
import com.uninew.db.dh.Managers.DbWarnsManager;
import com.uninew.db.dh.dao.DangerWarn;

public class SpeedManager implements IOverSpeedJudgeListener{
	
	private static final String TAG="SpeedManager";
	private BusMainService mainService;
	public OverSpeedJudge mOverSpeedJudge;
	private DbWarnsManager mDbWarnsManager;
	public SpeedManager(BusMainService mainService) {
		super();
		this.mainService = mainService;
		mOverSpeedJudge=new OverSpeedJudge(this);
		mDbWarnsManager=new DbWarnsManager(mainService);
	}
	@Override
	public void overSpeed(int state, long time) {
		// TODO Auto-generated method stub
		overSpeedManager(state, time);
	}
	
	@Override
	public void preOverSpeed(int state, long time) {
		// TODO Auto-generated method stub
		preOverSpeedManager(state, time);
	}
	
	private void overSpeedManager(int state, long time) {
		// TODO Auto-generated method stub
		switch (state) {
		case DefineOverSpeed.State_Start:
			//超速开始
			mainService.setOverSpeed(0x02);
			//超速开始，写入数据库
			DangerWarn dager = new DangerWarn(1, TimeTool.dateTormat(new java.sql.Date(time))
					,ReportStationService.mGpsInfo.getLongitude(),ReportStationService.mGpsInfo.getLatitude(), "您已超速，请减速行驶！");
			List<DangerWarn> warns=new ArrayList<>();
			warns.add(dager);
			mDbWarnsManager.updateWarns(warns);
			//状态提示
//			AppUtils.messageRemind(mainService, R.drawable.message, "超速报警", "您已经超速，请减速行驶！！", null, 103);
			Intent intent = new Intent("Com.Uninew.AlarmOpen");
			mainService.sendBroadcast(intent);
			//上报平台
			Intent intent5 = new Intent(ActionDefine.SpeedAlarm);
			intent5.putExtra(ActionDefine.SpeedAlarm_Key, state);
			mainService.sendBroadcast(intent5);	
			break;
		case DefineOverSpeed.State_Persist:
			//超速持续，语音提示
			startSpeech("您已超速，请减速行驶！");
			break;
		case DefineOverSpeed.State_End:
			//超速结束
			mainService.setOverSpeed(0x00);
			//超速结束，超速图标关闭
			Intent intent3 = new Intent("Com.Uninew.AlarmClose");
			mainService.sendBroadcast(intent3);
			//上报平台
			Intent intent4 = new Intent(ActionDefine.SpeedAlarm);
			intent4.putExtra(ActionDefine.SpeedAlarm_Key, state);
			mainService.sendBroadcast(intent4);	
		break;
		default:
			break;
		}
	}
	
	private void preOverSpeedManager(int state, long time) {
		// TODO Auto-generated method stub
		switch (state) {
		case DefineOverSpeed.State_Start:
			//预超速开始
			startSpeech("您即将超速，请控制车速！");
			mainService.setOverSpeed(0x01);
			break;
		case DefineOverSpeed.State_Persist:
			//预超速持续
			startSpeech("您即将超速，请控制车速！");
			break;
		case DefineOverSpeed.State_End:
			//预超速结束
			mainService.setOverSpeed(0x00);
		break;
		default:
			break;
		}
	}
	
	/**
	 * 语音播报
	 * 
	 * @param message
	 */
	public void startSpeech(String message) {
		TtsUtil.getInstance(mainService).startSpeak(message,0);
	}
}
