package com.uninew.bus.report.overspeed;

public interface DefineOverSpeed {
	
	/**结束*/
	int State_End=0x00;
	/**开始*/
	int State_Start=0x01;
	/**持续*/
	int State_Persist=0x02;
}
