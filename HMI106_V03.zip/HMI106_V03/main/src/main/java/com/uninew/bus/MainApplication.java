package com.uninew.bus;

import java.util.ArrayList;

import android.app.Activity;
import android.app.Application;
import android.content.Intent;
import android.util.Log;

import com.iflytek.cloud.SpeechUtility;
import com.uninew.bus.camera.DVRStateNotice;
import com.uninew.bus.channel.VoiceChannelControl;
import com.uninew.bus.log.CrashHandler;
import com.uninew.common.SDCardUtils;
import com.uninew.common.action.DefineServiceAction;
import com.uninew.common.tts.TtsUtil;

public class MainApplication extends Application {
	private static final String TAG = "MainApplication";
	private static ArrayList<Activity> activities;
	private static MainApplication instance;
	public static DVRStateNotice dvrState;

	@Override
	public void onCreate() {
		// TODO Auto-generated method stub
		super.onCreate();
		Log.e("test", "----onCreate-----"+System.currentTimeMillis());
		startService();
		instance = this;
		// 全局异常捕获
		 CrashHandler crashHandler = CrashHandler.getInstance();
		 crashHandler.init(this);
		activities = new ArrayList<Activity>();
		getVersions();
		// /** 语音播报初始化 */
		SpeechUtility.createUtility(getApplicationContext(), "appid="
				+ getString(R.string.app_id));
		TtsUtil.getInstance(this).startSpeak("", 0x00);
	}
	/**
	 * 开启服务
	 */
	private void startService() {
		// TODO Auto-generated method stub
		Log.e(TAG, "fileService---------------"+System.currentTimeMillis());
		Intent fileService = new Intent(DefineServiceAction.Action_FileService);
		fileService.setPackage(DefineServiceAction.Pkg_Main);
		startService(fileService);
		Log.e(TAG, "mainService---------------"+System.currentTimeMillis());
		Intent mainService = new Intent(DefineServiceAction.Action_MainService);
		mainService.setPackage(DefineServiceAction.Pkg_Main);
		startService(mainService);
		Log.e(TAG, "mainService   end---------------"+System.currentTimeMillis());
	}
	
	


	// 单例模式中获取唯一的MyApplication实例
	public static MainApplication getInstance() {
		if (null == instance) {
			instance = new MainApplication();
		}
		return instance;
	}

	// 添加Activity到容器中
	public void addActivity(Activity activity) {
		activities.add(activity);
	}

	public void deleteActivity(Activity activity) {
		activities.remove(activity);
	}

	// finish
	public void exit() {
		for (Activity activity : activities) {
			activity.finish();
		}
		activities.clear();
		// 杀死该应用进程
		android.os.Process.killProcess(android.os.Process.myPid());
	}
	
	private void getVersions(){
		SDCardUtils sdUtils = new SDCardUtils(getApplicationContext());
		String version = sdUtils.getVersionName();
//		String s[] = version.split(".");
		if(version.startsWith("V10")){
			VoiceChannelControl.equipment_versions = 1;
			Log.d(TAG, "equipment_versions:V10");
		}else if(version.startsWith("V05")){
			VoiceChannelControl.equipment_versions = 0;
			Log.d(TAG, "equipment_versions:V05");
		}
	}
}
