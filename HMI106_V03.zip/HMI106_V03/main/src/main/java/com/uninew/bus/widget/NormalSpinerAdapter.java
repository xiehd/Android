package com.uninew.bus.widget;

import android.content.Context;

public class NormalSpinerAdapter extends AbstractSpinerAdapter<String>{

	public  NormalSpinerAdapter(Context context){
		super(context);
	}
}
