package com.uninew.bus.main;
/***********************************************************************
 * Module:  IBusPresenter.java
 * Author:  Administrator
 * Purpose: Defines the Interface IBusPresenter
 ***********************************************************************/

import android.content.Context;

/** @pdOid ce65b13b-353e-4c9e-89e9-a91ab567697f */
public interface IBusPresenter {
	/** 
	 * @pdOid 7773b87f-c580-44d4-bb0f-e5011a9063d4 */
	void initViews();
   /** 
    * @pdOid 7773b87f-c580-44d4-bb0f-e5011a9063d4 */
   void switchUpDown();
  /**
   * 签到页面显示请求
   */
   void signViewRequest();
   /**
    * 签到
    * @param jobNumber
    */
   void sign(String jobNumber);
   /**
    * 签退
    * @param jobNumber
    */
   void signOut(String jobNumber);
}