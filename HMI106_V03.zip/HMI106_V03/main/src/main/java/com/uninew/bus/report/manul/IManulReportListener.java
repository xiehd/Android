package com.uninew.bus.report.manul;

import com.uninew.file.dao.StationDao;

public interface IManulReportListener {
	
	/**
	 * 上下行切换
	 * @param nextOrLast 上一站还是下一站引起的切换
	 */
	public void SwitchUpDownForManul(int nextOrLast);
	
	/**
	 * 上下站调节
	 * @param stationType 站点类型 （0-起点站，1-中间站，2-倒数第二站，3-终点站）
	 * @param currentStation 当前站
	 * @param nextStation 下一站
	 */
	public void MoveToLastOrNext(int stationType,StationDao currentStation,StationDao nextStation);
	
	
	/**
	 * 进出站状态更新
	 * @param stationType 站点类型 （0-起点站，1-中间站，2-倒数第二站，3-终点站）
	 * @param inOutState 进出站状态（0-进站，1-到站，2-出站）
	 * @param currentStation 当前站
	 * @param nextStation 下一站
	 */
	public void InOutStationForManul(int stationType,int inOutState,StationDao currentStation,StationDao nextStation);
	
	
}
