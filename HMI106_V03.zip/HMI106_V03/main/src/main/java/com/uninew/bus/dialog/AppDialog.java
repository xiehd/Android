package com.uninew.bus.dialog;

import java.util.List;
import java.util.Map;

public class AppDialog {
	private short dialogType;
	private String text;
	private List<QuestionOption> answerList;
	private String MsgTitle;
	private Map<String ,String> driverData;
	public AppDialog(short dialogType, String text,
			List<QuestionOption> answerList, String msgTitle) {
		super();
		this.dialogType = dialogType;
		this.text = text;

		switch (dialogType) {
		case MsgID.ID_TEXT_MSG_ISSUED:
			MsgTitle=msgTitle;
			break;
		case MsgID.ID_ASKED_ISSUED:
			this.answerList = answerList;
			break;
		case MsgID.ID_INFORMATION_SERVICE:
			MsgTitle = msgTitle;
			break;
		case MsgID.ID_VEHICLE_CONTROL:
			break;
		case MsgID.ID_DRIVER_IDENTITY_INFORMATION_COLLECTION_SUBMITTED:
			MsgTitle = msgTitle;
			break;
		}
	}

	public short getDialogType() {
		return dialogType;
	}

	public void setDialogType(short dialogType) {
		this.dialogType = dialogType;
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

	public List<QuestionOption> getAnswerList() {
		return answerList;
	}

	public void setAnswerList(List<QuestionOption> answerList) {
		this.answerList = answerList;
	}

	public String getMsgTitle() {
		return MsgTitle;
	}

	public void setMsgTitle(String msgTitle) {
		MsgTitle = msgTitle;
	}

	public Map<String, String> getDriverData() {
		return driverData;
	}

	public void setDriverData(Map<String, String> driverData) {
		this.driverData = driverData;
	}
	
}