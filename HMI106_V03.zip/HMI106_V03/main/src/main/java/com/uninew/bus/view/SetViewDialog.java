package com.uninew.bus.view;

import com.uninew.bus.R;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;

public class SetViewDialog extends Dialog implements android.view.View.OnClickListener {

	private static final String TAG = "DispatchDialog";
	private LayoutInflater layoutInflater;
	private View view;
	private Button bt_0;
	private Button bt_1;
	private Button bt_2;
	private Button bt_3;
	private Button bt_4;
	private Button bt_5;
	private Button bt_6;
	private Button bt_7;
	private Button bt_01;
	private Button bt_23;
	private Button bt_45;
	private Button bt_67;
	private Button bt_0123;
	private Button bt_4567;
	private Button bt_01234567;

	/** 设置显示页面 type 4：四路 8: 八路 */
	private int type = 4;

	private DisplayMetrics d;
	private Window dialogWindow;
	private WindowManager.LayoutParams lp;
	private ClickListener clickListener;

	/** 设置显示页面 type 4：四路 8: 八路 */
	public SetViewDialog(Context context, int type) {
		super(context);
		this.type = type;
		layoutInflater = LayoutInflater.from(context);
		dialogWindow = getWindow();
		lp = dialogWindow.getAttributes();
		d = context.getResources().getDisplayMetrics(); // 获取屏幕宽、高用
	}

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		if (type == 8) {
			view = layoutInflater.inflate(R.layout.dailog_eight_route, null);
		} else {
			view = layoutInflater.inflate(R.layout.dailog_four_route, null);
		}
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(view);
		lp.gravity = Gravity.CENTER;
		lp.width = (int) (d.widthPixels * 0.8);// 高度设置为屏幕的0.8
		dialogWindow.setAttributes(lp);
		if (type == 8) {
			initEightView();
			initEightListener();
		} else {
			initFourView();
			initFourListener();
		}

	}

	/** 设置显示页面 type 4：四路 8: 八路 */
	public void setType(int type) {
		this.type = type;
	}

	/** 设置触发事件 **/
	public void setClickListener(ClickListener clickListener) {
		this.clickListener = clickListener;
	}

	/** 确定按钮的触发事件 **/
	public interface ClickListener {
		/**
		 * 按键返回数据
		 * 
		 * @param type
		 *            显示页面 0：四路 1: 八路
		 * @param namber
		 *            显示的视频号数 
		 *            0x0010:双画面 0-1 0x0023 ： 双画面 2-3 如此类推 
		 *            0x0123：四画面 0123 0x4567：四画面 4567 
		 *            四路四画面的全部 ： 0x0011  八路八画面的全部 ：0x0111
		 */
		public void onBackView(int type, int namber);
	}

	private void initFourView() {
		bt_0 = (Button) view.findViewById(R.id.bt_one_0);
		bt_1 = (Button) view.findViewById(R.id.bt_one_1);
		bt_2 = (Button) view.findViewById(R.id.bt_one_2);
		bt_3 = (Button) view.findViewById(R.id.bt_one_3);
		bt_01 = (Button) view.findViewById(R.id.bt_two_0and1);
		bt_23 = (Button) view.findViewById(R.id.bt_two_2and3);
		bt_0123 = (Button) view.findViewById(R.id.bt_four_all);
	}

	private void initEightView() {
		bt_0 = (Button) view.findViewById(R.id.bt_one_0);
		bt_1 = (Button) view.findViewById(R.id.bt_one_1);
		bt_2 = (Button) view.findViewById(R.id.bt_one_2);
		bt_3 = (Button) view.findViewById(R.id.bt_one_3);
		bt_4 = (Button) view.findViewById(R.id.bt_one_4);
		bt_5 = (Button) view.findViewById(R.id.bt_one_5);
		bt_6 = (Button) view.findViewById(R.id.bt_one_6);
		bt_7 = (Button) view.findViewById(R.id.bt_one_7);
		bt_01 = (Button) view.findViewById(R.id.bt_two_0and1);
		bt_23 = (Button) view.findViewById(R.id.bt_two_2and3);
		bt_45 = (Button) view.findViewById(R.id.bt_two_4and5);
		bt_67 = (Button) view.findViewById(R.id.bt_two_6and7);
		bt_0123 = (Button) view.findViewById(R.id.bt_four_0123);
		bt_4567 = (Button) view.findViewById(R.id.bt_four_4567);
		bt_01234567 = (Button) view.findViewById(R.id.bt_eight_all);
	}

	private void initFourListener() {
		bt_0.setOnClickListener(this);
		bt_1.setOnClickListener(this);
		bt_2.setOnClickListener(this);
		bt_3.setOnClickListener(this);
		bt_01.setOnClickListener(this);
		bt_23.setOnClickListener(this);
		bt_0123.setOnClickListener(this);
	}

	private void initEightListener() {
		bt_0.setOnClickListener(this);
		bt_1.setOnClickListener(this);
		bt_2.setOnClickListener(this);
		bt_3.setOnClickListener(this);
		bt_4.setOnClickListener(this);
		bt_5.setOnClickListener(this);
		bt_6.setOnClickListener(this);
		bt_7.setOnClickListener(this);
		bt_01.setOnClickListener(this);
		bt_23.setOnClickListener(this);
		bt_45.setOnClickListener(this);
		bt_67.setOnClickListener(this);
		bt_0123.setOnClickListener(this);
		bt_4567.setOnClickListener(this);
		bt_01234567.setOnClickListener(this);
	}

	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.bt_one_0:
			clickListener.onBackView(type, 0x0000);
			break;
		case R.id.bt_one_1:
			clickListener.onBackView(type, 0x0001);
			break;
		case R.id.bt_one_2:
			clickListener.onBackView(type, 0x0002);
			break;
		case R.id.bt_one_3:
			clickListener.onBackView(type, 0x0003);
			break;
		case R.id.bt_one_4:
			clickListener.onBackView(type, 0x0004);
			break;
		case R.id.bt_one_5:
			clickListener.onBackView(type, 0x0005);
			break;
		case R.id.bt_one_6:
			clickListener.onBackView(type, 0x0006);
			break;
		case R.id.bt_one_7:
			clickListener.onBackView(type, 0x0007);
			break;
		case R.id.bt_two_0and1:
			clickListener.onBackView(type, 0x0010);
			break;

		case R.id.bt_two_2and3:
			clickListener.onBackView(type, 0x0023);
			break;
		case R.id.bt_two_4and5:
			clickListener.onBackView(type, 0x0045);
			break;
		case R.id.bt_two_6and7:
			clickListener.onBackView(type, 0x0067);
			break;

		case R.id.bt_four_0123:
			clickListener.onBackView(type, 0x0123);
			break;
		case R.id.bt_four_4567:
			clickListener.onBackView(type, 0x4567);
			break;

		case R.id.bt_eight_all:
			clickListener.onBackView(type, 0x0111);
			break;
		case R.id.bt_four_all:
			clickListener.onBackView(type, 0x0011);
			break;
		default:
			break;
		}
	}

}
