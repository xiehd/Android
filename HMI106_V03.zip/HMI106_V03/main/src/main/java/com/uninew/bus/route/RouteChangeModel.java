package com.uninew.bus.route;

import java.util.ArrayList;
import java.util.List;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.util.Log;

import com.uninew.file.common.DefineFileAction;
import com.uninew.file.common.FileBroadCastTools;
import com.uninew.file.dao.RoutesDao;
import com.uninew.file.dao.RunRoutesDao;

public class RouteChangeModel implements IRouteChangePresenter{
	
	private boolean D=true;
	private static final String TAG="RouteChangeModel";
	private Context mContext;
	private FileBroadCastTools mFileBroadCastTools;
	private IRouteChangeListener mRouteChangeListener;
	private IResultCallBack mSwitchResultCallBack,mDelResultCallBack;

	public RouteChangeModel(Context mContext,
			IRouteChangeListener mRouteChangeListener) {
		super();
		this.mContext = mContext;
		this.mRouteChangeListener = mRouteChangeListener;
		mFileBroadCastTools=new FileBroadCastTools(mContext);
		init();
	}

	private void init() {
		// TODO Auto-generated method stub
		registerListener();
		//查询线路信息和运行信息
		queryRouteMsgs();
	}
	
	private void queryRouteMsgs() {
		// TODO Auto-generated method stub
		mFileBroadCastTools.sendFileSearch("",DefineFileAction.SourceId.RoutesMsg);
		mFileBroadCastTools.sendFileSearch("",DefineFileAction.SourceId.RunningMsg);
	}

	RouteReceiver mRouteReceiver;
	public void registerListener() {
		mRouteReceiver=new RouteReceiver();
		IntentFilter filter = new IntentFilter();
		filter.addAction(DefineFileAction.FileServerSearchResponse);
		filter.addAction(DefineFileAction.FileServerRouteSwitchResponse);
		filter.addAction(DefineFileAction.FileServerDeleteResponse);
		mContext.registerReceiver(mRouteReceiver, filter);
	}

	public void unRegisterListener() {
		if (mRouteReceiver!=null) {
			mContext.unregisterReceiver(mRouteReceiver);
		}
	}
	
	private class RouteReceiver extends BroadcastReceiver {

		@Override
		public void onReceive(Context context, Intent intent) {
			String action = intent.getAction();
			switch (action) {
			case DefineFileAction.FileServerSearchResponse:
				fileSearchResponse(intent);
				break;
			case DefineFileAction.FileServerRouteSwitchResponse:
				routeSwitch(intent);
				break;
			case DefineFileAction.FileServerDeleteResponse:
				routeDelete(intent);
				break;
			default:
				break;
			}
		}

		private void routeDelete(Intent intent) {
			// TODO Auto-generated method stub
			int result = intent.getIntExtra(DefineFileAction.Delete_Key.DeleteResult, 0);
			if(result == DefineFileAction.Result.Result_Success){
				//切换成功
				mDelResultCallBack.resultCallBack(true);
			}else{
				mDelResultCallBack.resultCallBack(false);
			}
		}

		private void routeSwitch(Intent intent) {
			// TODO Auto-generated method stub
			int result = intent.getIntExtra(DefineFileAction.RouteSwitch_Key.SwitchResult, 0);
			if(result == DefineFileAction.Result.Result_Success){
				//切换成功
				mSwitchResultCallBack.resultCallBack(true);
			}else{
				mSwitchResultCallBack.resultCallBack(false);
			}
		}

		@SuppressWarnings("unchecked")
		public void fileSearchResponse(Intent intent) {
			// TODO Auto-generated method stub
			int result = intent.getIntExtra(DefineFileAction.Search_Key.SearchResult, 0);
			int sourceId = intent.getIntExtra(DefineFileAction.Search_Key.SourceId, 0);
			if(D)Log.d(TAG, "fileSearchResponse,result:"+result+",sourceId:"+sourceId);
			if (result == DefineFileAction.Result.Result_Success) {
				switch (sourceId) {
				case DefineFileAction.SourceId.RoutesMsg:
					List<RoutesDao> routes = (ArrayList<RoutesDao>) intent
					.getSerializableExtra(DefineFileAction.Search_Key.Value);
					mRouteChangeListener.setRoutes(routes);
					break;
				case DefineFileAction.SourceId.RunningMsg:
					List<RunRoutesDao> runRoutes=(ArrayList<RunRoutesDao>) intent
							.getSerializableExtra(DefineFileAction.Search_Key.Value);
					if(runRoutes!=null && runRoutes.size()==1){
						mRouteChangeListener.setCurrentRoutes(runRoutes.get(0));
					}
					break;
				default:
					break;
				}
			}
		}
	}
	
	@Override
	public void switchRoute(RoutesDao route,IResultCallBack resultCallBack) {
		// TODO Auto-generated method stub
		mSwitchResultCallBack=resultCallBack;
		RunRoutesDao runRoute=new RunRoutesDao();
		runRoute.setLineMark(route.getLineMark());
		runRoute.setEndStation(route.getEndStation());
		runRoute.setEndTime(route.getEndTime());
		runRoute.setRouteName(route.getRouteName());
		runRoute.setStartStation(route.getStartStation());
		runRoute.setStartTime(route.getStartTime());
		mFileBroadCastTools.sendRouteSwitch(runRoute);
	}


	@Override
	public void deleteRoute(RoutesDao route,IResultCallBack resultCallBack) {
		// TODO Auto-generated method stub
		mDelResultCallBack=resultCallBack;
		mFileBroadCastTools.sendFileDelete(route);
	}

	@Override
	public void exitManage() {
		// TODO Auto-generated method stub
		unRegisterListener();
	}

}
