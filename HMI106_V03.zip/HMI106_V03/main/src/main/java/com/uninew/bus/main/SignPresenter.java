package com.uninew.bus.main;
/***********************************************************************
 * Module:  SignPresenter.java
 * Author:  Administrator
 * Purpose: Defines the Class SignPresenter
 ***********************************************************************/

import java.util.*;

public class SignPresenter{
	
}