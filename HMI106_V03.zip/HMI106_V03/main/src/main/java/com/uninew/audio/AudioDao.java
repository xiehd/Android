package com.uninew.audio;

import java.util.ArrayList;
import java.util.Arrays;

/**
 * 声音管理对象类
 * 
 * @author Administrator
 * 
 */
public class AudioDao {
	/** 声音ID */
	private int SrcID;
	/** 声音优先级 */
	private int level;
	/** 是否外部播放 */
	private boolean isOut;
	/** 请求播报通道 */
	private int channel;
	/** 声道对应的播放器 */
	private PlayerManager pManager;
	private ArrayList<String> paths;

	public AudioDao() {
		super();
	}

	public AudioDao(int srcID, int level, boolean isOut,int channel,
			PlayerManager pManager, ArrayList<String> paths) {
		super();
		SrcID = srcID;
		this.level = level;
		this.isOut = isOut;
		this.pManager = pManager;
		this.paths = paths;
		this.channel=channel;
	}

	public int getSrcID() {
		return SrcID;
	}

	public void setSrcID(int srcID) {
		SrcID = srcID;
	}

	public int getLevel() {
		return level;
	}

	public void setLevel(int level) {
		this.level = level;
	}

	public boolean isOut() {
		return isOut;
	}

	public void setOut(boolean isOut) {
		this.isOut = isOut;
	}

	public PlayerManager getpManager() {
		return pManager;
	}

	public void setpManager(PlayerManager pManager) {
		this.pManager = pManager;
	}

	public ArrayList<String> getPaths() {
		return paths;
	}

	public void setPaths(ArrayList<String> paths) {
		this.paths = paths;
	}

	
	public int getChannel() {
		return channel;
	}

	public void setChannel(int channel) {
		this.channel = channel;
	}

	@Override
	public String toString() {
		return "AudioDao [SrcID=" + SrcID + ", level=" + level + ", isOut="
				+ isOut + ", pManager=" + pManager+ ", channel=" + channel+"]";
	}

}
