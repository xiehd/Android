package com.uninew.bus.report.tools;

import java.util.ArrayList;
import java.util.List;

import android.content.Context;
import android.util.Log;

import com.uninew.bus.R;
import com.uninew.file.dao.StationDao;

public class RouteTools {
	private static final String TAG="RouteTools";
	private Context mContext;
	
	public RouteTools(Context mContext) {
		super();
		this.mContext = mContext;
	}
	
	/**
	 * 根据路线名称确定上下行
	 * @return 0-上行 ，1-下行
	 */
	public int getUpDownSideNum(String routeName){
		if (routeName==null || "".equals(routeName)) {
			Log.e(TAG, "routeName is Null !!!");
			return -1;
		}
		if (routeName.endsWith(mContext.getResources().getString(R.string.file_up))) {
			return 0;
		}else if (routeName.endsWith(mContext.getResources().getString(R.string.file_down))) {
			return 1;
		}
		return -1;
	}
	
	/**
	 * 获取路线缩略名称
	 * @param routeName 完整路线名称  如9路上行-》9路
	 * @return
	 */
	public String getSimpleRouteName(String routeName){
		//上行
		String simple = null;
		if (routeName.endsWith(mContext.getResources().getString(R.string.file_up))) {
			simple=routeName.replace(mContext.getResources().getString(R.string.file_up), "").trim();
		}else if(routeName.endsWith(mContext.getResources().getString(R.string.file_down))){
			simple=routeName.replace(mContext.getResources().getString(R.string.file_down), "").trim();
		}
		return simple;
	}
	
	/**
	 * 获取路线缩略名称(去掉路字)
	 * @param routeName 完整路线名称  如9路上行-》9路
	 * @return
	 */
	public String getNumberRouteName(String routeName){
		String simple=getSimpleRouteName(routeName);
		if (simple==null) {
			return null;
		}
		String name = null;
		if (simple.contains(mContext.getResources().getString(R.string.file_road))) {
//			name=routeName.substring(0, routeName.length()-3);
			name=simple.replace(mContext.getResources().getString(R.string.file_road), "").trim();
		}else{
//			name=routeName.substring(0, routeName.length()-2);
			name=simple.replace(mContext.getResources().getString(R.string.file_road), "").trim();
		}
		return name;
	}
	
	/**
	 * 获取当前站点的后续站点集合
	 * @param currentStation 当前站点
	 * @param stations 路线站点
	 */
	public List<StationDao> getRestStations(StationDao currentStation,List<StationDao> stations){
		boolean start = false;
		List<StationDao> list=new ArrayList<StationDao>();
		for (int i = 0; i < stations.size(); i++) {
			if (currentStation.getStationId()==stations.get(i).getStationId()) {
				start=true;
			}
			if (start) {
				list.add(stations.get(i));
			}
		}
		return list;
	}	
	
}
