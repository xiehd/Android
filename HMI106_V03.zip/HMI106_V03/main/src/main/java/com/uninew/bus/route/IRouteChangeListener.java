package com.uninew.bus.route;

import java.util.List;

import com.uninew.file.dao.RoutesDao;
import com.uninew.file.dao.RunRoutesDao;

public interface IRouteChangeListener {
	/**
	 * 显示线路信息
	 * @param routes
	 */
	public void setRoutes(List<RoutesDao> routes);
	
	/**
	 * 显示当前线路
	 * @param route
	 */
	public void setCurrentRoutes(RunRoutesDao route);
}
