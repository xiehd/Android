package com.uninew.bus.report.marker;

import java.util.LinkedList;
import java.util.List;

import android.util.Log;

import com.uninew.bus.report.tools.DistanceCalculate;
import com.uninew.bus.report.tools.MyQueue;
import com.uninew.file.dao.MarkerDao;
import com.uninew.location.DefineLocationAction;


public class MarkerRemind implements IMarkerRemind{

	private static boolean D=false;
	private static final String TAG="MarkerRemind";
	private boolean isRun=true;
	
	private IMarkerRemindListener markerRemindListener;
	public MarkerRemind(IMarkerRemindListener markerRemindListener) {
		super();
		this.markerRemindListener = markerRemindListener;
		init();
	}
	
	private void init() {
		// TODO Auto-generated method stub
		mQueue = new MyQueue(new LinkedList<Double>());
		State_Marker.setState(State_Marker.EXCEPTION_STATE);
		new Thread(MarkerRunnable).start();
	}
//----------------------以下为外部传入数据接口----------------------------------------------------
	@Override
	public void onOffMarker(int state) {
		// TODO Auto-generated method stub
		if (state==0) {
			isRun=false;
		}else{
			isRun=true;
		}
	}

	@Override
	public void setGpsInfo(int positionState, double longitude,
			double latitude, float speed, int direction, long time) {
		// TODO Auto-generated method stub
		if (positionState == DefineLocationAction.Location_State_Positioned) {
			mLocationValid = true;
			// 已定位
			this.longitude = longitude;
			this.latitude = latitude;
			this.speed = speed;
		} else {
			mLocationValid = false;
		}
	}

	@Override
	public void setMarkers(List<MarkerDao> markers) {
		// TODO Auto-generated method stub
		if (markers==null || markers.size() < 1) {
			Log.e(TAG, "setMarkers,markers is null !!!");
			return;
		}
		this.markers=markers;
		if (markers.isEmpty()) {
			isRun=false;
		}else{
			isRun=true;
		}
		State_Marker.setState(State_Marker.EXCEPTION_STATE);
	}
//-------------------------以下为对外输出接口-------------------------------------------------------	
	/**
	 * 进出标记点信息
	 * @param inOutState 0-进，1-到，2-出
	 * @param marker 标记点
	 */
	public void inOutMarker(int inOutState,int markerType,MarkerDao marker){
		markerRemindListener.inOutMarker(inOutState,markerType, marker);
	}
//-------------------------以下算法相关-------------------------------------------------------------------
	private MyQueue mQueue;
	private MarkerDao nearestCd;
	private double distance;
	private byte exceptionCount = 0;
	private byte outExceptionCount = 0;
	// 轮询时间间隔(秒)
	private static int MarkerInterval = 1;
	// 趋势状态值 0-不变1-递增-1-递减
	private int trend;

	private boolean mLocationValid; 
	private double longitude;
	private double latitude;
	private float speed;
	
	private List<MarkerDao> markers;

	private Runnable MarkerRunnable = new Runnable() {

		@Override
		public void run() {	
			// TODO Auto-generated method stub
			try {
				while (true) {
//					if(D)Log.e(TAG, "isRun:"+isRun+",mLocationValid="+mLocationValid);
					if (isRun && mLocationValid) {
						managerMarker();
					}
					Thread.sleep(MarkerInterval * 1000);
				}
			} catch (Exception e) {
				// TODO: handle exception
			}
		}
	};

	private void managerMarker() {
		switch (State_Marker.getState()) {
		case IDLE:
			State_Marker.setState(State_Marker.EXCEPTION_STATE);
			break;
		case BEFORE_STATE:
			if (speed > 0) {
				State_Marker.setState(State_Marker.BEFORE_CALCULATE);
				managerMarker();
			}
			break;
		case BEFORE_CALCULATE:
			distance = getDistance();
			mQueue.add(distance);
			trend = mQueue.trendJudge();
			if(D)Log.d(TAG, "BEFORE_CALCULATE,distance=" + distance + ",trend="
					+ trend);
			if (trend == 1) {
				exceptionCount++;
				if(D)Log.e(TAG, "exceptionCount=" + exceptionCount);
				if (exceptionCount > 2) {
					exceptionCount = 0;
					State_Marker.setState(State_Marker.EXCEPTION_STATE);
					managerMarker();
				}
			} else {
				exceptionCount = 0;
				if (distance < nearestCd.getFrontMileage() && trend == -1) {
					mQueue.removeAll();
					State_Marker.setState(State_Marker.INTO_MANAGE);
					managerMarker();
				} else {
					// 自动循环
				}
			}
			break;
		case INTO_MANAGE:
			intoManage();
			State_Marker.setState(State_Marker.RECEIVE_STATE);
			break;
		case RECEIVE_STATE:
			if (speed > 0) {
				State_Marker.setState(State_Marker.RECEIVE_CALCULATE);
				managerMarker();
			}
			break;
		case RECEIVE_CALCULATE:
			distance = getDistance();
			if (distance > nearestCd.getFrontMileage()) {
				State_Marker.setState(State_Marker.AFTER_STATE);
				managerMarker();
			}
			break;
		case AFTER_STATE:
			if (speed > 0) {
				State_Marker.setState(State_Marker.AFTER_CALCULATE);
				managerMarker();
			}
			break;
		case AFTER_CALCULATE:
			distance = getDistance();
			if(D)Log.d(TAG, "AFTER_CALCULATE,distance=" + distance + ",trend=" + trend);
			mQueue.add(distance);
			trend = mQueue.trendJudge();
			if (trend == -1) {
				outExceptionCount++;
				if(D)Log.e(TAG, "outExceptionCount=" + outExceptionCount);
				if (outExceptionCount > 2) {
					outExceptionCount = 0;
					State_Marker.setState(State_Marker.EXCEPTION_STATE);
					managerMarker();
				}
			} else {
				outExceptionCount = 0;
				if (distance > nearestCd.getFrontMileage() && trend == 1) {
					mQueue.removeAll();
					State_Marker.setState(State_Marker.OUTTO_MANAGE);
					managerMarker();
				} else {
					// 自动循环
				}
			}
			break;
		case OUTTO_MANAGE:
			outManage();
			State_Marker.setState(State_Marker.EXCEPTION_STATE);
			break;
		case EXCEPTION_STATE:
			distance = getNearestDistance();
			if(distance > 0){
				mQueue.add(distance);
				if(D)Log.d(TAG, "EXCEPTION_STATE,distance=" + distance + ",trend="
						+ trend);
				if (distance > nearestCd.getFrontMileage()) {
					State_Marker.setState(State_Marker.BEFORE_STATE);
				} else {
					State_Marker.setState(State_Marker.RECEIVE_STATE);
				}
			}
			break;
		default:
			break;
		}
	}

	/**
	 * 获取最近距离以及最近点
	 * 
	 * @return
	 */
	private int getNearestDistance() {
		// TODO Auto-generated method stub
		List<MarkerDao> list;
		int dd = -1;
		list = DistanceCalculate.getSortedMarkers(latitude,
				longitude, markers);
		if (list != null && list.size() > 0) {
			nearestCd = list.get(0);
			dd = nearestCd.getDistance();
		}
		return dd;
	}

	/**
	 * 计算距离
	 * 
	 * @return
	 */
	private int getDistance() {
		if (nearestCd != null) {
			return DistanceCalculate.distance(longitude,
					latitude, nearestCd);
		}
		return 0;
	}

	
	private void intoManage() {
		// TODO Auto-generated method stub
		markerRemindListener.inOutMarker(DefineMarker.InOutState_In,nearestCd.getType(), nearestCd);
	}
	
	private void outManage() {
		// TODO Auto-generated method stub
		markerRemindListener.inOutMarker(DefineMarker.InOutState_Out,nearestCd.getType(), nearestCd);
	}
	private enum State_Marker {
		IDLE, // 空闲状态
		BEFORE_STATE, // 状态前
		BEFORE_CALCULATE, // 状态前计算
		RECEIVE_STATE, // 状态中
		RECEIVE_CALCULATE, // 状态中计算
		AFTER_STATE, // 状态后
		AFTER_CALCULATE, // 状态后计算
		EXCEPTION_STATE, // 异常状态
		INTO_MANAGE, // 进入处理
		OUTTO_MANAGE;// 离开处理

		private static State_Marker state = IDLE;

		public static State_Marker getState() {
			return state;
		}

		public static void setState(State_Marker state) {
			if(D)Log.d("State_Marker", String.format(
					"###### State Changed: %s ==> %s ######",
					State_Marker.state, state));
			State_Marker.state = state;
		}
	}
}
