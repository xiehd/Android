package com.uninew.bus.main;

import android.text.TextUtils;
import android.widget.Toast;

import com.uninew.common.tts.TtsUtil;


/***********************************************************************
 * Module:  SignModel.java
 * Author:  Administrator
 * Purpose: Defines the Class SignModel
 ***********************************************************************/


public class SignModel {
	
	private static final String TAG="";
	private boolean D=true;
	private BusMainService busMainService;
	
	public SignModel(BusMainService busMainService) {
		super();
		this.busMainService = busMainService;
	}
	
	/**
	 * 签到处理
	 * @param jobNumber
	 */
	public void sign(String jobNumber) {
		// TODO Auto-generated method stub
		if (true) {
			boolean result = judgeNum(jobNumber);
			if (!TextUtils.isEmpty(jobNumber)) {
				if (result) {
//					T_Sign t_Sign = new T_Sign(jobNumber, 0,
//							0.00, 0.00,
//							System.currentTimeMillis(), 0, 1);
//					try {
//						LogTool.logI(TAG,
//								"签到上发:"
//										+ new String(t_Sign.getData(),
//												"GBK"));
//					} catch (UnsupportedEncodingException e) {
//						// TODO Auto-generated catch block
//						e.printStackTrace();
//					}
//					tool.sendSign(t_Sign);
					Toast.makeText(busMainService, "签到中....",
							Toast.LENGTH_SHORT).show();
				} else {
					startSpeech("当天无此工号,请确认后再次签到");
				}
			}
		} else {
			startSpeech("当前未连接平台,请连接后重试。");
		}
	
	}
	
	/**
	 * 签退处理
	 * @param jobNumber
	 */
	public void signOut(String jobNumber) {
		// TODO Auto-generated method stub
		
	}
	
	/**
	 * 语音播报
	 * 
	 * @param message
	 */
	public void startSpeech(String message) {
		TtsUtil.getInstance(busMainService).startSpeak(message, 0);
	}
	
	/**
	 * 判断当天排班信息是否存在输入工号
	 * 
	 * @param jodNumber2
	 * @return 不存在:false 存在/当天排班信息:true
	 */
	public boolean judgeNum(String jodNumber2) {
		boolean result = false;
		return result;
	}
}